# Treino de Reflexo — Boxe 3D (V3, Godot)

Mesmo jogo da V2 (treinador prepara golpes/aberturas de guarda; o
paciente reage esquivando, abaixando ou golpeando no momento certo),
agora de volta ao 3D — a pedido, depois da V2 ter sido feita em pixel
art 2D. Todos os sistemas de jogo (dificuldade progressiva, pontuação,
combo, HUD, dados de sessão) continuam os mesmos; só a camada visual
mudou.

## Requisitos

- **Godot Engine 4.3** ou mais recente (versão "Standard"). Baixe em
  https://godotengine.org se ainda não tiver.

## Como abrir o projeto

1. No Gerenciador de Projetos do Godot, clique em **"Importar"**.
2. Navegue até a pasta `TreinoDeReflexo3D` e selecione o arquivo
   `project.godot`.
3. Clique em **"Importar e Editar"**.
4. Pressione **F5** (ou o botão ▶️) para rodar o jogo.

> **Sobre os ângulos das poses 3D:** eu não tenho o editor do Godot
> disponível neste ambiente para ver o resultado renderizado e ajustar
> visualmente. Os valores de rotação de cada pose (guarda, esquiva,
> soco, etc.) em `scripts/BoxerRig3D.gd` — dicionário `POSES` — são uma
> primeira aproximação razoável, pensada pra fazer sentido
> anatomicamente, mas é bem provável que você queira afinar alguns
> ângulos depois de ver rodando. É só mexer nos números ali, nenhuma
> outra parte do código precisa mudar.

## O que é esta V3 (comparada à V2, em pixel art)

- **Visual**: personagens 3D simples (cápsulas, esferas, caixas —
  torso, cabeça, pernas e braços com pivô no ombro), num ginásio/ringue
  também em primitivas 3D (piso, parede, cordas, postes, saco de
  pancadas), com iluminação (luz direcional + luz de destaque
  colorida) e névoa leve de profundidade.
- **Primeira pessoa**: a câmera fica na altura dos olhos do paciente,
  de frente para o treinador — você vê as próprias luvas (duas esferas
  simples) na parte de baixo da tela, como num jogo em primeira
  pessoa de verdade. O treinador é o único personagem com corpo
  visível, e agora tem olhos/sobrancelhas simples (`BoxerRig3D.gd`)
  só pra deixar óbvio visualmente que ele está de frente pra você —
  sem isso, era uma esfera simétrica sem "lado da frente" perceptível.
- **Sinal gráfico na tela (sem palavras)**: assim que o treinador
  começa a se preparar, aparece um ícone grande no centro da tela
  dizendo o que fazer — uma seta dupla azul pra esquiva/abaixar, uma
  luva laranja com rastro de movimento pra soco — em vez de texto.
  Fica meio apagado durante a preparação e com a cor cheia (+ um
  pulso) no instante em que a janela de reação abre. Ver
  `scripts/SignIcon.gd` (desenha tudo por código, sem imagem
  nenhuma) e a tela de **Tutorial** no menu, que mostra a legenda de
  cada sinal.
- **Tutorial**: o antigo "Como Jogar" virou uma tela de tutorial com
  a legenda visual de cada sinal (ícone + explicação), além dos
  controles de teclado/câmera — pra aprender o significado de cada
  sinal antes de começar o treino de verdade.
- **Animação por pose (tween), não por sprite**: os movimentos do
  treinador (guarda, preparação, golpe) são poses-alvo para as quais o
  corpo se move suavemente — ver `scripts/BoxerRig3D.gd`, função
  `go_to_pose()`. Os do paciente (esquiva, abaixar, soco) são
  movimentos de câmera/luva em primeira pessoa — ver as funções
  `_patient_*` em `Main.gd`.
- **Efeitos adaptados pro 3D**: partículas de impacto (`GPUParticles3D`),
  tremor de câmera (em vez de tremor de tela 2D) e flash continuam
  como popup 2D por cima da cena (`ACERTO!` / `ESQUIVA!` / `ERRO!` /
  `MUITO BOM!`), pra garantir texto sempre nítido.

**O que NÃO mudou** (a lógica do jogo é a mesma da V2, só trocou a
casca visual): `GameManager.gd` (pontuação/combo/precisão/reação),
`Trainer.gd` (dificuldade progressiva por tempo + geração de
desafios), `InputHandler.gd` (teclado), `CameraInput.gd` (webcam),
`AudioManager.gd` (sons), `SessionData.gd` (dados de sessão para
fisioterapia).

## Personagens 3D — feitos 100% por código

Nenhum arquivo 3D externo é usado. Os dois personagens são montados
com primitivas (esferas, cápsulas, cilindros) e têm articulações de
verdade:

- **Treinador** (`scripts/BoxerRig3D.gd`): fisiculturista — ombros e
  dorsais largos, peitoral, abdômen em gomos, trapézio, pescoço
  grosso, bíceps/tríceps, antebraços grossos, coxas e panturrilhas.
  Ombro + cotovelo em cada braço; quadril + joelho + tornozelo em cada
  perna (os joelhos dobram sozinhos quando o corpo desce, pés ficam
  no chão). Vida procedural: gingado de boxeador parado na guarda,
  respiração no peito, piscada, sobrancelha que franze (bravo /
  preparando golpe) e sobe (apanhando). O bote do soco agora vai
  PRA FRENTE, na direção do jogador.
- **Braços do jogador** (`scripts/PlayerArms3D.gd`): presos na
  câmera, com ombro + cotovelo + punho, luvas azuis com punho branco,
  polegar, atadura e veia no antebraço. Animações: entrada levantando
  a guarda, jab (esquerda) e direto (direita) com giro de punho e de
  tronco, esquiva lateral e abaixada cobrindo o rosto, tranco ao
  levar golpe, soquinho no ar ao comemorar, e respiração/balanço
  contínuo das luvas.

## Animações de luta

| Situação | Jogador (seus braços + câmera) | Treinador |
|---|---|---|
| Soco esquerda / direita | jab / direto com giro de punho e de tronco | apanha (esquerda/direita), fica tonto |
| Esquiva esquerda / direita | braços cobrem o rosto, corpo desvia | erra o soco e desequilibra |
| **Defesa alta** (↓ / S) | guarda sobe na frente do rosto e toma o tranco | soco bate nas luvas e quica; ele balança a cabeça |
| Erro | braços levam tranco, tela treme | fica bravo e avança |
| **Fim da luta — vitória** (precisão ≥ `WIN_PRECISION`, 60%) | gancho final → contagem → braços pro alto | cai de costas nocauteado, olhos fechados |
| **Fim da luta — derrota** | braços voam, câmera cai no chão, tela escurece | direto fulminante, depois comemora |

A luta dura sempre 1:30; o nocaute é o final dela.
Pra mudar o critério de vitória, ajuste `WIN_PRECISION` no topo de
`scripts/Main.gd`. Som opcional da contagem do juiz:
`assets/sounds/count.ogg`.

## Cenário do ginásio

O cenário foi refeito do zero (piso, teto com treliças e luzes tipo
fluorescente, paredes de tijolo, janelas mostrando a rua, pôsteres,
ringue decorativo com cordas/postes/escadinha, sacos de pancada
pendurados e bancos de musculação), tudo montado por primitivas +
texturas geradas por código em `tools/gen_textures.py` (nenhuma
imagem/foto real usada — os pôsteres são design gráfico original,
sem nenhuma marca ou personagem protegido por direitos autorais).

Isso não muda absolutamente nada da jogabilidade — a posição do
treinador, da câmera e das luvas continuam exatamente as mesmas de
antes; só o espaço ao redor ficou mais rico. As posições dos móveis/
ringue/sacos de pancada foram calculadas a partir do campo de visão
da câmera, mas eu não tenho como renderizar e conferir de verdade —
se algo (principalmente o ringue, que é o maior elemento) aparecer
fora de vista ou meio cortado, mexa nas constantes `RING_CENTER` e
nas posições passadas para `_build_bench()`/`_build_punching_bag()`
em `Main.gd` (`_build_world()`) até encaixar.

Pra regenerar/editar as texturas: `pip install pillow` e rode
`tools/gen_textures.py` — ele salva tudo em `assets/textures/`.

## Controles

No menu, escolha o modo antes de começar:

**⌨ Teclado** (sempre funciona)
- **← / A** — esquivar para a esquerda
- **→ / D** — esquivar para a direita
- **↓ / S** — defesa alta
- **Z** — soco com a esquerda
- **X** — soco com a direita
- **Esc** — pausar/continuar

**📷 Câmera** (experimental — leia a seção abaixo antes de usar)
- **Posição:** rosto no meio da imagem, mãos na guarda aparecendo,
  1 a 1,5 m da câmera, luz boa. A prévia no canto mostra guias.
- **Soco:** soque pra frente com a mão daquele lado.
- **Esquiva:** incline cabeça e tronco pro lado pedido.
- **Defesa alta:** suba as duas mãos juntas na frente do nariz.
- Os lados são sempre do **seu** ponto de vista. Se saírem trocados,
  aperte **M** durante o jogo.
- A prévia mostra o gesto que a câmera entendeu ("vi: SOCO ESQUERDA").
- No modo câmera, um gesto diferente do pedido é ignorado (não conta
  erro); só deixar o tempo acabar conta.
- Se o Godot não conseguir ler a câmera, o jogo detecta isso sozinho
  (em até ~2,5s) e volta para o teclado automaticamente, sem travar.

## Como o desafio funciona

- O treinador **ataca de um lado** → o paciente deve **esquivar para
  o lado oposto**.
- O treinador solta um **golpe alto na guarda** → o paciente faz a
  **defesa alta**.
- O treinador **abre a guarda de um lado** → o paciente deve
  **golpear aquele lado** (contra-ataque).

Cada desafio tem uma preparação visível (telegraph — o braço do
treinador recua e se prepara, **e um sinal gráfico aparece no centro
da tela** mostrando o que vai ser preciso fazer) e depois uma janela
de reação (o sinal fica com a cor cheia + um pulso). Responder errado
ou não responder a tempo conta como erro. A pontuação premia respostas
rápidas e corretas em sequência (combo). Sessão sempre dura 1:30,
com dificuldade subindo automaticamente com o tempo (fácil → médio →
difícil). A tela de **Tutorial**, no menu, mostra o que cada sinal
significa antes de você começar.

## Sobre o controle por câmera — leia isto primeiro

Usa a API nativa do Godot (`CameraServer` / `CameraFeed` /
`CameraTexture`) e detecta os gestos por **diferença entre quadros**
(onde e como a imagem mudou) — não é reconhecimento de esqueleto. Os
detalhes estão no topo de `scripts/CameraInput.gd`. Resumo:

- **Esquiva:** o topo da cabeça se mexe e o centro do movimento anda
  pro lado. O detector acompanha a posição da cabeça em relação ao
  centro, então **voltar pro meio não conta** como esquiva pro outro
  lado.
- **Soco:** movimento forte e largo em **um lado só** (a faixa do meio
  é ignorada, porque o punho cruza o centro vindo pra câmera), com a
  cabeça parada.
- **Defesa alta:** as **duas** mãos sobem juntas pro rosto, com a
  cabeça parada. Abaixar a guarda depois não conta de novo.
- Depois de cada gesto, espera o corpo parar antes de ler o próximo.

O algoritmo foi calibrado num simulador (jogador virtual com cabeça,
tronco e luvas, ruído de câmera e variação de brilho): parado por 20 s
→ nenhuma detecção falsa; 8 partidas aleatórias → 96% dos gestos
certos e nenhum lado trocado. Os limites (constantes no topo do
`CameraInput.gd`) podem ser ajustados depois de testar de verdade.

**Plataformas:** depende do suporte a câmera da sua versão do Godot.
Se nenhuma câmera for encontrada ou nenhuma imagem chegar em ~2,5 s,
o jogo volta sozinho pro teclado.

## Estrutura do projeto

```
TreinoDeReflexo3D/
├── project.godot          -> configuração do projeto e autoloads
├── scenes/
│   └── Main.tscn              -> cena principal (mínima; tudo é montado por código)
├── scripts/
│   ├── Main.gd                 -> monta o mundo 3D + HUD, controla o loop do jogo
│   ├── GameManager.gd          -> autoload: pontuação, combo, precisão, tempos de reação, resumo da sessão
│   ├── Trainer.gd               -> autoload: fases de dificuldade (por tempo) e geração de desafios/combos
│   ├── InputHandler.gd          -> autoload: leitura de teclado
│   ├── CameraInput.gd           -> autoload: câmera (webcam) + detecção de soco/esquiva/defesa alta
│   ├── CameraGuide.gd           -> guias desenhadas por cima da prévia da câmera
│   ├── AudioManager.gd          -> autoload: toca sons (com fallback silencioso)
│   ├── BoxerRig3D.gd            -> treinador fisiculturista 3D articulado: poses via tween + vida procedural
│   ├── PlayerArms3D.gd          -> braços do jogador (1ª pessoa) articulados e animados
│   ├── SignIcon.gd              -> ícone gráfico (seta/luva) desenhado por código para cada sinal na tela
│   └── SessionData.gd           -> estrutura de dados de uma sessão (para futuro histórico/relatórios)
└── assets/
    ├── sounds/                  -> onde colocar .ogg/.wav dos sons (veja LEIA-ME.txt)
    └── models/                  -> (vazio — personagens são feitos por código)
```

## Por que a cena é montada por código em vez de em arquivos `.tscn`?

Este projeto é montado num ambiente sem o editor do Godot disponível
para testar visualmente, e escrever tudo em GDScript reduz bastante o
risco de erro de sintaxe em `.tscn` complexos "no escuro". Funciona
igual — abra e rode o projeto normalmente. Recomendo abrir uma vez no
editor do Godot e rodar (F5) antes de qualquer outra alteração, pra
confirmar que está tudo redondo no seu ambiente, e para ajustar os
ângulos das poses em `BoxerRig3D.gd` com feedback visual de verdade.

## Como estender

- **Ajustar dificuldade**: todos os números (intervalo entre ataques,
  tempo de preparação, janela de reação, chance de combo) estão
  juntos no topo de `scripts/Trainer.gd`, em `PHASES`.
- **Ajustar poses/animações**: tudo em `scripts/BoxerRig3D.gd`,
  dicionário `POSES` — cada pose é só um conjunto de rotações
  (ombros, cabeça) e deslocamentos (corpo). Rode o jogo, veja o
  resultado, ajuste os números.
- **Ajustar os braços do jogador**: `scripts/PlayerArms3D.gd`,
  dicionário `POSES` (ombro/cotovelo/punho de cada pose) e
  `SHOULDER_POS` (posição em relação à câmera).
- **Novos tipos de desafio**: adicione o identificador em
  `Trainer.CHALLENGE_RESPONSE` (tipo -> resposta esperada) e as poses
  `<tipo>_wind` / `<tipo>_strike` correspondentes em `BoxerRig3D.POSES`.
- **Novos sons**: coloque arquivos `.ogg`/`.wav` em `assets/sounds/`
  com os nomes indicados em `assets/sounds/LEIA-ME.txt`.
- **Histórico de sessões / relatórios para fisioterapia**: use
  `SessionData.gd` como base — os comentários no arquivo têm
  sugestões concretas de como salvar e comparar sessões.


## FBF - FisioBoxFight: nova interface, boneco e movimentos (atualização)

**Interface (HUD)** — reorganizada a partir dos desenhos:
- **Cronômetro** grande no centro do topo; pausa no canto superior direito.
- **Indicadores laterais** (`scripts/ActionIndicator.gd`): à esquerda a luva
  VERMELHA (SOCO ESQ. e DEFESA ESQ.), à direita a luva AZUL (SOCO DIR. e
  DEFESA DIR.). Cada um é um círculo translúcido: *pulsa* quando o treinador
  está preparando aquela ação, fica com anel dourado forte na hora de agir,
  vira ✓ verde ao acertar e vermelho ao errar. Um brilho amarelo rápido
  mostra que a câmera/teclado *reconheceu* aquele movimento.
- **Boneco do jogador** (`scripts/PlayerAvatar.gd`) no centro-baixo, de
  frente pra tela como um espelho, com o indicador **AGACHAR** ao lado.
  Ele reaproveita o corpo do `BoxerRig3D` (em azul), dentro de um
  SubViewport com mundo 3D próprio e fundo transparente. O treinador
  continua no centro do ringue.
- **Informações da partida** (pontos, combo, precisão) numa faixa fina
  embaixo. A prévia da câmera nativa ficou pequena e translúcida no canto.
- O sinal grande do centro foi escondido (tapava o personagem); os
  indicadores laterais fazem esse papel. O nó continua existindo.

**Movimentos** (todos pela câmera, sem botão): soco esquerdo, soco direito,
defesa esquerda/direita (a esquiva lateral já existente, inclinar o tronco),
e **agachar** (reativado no detector Python; entra como a resposta "duck").
A defesa alta (duas mãos no rosto) continua valendo como "duck".

**Animações do boneco**: soco = braço recua e estica pra frente com o corpo
avançando; defesa = guarda fecha e sobe no rosto + corpo inclina/desliza
pro lado; agachar = corpo desce (joelhos dobram). Poses novas
`avatar_block` e `avatar_duck` em `BoxerRig3D.POSES`.

**O que NÃO foi alterado**: `GameManager.gd` (pontuação/combo/precisão),
`Trainer.gd`, cronômetro/duração (1:30), `CameraInput.gd`, toda a
detecção de socos e esquivas do `movimentos.py`.

**Ajustes rápidos**: cores esquerda/direita em `Main.gd`
(`HAND_LEFT_COLOR`/`HAND_RIGHT_COLOR`) e `PlayerAvatar.gd`; tamanho do
boneco nos `offset_*` do `avatar` em `_build_hud()`; limiares do
agachamento no topo do `movimentos.py` (`DUCK_*`) — o painel de números da
janela da câmera agora mostra `AGACHAR=OK/nao (escala, joelho)`.


### Ajuste V2 da interface (indicadores e cores)
- Indicadores **maiores** (círculo de 150 px, rótulo em fonte 20) e **piscando**:
  piscam devagar (~3x/s) quando o treinador está preparando aquela ação e
  rápido (~6,5x/s, crescendo e com anel dourado) na hora de agir. Parados,
  ficam visíveis mas mais fracos. Constantes `BLINK_*` em `ActionIndicator.gd`.
- **Desenhos refeitos** (`SignIcon.gd`): SOCO = luva com raios de impacto e
  rastro; DEFESA = bonequinho inclinado + seta pro lado; AGACHAR =
  bonequinho agachado + setas pra baixo; GUARDA ALTA = luvas no rosto.
- **Cores**: luva ESQUERDA vermelha e DIREITA azul no boneco do centro, nos
  braços em primeira pessoa (`PlayerArms3D.gd`), nos indicadores, na prévia
  da câmera do Godot (`CameraGuide.gd`) e nos alvos da janela da câmera
  Python (`COR_LUVA_ESQ` / `COR_LUVA_DIR` em `movimentos.py`).


### Novo menu (intro)
- **Cena**: o menu mostra o ringue com o treinador de frente, olhando e
  apontando a luva pro jogador (pose `menu_point` em `BoxerRig3D.gd`, com um
  "cutucar" contínuo). A câmera faz uma pequena aproximação ao abrir.
- **Opções à esquerda**, em botões vermelhos estilo gibi: COMEÇAR TREINO,
  CONTROLE (teclado / câmera / câmera Python), CONFIGURAÇÕES e TUTORIAL.
- **Configurações**: SOM (controle de volume 0–100%) e DIFICULDADE (Fácil /
  Normal / Difícil). Ficam salvas em `user://fbf_config.cfg`.
- **Dificuldade** (`Trainer.gd`, `DIFFICULTY_SCALE`): multiplica o aviso, a
  janela de reação, o intervalo e a frequência dos golpes. **Normal = os
  números originais**, então o jogo continua igual se você não mexer.
- Gameplay, HUD, pontuação, cronômetro e detecção da câmera **não foram
  alterados** nesta etapa.


### Visual profissional (cenário e modelos)
- **Cenário** (`scripts/GymDecor.gd`, só acrescenta peças): estofado escuro
  com friso vermelho nas paredes, letreiro dourado "FBF - FisioBoxFight" no
  fundo, faixas de LED (vermelha à esquerda, azul à direita, branca no fundo)
  com luz suave, relógio de parede, luvas vermelha e azul penduradas, espelho,
  tapete de treino, rack de halteres, anilhas, kettlebells, caixas pliométricas,
  power rack com barra e spots de luz no ringue e no treinador. Ambiente com
  brilho (glow), sombras de contato (SSAO) e menos névoa.
- **Modelos** (`BoxerRig3D.gd`, `_build_pro_details`): calção com faixa dourada,
  listras laterais, barra na perna e emblema FBF; botas com sola branca e
  cadarços; braçadeiras; pele com luz de contorno. O boneco do jogador ganhou
  protetor de cabeça na cor do corpo (`headgear = true`).


### Logo e créditos
- Logo em `assets/textures/logo_fbf.png` (fundo transparente).
- **Abertura** ao iniciar: logo + "by FisioSense / From Next-FIAP" com fade;
  qualquer tecla ou clique pula. Textos em `CREDIT_LINE_1/2` no `Main.gd`.
- **Menu**: logo no lugar do título, com os créditos logo abaixo.
- **Cenário**: o letreiro da parede do fundo agora mostra a logo + nome + créditos.
- Se a imagem faltar, tudo cai de volta para o título em texto.


### Relatório do treino
- No fim de cada treino é gerado um mini relatório: resumo (pontuação,
  precisão, acertos/erros, reação média/melhor, combo, fase), desempenho por
  movimento (soco esq./dir., defesa esq./dir., defesa alta/agachar),
  precisão em 3 blocos de 30 s (mostra cansaço), comparação com o treino
  anterior e **recomendações** baseadas em regras simples (simetria
  esquerda/direita, fadiga, reação, segurança).
- Abre pelo botão **Ver Relatório do Treino** na tela de resultados.
- Salva um `.txt` por treino em `user://reports/` (botão "Abrir pasta dos
  relatórios") e um histórico em `user://fbf_history.json`.
- As recomendações são orientações gerais e **não são diagnóstico**; o texto
  do relatório diz isso. Limiares no `_report_recommendations()` do `Main.gd`.


### Cenários (inspirados na variedade de arenas dos jogos de luta — 100% originais)
Escolha em **Menu → CENÁRIO** (tela com 6 cartões: miniatura, nome, descrição e botão). A
escolha fica salva. O treinador e a câmera do jogo NÃO mudam entre cenários — só o que está
ao redor —, então a detecção de movimentos e o gameplay são idênticos.

| Cenário | Destaques |
|---|---|
| Academia | o ringue original (agora agrupado em `GymRoot`) |
| Cidade à noite | rua molhada com reflexos (SSR), prédios com janelas acesas, letreiros de neon que piscam, carros, postes, torcida na calçada, vapor de bueiro |
| Dojô japonês | salão de madeira com portas shoji, porta aberta pro jardim (cerejeiras, torii, lanternas de pedra, montanhas), lanternas de papel piscando, raios de sol, pétalas caindo |
| Arena de campeonato | arquibancadas com torcida (MultiMesh) fazendo a "ola", holofotes varrendo, telão com **placar ao vivo**, LED que muda de cor, logo no chão |
| Praia tropical | mar com ondas por shader, espuma na beira, palmeiras balançando, cabana, guarda-sóis, rede de vôlei, gaivotas e nuvens |
| Fábrica abandonada | aço e tubulações, máquinas com engrenagens girando, esteira, janelas quebradas com luz azul, giroflex vermelho, lâmpadas piscando, poeira e faíscas |

Código em `scripts/scenarios/` (`ScenarioBase.gd` + um script por cenário +
`ScenarioPreview.gd` das miniaturas). Extras: pulso de luz do cenário a cada golpe certo
(vermelho = esquerda, azul = direita) e anúncio "NOME DA ARENA / VAI!" ao começar o treino.


### Tela final (relatório final) — refeita
A antiga tela de resultados quebrava (rótulos com quebra de linha e valores sobrepostos).
Agora é uma tela em rolagem que se ajusta a qualquer tamanho de janela:
- cabeçalho com logo, resultado (vitória/nocaute), data, arena, modo e dificuldade, e a
  **NOTA** (S/A/B/C/D + estrelas: 60% precisão, 25% reação, 15% combo);
- cartões: pontuação e precisão (contagem animada), reação média/melhor, combo, fase;
- gráficos (`scripts/ReportCharts.gd`): desempenho por movimento, precisão a cada 15 s e
  equilíbrio esquerda × direita (vermelho × azul);
- recomendações e orientações + aviso de que não é diagnóstico; confete na vitória;
- botões: Tentar Novamente, Relatório Detalhado (texto completo), Abrir Pasta dos Relatórios, Menu.


### Cenário secreto: SÃO PAULO — A CIDADE DO CAOS (código de resgate)
- Menu → **RESGATAR CÓDIGO** → digite `lipe 67` (aceita "LIPE67", "lipe-67"...). Isso
  desbloqueia (e já seleciona) a arena. O desbloqueio fica salvo (`user://fbf_config.cfg`,
  seção `unlocks`). Sem o código, o cartão aparece como "??? BLOQUEADO" na tela de arenas.
  Novos códigos: acrescente em `REDEEM_CODES` no `Main.gd`.
- Cenário (`scripts/scenarios/ScenarioSaoPaulo.gd`): Ponte Estaiada com mastro em X, cabos e
  LEDs que mudam de cor; Rio Tietê "orgânico" com pato de borracha, sofá, pneu e cone
  boiando (e cheirinho verde); congestionamento gigante (carros andando e parando,
  táxis, um carro que não sai do lugar e um com "VOLTAMOS EM 5 MINUTOS"); ônibus lotado com
  letreiro que muda; motoboys "FBF EXPRESS"; grafite gigante do FBF; postes com fios
  embolados e tênis pendurado; semáforo; banca, lanchonete, vendedor ambulante, ponto de
  ônibus; placas engraçadas; outdoor "PACIÊNCIA 500mg"; pedestres; skyline com caixas-d'água.
- **Cachorro caramelo** (de coroa, dono da arena): senta e olha a luta, passeia atrás dos
  lutadores, deita e ronca. Raramente aparece em lugar inesperado (teto da banca) e acena.
- **Eventos aleatórios** (só visuais, sempre no fundo): buzinaço, ônibus buzinando, placa
  bugando ("ERRO 404: TRÂNSITO NÃO ENCONTRADO"), helicóptero "AO VIVO: TRÂNSITO" e o caramelo.
- **Treinador com fantasia** (`BoxerRig3D.set_costume("brasil")`, só nesta arena): camisa
  amarela com gola verde e "67", calção azul, luvas verdes, boné amarelo/verde, óculos
  Juliet dourados e munhequeiras. Outras arenas voltam ao visual normal.
- Não altera detecção de movimentos nem gameplay; o cenário só mexe no que está ao redor.


### Modo ALEATÓRIO + 5 mapas "zoeira do Brasil"
- Tela de arenas: o primeiro cartão é **ALEATÓRIO** — sorteia uma arena liberada (diferente da atual) a
  cada partida (inclusive em "Tentar Novamente"). A escolha "aleatório" fica salva. O nome da arena
  sorteada aparece no anúncio "NOME DA ARENA / VAI!" e no relatório final. A tela agora rola (13 cartões).
- Novas arenas (todas em `scripts/scenarios/`, sem código de desbloqueio):
  - **Laje do Churrasco** (`ScenarioLaje`): tio da churrasqueira, paredão pulsando, piscina de plástico com
    flamingo, varal, bandeirinhas, caixa-d'água, vergalhão de obra eterna, pipa e gato.
  - **Arraiá do Caos** (`ScenarioArraia`): festa junina à noite — fogueira, barracas, quadrilha, sanfoneiro,
    balões, igrejinha, cadeia de R$5, fogos.
  - **Praia da Farofa** (`ScenarioFarofa`): praia lotada, futevôlei, queijo coalho, mate, polvilho, tiozão
    vermelho de sol, calçadão de ondas, gaivota ladrona.
  - **Estádio de Várzea** (`ScenarioVarzea`): luta no círculo central, trave torta, rede furada, torcida no
    alambrado, pelada ao fundo, vaca no campo e cachorro que rouba a bola.
  - **BR do Buraco** (`ScenarioBuraco`): rodovia esburacada (veículos pulam nas crateras), caminhão de
    melancia, "PONTE CAIU - SIGA EM FRENTE", posto pirata, vacas, tapa-buraco "em breve".
- Cada uma tem eventos aleatórios só visuais (fogos, buzinas, "MUUU", etc.). Gameplay e detecção
  de movimentos não foram alterados. Helpers novos em `ScenarioBase.gd` (`_person`, `_bunting`,
  `_plaque`, `_toast`, `_burst`).


### Código `lipe 67` agora libera 6 arenas
As 5 arenas "zoeira" (Laje, Arraiá, Praia da Farofa, Várzea, BR do Buraco) também são secretas e
saem junto com o São Paulo ao resgatar `lipe 67`. Antes do código elas aparecem como "??? BLOQUEADO"
e ficam fora do sorteio do modo Aleatório. Para outro código liberar arenas, use uma lista em `REDEEM_CODES`.


### Retrato do jogador e defesa alta
- O boneco que representa o jogador agora fica no **canto superior esquerdo**, numa moldura dourada
  com o rótulo "VOCÊ" (`_build_hud()` em `Main.gd`, variável `portrait`).
- **Defesa alta** agora é defesa alta: as duas luvas sobem no rosto e o queixo abaixa, com leve recuo
  do tronco (`PlayerAvatar._guard_up()`), **sem abaixar o corpo**. O **agachar** (câmera Python) continua
  sendo uma animação à parte, com o corpo descendo (`PlayerAvatar._duck()`). Os dois seguem valendo como
  a mesma resposta "duck" pro jogo — só a animação do boneco mudou (o rótulo cru vem de
  `CameraInputUDP.last_label`). No teclado, ↓/S = defesa alta.


### Mais difícil, sessão maior e combos de ataques
- **Sessão de 2:00** (`GameManager.SESSION_DURATION_SEC = 120`; antes 1:30). Fases: Fácil até 30 s, Médio até 1:15, Difícil no resto.
  O relatório usa blocos de 15 s e divide o treino em terços (0-40, 40-80, 80-120 s) automaticamente.
- **Um pouco mais difícil** (`Trainer.PHASES`): aviso (telegraph) e janela de reação ~15% menores e golpes mais seguidos.
  A dificuldade do menu (Fácil/Normal/Difícil) continua multiplicando esses números.
- **Combos de ataques**: de vez em quando o treinador solta 2 a 4 golpes seguidos (Fácil 2; Médio 2-3; Difícil 3-4).
  Aparece "COMBO DE ATAQUES!" (só defesas), "CONTRA-ATAQUE!" (só socos) ou "COMBO MISTO!" com o progresso (1/3...).
  Acertou todos: **COMBO PERFEITO! +bônus** (25 pts × golpes × fase). Errou algum: "COMBO QUEBRADO" (os acertos contam normal).
  No máximo um combo a cada 12 s e nunca antes dos 10 s (`COMBO_COOLDOWN_SEC`, `COMBO_FIRST_AT`, `combo_chance` em `Trainer.gd`).
  O relatório mostra combos totais e perfeitos.


### Segredo: minijogo "67" (easter egg) + conquista
**Escondido:** não aparece em nenhum botão do menu. A palavra secreta é **`pesca`**.
- **Descobrir (3 caminhos):** (a) digitar `pesca` com o teclado no menu; (b) clicar **5 vezes no logo do FBF**
  (ele estremece e o som sobe a cada clique) — abre um prompt escondido ("psiu... sussurre a palavra"); (c) usar
  `pesca` em RESGATAR CÓDIGO. Há uma dica enigmática no Tutorial.
- **Animação de desbloqueio** (`_secret_unlock_sequence()` em `Main.gd`): a tela escurece com um rumor grave, mensagem
  misteriosa digitada letra a letra, glitch, o **67** despenca com impacto (tremor, flash, anel de choque, "boom") e
  "MINIJOGO SECRETO DESBLOQUEADO". O desbloqueio é salvo em `user://fbf_config.cfg` (seção `secrets`).
- **Depois de desbloqueado:** os mesmos 5 cliques no logo (ou digitar `pesca`) entram direto no minijogo.
- **Minijogo** (`scripts/Minigame67.gd`, tela própria "minigame67", independente do jogo de fisioterapia): contador gigante
  de 0 a 67, estilo fliperama synthwave (grade em perspectiva, sol, scanlines, estrelas, 6 e 7 flutuando), botão grande
  "APERTE!" (ou ESPAÇO/ENTER/clique no número), peixe que pula a cada aperto, número que "soca" a tela, frases engraçadas por
  marco, festa a cada 10, tempo e recorde, **REINICIAR** e **VOLTAR AO FBF**. No 67: tela de vitória com confete, fogos e
  "VOCÊ É O ESCOLHIDO DO 67".
- **Sons** (`scripts/SynthSfx.gd`): efeitos sintetizados por código (não precisa de arquivos de áudio) e respeitam o volume do menu.
- **Conquista "O escolhido do 67":** ao chegar ao 67 pela primeira vez (aviso na tela + registro salvo). Lista em
  RESGATAR CÓDIGO → CONQUISTAS ("???" enquanto não obtida).
- Não mexe em câmera, golpes, cronômetro, pontuação, cenários nem no menu principal.


### Desempenho (anti-lag): Configurações → GRÁFICOS
- Novo ajuste **BAIXA / MÉDIA / ALTA** (padrão: MÉDIA; fica salvo). Não muda o jogo, só o custo de renderização:
  - **Média**: resolução 3D 90%, sem SSAO e sem reflexos (SSR), sombras só do sol (1 cascata) e só nas peças grandes.
  - **Baixa**: resolução 3D 70%, sem brilho (glow), sem nenhuma sombra, metade das partículas.
  - **Alta**: tudo como antes.
- **F3** mostra/esconde o contador de FPS (canto inferior direito) pra comparar.
- Implementação: `_apply_quality()`, `_tune_environment()` e `_tune_scene()` no `Main.gd` (os valores originais ficam em
  metadados, então voltar pra ALTA restaura tudo).


### Se o Godot estiver lento na sua máquina (mesmo com outros projetos ok)
Este projeto é 3D com vários cenários e usa o renderizador padrão **Forward+** (Vulkan), mais pesado que o de projetos 2D/simples.
1. Aperte **F3** dentro do jogo: aparece o FPS, o **nome da placa de vídeo** e o **método de renderização**. Se for uma
   Intel/AMD integrada em vez da sua placa dedicada, force o Godot a usar a dedicada (Windows → Configurações → Sistema →
   Tela → Elementos gráficos → adicionar o Godot → Alto desempenho).
2. Rodando pelo editor, desmarque **Debug → Embed Game on Next Play** (jogo embutido no editor costuma ficar mais lento) e
   rode o jogo em janela separada.
3. Teste sem o editor: **Projeto → Exportar** (Windows Desktop, sem "Exportar com depuração") e abra o .exe — a versão
   release é bem mais rápida que a de depuração.
4. Se nada resolver: **Projeto → Configurações do projeto → Renderização → Renderer → Compatibilidade** (reinicia o editor).
   Roda em praticamente qualquer PC; perde só SSAO/reflexos (que já ficam desligados em MÉDIA/BAIXA).
5. Na primeira execução o jogo já começa em gráficos BAIXA se detectar placa de vídeo integrada/fraca.


### Limpar o cache do Godot
Use o `LIMPAR_CACHE_GODOT.bat` (na mesma pasta do `JOGAR.bat`, com o Godot fechado): opção 1 = cache do projeto
(`.godot` + `.import`), 2 = também o cache global (shaders), 3 = **reset total** do Godot (faz antes uma cópia dos saves na
Área de Trabalho). Os saves do FBF (desbloqueios, recordes, relatórios) ficam em `%APPDATA%\Godot\app_userdata\FBF - FisioBoxFight`.


### Renderizador: agora Compatibilidade (OpenGL)
O Vulkan não estava disponível no PC de teste ("Cannot find a compatible Vulkan installable client driver" — driver de vídeo
sem Vulkan), então o projeto agora usa o renderizador **GL Compatibility** (`project.godot` → `[rendering]`), que não depende de
Vulkan e é mais leve em placas integradas. SSAO/reflexos (SSR) não existem nesse modo (já ficavam desligados em MÉDIA/BAIXA).
Para voltar ao Forward+ (placa com driver Vulkan bom): Projeto → Configurações do projeto → Renderização → Renderer →
Forward+ e reinicie o editor.


### Ajuste: o 67 só desbloqueia pelo código
O minijogo secreto agora só se desbloqueia (e só se acessa depois) digitando **`pesca`** em **RESGATAR CÓDIGO**. Foram removidos os
caminhos alternativos (digitar no menu e os 5 cliques no logo). Depois de desbloqueado, digitar `pesca` de novo no mesmo campo entra
direto no minijogo.


### Desbloqueios por código NÃO ficam salvos
A cada vez que o jogo é fechado, os códigos resetam: as arenas secretas (`lipe 67`) e o minijogo 67 (`pesca`) voltam a ficar bloqueados e o código
precisa ser digitado de novo em RESGATAR CÓDIGO. Continuam salvos: volume, dificuldade, gráficos, controle/arena escolhidos (não-secretos), recorde
do minijogo, conquistas e relatórios. Para voltar a salvar os desbloqueios, regrave `unlocked`/`unlocked67` em `_save_settings()` e releia em `_load_settings()`.


### Minijogo 67 com a câmera: a "balança" do meme
- No minijogo secreto 67, **mexa as mãos como uma balança**: uma mão sobe e a outra desce. Cada vez que o lado que está em cima
  **troca**, conta **+1**. Dá pra chegar ao 67 sem tocar em nada (o botão e o ESPAÇO continuam valendo).
- Precisa do detector Python + ponte rodando (o `JOGAR.bat` abre os dois). Ao abrir o minijogo, o jogo liga sozinho a escuta da câmera
  (porta 5555). No topo aparece **"CÂMERA ATIVA"** quando o detector está mandando dados; senão, **"aguardando o detector"**.
- Na tela há uma balança desenhada (prato esquerdo vermelho, direito azul) que acompanha as suas mãos.
- Como funciona: o `movimentos.py` calcula qual pulso está mais alto (diferença ÷ largura dos ombros > `BALANCA_LIMIAR` = 0,35),
  confirma por 2 frames e escreve `BALANCA:ESQ|DIR|NEUTRO` no log; a `tools/ponte_jogo.py` manda `BALANCA ESQ|DIR|NEUTRO` por UDP;
  o `CameraInputUDP.gd` emite `balanca_changed` e o `Minigame67.gd` conta as trocas (intervalo mínimo de 130 ms).
  Nada disso mexe nos movimentos do jogo principal (só lê os pontos do corpo).
- Se contar demais/de menos: ajuste `BALANCA_LIMIAR` no `movimentos.py` (maior = exige mãos mais afastadas).


### Balança mais rápida + garoto do 67
- **Contagem rápida:** o detector agora usa **histerese** (`BALANCA_LIMIAR` = 0,15): o lado só troca quando a outra mão passa do outro lado,
  a troca vale **na hora** (sem esperar 2 frames) e não existe mais "neutro" no meio. O minijogo conta trocas a cada ≥ 60 ms (antes 130).
  Atualize também o `movimentos.py` (é ele que decide o lado).
- **O garoto do 67:** no lado direito da tela do minijogo há um garoto de desenho (original, feito por código — não usa foto nenhuma) fazendo o gesto:
  mãos abertas com o 6 e o 7, subindo e descendo como balança, olhos arregalados e sorrisão. Pela câmera ele copia as suas mãos; pelo botão/ESPAÇO
  ele troca de mão a cada contagem; na vitória ele pula (`_draw_kid()` em `Minigame67.gd`).


### Minijogo 67 em 30 segundos + menus melhores + botão de voltar
- **Minijogo 67 (30 s):** não precisa mais chegar ao 67. O relógio de 30 s começa no **primeiro movimento** e vale fazer o **máximo**.
  A barra mostra o tempo restante (últimos 5 s: relógio vermelho e "tick"). Passou do **67**? Festa especial + a conquista "O escolhido do 67" e a
  rodada continua até acabar o tempo. No fim: nota (DEDO DE MANTEIGA → ... → O ESCOLHIDO DO 67 → LENDA), trocas por segundo e **recorde** (maior pontuação,
  salvo). Detalhes em `Minigame67.gd` (`DURATION`, `SPECIAL`, `_rank()`).
- **Menus:** painel translúcido com borda dourada e rolagem atrás das opções, títulos de página com linha dourada, botões que crescem e fazem "tick" ao passar
  o mouse, fade ao trocar de página e dica "ESC: voltar • F3: FPS".
- **Voltar pra página anterior em tudo:** as páginas do menu (Controle, Configurações, Resgatar código → Conquistas) guardam o histórico e o "◀ VOLTAR" volta
  **pra de onde você veio**; Tutorial, Arenas e Relatório ganharam um **"◀ VOLTAR" fixo** no canto superior esquerdo; o Relatório volta pros resultados;
  o minijogo tem VOLTAR AO FBF. A tecla **ESC** também volta (nas telas de resultado, vai pro menu).


### Correção: tela do minijogo 67 colada à esquerda
O tremor da tela mudava a `position` do contêiner a cada frame; com o tamanho ainda "velho" (0) isso travava o tamanho e deixava tudo colado à esquerda.
Agora o tremor mexe nos *offsets* (o tamanho nunca muda) e o minijogo refaz o encaixe em tela cheia sempre que aparece (`_refit()`).


### Botão "ABRIR CÂMERA" (abre o detector Python sozinho)
CONTROLE → **ABRIR CÂMERA AGORA** abre o detector e a ponte escondidos (OS.create_process com pythonw/pyw/python
ou os .exe compilados) e clicar de novo fecha. Status ao vivo (ativa / abrindo / sem sinal), opção **abrir sozinha ao
iniciar** (modo salvo em `fbf_config.cfg`) e chip **CÂMERA ATIVA** no HUD (clicável). Código: `_find_camera_dir()`,
`_spawn_python()`, `_garantir_camera_python()`, `_start_camera()`, `_update_camera_ui()` em `Main.gd`.
Antes o lançador existia mas nunca era chamado e só procurava `CameraSensores` perto do .exe (por isso não abria no
editor); agora procura também dentro do projeto e uma pasta acima.


### "Não consigo ver a câmera" (corrigido)
A janela da webcam (OpenCV) abria **escondida atrás do jogo** (o Windows impede um processo em segundo plano de roubar o
foco; a posição antiga era x=10,y=700). Agora o jogo abre o detector pelo `CameraSensores/tools/lancador.py`, que define
`FBF_JANELA_NA_FRENTE=1`: a janela vai pro **canto inferior direito** da área de trabalho e fica **sempre na frente**
(`_fixar_janela_na_frente()` em `movimentos.py`). O lançador também grava a saída em `CameraSensores/camera_erro.log` e mostra
uma **janela de aviso** se o detector falhar (antes o erro sumia, porque o `pythonw` não tem console). O status no menu também
mostra "não achei o Python / a pasta CameraSensores" quando é o caso.


### Câmera dentro do jogo (no lugar do bonequinho)
O detector manda cada quadro (JPEG 320 px, ~15 fps) por UDP para a porta **5556** (`--video-porta`, `_enviar_frame_ao_jogo()` em
`movimentos.py`); `CameraInputUDP.gd` recebe (`_poll_video()`, `video_texture`) e o HUD mostra a webcam em um `TextureRect`
(208×117, 16:9) dentro da moldura do canto superior esquerdo, com "● AO VIVO", escondendo o bonequinho enquanto o vídeo chega (se
parar, o bonequinho volta). `--sem-janela` esconde a janela separada do OpenCV. Opções em CONTROLE: **CÂMERA NO CANTO DO JOGO** e
**JANELA SEPARADA DA CÂMERA** (salvas em `fbf_config.cfg`, seção `camera`). O quadro tem 16:9 e a moldura cabe antes da coluna de
indicadores da esquerda (até y≈158).


### Diagnóstico da câmera no jogo (pasta antiga / sem vídeo)
O menu e o chip do HUD agora dizem **qual `CameraSensores` está sendo usado** ("Pasta usada: ...") e avisam quando ele é ANTIGO
(o `movimentos.py` não tem `--video-porta`) ou quando a câmera está ativa mas o vídeo não chega (porta 5556). O jogo prefere o
`movimentos.py` novo ao `movimentos.exe` antigo. Novo ajuste: **TAMANHO DA CÂMERA NO JOGO** (pequeno 208×117 / médio 256×144 —
o médio vai até y≈164, logo acima da coluna de indicadores da esquerda).
