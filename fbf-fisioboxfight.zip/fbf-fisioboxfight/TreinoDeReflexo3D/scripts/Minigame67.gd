# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name Minigame67
# MINIGAME SECRETO "67" (easter egg do FBF). Totalmente independente do jogo
# de fisioterapia: tela própria, estilo fliperama synthwave. Aperte o botão
# (ou ESPAÇO / ENTER / clique no número) pra contar de 0 até 67. Cada aperto
# faz o número "socar" a tela, um peixe pula (o segredo é "pesca"!), sons
# sintetizados ficam mais agudos e a cada 10 tem festa. No 67: tela de vitória
# especial com confete e fogos.
#
# MODO CÂMERA (meme da balança): com o detector Python + ponte rodando, é só
# mexer as mãos como uma balança — uma sobe e a outra desce. Cada vez que o
# lado "de cima" troca, conta +1 (sem apertar nada). O botão/ESPAÇO continuam
# funcionando.
#
# MODO 30 SEGUNDOS: não precisa chegar ao 67 — o relógio de 30 s começa no
# primeiro movimento e vale fazer o MÁXIMO que der. Passou do 67? Festa
# especial (e a conquista "O escolhido do 67") e o jogo segue até o tempo
# acabar. No fim: tela de resultado com nota e recorde.
#
# Sinais: back_requested (voltar ao FBF), run_finished(score) (acabou o tempo),
# reached_67 (chegou ao 67 durante a rodada).

signal back_requested
signal run_finished(score: int)
signal reached_67

const DURATION := 30.0
const SPECIAL := 67

const MILESTONES := {
	1: "COMEÇOU! O DEDO ESQUENTOU",
	6: "SEIS...",
	7: "SETE?! CALMA, AINDA NÃO",
	10: "AQUECENDO O DEDO",
	13: "AZAR? NÃO, É FÉ",
	20: "TÁ VICIADO, HEIN",
	25: "QUASE UM TERÇO!",
	30: "O DEDO PEDE ARREGO",
	40: "CHAMA O FISIOTERAPEUTA!",
	50: "METADE... E MAIS UM POUCO",
	60: "SESSENTA! SÓ FALTA O SETE",
	65: "QUASE LÁ, CAMPEÃO",
	66: "SEIS SEIS... FALTA O 7!",
	80: "SUPER DEDO!",
	100: "LENDA DO 67!",
}

const GENERIC := ["ISSO!", "MAIS RÁPIDO!", "NÃO PARA!", "O PEIXE TÁ MORDENDO!", "PESCANDO NÚMEROS...", "MAIS UM!", "AI, QUE DEDO!"]
const POPS := ["+1", "+1", "+1", "BOA!", "ISSO!", "+1", "OPA!"]

var sfx: SynthSfx
var best_score: int = 0

var count: int = 0
var running: bool = false
var finished: bool = false

var _t: float = 0.0
var _start_ms: int = 0
var _elapsed: float = 0.0
var _shake: float = 0.0
var _flash: float = 0.0
var _fish_t: float = -1.0
var _fish_dir: float = 1.0
var _fireworks_left: float = 0.0
var _fw_timer: float = 0.0
var _rng := RandomNumberGenerator.new()

var _drift: Array = []
var _stars: Array = []

var _content: Control
var _title: Label
var _num: Label
var _msg: Label
var _time_label: Label
var _best_label: Label
var _bar: ProgressBar
var _bar_fill: StyleBoxFlat
var _button: Button
var _win_panel: PanelContainer
var _win_title: Label
var _win_sub: Label
var _win_stats: Label
var _confetti: CPUParticles2D
var _num_tween: Tween
var _time_left: float = 30.0
var _reached67: bool = false
var _last_tick_sec: int = -1
var _win_ach: Label

# gesto da balança
var _balance: String = "neutro"
var _last_side: String = ""
var _last_swap_ms: int = 0
var _beam: float = 0.0
var _cam_label: Label

# garoto que faz o 67
var _kid_e: float = 0.0
var _kid_target: float = 1.0


func _ready() -> void:

	_rng.randomize()

	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	# garante o tamanho certo toda vez que a tela do minijogo é mostrada
	visibility_changed.connect(_refit_deferred)

	for i in range(60):
		_stars.append(Vector2(_rng.randf(), _rng.randf() * 0.6))

	for i in range(14):
		_drift.append({
			"x": _rng.randf(),
			"y": _rng.randf(),
			"speed": _rng.randf_range(0.03, 0.09),
			"size": _rng.randi_range(60, 150),
			"txt": "6" if i % 2 == 0 else "7",
		})

	_build_ui()
	start()


func _refit_deferred() -> void:

	if is_visible_in_tree():
		call_deferred("_refit")


# Refaz o encaixe em tela cheia (corrige qualquer tamanho "preso" em 0).
func _refit() -> void:

	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	if _content:
		_content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _mk_button(text: String, color: Color, font_size: int, radius: int) -> Button:

	var b := Button.new()

	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", Color(1, 1, 1))
	b.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	b.add_theme_constant_override("outline_size", 8)

	var states := {"normal": 1.0, "hover": 1.25, "pressed": 0.7}

	for k in states.keys():

		var sb := StyleBoxFlat.new()
		var m: float = states[k]

		sb.bg_color = Color(minf(color.r * m, 1.0), minf(color.g * m, 1.0), minf(color.b * m, 1.0))
		sb.border_color = Color(1, 1, 1, 0.9)
		sb.set_border_width_all(4)
		sb.set_corner_radius_all(radius)
		sb.shadow_color = Color(color.r, color.g, color.b, 0.6)
		sb.shadow_size = 14

		if k == "pressed":
			sb.content_margin_top = 6

		b.add_theme_stylebox_override(k, sb)

	return b


func _mk_label(size_px: int, color: Color, outline: int = 8) -> Label:

	var l := Label.new()

	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", outline)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE

	return l


func _build_ui() -> void:

	_content = Control.new()
	_content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_content)

	_title = _mk_label(28, Color(1.0, 0.85, 0.3), 8)
	_title.text = "★  FBF ARCADE  ★  MINIJOGO SECRETO 67  ★"
	_title.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_title.offset_top = 8
	_title.offset_bottom = 54
	_content.add_child(_title)

	_cam_label = _mk_label(16, Color(1.0, 0.8, 0.4), 5)
	_cam_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_cam_label.offset_top = 52
	_cam_label.offset_bottom = 80
	_content.add_child(_cam_label)

	_time_label = _mk_label(26, Color(0.5, 1.0, 0.9), 7)
	_time_label.text = "TEMPO 30.0 s"
	_time_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_time_label.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_time_label.offset_left = 24
	_time_label.offset_top = 14
	_time_label.offset_right = 260
	_time_label.offset_bottom = 50
	_content.add_child(_time_label)

	_best_label = _mk_label(20, Color(1.0, 0.75, 0.3), 6)
	_best_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_best_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_best_label.offset_left = -300
	_best_label.offset_top = 14
	_best_label.offset_right = -24
	_best_label.offset_bottom = 50
	_content.add_child(_best_label)

	# número gigante, centralizado (clicável também)
	_num = _mk_label(250, Color(1, 1, 1), 30)
	_num.text = "0"
	_num.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_num.offset_top = 62
	_num.offset_bottom = 342
	_num.mouse_filter = Control.MOUSE_FILTER_STOP
	_num.gui_input.connect(_on_num_input)
	_content.add_child(_num)

	_msg = _mk_label(30, Color(1, 1, 1), 8)
	_msg.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_msg.offset_top = 346
	_msg.offset_bottom = 388
	_content.add_child(_msg)

	# barra de progresso 0..67
	_bar = ProgressBar.new()
	_bar.min_value = 0
	_bar.max_value = DURATION
	_bar.value = DURATION
	_bar.show_percentage = false
	_bar.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_bar.offset_left = 140
	_bar.offset_right = -140
	_bar.offset_top = 398
	_bar.offset_bottom = 426
	_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.02, 0.02, 0.06, 0.8)
	bg.border_color = Color(1, 1, 1, 0.8)
	bg.set_border_width_all(3)
	bg.set_corner_radius_all(14)

	_bar_fill = StyleBoxFlat.new()
	_bar_fill.bg_color = Color(1.0, 0.3, 0.7)
	_bar_fill.set_corner_radius_all(12)

	_bar.add_theme_stylebox_override("background", bg)
	_bar.add_theme_stylebox_override("fill", _bar_fill)
	_content.add_child(_bar)

	# botão de arcade
	_button = _mk_button("APERTE!", Color(0.9, 0.1, 0.2), 28, 90)
	_button.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_button.offset_left = -90
	_button.offset_right = 90
	_button.offset_top = -240
	_button.offset_bottom = -60
	_button.pressed.connect(_hit)
	_content.add_child(_button)

	var restart := _mk_button("REINICIAR", Color(0.15, 0.45, 0.9), 22, 12)
	restart.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	restart.offset_left = 24
	restart.offset_right = 230
	restart.offset_top = -74
	restart.offset_bottom = -20
	restart.pressed.connect(start)
	_content.add_child(restart)

	var back := _mk_button("VOLTAR AO FBF", Color(0.2, 0.6, 0.3), 22, 12)
	back.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	back.offset_left = -270
	back.offset_right = -24
	back.offset_top = -74
	back.offset_bottom = -20
	back.pressed.connect(func(): back_requested.emit())
	_content.add_child(back)

	# confete da vitória (chove do topo)
	_confetti = CPUParticles2D.new()
	_confetti.emitting = false
	_confetti.one_shot = true
	_confetti.amount = 160
	_confetti.lifetime = 5.0
	_confetti.explosiveness = 0.0
	_confetti.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	_confetti.emission_rect_extents = Vector2(640, 4)
	_confetti.direction = Vector2(0, 1)
	_confetti.spread = 14.0
	_confetti.gravity = Vector2(0, 180)
	_confetti.initial_velocity_min = 90.0
	_confetti.initial_velocity_max = 220.0
	_confetti.angular_velocity_min = -300.0
	_confetti.angular_velocity_max = 300.0
	_confetti.scale_amount_min = 6.0
	_confetti.scale_amount_max = 12.0
	_confetti.color = Color(1.0, 0.8, 0.25)
	_confetti.hue_variation_min = -1.0
	_confetti.hue_variation_max = 1.0
	add_child(_confetti)

	_build_win_panel()


func _build_win_panel() -> void:

	_win_panel = PanelContainer.new()
	_win_panel.set_anchors_preset(Control.PRESET_CENTER)
	_win_panel.offset_left = -330
	_win_panel.offset_right = 330
	_win_panel.offset_top = -230
	_win_panel.offset_bottom = 230
	_win_panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.10, 0.94)
	sb.border_color = Color(1.0, 0.85, 0.3)
	sb.set_border_width_all(5)
	sb.set_corner_radius_all(20)
	sb.content_margin_left = 24
	sb.content_margin_right = 24
	sb.content_margin_top = 14
	sb.content_margin_bottom = 18
	sb.shadow_color = Color(1.0, 0.4, 0.8, 0.6)
	sb.shadow_size = 30
	_win_panel.add_theme_stylebox_override("panel", sb)
	add_child(_win_panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	_win_panel.add_child(v)

	_win_title = _mk_label(150, Color(1, 1, 1), 22)
	_win_title.text = "0"
	v.add_child(_win_title)

	_win_sub = _mk_label(32, Color(1.0, 0.9, 0.4), 8)
	_win_sub.text = ""
	v.add_child(_win_sub)

	_win_stats = _mk_label(20, Color(0.8, 1.0, 0.9), 5)
	v.add_child(_win_stats)

	_win_ach = _mk_label(16, Color(1.0, 0.75, 0.3), 5)
	v.add_child(_win_ach)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(row)

	var again := _mk_button("JOGAR DE NOVO", Color(0.15, 0.45, 0.9), 22, 12)
	again.custom_minimum_size = Vector2(230, 50)
	again.pressed.connect(start)
	row.add_child(again)

	var back := _mk_button("VOLTAR AO FBF", Color(0.2, 0.6, 0.3), 22, 12)
	back.custom_minimum_size = Vector2(230, 50)
	back.pressed.connect(func(): back_requested.emit())
	row.add_child(back)


# ------------------------------------------------------------
# Controle do jogo
# ------------------------------------------------------------

func start() -> void:

	count = 0
	running = false
	finished = false
	_elapsed = 0.0
	_shake = 0.0
	_flash = 0.0
	_fish_t = -1.0
	_fireworks_left = 0.0

	if _win_panel:
		_win_panel.visible = false

	if _confetti:
		_confetti.emitting = false

	_last_side = ""
	_last_swap_ms = 0
	_kid_e = 0.0
	_kid_target = 1.0
	_time_left = DURATION
	_reached67 = false
	_last_tick_sec = -1
	_bar.value = DURATION

	_update_number()
	_msg.text = "FAÇA O MÁXIMO EM 30 SEGUNDOS! O TEMPO COMEÇA NO 1º MOVIMENTO"
	_msg.modulate = Color(1, 1, 1)
	_time_label.text = "TEMPO 30.0 s"
	_time_label.add_theme_color_override("font_color", Color(0.5, 1.0, 0.9))

	_best_label.text = "RECORDE --" if best_score <= 0 else "RECORDE %d" % best_score

	if sfx:
		sfx.play("tick", 1.0, -6.0)


func _update_number() -> void:

	_num.text = str(count)

	var hue: float = fmod(float(mini(count, SPECIAL)) / float(SPECIAL) * 0.9 + 0.55, 1.0)
	var col := Color.from_hsv(hue, 0.85, 1.0)

	_num.add_theme_color_override("font_color", col)
	_num.add_theme_color_override("font_outline_color", Color.from_hsv(hue, 0.9, 0.35))

	_bar_fill.bg_color = col


# Chamado pelo Main a cada mudança do gesto da balança (esq / dir / neutro).
func on_balance(state: String) -> void:

	_balance = state

	if finished or not is_visible_in_tree():
		return

	if state != "esq" and state != "dir":
		return

	if state == _last_side:
		return

	var now: int = Time.get_ticks_msec()

	if now - _last_swap_ms < 60:
		return

	_last_swap_ms = now
	_last_side = state

	_hit(true)


func _on_num_input(event: InputEvent) -> void:

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_hit()


func _input(event: InputEvent) -> void:

	if not is_visible_in_tree():
		return

	if event is InputEventKey and event.pressed and not event.echo:

		if event.physical_keycode == KEY_SPACE or event.physical_keycode == KEY_ENTER or event.physical_keycode == KEY_KP_ENTER:

			if finished:
				start()
			else:
				_hit()

			get_viewport().set_input_as_handled()

		elif event.physical_keycode == KEY_ESCAPE:
			back_requested.emit()
			get_viewport().set_input_as_handled()


func _hit(from_camera: bool = false) -> void:

	if finished:
		return

	if not running:
		running = true
		_start_ms = Time.get_ticks_msec()

	count += 1
	_update_number()

	# o garoto troca de mão a cada contagem (pela câmera, segue o seu lado)
	if from_camera:
		_kid_target = 1.0 if _last_side == "esq" else -1.0
	else:
		_kid_target = -_kid_target if absf(_kid_target) > 0.1 else 1.0

	if sfx:
		sfx.play("blip", 0.8 + minf(float(count) / 80.0, 1.0) * 2.4, -6.0)

	# soco no número
	if _num_tween and _num_tween.is_valid():
		_num_tween.kill()

	_num.pivot_offset = _num.size / 2.0
	_num.scale = Vector2(1.3, 1.3)
	_num.rotation_degrees = _rng.randf_range(-6.0, 6.0)

	_num_tween = create_tween()
	_num_tween.set_parallel(true)
	_num_tween.tween_property(_num, "scale", Vector2(1, 1), 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_num_tween.tween_property(_num, "rotation_degrees", 0.0, 0.16)

	_shake = minf(_shake + 4.0 + float(count) * 0.12, 18.0)

	# peixe pulando (o segredo é "pesca")
	_fish_t = 0.0
	_fish_dir = -_fish_dir

	_pop(POPS[_rng.randi() % POPS.size()])
	_burst(_num.global_position + _num.size / 2.0, 6 + count / 6, Color.from_hsv(_rng.randf(), 0.8, 1.0), 260.0)

	# mensagens
	if MILESTONES.has(count):
		_msg.text = MILESTONES[count]
	elif count % 5 == 0:
		_msg.text = GENERIC[_rng.randi() % GENERIC.size()]

	_msg.modulate = Color.from_hsv(_rng.randf(), 0.5, 1.0)

	if count % 10 == 0:
		_flash = 0.35
		_burst(size / 2.0, 40, Color(1.0, 0.85, 0.3), 480.0)

		if sfx:
			sfx.play("coin", 1.0, -3.0)

	if count == SPECIAL - 1 and sfx:
		sfx.play("glitch", 1.0, -4.0)

	# chegou ao 67: festa especial, mas a rodada continua até o tempo acabar
	if count == SPECIAL and not _reached67:

		_reached67 = true
		_flash = 1.0
		_shake = 26.0
		_msg.text = "É O 67!!! CONTINUA, NÃO PARA!"
		_burst(size / 2.0, 90, Color(1.0, 0.85, 0.3), 560.0)

		if sfx:
			sfx.play("boom", 1.0, -2.0)
			sfx.play("win", 1.0, -4.0)

		reached_67.emit()


func _pop(text: String) -> void:

	var l := _mk_label(40, Color(1.0, 0.95, 0.4), 10)

	l.text = text
	l.position = Vector2(size.x / 2.0 + _rng.randf_range(-260.0, 200.0), 130.0 + _rng.randf_range(0.0, 140.0))
	add_child(l)

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 90.0, 0.6)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.chain().tween_callback(l.queue_free)


func _burst(pos: Vector2, amount: int, color: Color, speed: float) -> void:

	var p := CPUParticles2D.new()

	p.position = pos
	p.amount = maxi(amount, 4)
	p.lifetime = 0.8
	p.one_shot = true
	p.explosiveness = 1.0
	p.spread = 180.0
	p.gravity = Vector2(0, 520)
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.scale_amount_min = 4.0
	p.scale_amount_max = 9.0
	p.color = color
	p.hue_variation_min = -0.2
	p.hue_variation_max = 0.2
	p.emitting = true
	add_child(p)

	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_callback(p.queue_free)


func _rank(n: int) -> String:

	if n >= 100:
		return "LENDA DO 67!"

	if n >= SPECIAL:
		return "O ESCOLHIDO DO 67!"

	if n >= 50:
		return "QUASE ESCOLHIDO!"

	if n >= 35:
		return "DEDO DE OURO"

	if n >= 20:
		return "AQUECENDO..."

	return "DEDO DE MANTEIGA"


# Acabou o tempo: mostra a nota, o recorde e (se passou do 67) a conquista.
func _finish() -> void:

	if finished:
		return

	finished = true
	running = false
	_time_left = 0.0

	_time_label.text = "TEMPO 0.0 s"
	_bar.value = 0.0

	var record: bool = count > best_score

	if record:
		best_score = count

	_best_label.text = "RECORDE %d" % best_score
	_msg.text = "TEMPO ESGOTADO!"
	_flash = 0.7
	_shake = 18.0
	_fireworks_left = 4.0 if _reached67 else 0.0

	if sfx:
		sfx.play("boom", 1.0, -2.0)
		sfx.play("win" if count >= 35 else "error", 1.0, -2.0)

	if count >= 35 or record:
		_confetti.position = Vector2(size.x / 2.0, -12.0)
		_confetti.emission_rect_extents = Vector2(size.x / 2.0, 4.0)
		_confetti.restart()
		_confetti.emitting = true

	_win_title.text = str(count)
	_win_sub.text = _rank(count)
	_win_stats.text = "%.1f trocas por segundo%s" % [float(count) / DURATION, "   •   NOVO RECORDE!" if record else ""]
	_win_ach.text = "CONQUISTA: O escolhido do 67" if _reached67 else "Faça 67 ou mais pra ganhar a conquista \"O escolhido do 67\""

	_win_panel.visible = true
	_win_panel.pivot_offset = _win_panel.size / 2.0
	_win_panel.scale = Vector2(0.2, 0.2)

	var tw := create_tween()
	tw.tween_property(_win_panel, "scale", Vector2(1, 1), 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	run_finished.emit(count)


# ------------------------------------------------------------
# Animação / desenho
# ------------------------------------------------------------

func _process(delta: float) -> void:

	if not is_visible_in_tree():
		return

	_t += delta

	if running:
		_elapsed = float(Time.get_ticks_msec() - _start_ms) / 1000.0
		_time_left = maxf(0.0, DURATION - _elapsed)
		_time_label.text = "TEMPO %.1f s" % _time_left
		_bar.value = _time_left

		# últimos 5 s: relógio vermelho e "tick" a cada segundo
		var urgent: bool = _time_left <= 5.0

		_time_label.add_theme_color_override("font_color", Color(1.0, 0.3, 0.3) if urgent else Color(0.5, 1.0, 0.9))

		if urgent and int(ceil(_time_left)) != _last_tick_sec:
			_last_tick_sec = int(ceil(_time_left))

			if sfx:
				sfx.play("tick", 0.8, -8.0)

		if _time_left <= 0.0:
			_finish()

	_shake = maxf(0.0, _shake - delta * 40.0)
	# tremor da tela: mexe nos OFFSETS (esquerda/direita iguais, topo/base iguais),
	# assim o tamanho do conteúdo nunca muda. (Antes eu mudava a `position` a cada
	# frame, o que podia "congelar" o tamanho em 0 e deixar tudo colado à esquerda.)
	var shake_v := Vector2(_rng.randf_range(-1.0, 1.0), _rng.randf_range(-1.0, 1.0)) * _shake

	_content.offset_left = shake_v.x
	_content.offset_right = shake_v.x
	_content.offset_top = shake_v.y
	_content.offset_bottom = shake_v.y

	_flash = maxf(0.0, _flash - delta * 2.0)

	if _fish_t >= 0.0:
		_fish_t += delta * 2.4
		if _fish_t > 1.0:
			_fish_t = -1.0

	_title.add_theme_color_override("font_color", Color.from_hsv(fmod(_t * 0.2, 1.0), 0.6, 1.0))

	# balança: o desenho acompanha as mãos
	var target: float = 1.0 if _balance == "esq" else (-1.0 if _balance == "dir" else 0.0)
	_beam = lerpf(_beam, target, minf(1.0, delta * 12.0))

	# status da câmera (só muda o texto quando precisa)
	var cam_ok: bool = (
		CameraInputUDP.ligado
		and CameraInputUDP.last_balanca_msec > 0
		and Time.get_ticks_msec() - CameraInputUDP.last_balanca_msec < 2500
	)

	var cam_text: String = (
		"CÂMERA ATIVA: faça a balança! (uma mão sobe, a outra desce)" if cam_ok
		else "CÂMERA: aguardando o detector... (ou use o botão / ESPAÇO)"
	)

	# o garoto copia a sua balança em tempo real (pela câmera) e acompanha o contador
	if cam_ok and (_balance == "esq" or _balance == "dir"):
		_kid_target = 1.0 if _balance == "esq" else -1.0

	_kid_e = lerpf(_kid_e, _kid_target, minf(1.0, delta * 18.0))

	if _cam_label.text != cam_text:
		_cam_label.text = cam_text
		_cam_label.add_theme_color_override("font_color", Color(0.5, 1.0, 0.6) if cam_ok else Color(1.0, 0.8, 0.4))

	if finished:
		_win_title.add_theme_color_override("font_color", Color.from_hsv(fmod(_t * 0.8, 1.0), 0.75, 1.0))

		_fireworks_left -= delta
		_fw_timer -= delta

		if _fireworks_left > 0.0 and _fw_timer <= 0.0:
			_fw_timer = 0.35
			_burst(Vector2(_rng.randf_range(0.1, 0.9) * size.x, _rng.randf_range(0.1, 0.5) * size.y), 34, Color.from_hsv(_rng.randf(), 0.8, 1.0), 420.0)

			if sfx:
				sfx.play("coin", _rng.randf_range(0.7, 1.6), -10.0)

	queue_redraw()


func _draw() -> void:

	var s: Vector2 = size

	# fundo em degradê
	draw_polygon(
		PackedVector2Array([Vector2(0, 0), Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(0, s.y)]),
		PackedColorArray([Color(0.06, 0.01, 0.18), Color(0.06, 0.01, 0.18), Color(0.30, 0.04, 0.38), Color(0.30, 0.04, 0.38)])
	)

	# estrelas piscando
	for i in range(_stars.size()):
		var st: Vector2 = _stars[i]
		var a: float = 0.4 + 0.6 * absf(sin(_t * 1.5 + float(i)))
		draw_circle(Vector2(st.x * s.x, st.y * s.y), 1.6, Color(1, 1, 1, a))

	# sol synthwave atrás do número
	var sc := Vector2(s.x / 2.0, s.y * 0.40)
	draw_circle(sc, 190.0, Color(1.0, 0.45, 0.35, 0.22))
	draw_circle(sc, 150.0, Color(1.0, 0.65, 0.3, 0.18))

	for k in range(6):
		draw_rect(Rect2(Vector2(sc.x - 200.0, sc.y + 20.0 + float(k) * 26.0), Vector2(400.0, 4.0 + float(k) * 2.0)), Color(0.06, 0.01, 0.18, 0.9))

	# números 6 e 7 flutuando ao fundo
	var font: Font = ThemeDB.fallback_font

	for d in _drift:
		var y: float = fmod(float(d["y"]) - _t * float(d["speed"]) + 10.0, 1.0)
		draw_string(font, Vector2(float(d["x"]) * s.x, y * s.y), str(d["txt"]), HORIZONTAL_ALIGNMENT_LEFT, -1, int(d["size"]), Color(1.0, 0.4, 0.8, 0.10))

	# chão em grade com perspectiva
	var horizon: float = s.y * 0.62
	var vp := Vector2(s.x / 2.0, horizon)

	for i in range(-14, 15):
		draw_line(vp, Vector2(s.x / 2.0 + float(i) * s.x * 0.12, s.y), Color(0.3, 0.9, 1.0, 0.25), 1.5)

	for j in range(10):
		var f: float = fmod(float(j) / 10.0 + _t * 0.15, 1.0)
		var yy: float = horizon + (s.y - horizon) * f * f
		draw_line(Vector2(0, yy), Vector2(s.x, yy), Color(1.0, 0.3, 0.8, 0.30 * f + 0.05), 2.0)

	# peixe pulando
	if _fish_t >= 0.0:
		_draw_fish()

	_draw_scale()
	_draw_kid()

	# linhas de scanline (CRT)
	var y2: float = 0.0

	while y2 < s.y:
		draw_line(Vector2(0, y2), Vector2(s.x, y2), Color(0, 0, 0, 0.10), 1.0)
		y2 += 4.0

	# flash branco
	if _flash > 0.0:
		draw_rect(Rect2(Vector2.ZERO, s), Color(1, 1, 1, _flash * 0.6))


# Balança do meme: o prato do lado da mão que está em cima sobe.
func _draw_scale() -> void:

	var c := Vector2(size.x * 0.13, size.y * 0.72)
	var a: float = 0.38 * _beam
	var half: float = 92.0

	var left_end := c + Vector2(-cos(a), -sin(a)) * half
	var right_end := c + Vector2(cos(a), sin(a)) * half

	# base
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, 6), c + Vector2(-26, 70), c + Vector2(26, 70)]), Color(0.85, 0.85, 0.95, 0.85))
	draw_circle(c, 9.0, Color(1.0, 0.85, 0.3))

	# travessa
	draw_line(left_end, right_end, Color(1.0, 0.9, 0.5), 7.0, true)

	# pratos pendurados (esquerda vermelha, direita azul — as cores das luvas)
	var cols := [Color(0.95, 0.28, 0.28), Color(0.30, 0.55, 1.0)]
	var ends := [left_end, right_end]
	var labels := ["ESQ", "DIR"]

	for i in range(2):
		var e: Vector2 = ends[i]
		var col: Color = cols[i]
		var pan := e + Vector2(0, 52)

		draw_line(e, pan + Vector2(-34, 0), Color(1, 1, 1, 0.7), 2.0, true)
		draw_line(e, pan + Vector2(34, 0), Color(1, 1, 1, 0.7), 2.0, true)
		draw_arc(pan, 36.0, 0.0, PI, 20, col, 8.0, true)
		draw_string(ThemeDB.fallback_font, pan + Vector2(-16, 26), labels[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, col)

	draw_string(ThemeDB.fallback_font, c + Vector2(-34, 92), "BALANÇA", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, 0.8))


# Garoto de desenho (original, feito por código) fazendo o gesto do 67: as
# mãos sobem e descem como uma balança. Copia as suas mãos pela câmera ou troca
# de mão a cada contagem.
func _draw_kid() -> void:

	var s: Vector2 = size
	var font: Font = ThemeDB.fallback_font

	var jump: float = 0.0

	if finished:
		jump = absf(sin(_t * 9.0)) * 22.0
	elif running:
		jump = sin(_t * 6.0) * 2.0

	var h := Vector2(s.x * 0.86, s.y * 0.36 - jump)

	var skin := Color(1.0, 0.82, 0.70)
	var hoodie := Color(0.62, 0.64, 0.70)
	var hoodie_d := Color(0.46, 0.48, 0.54)
	var hair := Color(0.74, 0.56, 0.34)
	var hair_d := Color(0.55, 0.40, 0.22)
	var gold := Color(1.0, 0.8, 0.2)
	var e: float = _kid_e

	# corpo (moletom) e capuz
	draw_colored_polygon(PackedVector2Array([h + Vector2(-70, 58), h + Vector2(70, 58), h + Vector2(100, 250), h + Vector2(-100, 250)]), hoodie)
	draw_arc(h + Vector2(0, 62), 56.0, PI, TAU, 24, hoodie_d, 16.0, true)
	draw_rect(Rect2(h + Vector2(-16, 40), Vector2(32, 26)), skin)

	# braços: a mão esquerda (da tela) sobe quando e > 0, a direita desce
	var sh_l := h + Vector2(-72, 90)
	var sh_r := h + Vector2(72, 90)
	var el_l := h + Vector2(-132, 128 - e * 44.0)
	var el_r := h + Vector2(132, 128 + e * 44.0)
	var hand_l := h + Vector2(-150, 150 - e * 84.0)
	var hand_r := h + Vector2(150, 150 + e * 84.0)

	draw_line(sh_l, el_l, hoodie, 32.0, true)
	draw_line(el_l, hand_l, hoodie, 27.0, true)
	draw_line(sh_r, el_r, hoodie, 32.0, true)
	draw_line(el_r, hand_r, hoodie, 27.0, true)

	# mãos abertas (palma pra cima) com o 6 e o 7
	var hands := [hand_l, hand_r]
	var digits := ["6", "7"]

	for i in range(2):

		var hp: Vector2 = hands[i]

		draw_circle(hp, 19.0, skin)

		for k in range(4):
			var ang: float = -PI / 2.0 + (float(k) - 1.5) * 0.36
			draw_line(hp, hp + Vector2(cos(ang), sin(ang)) * 34.0, skin, 8.0, true)

		draw_string(font, hp + Vector2(-16.0, -48.0), digits[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 58, Color(0, 0, 0, 0.55))
		draw_string(font, hp + Vector2(-18.0, -50.0), digits[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 58, gold)

	# cabeça
	draw_circle(h, 54.0, skin)

	# cabelo bagunçado
	var hair_pts := PackedVector2Array()

	for i in range(17):
		var a: float = PI + float(i) * PI / 16.0
		var r: float = 60.0 + (11.0 if i % 2 == 0 else 0.0)
		hair_pts.append(h + Vector2(cos(a) * r, sin(a) * (r - 4.0) + 6.0))

	hair_pts.append(h + Vector2(50, -6))
	hair_pts.append(h + Vector2(-50, -6))
	draw_colored_polygon(hair_pts, hair)

	draw_colored_polygon(PackedVector2Array([h + Vector2(-44, -24), h + Vector2(-12, -40), h + Vector2(-22, 4)]), hair_d)
	draw_colored_polygon(PackedVector2Array([h + Vector2(-8, -38), h + Vector2(26, -36), h + Vector2(10, -2)]), hair)
	draw_colored_polygon(PackedVector2Array([h + Vector2(20, -34), h + Vector2(48, -18), h + Vector2(34, 2)]), hair_d)
	draw_colored_polygon(PackedVector2Array([h + Vector2(-58, -4), h + Vector2(-46, -6), h + Vector2(-52, 40)]), hair)
	draw_colored_polygon(PackedVector2Array([h + Vector2(58, -4), h + Vector2(46, -6), h + Vector2(52, 40)]), hair)

	# rosto: olhos arregalados (acompanham a mão de cima), sobrancelhas, sorrisão
	var look: float = -e * 3.0

	for sx in [-1.0, 1.0]:
		var ex: float = sx * 20.0
		draw_circle(h + Vector2(ex, -2.0), 12.0, Color(1, 1, 1))
		draw_circle(h + Vector2(ex + look, -2.0), 5.5, Color(0.1, 0.07, 0.05))
		draw_circle(h + Vector2(ex + look + 1.5, -4.0), 1.8, Color(1, 1, 1))
		draw_line(h + Vector2(ex - 12.0, -20.0 - sx * 2.0), h + Vector2(ex + 10.0, -24.0 + sx * 2.0), hair_d, 4.0, true)

	draw_circle(h + Vector2(0, 8), 3.0, Color(0.9, 0.65, 0.55))
	draw_circle(h + Vector2(-32, 14), 7.0, Color(1.0, 0.6, 0.55, 0.5))
	draw_circle(h + Vector2(32, 14), 7.0, Color(1.0, 0.6, 0.55, 0.5))

	draw_arc(h + Vector2(0, 14), 26.0, 0.12 * PI, 0.88 * PI, 18, Color(0.35, 0.1, 0.1), 5.0, true)
	draw_rect(Rect2(h + Vector2(-21, 22), Vector2(42, 9)), Color(1, 1, 1))

	draw_string(font, h + Vector2(-62.0, 276.0), "O GAROTO DO 67", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1, 0.85))


func _draw_fish() -> void:

	var s: Vector2 = size
	var p: float = _fish_t

	var x0: float = s.x * (0.12 if _fish_dir > 0.0 else 0.88)
	var x1: float = s.x * (0.88 if _fish_dir > 0.0 else 0.12)
	var base_y: float = s.y * 0.66

	var pos := Vector2(lerpf(x0, x1, p), base_y - sin(p * PI) * s.y * 0.34)
	var slope: float = -cos(p * PI) * s.y * 0.34 * PI / absf(x1 - x0) * signf(x1 - x0)
	var ang: float = atan2(slope, 1.0) * signf(x1 - x0)

	draw_set_transform(pos, ang if _fish_dir > 0.0 else ang + PI, Vector2.ONE)

	var body := PackedVector2Array()

	for i in range(20):
		var a: float = float(i) * TAU / 20.0
		body.append(Vector2(cos(a) * 34.0, sin(a) * 16.0))

	draw_colored_polygon(body, Color(1.0, 0.55, 0.15))
	draw_colored_polygon(PackedVector2Array([Vector2(-30, 0), Vector2(-56, -18), Vector2(-56, 18)]), Color(1.0, 0.4, 0.1))
	draw_colored_polygon(PackedVector2Array([Vector2(-6, -15), Vector2(6, -28), Vector2(14, -14)]), Color(0.95, 0.3, 0.1))

	for k in range(3):
		draw_line(Vector2(-8.0 + float(k) * 8.0, -12), Vector2(-8.0 + float(k) * 8.0, 12), Color(1, 0.85, 0.5, 0.7), 2.0)

	draw_circle(Vector2(20, -4), 4.0, Color(1, 1, 1))
	draw_circle(Vector2(21, -4), 2.0, Color(0, 0, 0))

	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# respingos no início e no fim
	if p < 0.2 or p > 0.8:
		var sp: Vector2 = Vector2(x0 if p < 0.2 else x1, base_y + 8.0)
		for k in range(5):
			draw_circle(sp + Vector2(float(k - 2) * 12.0, -absf(float(k - 2)) * 6.0 - 6.0), 4.0, Color(0.6, 0.9, 1.0, 0.8))
