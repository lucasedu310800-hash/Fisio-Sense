# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioFarofa
# PRAIA DA FAROFA: praia lotada ao meio-dia, guarda-sol em cima de guarda-sol,
# futevôlei, ambulantes (queijo coalho, mate, biscoito de polvilho), tiozão
# vermelho de sol, calçadão de ondas, gaivota ladrona e placas do calor.

var _rng := RandomNumberGenerator.new()
var _heads: Array = []
var _vendors: Array = []
var _players: Array = []
var _ball: Node3D
var _foam: Array = []
var _event_timer: float = 8.0


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.20, 0.45, 0.85)
	sky_mat.sky_horizon_color = Color(0.75, 0.88, 1.0)
	sky_mat.ground_horizon_color = Color(0.85, 0.85, 0.8)
	sky_mat.ground_bottom_color = Color(0.6, 0.55, 0.45)

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.8, 0.82, 0.9)
	env.ambient_light_energy = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.85, 0.92, 1.0)
	env.fog_density = 0.004
	env.glow_enabled = true
	env.glow_intensity = 0.5
	env.ssao_enabled = true

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-62, 25, 0), Color(1.0, 0.97, 0.88), 1.7)

	_build_sand_sea()
	_build_promenade()
	_build_crowd()
	_build_umbrellas()
	_build_futevolei()
	_build_vendors()
	_build_signs()

	_make_accent(Vector3(0, 3.5, -3.0), Color(1.0, 0.95, 0.85), 0.35, 10.0)

	_anim.append(_update)


func _wave_texture() -> ImageTexture:

	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)

	for y in range(64):
		for x in range(64):
			var v: float = sin(float(x) / 64.0 * TAU * 2.0 + sin(float(y) / 64.0 * TAU) * 1.8)
			var c := Color(0.95, 0.94, 0.9, 1.0) if v > 0.0 else Color(0.12, 0.12, 0.14, 1.0)
			img.set_pixel(x, y, c)

	return ImageTexture.create_from_image(img)


func _build_sand_sea() -> void:

	_box(self, Vector3(0, -0.06, -2.0), Vector3(80, 0.12, 15.0), _mat(Color(0.95, 0.83, 0.6), 1.0, 0.0))
	_box(self, Vector3(0, 0.001, -9.0), Vector3(80, 0.004, 1.8), _mat(Color(0.7, 0.58, 0.4), 0.55, 0.0))

	var shader := Shader.new()
	shader.code = ScenarioBeach.WATER_SHADER

	var water := ShaderMaterial.new()
	water.shader = shader
	water.set_shader_parameter("deep_color", Color(0.05, 0.5, 0.65, 1.0))
	water.set_shader_parameter("shallow_color", Color(0.3, 0.85, 0.8, 1.0))
	water.set_shader_parameter("sun_tint", Color(1.0, 1.0, 0.9, 1.0))

	var mesh := PlaneMesh.new()
	mesh.size = Vector2(140, 80)
	mesh.subdivide_width = 80
	mesh.subdivide_depth = 50

	var sea := MeshInstance3D.new()
	sea.mesh = mesh
	_put(self, sea, Vector3(0, -0.04, -49.0), Vector3.ZERO, water)
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	var foam_mat := StandardMaterial3D.new()
	foam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	foam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	foam_mat.albedo_color = Color(1, 1, 1, 0.6)

	for i in range(2):
		_foam.append(_no_shadow(_plane(self, Vector3(0, 0.012, -9.3 - float(i) * 1.2), Vector2(80, 0.4), foam_mat)))


func _build_promenade() -> void:

	var tex := StandardMaterial3D.new()
	tex.albedo_texture = _wave_texture()
	tex.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	tex.uv1_scale = Vector3(30.0, 2.0, 1.0)

	# calçadão de ondas atrás da praia lotada
	_box(self, Vector3(0, 0.04, 6.6), Vector3(80, 0.1, 3.0), tex)

	# prédios ao fundo (praia urbana)
	for i in range(14):
		var w: float = _rng.randf_range(4.0, 6.5)
		var h: float = _rng.randf_range(14.0, 30.0)
		var m := _building_mat(6000 + i, w, h, Color(0.95, 0.93, 0.88), 0.18)
		_box(self, Vector3(-40.0 + float(i) * 6.2, h / 2.0, -80.0), Vector3(w, h, 6.0), m)

	# morros verdes
	_sphere(self, Vector3(-30.0, -6.0, -75.0), 22.0, _mat(Color(0.15, 0.4, 0.25), 1.0, 0.0))
	_sphere(self, Vector3(34.0, -8.0, -78.0), 26.0, _mat(Color(0.18, 0.45, 0.28), 1.0, 0.0))


func _build_crowd() -> void:

	var suits := [
		Color(0.95, 0.2, 0.2), Color(0.2, 0.55, 0.95), Color(0.98, 0.85, 0.15),
		Color(0.2, 0.8, 0.45), Color(0.95, 0.4, 0.75), Color(0.98, 0.98, 0.98),
	]
	var skins := [Color(0.98, 0.78, 0.65), Color(0.78, 0.56, 0.42), Color(0.55, 0.38, 0.28), Color(0.4, 0.28, 0.2)]

	for i in range(34):

		var x: float = _rng.randf_range(-15.0, 15.0)
		var z: float = _rng.randf_range(-8.2, 4.5)

		if absf(x) < 2.6 and z > -4.6:
			continue

		var p: Dictionary = _person(self, Vector3(x, 0.0, z), suits[_rng.randi() % suits.size()], skins[_rng.randi() % skins.size()], suits[_rng.randi() % suits.size()])
		var n: Node3D = p["node"]

		# alguns deitados tomando sol
		if _rng.randf() < 0.4:
			n.rotation_degrees.x = -90.0
			n.position.y = 0.16

	# cabeças na água (pessoas se refrescando)
	for i in range(14):
		var h := _sphere(self, Vector3(_rng.randf_range(-16.0, 16.0), 0.0, _rng.randf_range(-12.0, -18.0)), 0.17, _mat(skins[_rng.randi() % skins.size()], 0.6, 0.0))
		_heads.append({"node": h, "phase": _rng.randf_range(0.0, 6.0)})

	# tiozão vermelho de sol (sunga bem pequena, gigante)
	var tio: Dictionary = _person(self, Vector3(-3.6, 0.0, -5.6), Color(0.92, 0.33, 0.25), Color(0.92, 0.33, 0.25), Color(0.1, 0.4, 0.9), Color(0, 0, 0, 0), 1.15)
	var tn: Node3D = tio["node"]
	_sphere(tn, Vector3(0, 1.1, 0), 0.28, _mat(Color(0.92, 0.33, 0.25), 0.7, 0.0), Vector3(1.0, 1.0, 1.1))
	_toast("40 GRAUS!", Vector3(-3.6, 2.6, -5.6), Color(1.0, 0.5, 0.3), 60)


func _build_umbrellas() -> void:

	for i in range(24):

		var x: float = _rng.randf_range(-16.0, 16.0)
		var z: float = _rng.randf_range(-8.0, 5.0)

		if absf(x) < 3.0 and z > -5.0:
			continue

		var root := Node3D.new()
		root.position = Vector3(x, 0.0, z)
		root.rotation_degrees = Vector3(0, 0, _rng.randf_range(-8.0, 8.0))
		add_child(root)

		_cyl(root, Vector3(0, 1.1, 0), 0.03, 2.2, _mat(Color(0.9, 0.9, 0.9), 0.5, 0.5))
		_cone(root, Vector3(0, 2.15, 0), 1.3, 0.5, _mat(Color.from_hsv(_rng.randf(), 0.75, 0.95), 0.8, 0.0), Vector3.ZERO, 8)
		_cone(root, Vector3(0, 2.2, 0), 0.9, 0.45, _mat(Color(0.98, 0.98, 0.98), 0.8, 0.0), Vector3.ZERO, 8)


func _build_futevolei() -> void:

	var pole := _mat(Color(0.9, 0.9, 0.9), 0.5, 0.4)
	var net := _mat(Color(1, 1, 1, 0.45), 1.0, 0.0)
	net.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

	_cyl(self, Vector3(-9.6, 1.1, -3.0), 0.04, 2.2, pole)
	_cyl(self, Vector3(-5.6, 1.1, -3.0), 0.04, 2.2, pole)
	_box(self, Vector3(-7.6, 1.6, -3.0), Vector3(4.0, 0.7, 0.01), net)

	for i in range(2):
		var p: Dictionary = _person(self, Vector3(-8.6 + float(i) * 2.0, 0.0, -3.0), Color(0.95, 0.4, 0.2), Color(0.85, 0.62, 0.48), Color(0.1, 0.4, 0.9))
		_players.append(p["node"])

	_ball = Node3D.new()
	add_child(_ball)
	_sphere(_ball, Vector3.ZERO, 0.16, _mat(Color(0.98, 0.98, 0.98), 0.4, 0.0))
	_sphere(_ball, Vector3(0.05, 0.05, 0.14), 0.05, _mat(Color(0.1, 0.4, 0.9), 0.4, 0.0))


func _build_vendors() -> void:

	# queijo coalho na brasa
	var q := Node3D.new()
	q.position = Vector3(8.0, 0.0, -4.4)
	add_child(q)
	_box(q, Vector3(0, 0.55, 0), Vector3(1.0, 0.5, 0.6), _mat(Color(0.2, 0.2, 0.22), 0.6, 0.4))
	_box(q, Vector3(0, 0.85, 0), Vector3(0.9, 0.06, 0.5), _emit(Color(1.0, 0.45, 0.1), 1.6))

	for i in range(5):
		_box(q, Vector3(-0.35 + float(i) * 0.18, 1.15, 0), Vector3(0.03, 0.5, 0.03), _mat(Color(0.5, 0.3, 0.15), 0.8, 0.0))
		_box(q, Vector3(-0.35 + float(i) * 0.18, 1.1, 0), Vector3(0.1, 0.22, 0.08), _mat(Color(0.97, 0.85, 0.5), 0.7, 0.0))

	_person(q, Vector3(-0.9, 0.0, 0.1), Color(0.95, 0.95, 0.95), Color(0.7, 0.5, 0.36), Color(0.2, 0.3, 0.5), Color(0.95, 0.5, 0.15))
	_label("QUEIJO COALHO!", Vector3(0, 2.3, 0), 44, 0.005, Color(1.0, 0.9, 0.4), Vector3.ZERO, q).outline_size = 10

	_particles(Vector3(8.0, 1.6, -4.4), Vector3(0.3, 0.05, 0.2), 16, 2.0, Color(0.9, 0.9, 0.9, 0.25), 0.4, Vector3(0.1, 0.6, 0), 0.3, 0.5, false, Vector3(0, 1, 0), 15.0)

	# ambulante do mate gelado, andando na beira
	var mate: Dictionary = _person(self, Vector3(-2.0, 0.0, -7.4), Color(0.2, 0.7, 0.4), Color(0.75, 0.55, 0.4), Color(0.2, 0.25, 0.4), Color(0.95, 0.9, 0.3))
	var mn: Node3D = mate["node"]
	_cyl(mn, Vector3(0.3, 1.0, 0), 0.22, 0.6, _mat(Color(0.9, 0.9, 0.95), 0.4, 0.2))
	_label("MATE GELADO", Vector3(0, 2.1, 0), 34, 0.0045, Color(1, 1, 1), Vector3.ZERO, mn).outline_size = 8
	_vendors.append({"node": mn, "speed": 0.7, "legs": mate["legs"]})

	# biscoito de polvilho (varal de saquinhos)
	var bs: Dictionary = _person(self, Vector3(4.0, 0.0, -7.0), Color(0.95, 0.5, 0.15), Color(0.6, 0.42, 0.3), Color(0.25, 0.25, 0.3), Color(0.15, 0.45, 0.9))
	var bn: Node3D = bs["node"]
	_cyl(bn, Vector3(-0.3, 1.6, 0), 0.02, 1.6, _mat(Color(0.8, 0.8, 0.8), 0.5, 0.5))

	for i in range(6):
		_box(bn, Vector3(-0.3, 2.1 - float(i % 3) * 0.3, -0.2 + float(i / 3) * 0.4), Vector3(0.22, 0.28, 0.05), _mat(Color(1.0, 0.9, 0.3), 0.8, 0.0))

	_label("POLVILHO!", Vector3(0, 2.6, 0), 34, 0.0045, Color(1.0, 0.9, 0.4), Vector3.ZERO, bn).outline_size = 8
	_vendors.append({"node": bn, "speed": -0.5, "legs": bs["legs"]})


func _build_signs() -> void:

	_plaque(Vector3(9.5, 2.0, -1.0), Vector2(3.6, 1.0), Color(0.98, 0.85, 0.1), "40°C NA SOMBRA\n(E NÃO TEM SOMBRA)", Color(0.15, 0.05, 0.02), 32, 0.0, true)
	_plaque(Vector3(-11.5, 1.8, 0.0), Vector2(3.4, 0.9), Color(0.9, 0.2, 0.2), "PROIBIDO LEVAR FAROFA\n(JÁ ERA)", Color(1, 1, 1), 30, 0.0, true)
	_plaque(Vector3(0.0, 1.4, -6.6), Vector2(3.0, 0.7), Color(0.2, 0.5, 0.9), "PROTETOR SOLAR: 0%", Color(1, 1, 1), 26)


func _update(t: float, dt: float) -> void:

	for h in _heads:
		var n: Node3D = h["node"]
		n.position.y = -0.03 + sin(t * 1.6 + float(h["phase"])) * 0.06

	for i in range(_foam.size()):
		var f: Node3D = _foam[i]
		f.position.z = -9.3 - float(i) * 1.2 + sin(t * 0.9 + float(i)) * 0.5

	for v in _vendors:
		var vn: Node3D = v["node"]
		vn.position.x += dt * float(v["speed"])

		if vn.position.x > 14.0:
			vn.position.x = -14.0
		elif vn.position.x < -14.0:
			vn.position.x = 14.0

		var lg: Array = v["legs"]
		var l0: Node3D = lg[0]
		var l1: Node3D = lg[1]
		var sw: float = sin(t * 6.0) * 0.5
		l0.rotation.z = sw
		l1.rotation.z = -sw

	# futevôlei: bola vai e volta e os jogadores pulam
	if _ball and _players.size() >= 2:
		var k: float = 0.5 + 0.5 * sin(t * 1.6)
		_ball.position = Vector3(lerpf(-8.6, -6.6, k), 1.0 + 2.2 * sin(k * PI), -3.0)

		var p0: Node3D = _players[0]
		var p1: Node3D = _players[1]
		p0.position.y = maxf(0.0, sin(t * 1.6 + 2.5)) * 0.7
		p1.position.y = maxf(0.0, -sin(t * 1.6 + 2.5)) * 0.7

	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(8.0, 15.0)
		_event()


func _event() -> void:

	var r: int = _rng.randi() % 3

	if r == 0:
		_toast("OLHA O QUEIJO!", Vector3(6.0, 3.4, -4.4), Color(1.0, 0.9, 0.4), 70)
	elif r == 1:
		_toast("EITA, ONDA!", Vector3(0.0, 2.2, -9.0), Color(0.5, 0.9, 1.0), 80)
	else:
		# gaivota rouba o queijo
		var gull := Node3D.new()
		gull.position = Vector3(-14.0, 4.0, -7.0)
		add_child(gull)

		var white := _mat(Color(0.98, 0.98, 0.98), 0.6, 0.0)
		_box(gull, Vector3(-0.4, 0, 0), Vector3(0.8, 0.03, 0.2), white, Vector3(0, 0, 15))
		_box(gull, Vector3(0.4, 0, 0), Vector3(0.8, 0.03, 0.2), white, Vector3(0, 0, -15))
		_toast("MEU QUEIJO!", Vector3(-4.0, 5.5, -7.0), Color(1.0, 0.6, 0.3), 70)

		var tw := create_tween()
		tw.tween_property(gull, "position:x", 14.0, 5.0)
		tw.tween_callback(gull.queue_free)
