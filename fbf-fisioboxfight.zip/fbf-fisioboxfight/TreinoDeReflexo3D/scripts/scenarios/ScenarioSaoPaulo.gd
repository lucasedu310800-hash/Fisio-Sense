# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioSaoPaulo
# SÃO PAULO — A CIDADE DO CAOS (cenário secreto, desbloqueado com código).
# Arena de rua com humor de meme brasileiro: Ponte Estaiada com mastro em
# X e LEDs, Rio Tietê "orgânico" com coisas boiando, congestionamento
# gigante, ônibus lotado, motoboys, grafites, fios e postes, placas
# engraçadas, banca, lanchonete, vendedor ambulante e o CACHORRO CARAMELO
# — dono oficial da arena (de coroa!).
#
# Tudo fica ao redor: a área de luta (|x| < 2, z de -3 a 1) está livre. O
# trânsito e a cidade ficam ao fundo (z < -4.5). Os eventos aleatórios são
# só visuais e nunca passam pela frente do treinador.

const WATER_SHADER := """
shader_type spatial;

uniform vec4 deep_color : source_color = vec4(0.17, 0.21, 0.09, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.36, 0.40, 0.17, 1.0);

varying float wave_h;

void vertex() {
	float w = sin(VERTEX.x * 0.9 + TIME * 0.9) * 0.05
		+ sin(VERTEX.z * 1.3 + TIME * 0.6) * 0.04
		+ sin((VERTEX.x - VERTEX.z) * 0.5 + TIME * 0.4) * 0.06;
	VERTEX.y += w;
	wave_h = w;
}

void fragment() {
	float f = clamp(wave_h * 5.0 + 0.5, 0.0, 1.0);
	vec3 col = mix(deep_color.rgb, shallow_color.rgb, f);
	col += vec3(0.10, 0.08, 0.02) * smoothstep(0.07, 0.11, wave_h);
	ALBEDO = col;
	ROUGHNESS = 0.15;
	METALLIC = 0.1;
	SPECULAR = 0.7;
}
"""

const BUS_TEXTS := [
	"LOTADO -> SEMPRE",
	"SAO MIGUEL VIA TRANSITO",
	"NAO PARA (PODE ACENAR)",
	"CHEGO JA (MENTIRA)",
]

const HONKS := ["BI-BI!", "ANDA LOGO!", "PRA QUE CORRE?!", "BUZINACO!", "TA PARADO, MOÇO!"]

var _rng := RandomNumberGenerator.new()

var _jam_cars: Array = []
var _creepers: Array = []
var _bikes: Array = []
var _peds: Array = []
var _floaters: Array = []
var _far_cars: Array = []
var _bridge_mats: Array = []
var _light_mats: Array = []
var _tl_mats: Array = []
var _bus: Node3D
var _bus_label: Label3D
var _bus_text_idx: int = 0
var _bus_text_t: float = 0.0
var _sign_10min: Label3D
var _stuck_car: Node3D
var _vendor_arm: Node3D
var _open_mat: StandardMaterial3D

# cachorro caramelo
var _dog: Node3D
var _dog_body: Node3D
var _dog_tail: Node3D
var _dog_head: Node3D
var _dog_legs: Array = []
var _dog_tongue: Node3D
var _dog_zzz: Label3D
var _dog_state: String = "sit"
var _dog_timer: float = 2.0
var _dog_target: Vector3 = Vector3.ZERO
var _dog_busy: bool = false

var _event_timer: float = 9.0


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.30, 0.42, 0.78)
	sky_mat.sky_horizon_color = Color(1.0, 0.72, 0.46)
	sky_mat.ground_horizon_color = Color(0.90, 0.68, 0.48)
	sky_mat.ground_bottom_color = Color(0.40, 0.30, 0.24)
	sky_mat.sun_angle_max = 28.0

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.68, 0.58)
	env.ambient_light_energy = 0.9

	# neblina de "poluição" quentinha (a cara de São Paulo no fim da tarde)
	env.fog_enabled = true
	env.fog_light_color = Color(0.92, 0.76, 0.62)
	env.fog_density = 0.008

	env.glow_enabled = true
	env.glow_intensity = 0.8
	env.glow_hdr_threshold = 0.95

	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.3

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-15, 152, 0), Color(1.0, 0.72, 0.40), 1.6)
	_sun(Vector3(-32, -22, 0), Color(0.85, 0.65, 0.75), 0.35, false)

	_build_ground()
	_build_traffic()
	_build_bus()
	_build_motoboys()
	_build_river()
	_build_bridge()
	_build_skyline()
	_build_graffiti_wall()
	_build_right_side()
	_build_bus_stop()
	_build_poles_and_wires()
	_build_traffic_light()
	_build_signs()
	_build_people()
	_build_dog()

	_make_accent(Vector3(0.0, 3.2, -3.0), Color(1.0, 0.8, 0.5), 0.45, 9.0)

	_anim.append(_update_world)
	_anim.append(_update_dog)


# ============================================================
# Ferramentas próprias
# ============================================================

func _cable(parent: Node3D, a: Vector3, b: Vector3, mat: Material, thick: float) -> void:

	var dir: Vector3 = b - a
	var length: float = dir.length()

	if length < 0.001:
		return

	var mesh := BoxMesh.new()
	mesh.size = Vector3(thick, thick, length)

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)

	mi.transform = Transform3D(Basis.looking_at(dir.normalized(), Vector3.UP), (a + b) / 2.0)


func _wire(a: Vector3, b: Vector3, sag: float, mat: Material) -> void:

	var prev: Vector3 = a
	var n: int = 6

	for i in range(1, n + 1):
		var k: float = float(i) / float(n)
		var p: Vector3 = a.lerp(b, k)
		p.y -= sag * 4.0 * k * (1.0 - k)
		_cable(self, prev, p, mat, 0.03)
		prev = p


func _pop_label(text: String, pos: Vector3, color: Color, font_size: int) -> void:

	var l := _label(text, pos, font_size, 0.006, color)
	l.outline_size = 16
	l.scale = Vector3(0.2, 0.2, 0.2)

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "scale", Vector3(1, 1, 1), 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "position:y", pos.y + 0.7, 1.4)
	tw.chain().tween_property(l, "modulate:a", 0.0, 0.4)
	tw.chain().tween_callback(l.queue_free)


func _sign_board(pos: Vector3, size: Vector2, bg: Color, text: String, fg: Color, font_size: int, post_h: float = 2.2, rot_y: float = 0.0) -> Label3D:

	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0, rot_y, 0)
	add_child(root)

	var post := _mat(Color(0.15, 0.15, 0.17), 0.5, 0.6)

	if post_h > 0.0:
		_cyl(root, Vector3(-size.x / 2.0 + 0.3, post_h / 2.0, -0.05), 0.05, post_h, post)
		_cyl(root, Vector3(size.x / 2.0 - 0.3, post_h / 2.0, -0.05), 0.05, post_h, post)

	var y: float = post_h + size.y / 2.0 - 0.1 if post_h > 0.0 else 0.0

	_box(root, Vector3(0, y, 0), Vector3(size.x, size.y, 0.06), _mat(bg, 0.6, 0.0))
	_box(root, Vector3(0, y, 0.005), Vector3(size.x - 0.12, size.y - 0.12, 0.06), _mat(bg.darkened(0.12), 0.6, 0.0))

	var l := _label(text, Vector3(0, y, 0.05), font_size, 0.0045, fg, Vector3.ZERO, root)
	l.outline_size = 0

	return l


func _mosaic_texture() -> ImageTexture:

	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)

	for y in range(64):
		for x in range(64):
			var v: float = sin(float(x) / 64.0 * TAU * 2.0 + sin(float(y) / 64.0 * TAU) * 1.6)
			var c := Color(0.90, 0.88, 0.84, 1.0) if v > 0.0 else Color(0.24, 0.24, 0.27, 1.0)
			img.set_pixel(x, y, c)

	return ImageTexture.create_from_image(img)


# ============================================================
# Chão: calçada de mosaico (arena), rua, canteiro
# ============================================================

func _build_ground() -> void:

	var plaza := StandardMaterial3D.new()
	plaza.albedo_texture = _mosaic_texture()
	plaza.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	plaza.uv1_scale = Vector3(17.0, 3.8, 1.0)
	plaza.roughness = 0.75

	_box(self, Vector3(0, -0.05, -0.8), Vector3(34, 0.1, 7.6), plaza)
	_box(self, Vector3(0, -0.06, 1.0), Vector3(80, 0.1, 30), _mat(Color(0.55, 0.5, 0.45), 0.9, 0.0))

	var curb := _mat(Color(0.72, 0.70, 0.66), 0.7, 0.0)
	var asphalt := _mat(Color(0.20, 0.20, 0.22), 0.85, 0.05)

	_box(self, Vector3(0, 0.03, -4.72), Vector3(80, 0.14, 0.25), curb)
	_box(self, Vector3(0, -0.06, -8.05), Vector3(80, 0.1, 6.5), asphalt)
	_box(self, Vector3(0, 0.03, -11.4), Vector3(80, 0.14, 0.25), curb)

	# faixas da rua e faixa de pedestres (zebra) do lado direito
	var white := _mat(Color(0.94, 0.94, 0.9), 0.6, 0.0)

	for i in range(-16, 17):
		_box(self, Vector3(float(i) * 2.4, -0.005, -7.55), Vector3(1.2, 0.006, 0.12), white)
		_box(self, Vector3(float(i) * 2.4 + 1.0, -0.005, -9.25), Vector3(1.2, 0.006, 0.12), white)

	# faixa de pedestres (listras no sentido da travessia)
	for i in range(9):
		_box(self, Vector3(11.0 + float(i) * 1.0, -0.004, -8.05), Vector3(0.55, 0.006, 6.2), white)

	# margem de concreto do rio
	_box(self, Vector3(0, -0.10, -12.6), Vector3(80, 0.2, 2.4), _mat(Color(0.62, 0.62, 0.60), 0.9, 0.0))
	_box(self, Vector3(0, -0.18, -13.9), Vector3(80, 0.16, 0.5), _mat(Color(0.50, 0.50, 0.48), 0.9, 0.0))

	# grade de proteção (amarela e preta) na beira
	var rail_y := _mat(Color(0.95, 0.75, 0.1), 0.5, 0.2)

	for i in range(-14, 15):
		_cyl(self, Vector3(float(i) * 2.2, 0.5, -13.2), 0.035, 1.0, rail_y)

	_box(self, Vector3(0, 0.95, -13.2), Vector3(80, 0.06, 0.06), rail_y)
	_box(self, Vector3(0, 0.6, -13.2), Vector3(80, 0.05, 0.05), rail_y)


# ============================================================
# Trânsito: congestionamento gigante
# ============================================================

func _make_car(pos: Vector3, color: Color, flip: bool, kind: int) -> Node3D:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	var body := Node3D.new()
	root.add_child(body)

	if flip:
		body.rotation_degrees = Vector3(0, 180, 0)

	var paint := _mat(color, 0.3, 0.4)
	var glass := _mat(Color(0.08, 0.12, 0.18), 0.05, 0.8)
	var rubber := _mat(Color(0.03, 0.03, 0.04), 0.9, 0.0)
	var head := _emit(Color(1.0, 0.95, 0.75), 2.0)
	var tail := _emit(Color(1.0, 0.1, 0.08), 1.8)

	var length: float = 2.3
	var cab_w: float = 1.2
	var cab_h: float = 0.5

	if kind == 1:
		length = 2.0
		cab_w = 1.3
	elif kind == 2:
		length = 2.6
		cab_w = 2.3
		cab_h = 0.9

	_box(body, Vector3(0, 0.5, 0), Vector3(length, 0.62, 1.05), paint)
	_box(body, Vector3(-0.1, 0.5 + 0.31 + cab_h / 2.0, 0), Vector3(cab_w, cab_h, 0.95), glass)
	_box(body, Vector3(-0.1, 0.5 + 0.31 + cab_h, 0), Vector3(cab_w * 0.95, 0.05, 0.9), paint)

	for wx in [-0.72, 0.72]:
		for wz in [-0.5, 0.5]:
			_cyl(body, Vector3(wx, 0.27, wz), 0.28, 0.2, rubber, Vector3(90, 0, 0), 12)

	for zz in [-0.34, 0.34]:
		_no_shadow(_box(body, Vector3(length / 2.0, 0.6, zz), Vector3(0.05, 0.11, 0.24), head))
		_no_shadow(_box(body, Vector3(-length / 2.0, 0.6, zz), Vector3(0.05, 0.11, 0.24), tail))

	# táxi: placa no teto
	if kind == 3:
		_box(body, Vector3(-0.1, 1.55, 0), Vector3(0.5, 0.16, 0.22), _emit(Color(1.0, 0.95, 0.5), 1.4))

	return root


func _build_traffic() -> void:

	var colors := [
		Color(0.85, 0.10, 0.12), Color(0.15, 0.35, 0.85), Color(0.95, 0.85, 0.15),
		Color(0.92, 0.92, 0.94), Color(0.14, 0.14, 0.18), Color(0.20, 0.65, 0.35),
		Color(0.95, 0.50, 0.10), Color(0.55, 0.55, 0.60),
	]

	for lane in range(2):

		var z: float = -6.7 if lane == 0 else -8.4
		var flip: bool = (lane == 1)
		var idx: int = 0
		var x: float = -17.0

		while x < 17.0:

			var kind: int = _rng.randi() % 4
			var col: Color = colors[_rng.randi() % colors.size()]

			if kind == 3:
				col = Color(0.98, 0.85, 0.12)

			var car := _make_car(Vector3(x, 0, z), col, flip, kind)
			_jam_cars.append(car)

			# carro do "voltamos em 5 minutos"
			if lane == 0 and idx == 5:
				var placard := _box(car, Vector3(0, 1.75, 0), Vector3(1.6, 0.45, 0.04), _mat(Color(0.98, 0.98, 0.9), 0.7, 0.0))
				placard.rotation_degrees = Vector3(0, 0, 0)
				_label("VOLTAMOS EM\n5 MINUTOS", Vector3(0, 1.75, 0.04), 40, 0.0038, Color(0.05, 0.05, 0.05), Vector3.ZERO, car).outline_size = 0

			# carro que não sai do lugar (pneu girando + fumacinha)
			elif lane == 0 and idx == 9:
				_stuck_car = car
				var smoke := _particles(
					Vector3(0, 0, 0), Vector3(0.1, 0.05, 0.1), 22, 1.6,
					Color(0.7, 0.7, 0.72, 0.25), 0.5,
					Vector3(0.0, 0.6, 0.0), 0.3, 0.6, false, Vector3(0, 1, 0), 25.0
				)
				smoke.get_parent().remove_child(smoke)
				car.add_child(smoke)
				smoke.position = Vector3(-1.4 if not flip else 1.4, 0.4, 0.0)

			else:
				if _rng.randf() < 0.45:
					_creepers.append({"node": car, "base": x, "phase": _rng.randf_range(0.0, 6.28)})

			x += 3.7
			idx += 1


# ============================================================
# Ônibus lotado passando devagar
# ============================================================

func _build_bus() -> void:

	_bus = Node3D.new()
	_bus.position = Vector3(-20.0, 0, -10.2)
	add_child(_bus)

	var white := _mat(Color(0.94, 0.94, 0.92), 0.4, 0.2)
	var stripe := _mat(Color(0.10, 0.55, 0.28), 0.4, 0.2)
	var yellow := _mat(Color(0.98, 0.80, 0.10), 0.4, 0.2)
	var window_mat := _emit(Color(0.95, 0.80, 0.50), 0.7)
	var dark := _mat(Color(0.08, 0.06, 0.05), 0.8, 0.0)
	var rubber := _mat(Color(0.03, 0.03, 0.04), 0.9, 0.0)

	_box(_bus, Vector3(0, 1.6, 0), Vector3(9.2, 2.6, 2.6), white)
	_box(_bus, Vector3(0, 0.8, 0), Vector3(9.25, 0.35, 2.62), stripe)
	_box(_bus, Vector3(0, 0.55, 0), Vector3(9.25, 0.15, 2.62), yellow)

	for sz in [-1.0, 1.0]:

		var z: float = sz * 1.31
		_no_shadow(_box(_bus, Vector3(0, 2.15, z), Vector3(8.2, 0.9, 0.04), window_mat))

		# gente amontoada nas janelas
		for i in range(16):
			var hx: float = -3.8 + float(i) * 0.5
			var hy: float = 2.0 + (0.12 if i % 2 == 0 else 0.0)
			_sphere(_bus, Vector3(hx, hy, z + sz * 0.03), 0.17, dark)
			_box(_bus, Vector3(hx, hy - 0.28, z + sz * 0.03), Vector3(0.28, 0.35, 0.05), dark)

	for wx in [-3.0, 3.0]:
		for wz in [-1.3, 1.3]:
			_cyl(_bus, Vector3(wx, 0.5, wz), 0.5, 0.3, rubber, Vector3(90, 0, 0), 14)

	_no_shadow(_box(_bus, Vector3(4.6, 0.8, 0.8), Vector3(0.05, 0.16, 0.3), _emit(Color(1.0, 0.95, 0.75), 2.0)))
	_no_shadow(_box(_bus, Vector3(4.6, 0.8, -0.8), Vector3(0.05, 0.16, 0.3), _emit(Color(1.0, 0.95, 0.75), 2.0)))

	# letreiro (troca de texto)
	_box(_bus, Vector3(0, 2.95, 1.32), Vector3(3.6, 0.5, 0.05), dark)
	_bus_label = _label(BUS_TEXTS[0], Vector3(0, 2.95, 1.36), 44, 0.0036, Color(1.0, 0.75, 0.15), Vector3.ZERO, _bus)
	_bus_label.outline_size = 0

	# fumacinha do escapamento
	var puff := _particles(
		Vector3(0, 0, 0), Vector3(0.08, 0.05, 0.08), 20, 1.8,
		Color(0.2, 0.2, 0.22, 0.35), 0.5,
		Vector3(-0.4, 0.5, 0.0), 0.3, 0.6, false, Vector3(-1, 1, 0), 20.0
	)
	puff.get_parent().remove_child(puff)
	_bus.add_child(puff)
	puff.position = Vector3(-4.7, 0.5, 0.9)

	# ônibus parado (fundo esquerdo) — congestionamento
	var parked := Node3D.new()
	parked.position = Vector3(-14.0, 0, -10.2)
	add_child(parked)
	_box(parked, Vector3(0, 1.6, 0), Vector3(9.2, 2.6, 2.6), _mat(Color(0.85, 0.2, 0.2), 0.4, 0.2))
	_box(parked, Vector3(0, 2.15, 1.31), Vector3(8.2, 0.9, 0.04), window_mat)


# ============================================================
# Motoboys costurando o trânsito
# ============================================================

func _make_bike(color: Color, helmet: Color) -> Dictionary:

	var root := Node3D.new()
	add_child(root)

	var dark := _mat(Color(0.06, 0.06, 0.07), 0.6, 0.4)
	var rubber := _mat(Color(0.03, 0.03, 0.04), 0.9, 0.0)
	var wheels: Array = []

	for wx in [-0.55, 0.55]:
		var pivot := Node3D.new()
		pivot.position = Vector3(wx, 0.32, 0)
		root.add_child(pivot)
		_cyl(pivot, Vector3.ZERO, 0.32, 0.12, rubber, Vector3(90, 0, 0), 12)
		_box(pivot, Vector3.ZERO, Vector3(0.5, 0.05, 0.14), _mat(Color(0.7, 0.7, 0.72), 0.3, 0.8))
		wheels.append(pivot)

	_box(root, Vector3(0, 0.55, 0), Vector3(1.0, 0.18, 0.2), _mat(color, 0.3, 0.4))
	_box(root, Vector3(0.45, 0.85, 0), Vector3(0.05, 0.4, 0.05), dark, Vector3(0, 0, -20))
	_box(root, Vector3(0.5, 1.05, 0), Vector3(0.05, 0.05, 0.5), dark)
	_no_shadow(_box(root, Vector3(0.62, 0.7, 0), Vector3(0.05, 0.14, 0.18), _emit(Color(1.0, 0.95, 0.75), 2.2)))

	# piloto
	var body := _mat(Color(0.95, 0.8, 0.1), 0.7, 0.0)
	var torso := _box(root, Vector3(-0.05, 1.05, 0), Vector3(0.3, 0.55, 0.3), body, Vector3(0, 0, -18))
	torso.name = "Torso"
	_box(root, Vector3(-0.15, 0.68, 0.14), Vector3(0.5, 0.14, 0.14), _mat(Color(0.15, 0.2, 0.5), 0.7, 0.0), Vector3(0, 0, 8))
	_box(root, Vector3(-0.15, 0.68, -0.14), Vector3(0.5, 0.14, 0.14), _mat(Color(0.15, 0.2, 0.5), 0.7, 0.0), Vector3(0, 0, 8))
	_sphere(root, Vector3(0.12, 1.42, 0), 0.17, _mat(helmet, 0.3, 0.2))
	_box(root, Vector3(0.24, 1.42, 0), Vector3(0.06, 0.1, 0.24), _mat(Color(0.05, 0.05, 0.08), 0.1, 0.8))

	# baú de entrega
	var box_mat := _mat(Color(0.9, 0.12, 0.10), 0.5, 0.1)
	_box(root, Vector3(-0.65, 1.05, 0), Vector3(0.55, 0.55, 0.55), box_mat)
	_label("FBF\nEXPRESS", Vector3(-0.65, 1.05, 0.29), 40, 0.0028, Color(1.0, 0.95, 0.4), Vector3.ZERO, root).outline_size = 0

	return {"node": root, "wheels": wheels}


func _build_motoboys() -> void:

	var specs := [
		[-20.0, 6.5, 1.0, Color(0.85, 0.1, 0.1), Color(0.95, 0.5, 0.1)],
		[6.0, 5.2, 1.0, Color(0.1, 0.4, 0.85), Color(0.95, 0.95, 0.95)],
		[18.0, 7.2, -1.0, Color(0.2, 0.7, 0.3), Color(0.9, 0.2, 0.2)],
		[-8.0, 5.8, -1.0, Color(0.95, 0.8, 0.1), Color(0.1, 0.1, 0.15)],
	]

	for s in specs:

		var bike: Dictionary = _make_bike(s[3], s[4])
		var node: Node3D = bike["node"]
		var dir: float = s[2]

		node.position = Vector3(float(s[0]), 0.0, -5.55 - (0.0 if dir > 0.0 else 0.0))

		if dir < 0.0:
			node.rotation_degrees = Vector3(0, 180, 0)

		_bikes.append({"node": node, "speed": float(s[1]) * dir, "wheels": bike["wheels"], "phase": _rng.randf_range(0.0, 6.0)})


# ============================================================
# Rio Tietê (com humor)
# ============================================================

func _floater(kind: int, x: float, z: float) -> void:

	var root := Node3D.new()
	root.position = Vector3(x, -0.2, z)
	add_child(root)

	var yellow := _mat(Color(1.0, 0.85, 0.1), 0.4, 0.0)
	var orange := _mat(Color(1.0, 0.5, 0.1), 0.4, 0.0)
	var black := _mat(Color(0.03, 0.03, 0.03), 0.5, 0.0)

	if kind == 0:
		# patinho de borracha gigante
		_sphere(root, Vector3(0, 0.35, 0), 0.6, yellow, Vector3(1.3, 0.95, 1.0))
		_sphere(root, Vector3(0.65, 0.95, 0), 0.34, yellow)
		_box(root, Vector3(1.0, 0.92, 0), Vector3(0.28, 0.08, 0.2), orange)
		_sphere(root, Vector3(0.88, 1.05, 0.2), 0.05, black)
		_sphere(root, Vector3(0.88, 1.05, -0.2), 0.05, black)
	elif kind == 1:
		# pneu
		_torus(root, Vector3(0, 0.18, 0), 0.32, 0.65, black, Vector3(15, 0, 0))
	elif kind == 2:
		# sofá velho boiando
		var fabric := _mat(Color(0.55, 0.25, 0.2), 0.9, 0.0)
		_box(root, Vector3(0, 0.3, 0), Vector3(2.0, 0.5, 0.9), fabric)
		_box(root, Vector3(0, 0.75, -0.35), Vector3(2.0, 0.6, 0.25), fabric)
		_box(root, Vector3(-0.95, 0.55, 0), Vector3(0.2, 0.5, 0.9), fabric)
		_box(root, Vector3(0.95, 0.55, 0), Vector3(0.2, 0.5, 0.9), fabric)
	elif kind == 3:
		# sacola plástica flutuante
		_sphere(root, Vector3(0, 0.25, 0), 0.4, _mat(Color(0.95, 0.95, 0.95), 0.6, 0.0), Vector3(1.0, 0.6, 0.8))
	else:
		# cone de trânsito (o rio também tem trânsito)
		_cone(root, Vector3(0, 0.5, 0), 0.35, 1.0, _mat(Color(1.0, 0.45, 0.1), 0.5, 0.0))
		_box(root, Vector3(0, 0.05, 0), Vector3(0.8, 0.1, 0.8), black)

	_floaters.append({"node": root, "speed": _rng.randf_range(0.25, 0.6), "phase": _rng.randf_range(0.0, 6.0)})


func _build_river() -> void:

	var shader := Shader.new()
	shader.code = WATER_SHADER

	var water := ShaderMaterial.new()
	water.shader = shader

	var mesh := PlaneMesh.new()
	mesh.size = Vector2(150, 46)
	mesh.subdivide_width = 80
	mesh.subdivide_depth = 26

	var sea := MeshInstance3D.new()
	sea.mesh = mesh
	_put(self, sea, Vector3(0, -0.28, -37.0), Vector3.ZERO, water)
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# margem de concreto do outro lado
	_box(self, Vector3(0, -0.1, -60.5), Vector3(150, 0.5, 2.0), _mat(Color(0.55, 0.55, 0.53), 0.9, 0.0))

	_floater(0, -6.0, -17.0)
	_floater(1, 8.0, -19.0)
	_floater(2, -18.0, -22.0)
	_floater(3, 2.0, -16.0)
	_floater(4, 14.0, -24.0)
	_floater(0, 20.0, -27.0)
	_floater(1, -12.0, -29.0)

	# cheirinho verde subindo do rio (caricato)
	_particles(
		Vector3(0, 0.3, -19.0), Vector3(12.0, 0.1, 3.0), 26, 4.0,
		Color(0.5, 0.75, 0.2, 0.18), 1.4,
		Vector3(0.0, 0.25, 0.0), 0.1, 0.25, false, Vector3(0, 1, 0), 15.0
	)

	# passarela de pedestres sobre o rio
	var deck := _mat(Color(0.55, 0.55, 0.55), 0.7, 0.2)
	var rail := _mat(Color(0.2, 0.3, 0.5), 0.5, 0.4)

	_box(self, Vector3(-15.0, 2.2, -27.0), Vector3(2.4, 0.2, 26.0), deck)

	for zz in range(-39, -14, 3):
		_box(self, Vector3(-15.0, 1.1, float(zz)), Vector3(0.4, 2.2, 0.4), deck)
		_box(self, Vector3(-16.1, 3.0, float(zz)), Vector3(0.06, 1.0, 0.06), rail)
		_box(self, Vector3(-13.9, 3.0, float(zz)), Vector3(0.06, 1.0, 0.06), rail)

	_box(self, Vector3(-16.1, 3.5, -27.0), Vector3(0.08, 0.08, 26.0), rail)
	_box(self, Vector3(-13.9, 3.5, -27.0), Vector3(0.08, 0.08, 26.0), rail)


# ============================================================
# Ponte Estaiada: mastro em X, tabuleiros curvos, cabos e LEDs
# ============================================================

func _build_bridge() -> void:

	var root := Node3D.new()
	root.position = Vector3(7.0, -0.2, -33.0)
	root.scale = Vector3(0.62, 0.62, 0.62)
	add_child(root)

	var mast_mat := _emit(Color(0.85, 0.9, 1.0), 1.1)
	var deck_mat := _mat(Color(0.80, 0.80, 0.84), 0.5, 0.2)
	var cable_mat := _emit(Color(0.92, 0.92, 1.0), 0.35)
	var led_mat := _emit(Color(1.0, 0.4, 0.8), 1.8)
	var pier_mat := _mat(Color(0.65, 0.65, 0.68), 0.7, 0.1)

	_bridge_mats.append(mast_mat)
	_bridge_mats.append(led_mat)

	# mastro: duas barras cruzadas (X)
	var ang: float = rad_to_deg(atan2(5.7, 32.0))
	var len_bar: float = sqrt(5.7 * 5.7 + 32.0 * 32.0)

	_box(root, Vector3(-0.55, 16.0, 0), Vector3(1.9, len_bar, 1.9), mast_mat, Vector3(0, 0, -ang))
	_box(root, Vector3(0.55, 16.0, 0), Vector3(1.9, len_bar, 1.9), mast_mat, Vector3(0, 0, ang))

	# tabuleiros (dois, um de cada lado do mastro, se afastando em curva)
	for side in [-1.0, 1.0]:

		var deck_root := Node3D.new()
		deck_root.position = Vector3(0, 8.0, side * 2.6)
		deck_root.rotation_degrees = Vector3(0, -side * 3.0, 0)
		root.add_child(deck_root)

		_box(deck_root, Vector3(0, 0, 0), Vector3(88, 0.9, 3.6), deck_mat)
		_box(deck_root, Vector3(0, -0.8, 0), Vector3(88, 0.7, 2.2), deck_mat)
		_no_shadow(_box(deck_root, Vector3(0, 0.55, side * 1.75), Vector3(88, 0.14, 0.12), led_mat))

	# cabos (fan) nos dois lados e nos dois planos
	for zs in [-1.0, 1.0]:
		for i in range(12):

			var anchor_y: float = 31.0 - float(i) * 0.75
			var t: float = anchor_y / 32.0
			var deck_x: float = 5.0 + float(i) * 3.3

			# direita: âncora na barra que se inclina pra direita
			var ax_r: float = -3.4 + 5.7 * t
			var ax_l: float = 3.4 - 5.7 * t

			_cable(root, Vector3(ax_r, anchor_y, zs * 0.6), Vector3(deck_x, 8.6, zs * 3.6), cable_mat, 0.14)
			_cable(root, Vector3(ax_l, anchor_y, zs * 0.6), Vector3(-deck_x, 8.6, zs * 3.6), cable_mat, 0.14)

	# pilares na água
	for px in [-36.0, 36.0]:
		_box(root, Vector3(px, 3.5, 0), Vector3(3.6, 9.0, 6.0), pier_mat)

	# luz colorida do mastro batendo no rio
	_omni(Vector3(7.0, 10.0, -26.0), Color(0.6, 0.5, 1.0), 2.0, 26.0)


# ============================================================
# Skyline (prédios, caixa-d'água) + trânsito distante na outra margem
# ============================================================

func _build_skyline() -> void:

	var x: float = -64.0
	var idx: int = 0

	while x < 64.0:

		var w: float = _rng.randf_range(5.0, 8.0)
		var h: float = _rng.randf_range(14.0, 42.0)
		var z: float = -66.0 - _rng.randf_range(0.0, 8.0)

		var m := _building_mat(9000 + idx, w, h, Color(0.95, 0.80, 0.72), 0.45)
		_box(self, Vector3(x + w / 2.0, h / 2.0, z), Vector3(w, h, 7.0), m)

		# caixa-d'água no topo de alguns
		if idx % 3 == 0:
			var tank := _mat(Color(0.35, 0.40, 0.48), 0.6, 0.3)
			_cyl(self, Vector3(x + w / 2.0, h + 1.2, z), 1.1, 1.6, tank)
			for lx in [-0.7, 0.7]:
				_box(self, Vector3(x + w / 2.0 + lx, h + 0.4, z), Vector3(0.12, 0.8, 0.12), tank)

		x += w + _rng.randf_range(0.5, 2.5)
		idx += 1

	# prédio com caixa-d'água mais perto (bem à vista)
	var near_m := _building_mat(777, 6.0, 15.0, Color(1.0, 0.85, 0.7), 0.5)
	_box(self, Vector3(-12.0, 7.5, -42.0), Vector3(6.0, 15.0, 6.0), near_m)

	var tank2 := _mat(Color(0.30, 0.45, 0.65), 0.5, 0.2)
	_cyl(self, Vector3(-12.0, 16.5, -42.0), 1.4, 2.0, tank2)
	_cone(self, Vector3(-12.0, 17.8, -42.0), 1.5, 0.6, _mat(Color(0.55, 0.15, 0.12), 0.6, 0.0))

	for lx in [-1.2, 1.2]:
		for lz in [-1.2, 1.2]:
			_box(self, Vector3(-12.0 + lx, 15.4, -42.0 + lz), Vector3(0.14, 1.0, 0.14), tank2)

	_label("CAIXA D'AGUA\nDO SEU ZE", Vector3(-12.0, 16.4, -40.9), 36, 0.0045, Color(1, 1, 1))

	# avenida distante (outra margem) com faróis andando
	_box(self, Vector3(0, -0.05, -61.5), Vector3(150, 0.1, 2.5), _mat(Color(0.14, 0.14, 0.16), 0.8, 0.0))

	for i in range(16):
		var car := Node3D.new()
		car.position = Vector3(-60.0 + float(i) * 7.5, 0.4, -61.0 if i % 2 == 0 else -62.0)
		add_child(car)

		var col: Color = Color(1.0, 0.95, 0.75) if i % 2 == 0 else Color(1.0, 0.15, 0.1)
		_no_shadow(_box(car, Vector3.ZERO, Vector3(1.6, 0.5, 0.7), _emit(col, 1.6)))

		_far_cars.append({"node": car, "speed": (4.0 if i % 2 == 0 else -4.0) * _rng.randf_range(0.7, 1.2)})


# ============================================================
# Grafite gigante do FBF (parede da esquerda)
# ============================================================

func _build_graffiti_wall() -> void:

	var wall_root := Node3D.new()
	wall_root.position = Vector3(-12.6, 0.0, -3.4)
	wall_root.rotation_degrees = Vector3(0, 90, 0)
	add_child(wall_root)

	# muro
	_box(wall_root, Vector3(0, 2.4, -0.2), Vector3(16.0, 4.8, 0.4), _mat(Color(0.75, 0.70, 0.64), 0.95, 0.0))
	_box(wall_root, Vector3(0, 4.9, -0.2), Vector3(16.2, 0.2, 0.5), _mat(Color(0.5, 0.48, 0.45), 0.9, 0.0))

	# painéis de cor do mural
	var panels := [
		[Vector3(-5.2, 2.2, 0.02), Vector2(4.6, 3.6), Color(0.15, 0.55, 0.95)],
		[Vector3(-0.6, 2.4, 0.02), Vector2(4.8, 3.9), Color(0.98, 0.78, 0.12)],
		[Vector3(4.2, 2.2, 0.02), Vector2(5.4, 3.6), Color(0.85, 0.15, 0.55)],
	]

	for p in panels:
		var pos: Vector3 = p[0]
		var sz: Vector2 = p[1]
		var col: Color = p[2]
		_box(wall_root, pos, Vector3(sz.x, sz.y, 0.03), _mat(col, 0.8, 0.0))

	# luva de boxe grafitada (vermelha) com contorno
	var outline := _mat(Color(0.03, 0.03, 0.05), 0.8, 0.0)
	var red := _mat(Color(0.9, 0.12, 0.12), 0.5, 0.0)

	_sphere(wall_root, Vector3(-0.6, 2.5, 0.06), 1.55, outline, Vector3(1.0, 1.0, 0.06))
	_sphere(wall_root, Vector3(-0.6, 2.5, 0.09), 1.4, red, Vector3(1.0, 1.0, 0.06))
	_sphere(wall_root, Vector3(0.55, 2.2, 0.11), 0.6, red, Vector3(1.0, 1.0, 0.06))
	_box(wall_root, Vector3(-0.6, 1.0, 0.1), Vector3(1.6, 0.7, 0.05), _mat(Color(0.95, 0.95, 0.95), 0.6, 0.0))

	# letras
	_label("FBF", Vector3(-0.6, 3.9, 0.14), 200, 0.0085, Color(1.0, 0.95, 0.3), Vector3.ZERO, wall_root).outline_size = 26
	_label("LIPE 67", Vector3(-5.2, 2.2, 0.08), 120, 0.006, Color(1, 1, 1), Vector3(0, 0, 8), wall_root).outline_size = 20
	_label("SP\nÉ NÓIS", Vector3(4.2, 2.6, 0.08), 110, 0.006, Color(1.0, 0.95, 0.4), Vector3(0, 0, -6), wall_root).outline_size = 20

	# estrelas e raios
	var star := _emit(Color(1.0, 0.95, 0.4), 1.0)

	for i in range(9):
		_sphere(wall_root, Vector3(-7.4 + float(i) * 1.7, 4.3 - float(i % 3) * 0.2, 0.09), 0.13, star, Vector3(1, 1, 0.3))

	_box(wall_root, Vector3(2.4, 1.4, 0.1), Vector3(0.25, 1.6, 0.05), _mat(Color(1.0, 0.95, 0.2), 0.5, 0.0), Vector3(0, 0, 25))

	# pichações pequenas
	_label("VAI LOGO", Vector3(-7.2, 0.7, 0.05), 60, 0.0045, Color(0.05, 0.05, 0.05), Vector3(0, 0, 4), wall_root).outline_size = 0
	_label("TA PAGO", Vector3(7.2, 0.6, 0.05), 60, 0.0045, Color(0.05, 0.05, 0.05), Vector3(0, 0, -5), wall_root).outline_size = 0


# ============================================================
# Direita: lanchonete, banca, vendedor ambulante
# ============================================================

func _build_right_side() -> void:

	# ---------- lanchonete de esquina ----------
	var shop := Node3D.new()
	shop.position = Vector3(13.6, 0.0, -1.6)
	shop.rotation_degrees = Vector3(0, -90, 0)
	add_child(shop)

	_box(shop, Vector3(0, 1.9, -1.6), Vector3(7.0, 3.8, 3.2), _mat(Color(0.98, 0.78, 0.18), 0.7, 0.0))
	_box(shop, Vector3(0, 1.2, 0.0), Vector3(5.2, 2.4, 0.15), _mat(Color(0.30, 0.20, 0.12), 0.6, 0.0))
	_no_shadow(_box(shop, Vector3(0, 1.4, 0.05), Vector3(4.4, 1.3, 0.05), _emit(Color(1.0, 0.85, 0.5), 0.8)))

	# toldo listrado
	for i in range(8):
		var c: Color = Color(0.9, 0.1, 0.1) if i % 2 == 0 else Color(0.97, 0.97, 0.97)
		_box(shop, Vector3(-3.15 + float(i) * 0.9, 2.75, 0.6), Vector3(0.9, 0.06, 1.5), _mat(c, 0.8, 0.0), Vector3(-14, 0, 0))

	_box(shop, Vector3(0, 3.3, 0.06), Vector3(5.6, 0.8, 0.1), _mat(Color(0.75, 0.08, 0.08), 0.5, 0.0))
	_label("LANCHONETE DO ZÉ", Vector3(0, 3.3, 0.13), 70, 0.0052, Color(1.0, 0.95, 0.5), Vector3.ZERO, shop).outline_size = 10
	_label("PASTEL • COXINHA • CALDO DE CANA", Vector3(0, 2.2, 0.08), 34, 0.0038, Color(0.98, 0.95, 0.85), Vector3.ZERO, shop).outline_size = 6

	# letreiro "ABERTO" piscando
	_open_mat = _emit(Color(0.3, 1.0, 0.4), 2.0)
	_no_shadow(_box(shop, Vector3(2.2, 1.2, 0.09), Vector3(0.9, 0.35, 0.04), _open_mat))
	_label("ABERTO", Vector3(2.2, 1.2, 0.12), 34, 0.0032, Color(0.02, 0.15, 0.05), Vector3.ZERO, shop).outline_size = 0

	# mesinhas com guarda-sol
	for tx in [-1.8, 0.4]:
		_cyl(shop, Vector3(tx, 0.7, 1.6), 0.35, 0.05, _mat(Color(0.9, 0.9, 0.9), 0.5, 0.2))
		_cyl(shop, Vector3(tx, 0.35, 1.6), 0.04, 0.7, _mat(Color(0.3, 0.3, 0.3), 0.5, 0.6))
		_cone(shop, Vector3(tx, 1.7, 1.6), 0.8, 0.3, _mat(Color(0.1, 0.5, 0.9), 0.8, 0.0), Vector3.ZERO, 8)
		_cyl(shop, Vector3(tx, 0.85, 1.6), 0.02, 1.7, _mat(Color(0.8, 0.8, 0.8), 0.5, 0.5))

	# ---------- banca de jornal (teto serve de "lugar inesperado" p/ o caramelo) ----------
	var banca := Node3D.new()
	banca.position = Vector3(8.6, 0.0, -3.7)
	add_child(banca)

	_box(banca, Vector3(0, 1.1, 0), Vector3(2.4, 2.2, 1.5), _mat(Color(0.12, 0.45, 0.30), 0.6, 0.0))
	_box(banca, Vector3(0, 2.28, 0.0), Vector3(2.7, 0.14, 1.8), _mat(Color(0.95, 0.75, 0.1), 0.5, 0.0))

	# revistas coloridas na frente
	for r in range(3):
		for c in range(7):
			var col := Color.from_hsv(_rng.randf(), 0.7, 0.95)
			_box(banca, Vector3(-0.95 + float(c) * 0.32, 1.9 - float(r) * 0.42, 0.78), Vector3(0.26, 0.34, 0.02), _mat(col, 0.6, 0.0))

	_label("BANCA DO SEU JOSÉ", Vector3(0, 2.62, 0.92), 40, 0.0042, Color(1, 1, 1), Vector3.ZERO, banca).outline_size = 8
	_label("TEM ÁLBUM DE FIGURINHA", Vector3(0, 0.55, 0.8), 30, 0.0034, Color(1.0, 0.95, 0.5), Vector3.ZERO, banca).outline_size = 6

	# ---------- vendedor ambulante ----------
	var cart := Node3D.new()
	cart.position = Vector3(5.6, 0.0, -3.9)
	add_child(cart)

	_box(cart, Vector3(0, 0.7, 0), Vector3(1.4, 0.7, 0.8), _mat(Color(0.85, 0.85, 0.9), 0.5, 0.3))
	_box(cart, Vector3(0, 0.36, 0), Vector3(1.5, 0.06, 0.9), _mat(Color(0.3, 0.3, 0.32), 0.5, 0.5))

	for wx in [-0.55, 0.55]:
		_cyl(cart, Vector3(wx, 0.24, 0.45), 0.22, 0.08, _mat(Color(0.05, 0.05, 0.05), 0.8, 0.0), Vector3(90, 0, 0), 12)

	_cyl(cart, Vector3(0, 1.9, 0), 0.03, 1.5, _mat(Color(0.8, 0.8, 0.8), 0.5, 0.5))

	_cone(cart, Vector3(0, 2.6, 0), 1.15, 0.5, _mat(Color(1.0, 0.3, 0.2), 0.8, 0.0), Vector3.ZERO, 8)
	_cone(cart, Vector3(0, 2.66, 0), 0.7, 0.42, _mat(Color(1.0, 0.9, 0.2), 0.8, 0.0), Vector3.ZERO, 8)

	_label("ÁGUA GELADA R$2", Vector3(0, 1.0, 0.44), 38, 0.0034, Color(0.1, 0.2, 0.6), Vector3.ZERO, cart).outline_size = 0

	# o vendedor
	var man := Node3D.new()
	man.position = Vector3(-1.1, 0.0, 0.1)
	cart.add_child(man)

	_box(man, Vector3(0, 0.45, 0), Vector3(0.28, 0.9, 0.2), _mat(Color(0.2, 0.3, 0.5), 0.8, 0.0))
	_box(man, Vector3(0, 1.15, 0), Vector3(0.4, 0.6, 0.26), _mat(Color(0.9, 0.35, 0.2), 0.8, 0.0))
	_sphere(man, Vector3(0, 1.62, 0), 0.19, _mat(Color(0.65, 0.45, 0.32), 0.6, 0.0))
	_sphere(man, Vector3(0, 1.75, 0), 0.19, _mat(Color(0.1, 0.4, 0.8), 0.6, 0.0), Vector3(1.0, 0.55, 1.0))

	_vendor_arm = Node3D.new()
	_vendor_arm.position = Vector3(0.24, 1.4, 0)
	man.add_child(_vendor_arm)
	_box(_vendor_arm, Vector3(0, 0.25, 0), Vector3(0.11, 0.55, 0.11), _mat(Color(0.65, 0.45, 0.32), 0.6, 0.0))


# ============================================================
# Ponto de ônibus
# ============================================================

func _build_bus_stop() -> void:

	var root := Node3D.new()
	root.position = Vector3(-8.2, 0.0, -4.0)
	add_child(root)

	var metal := _mat(Color(0.2, 0.22, 0.28), 0.5, 0.6)
	var glass := _mat(Color(0.6, 0.8, 0.95, 0.35), 0.05, 0.1)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

	for sx in [-1.5, 1.5]:
		_box(root, Vector3(sx, 1.2, -0.4), Vector3(0.1, 2.4, 0.1), metal)

	_box(root, Vector3(0, 2.45, -0.1), Vector3(3.4, 0.12, 1.3), _mat(Color(0.9, 0.2, 0.2), 0.5, 0.2))
	_box(root, Vector3(0, 1.2, -0.45), Vector3(3.0, 2.0, 0.04), glass)
	_box(root, Vector3(0, 0.5, -0.15), Vector3(2.4, 0.08, 0.4), _mat(Color(0.5, 0.35, 0.2), 0.7, 0.0))

	_sign_board(Vector3(-6.2, 0.0, -3.7), Vector2(1.5, 1.1), Color(0.1, 0.4, 0.85), "PONTO 6767\nÔNIBUS: CHEGA\nQUANDO CHEGAR", Color(1, 1, 1), 26, 2.2)

	# gente esperando (há horas)
	var cols := [Color(0.9, 0.3, 0.3), Color(0.3, 0.6, 0.9)]

	for i in range(2):
		var p := Node3D.new()
		p.position = Vector3(-0.5 + float(i) * 0.9, 0.0, -0.1)
		root.add_child(p)
		_box(p, Vector3(0, 0.45, 0), Vector3(0.26, 0.9, 0.2), _mat(Color(0.2, 0.2, 0.3), 0.8, 0.0))
		_box(p, Vector3(0, 1.1, 0), Vector3(0.36, 0.5, 0.24), _mat(cols[i], 0.8, 0.0))
		_sphere(p, Vector3(0, 1.5, 0), 0.17, _mat(Color(0.8, 0.6, 0.45), 0.6, 0.0))


# ============================================================
# Postes, fios embolados e um tênis pendurado
# ============================================================

func _build_poles_and_wires() -> void:

	var pole_mat := _mat(Color(0.40, 0.36, 0.33), 0.9, 0.0)
	var wire_mat := _mat(Color(0.03, 0.03, 0.04), 0.7, 0.0)
	var xs := [-10.0, -2.4, 4.6, 11.6]
	var z: float = -4.95

	for px in xs:

		var x: float = px

		_cyl(self, Vector3(x, 4.0, z), 0.11, 8.0, pole_mat)
		_box(self, Vector3(x, 7.5, z), Vector3(2.0, 0.1, 0.1), pole_mat)
		_box(self, Vector3(x, 6.7, z), Vector3(1.6, 0.1, 0.1), pole_mat)
		_cyl(self, Vector3(x + 0.3, 6.0, z), 0.22, 0.5, _mat(Color(0.35, 0.4, 0.42), 0.5, 0.4))
		_cyl(self, Vector3(x - 0.3, 5.2, z), 0.16, 0.4, _mat(Color(0.35, 0.4, 0.42), 0.5, 0.4))

	# fios: vários por vão, cada um com caimento diferente
	for i in range(xs.size() - 1):
		var x0: float = xs[i]
		var x1: float = xs[i + 1]
		for k in range(6):
			var y: float = 7.5 if k < 3 else 6.7
			var dz: float = -0.12 + float(k % 3) * 0.12
			_wire(Vector3(x0 + (float(k % 3) - 1.0) * 0.8, y, z + dz), Vector3(x1 + (float(k % 3) - 1.0) * 0.8, y, z + dz), 0.35 + float(k) * 0.12, wire_mat)

	# fios soltos "bagunçados" descendo
	_wire(Vector3(xs[1], 6.7, z), Vector3(xs[1] + 1.4, 3.6, z + 0.5), 0.4, wire_mat)
	_wire(Vector3(xs[2], 7.5, z), Vector3(xs[2] - 1.6, 4.2, z + 0.6), 0.5, wire_mat)

	# tênis pendurado nos fios (clássico)
	var lace := _mat(Color(0.9, 0.9, 0.9), 0.6, 0.0)

	for sx in [-0.2, 0.2]:
		_cyl(self, Vector3(1.1 + sx, 6.55, z), 0.008, 0.5, wire_mat)
		_box(self, Vector3(1.1 + sx, 6.2, z), Vector3(0.14, 0.12, 0.3), _mat(Color(0.95, 0.35, 0.15), 0.6, 0.0))
		_box(self, Vector3(1.1 + sx, 6.14, z), Vector3(0.15, 0.04, 0.32), lace)

	# fio com pipa presa
	_wire(Vector3(xs[0], 7.5, z), Vector3(xs[0] - 1.0, 5.0, z + 0.3), 0.2, wire_mat)
	_box(self, Vector3(xs[0] - 1.0, 4.6, z + 0.3), Vector3(0.5, 0.6, 0.02), _mat(Color(0.9, 0.2, 0.5), 0.8, 0.0), Vector3(0, 0, 40))


# ============================================================
# Semáforo (ciclo verde/amarelo/vermelho)
# ============================================================

func _build_traffic_light() -> void:

	var metal := _mat(Color(0.12, 0.12, 0.14), 0.5, 0.6)
	var x: float = 2.0
	var z: float = -4.6

	_cyl(self, Vector3(x, 1.8, z), 0.06, 3.6, metal)
	_box(self, Vector3(x, 3.4, z), Vector3(0.36, 1.05, 0.32), metal)

	var colors := [Color(1.0, 0.1, 0.1), Color(1.0, 0.85, 0.1), Color(0.2, 1.0, 0.3)]

	for i in range(3):
		var m := _emit(colors[i], 0.2)
		_no_shadow(_sphere(self, Vector3(x, 3.7 - float(i) * 0.32, z + 0.17), 0.12, m))
		_tl_mats.append(m)


# ============================================================
# Placas engraçadas (memes brasileiros originais)
# ============================================================

func _build_signs() -> void:

	# placa dos "10 minutos sem trânsito"
	_sign_10min = _sign_board(Vector3(-4.0, 0.0, -4.55), Vector2(3.3, 1.3), Color(0.98, 0.82, 0.10), "SÃO PAULO:\n10 MINUTOS SEM TRÂNSITO", Color(0.05, 0.05, 0.05), 44, 2.1)

	# caramelo em serviço
	_sign_board(Vector3(11.2, 0.0, -4.55), Vector2(2.7, 1.0), Color(0.10, 0.40, 0.85), "ATENÇÃO:\nCARAMELO EM SERVIÇO", Color(1, 1, 1), 40, 2.1)

	# limite de velocidade "na teoria"
	var sp := Node3D.new()
	sp.position = Vector3(-0.2, 0.0, -4.6)
	add_child(sp)
	_cyl(sp, Vector3(0, 1.3, 0), 0.04, 2.6, _mat(Color(0.3, 0.3, 0.32), 0.5, 0.6))
	_cyl(sp, Vector3(0, 2.75, 0.03), 0.42, 0.05, _mat(Color(0.9, 0.05, 0.05), 0.5, 0.0), Vector3(90, 0, 0), 24)
	_cyl(sp, Vector3(0, 2.75, 0.06), 0.32, 0.05, _mat(Color(0.98, 0.98, 0.98), 0.5, 0.0), Vector3(90, 0, 0), 24)
	_label("40", Vector3(0, 2.78, 0.1), 70, 0.0042, Color(0.05, 0.05, 0.05), Vector3.ZERO, sp).outline_size = 0
	_box(sp, Vector3(0, 2.2, 0.03), Vector3(1.1, 0.34, 0.03), _mat(Color(0.98, 0.98, 0.98), 0.5, 0.0))
	_label("(NA TEORIA)", Vector3(0, 2.2, 0.06), 30, 0.0032, Color(0.05, 0.05, 0.05), Vector3.ZERO, sp).outline_size = 0

	# placa Marginal Tietê (verde de rodovia) na outra ponta da rua
	_sign_board(Vector3(10.0, 0.0, -11.7), Vector2(5.2, 1.8), Color(0.05, 0.45, 0.25), "MARGINAL TIETÊ  ->\nKm 67", Color(1, 1, 1), 60, 3.4)
	_sign_board(Vector3(10.0, 2.85, -11.66), Vector2(4.4, 0.6), Color(0.05, 0.45, 0.25), "(a ponte é do Pinheiros, deixa quieto)", Color(1.0, 0.95, 0.4), 26, 0.0)

	# placa do rio
	_sign_board(Vector3(-2.0, 0.0, -13.0), Vector2(3.6, 1.3), Color(0.95, 0.95, 0.90), "RIO TIETÊ\nCHEIRO INCLUSO", Color(0.1, 0.35, 0.1), 40, 1.5, 0.0)
	_sign_board(Vector3(3.4, 0.0, -13.0), Vector2(3.0, 1.0), Color(0.85, 0.10, 0.10), "PROIBIDO NADAR\n(E RESPIRAR)", Color(1, 1, 1), 36, 1.5, 0.0)

	# estacionamento proibido... mas quem vai parar?
	_sign_board(Vector3(13.0, 0.0, -11.5), Vector2(3.0, 1.0), Color(0.1, 0.25, 0.7), "PROIBIDO ESTACIONAR\n(MAS QUEM VAI PARAR?)", Color(1, 1, 1), 30, 1.8)

	# outdoor absurdo
	var bb := Node3D.new()
	bb.position = Vector3(-4.0, 0.0, -12.0)
	add_child(bb)

	for sx in [-3.2, 3.2]:
		_cyl(bb, Vector3(sx, 2.7, 0), 0.12, 5.4, _mat(Color(0.25, 0.25, 0.28), 0.5, 0.6))

	_box(bb, Vector3(0, 6.2, 0), Vector3(8.6, 3.4, 0.2), _mat(Color(0.2, 0.2, 0.22), 0.5, 0.5))
	_box(bb, Vector3(0, 6.2, 0.11), Vector3(8.2, 3.0, 0.05), _emit(Color(0.85, 0.15, 0.55), 0.8))
	_label("PACIÊNCIA 500mg", Vector3(0, 6.8, 0.16), 110, 0.0062, Color(1.0, 0.95, 0.3), Vector3.ZERO, bb).outline_size = 14
	_label("o remédio oficial de quem pegou a Marginal", Vector3(0, 5.95, 0.16), 44, 0.0046, Color(1, 1, 1), Vector3.ZERO, bb).outline_size = 8
	_label("Ao volante: tome 2 comprimidos e respire", Vector3(0, 5.3, 0.16), 34, 0.0042, Color(1.0, 0.85, 0.9), Vector3.ZERO, bb).outline_size = 6


# ============================================================
# Pedestres andando na calçada
# ============================================================

func _build_people() -> void:

	var shirts := [
		Color(0.9, 0.25, 0.2), Color(0.2, 0.55, 0.9), Color(0.95, 0.8, 0.15),
		Color(0.3, 0.75, 0.4), Color(0.7, 0.3, 0.85), Color(0.95, 0.95, 0.95),
	]
	var skins := [Color(0.95, 0.76, 0.62), Color(0.76, 0.56, 0.42), Color(0.52, 0.36, 0.26), Color(0.36, 0.25, 0.19)]

	for i in range(8):

		var p := Node3D.new()
		var dir: float = 1.0 if i % 2 == 0 else -1.0

		p.position = Vector3(-14.0 + float(i) * 3.6, 0.0, -3.85 - float(i % 3) * 0.28)
		p.rotation_degrees = Vector3(0, 0 if dir > 0.0 else 180, 0)
		add_child(p)

		var legs: Array = []

		for lz in [-0.08, 0.08]:
			var pivot := Node3D.new()
			pivot.position = Vector3(0, 0.85, lz)
			p.add_child(pivot)
			_box(pivot, Vector3(0, -0.4, 0), Vector3(0.14, 0.8, 0.14), _mat(Color(0.2, 0.22, 0.32), 0.8, 0.0))
			legs.append(pivot)

		_box(p, Vector3(0, 1.15, 0), Vector3(0.24, 0.6, 0.34), _mat(shirts[_rng.randi() % shirts.size()], 0.8, 0.0))
		_sphere(p, Vector3(0, 1.62, 0), 0.17, _mat(skins[_rng.randi() % skins.size()], 0.6, 0.0))

		_peds.append({"node": p, "legs": legs, "speed": _rng.randf_range(0.6, 1.1) * dir, "phase": _rng.randf_range(0.0, 6.0)})


# ============================================================
# O CACHORRO CARAMELO — dono oficial da arena (de coroa)
# ============================================================

func _build_dog() -> void:

	_dog = Node3D.new()
	_dog.position = Vector3(-6.4, 0.0, -4.35)
	add_child(_dog)

	var fur := _mat(Color(0.86, 0.55, 0.24), 0.85, 0.0)
	var fur_dark := _mat(Color(0.62, 0.36, 0.15), 0.85, 0.0)
	var cream := _mat(Color(0.97, 0.84, 0.60), 0.85, 0.0)
	var black := _mat(Color(0.03, 0.03, 0.03), 0.4, 0.0)
	var white := _mat(Color(1, 1, 1), 0.4, 0.0)
	var gold := _mat(Color(1.0, 0.8, 0.2), 0.3, 0.7)

	# o cachorro olha pra +X; o grupo do corpo inclina ao sentar
	_dog_body = Node3D.new()
	_dog_body.position = Vector3(0, 0, 0)
	_dog.add_child(_dog_body)

	_sphere(_dog_body, Vector3(0, 0.45, 0), 0.3, fur, Vector3(1.55, 0.95, 0.9))
	_sphere(_dog_body, Vector3(0.25, 0.38, 0), 0.24, cream, Vector3(1.0, 0.9, 0.85))

	# cabeça
	_dog_head = Node3D.new()
	_dog_head.position = Vector3(0.5, 0.68, 0)
	_dog_body.add_child(_dog_head)

	_sphere(_dog_head, Vector3.ZERO, 0.2, fur)
	_sphere(_dog_head, Vector3(0.17, -0.05, 0), 0.11, cream, Vector3(1.4, 0.85, 0.95))
	_sphere(_dog_head, Vector3(0.3, -0.02, 0), 0.045, black)

	for sz in [-1.0, 1.0]:
		_sphere(_dog_head, Vector3(0.12, 0.07, sz * 0.09), 0.036, black)
		_sphere(_dog_head, Vector3(0.14, 0.085, sz * 0.09), 0.012, white)
		var ear := _sphere(_dog_head, Vector3(-0.02, 0.1, sz * 0.17), 0.1, fur_dark, Vector3(0.45, 1.25, 0.8))
		ear.rotation_degrees = Vector3(sz * 18.0, 0, 0)

	# língua (aparece quando ofegante)
	_dog_tongue = Node3D.new()
	_dog_tongue.position = Vector3(0.27, -0.13, 0)
	_dog_head.add_child(_dog_tongue)
	_box(_dog_tongue, Vector3.ZERO, Vector3(0.05, 0.1, 0.06), _mat(Color(1.0, 0.45, 0.55), 0.5, 0.0))

	# COROA (dono da arena)
	_cone(_dog_head, Vector3(-0.02, 0.27, 0), 0.11, 0.14, gold, Vector3.ZERO, 5)
	for k in range(5):
		var a: float = float(k) * TAU / 5.0
		_sphere(_dog_head, Vector3(-0.02 + cos(a) * 0.09, 0.35, sin(a) * 0.09), 0.02, gold)

	# rabo
	_dog_tail = Node3D.new()
	_dog_tail.position = Vector3(-0.45, 0.55, 0)
	_dog_body.add_child(_dog_tail)
	_box(_dog_tail, Vector3(-0.15, 0.08, 0), Vector3(0.36, 0.07, 0.07), fur, Vector3(0, 0, 25))

	# patas
	var leg_defs := [
		Vector3(0.28, 0.32, 0.13), Vector3(0.28, 0.32, -0.13),
		Vector3(-0.28, 0.32, 0.13), Vector3(-0.28, 0.32, -0.13),
	]

	for ld in leg_defs:
		var pivot := Node3D.new()
		pivot.position = ld
		_dog.add_child(pivot)
		_box(pivot, Vector3(0, -0.15, 0), Vector3(0.1, 0.32, 0.1), fur)
		_sphere(pivot, Vector3(0, -0.31, 0.01), 0.06, cream, Vector3(1.2, 0.7, 1.0))
		_dog_legs.append(pivot)

	# Zzz
	_dog_zzz = _label("Z z z", Vector3(0.3, 1.1, 0), 48, 0.006, Color(0.9, 0.95, 1.0), Vector3.ZERO, _dog)
	_dog_zzz.visible = false

	# almofada vermelha do "trono" + plaquinha (fica sempre lá, mesmo sem ele)
	_box(self, Vector3(-6.4, 0.06, -4.35), Vector3(1.0, 0.12, 0.8), _mat(Color(0.75, 0.10, 0.20), 0.9, 0.0))
	_sign_board(Vector3(-6.4, 0.0, -4.95), Vector2(1.8, 0.5), Color(0.98, 0.85, 0.2), "PROPRIEDADE DO CARAMELO", Color(0.1, 0.05, 0.02), 20, 0.7)

	_dog_state = "sit"
	_dog_timer = 3.0


func _dog_face(target: Vector3) -> void:

	var dx: float = target.x - _dog.position.x
	var dz: float = target.z - _dog.position.z

	_dog.rotation.y = lerp_angle(_dog.rotation.y, atan2(-dz, dx), 0.1)


func _pick_dog_state() -> void:

	var r: float = _rng.randf()

	if r < 0.40:
		_dog_state = "sit"
		_dog_timer = _rng.randf_range(6.0, 10.0)
	elif r < 0.75:
		_dog_state = "walk"
		_dog_timer = _rng.randf_range(4.0, 8.0)
		var tx: float = _rng.randf_range(-10.0, 10.0)
		_dog_target = Vector3(tx, 0.0, -4.35)
	else:
		_dog_state = "lie"
		_dog_timer = _rng.randf_range(8.0, 14.0)


func _update_dog(t: float, dt: float) -> void:

	if _dog == null:
		return

	# animações pontuais (evento do caramelo em lugar inesperado) mandam no cachorro
	if _dog_busy:
		_dog_wag(t, 12.0)
		return

	_dog_timer -= dt

	if _dog_timer <= 0.0:
		_pick_dog_state()

	var watch := Vector3(0.0, 0.0, -2.2)
	var walking: bool = false
	var sitting: bool = false
	var lying: bool = false

	match _dog_state:

		"walk":
			var to: Vector3 = _dog_target - _dog.position
			to.y = 0.0

			if to.length() < 0.15:
				_dog_timer = 0.0
			else:
				var step: Vector3 = to.normalized() * 1.1 * dt
				_dog.position += step
				_dog.rotation.y = lerp_angle(_dog.rotation.y, atan2(-to.z, to.x), 0.15)
				walking = true

		"sit":
			_dog_face(watch)
			sitting = true

		"lie":
			_dog_face(watch)
			lying = true

	# ---- poses ----
	var body_rot: float = 0.0
	var body_y: float = 0.0
	var hind: float = 0.0
	var front: float = 0.0

	if walking:
		var s: float = sin(t * 9.0)
		_dog_legs[0].rotation.z = s * 0.6
		_dog_legs[1].rotation.z = -s * 0.6
		_dog_legs[2].rotation.z = -s * 0.6
		_dog_legs[3].rotation.z = s * 0.6
		body_y = absf(sin(t * 9.0)) * 0.03
	elif sitting:
		body_rot = 28.0
		body_y = -0.02
		hind = 1.2
		_dog_legs[0].rotation.z = 0.0
		_dog_legs[1].rotation.z = 0.0
		_dog_legs[2].rotation.z = hind
		_dog_legs[3].rotation.z = hind
	elif lying:
		body_y = -0.22
		for i in range(4):
			var leg: Node3D = _dog_legs[i]
			leg.rotation.z = 1.4 if i < 2 else 1.2
			leg.position.y = 0.16

	if not lying:
		for i in range(4):
			var leg2: Node3D = _dog_legs[i]
			leg2.position.y = 0.32

	_dog_body.position.y = body_y
	_dog_body.rotation_degrees.z = body_rot

	# cabeça: olha pra luta quando sentado; cai no chão quando dorme
	if lying:
		_dog_head.rotation_degrees.z = -35.0
		_dog_head.position = Vector3(0.5, 0.42, 0)
		_dog_zzz.visible = true
		_dog_zzz.position.y = 0.95 + sin(t * 1.5) * 0.08
	else:
		_dog_head.rotation_degrees.z = 0.0
		_dog_head.position = Vector3(0.5, 0.68, 0)
		_dog_head.rotation_degrees.y = sin(t * 0.7) * 12.0 if sitting else 0.0
		_dog_zzz.visible = false

	_dog_tongue.visible = walking or (sitting and sin(t * 2.0) > 0.2)

	_dog_wag(t, 14.0 if not lying else 2.0)


func _dog_wag(t: float, speed: float) -> void:

	if _dog_tail:
		_dog_tail.rotation_degrees.y = sin(t * speed) * 35.0


# ============================================================
# Atualização geral (trânsito, ônibus, motoboys, rio, ponte...)
# ============================================================

func _update_world(t: float, dt: float) -> void:

	# carros do congestionamento: anda-e-para bem devagarinho
	for c in _creepers:
		var n: Node3D = c["node"]
		var phase: float = c["phase"]
		var k: float = 0.5 + 0.5 * sin(t * 0.35 + phase)
		n.position.x = float(c["base"]) + k * 0.9

	# carro que não sai do lugar: treme e "patina"
	if _stuck_car:
		_stuck_car.position.z = -6.7 + sin(t * 40.0) * 0.012
		_stuck_car.rotation_degrees.z = sin(t * 33.0) * 0.5

	# ônibus lotado: passa lento e troca o letreiro
	if _bus:
		_bus.position.x += dt * 0.9
		if _bus.position.x > 34.0:
			_bus.position.x = -34.0

		_bus_text_t += dt
		if _bus_text_t > 4.0:
			_bus_text_t = 0.0
			_bus_text_idx = (_bus_text_idx + 1) % BUS_TEXTS.size()
			if _bus_label:
				_bus_label.text = BUS_TEXTS[_bus_text_idx]

	# motoboys costurando
	for b in _bikes:
		var node: Node3D = b["node"]
		var sp: float = b["speed"]
		node.position.x += dt * sp
		node.position.y = absf(sin(t * 12.0 + float(b["phase"]))) * 0.02

		if node.position.x > 28.0:
			node.position.x = -28.0
		elif node.position.x < -28.0:
			node.position.x = 28.0

		for w in b["wheels"]:
			var wheel: Node3D = w
			wheel.rotation.z -= dt * absf(sp) * 3.0

	# pedestres
	for p in _peds:
		var pn: Node3D = p["node"]
		var ps: float = p["speed"]
		pn.position.x += dt * ps

		if pn.position.x > 15.0:
			pn.position.x = -15.0
		elif pn.position.x < -15.0:
			pn.position.x = 15.0

		var swing: float = sin(t * 6.0 + float(p["phase"])) * 0.6
		var lg: Array = p["legs"]
		var l0: Node3D = lg[0]
		var l1: Node3D = lg[1]
		l0.rotation.z = swing
		l1.rotation.z = -swing
		pn.position.y = absf(swing) * 0.02

	# coisas boiando no rio (vão à deriva e balançam)
	for f in _floaters:
		var fn: Node3D = f["node"]
		fn.position.x += dt * float(f["speed"])

		if fn.position.x > 36.0:
			fn.position.x = -36.0

		fn.position.y = -0.2 + sin(t * 1.2 + float(f["phase"])) * 0.05
		fn.rotation_degrees.z = sin(t * 0.9 + float(f["phase"])) * 4.0

	# trânsito distante na outra margem
	for fc in _far_cars:
		var cn: Node3D = fc["node"]
		cn.position.x += dt * float(fc["speed"])

		if cn.position.x > 62.0:
			cn.position.x = -62.0
		elif cn.position.x < -62.0:
			cn.position.x = 62.0

	# LEDs da Ponte Estaiada mudam de cor
	for i in range(_bridge_mats.size()):
		var m: StandardMaterial3D = _bridge_mats[i]
		var c := Color.from_hsv(fmod(t * 0.05 + float(i) * 0.3, 1.0), 0.55, 1.0)
		m.emission = c
		m.albedo_color = c

	# semáforo: verde -> amarelo -> vermelho
	var cycle: float = fmod(t, 10.0)
	var idx_on: int = 2 if cycle < 4.5 else (1 if cycle < 5.5 else 0)

	for i in range(_tl_mats.size()):
		var sm: StandardMaterial3D = _tl_mats[i]
		sm.emission_energy_multiplier = 3.0 if i == idx_on else 0.15

	# "ABERTO" piscando
	if _open_mat:
		_open_mat.emission_energy_multiplier = 2.4 if fmod(t, 1.6) < 1.1 else 0.3

	# vendedor acenando
	if _vendor_arm:
		_vendor_arm.rotation_degrees.z = -40.0 + sin(t * 5.0) * 30.0

	# eventos aleatórios (só visuais, sempre no fundo)
	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(9.0, 18.0)
		_fire_random_event()


# ============================================================
# Eventos aleatórios ocasionais
# ============================================================

func _fire_random_event() -> void:

	var r: int = _rng.randi() % 6

	match r:
		0, 1:
			_ev_honk()
		2:
			_ev_dog_roof()
		3:
			_ev_helicopter()
		4:
			_ev_sign_glitch()
		5:
			_ev_bus_horn()


func _ev_honk() -> void:

	if _jam_cars.is_empty():
		return

	var car: Node3D = _jam_cars[_rng.randi() % _jam_cars.size()]
	var p: Vector3 = car.position + Vector3(0, 2.0, 0)

	_pop_label(HONKS[_rng.randi() % HONKS.size()], p, Color(1.0, 0.85, 0.2), 64)

	var tw := create_tween()
	tw.tween_property(car, "rotation_degrees:z", 2.0, 0.06)
	tw.tween_property(car, "rotation_degrees:z", -2.0, 0.06)
	tw.tween_property(car, "rotation_degrees:z", 2.0, 0.06)
	tw.tween_property(car, "rotation_degrees:z", 0.0, 0.08)


func _ev_bus_horn() -> void:

	if _bus == null:
		return

	_pop_label("PÓÓÓÓÓ!", _bus.position + Vector3(2.0, 4.2, 0), Color(1.0, 0.5, 0.3), 80)

	var tw := create_tween()
	tw.tween_property(_bus, "rotation_degrees:z", 1.0, 0.07)
	tw.tween_property(_bus, "rotation_degrees:z", -1.0, 0.07)
	tw.tween_property(_bus, "rotation_degrees:z", 0.0, 0.1)


func _ev_sign_glitch() -> void:

	if _sign_10min == null:
		return

	var old: String = _sign_10min.text

	_sign_10min.text = "ERRO 404:\nTRÂNSITO NÃO ENCONTRADO"

	var tw := create_tween()
	tw.tween_interval(3.5)
	tw.tween_callback(func(): _sign_10min.text = old)


# O caramelo aparece em um lugar inesperado (teto da banca), olha pra
# câmera e depois "some" de volta pro trono.
func _ev_dog_roof() -> void:

	if _dog_busy or _dog == null:
		return

	_dog_busy = true

	var old_pos: Vector3 = _dog.position
	var old_rot: float = _dog.rotation.y

	_puff(_dog.position + Vector3(0, 0.5, 0))

	_dog.position = Vector3(8.6, 2.35, -3.7)
	_dog.scale = Vector3(0.1, 0.1, 0.1)
	_dog.rotation.y = atan2(-(0.9 - -3.7), 0.0 - 8.6)

	# pose sentada, olhando pra câmera
	_dog_body.rotation_degrees.z = 28.0
	_dog_legs[2].rotation.z = 1.2
	_dog_legs[3].rotation.z = 1.2
	_dog_legs[0].rotation.z = 0.0
	_dog_legs[1].rotation.z = 0.0
	_dog_head.rotation_degrees = Vector3.ZERO
	_dog_zzz.visible = false
	_dog_tongue.visible = true

	_pop_label("OI!", Vector3(8.6, 3.8, -3.7), Color(1.0, 0.85, 0.3), 70)

	var tw := create_tween()
	tw.tween_property(_dog, "scale", Vector3(1, 1, 1), 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(5.0)
	tw.tween_callback(
		func():
			_puff(_dog.position + Vector3(0, 0.5, 0))
			_dog.position = old_pos
			_dog.rotation.y = old_rot
			_dog_state = "sit"
			_dog_timer = 5.0
			_dog_busy = false
	)


func _puff(pos: Vector3) -> void:

	var p := _particles(
		pos, Vector3(0.2, 0.2, 0.2), 14, 0.6,
		Color(1.0, 1.0, 1.0, 0.8), 0.35,
		Vector3(0, 0.5, 0), 0.8, 1.6, false, Vector3(0, 1, 0), 180.0
	)

	p.one_shot = true
	p.explosiveness = 1.0
	p.preprocess = 0.0
	p.emitting = true

	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_callback(p.queue_free)


# Helicóptero da TV cobrindo o trânsito (bem alto e ao fundo)
func _ev_helicopter() -> void:

	var heli := Node3D.new()
	heli.position = Vector3(-40.0, 14.0, -26.0)
	add_child(heli)

	_sphere(heli, Vector3.ZERO, 0.8, _mat(Color(0.9, 0.15, 0.15), 0.4, 0.3), Vector3(1.4, 1.0, 1.0))
	_box(heli, Vector3(-1.6, 0.2, 0), Vector3(2.0, 0.14, 0.14), _mat(Color(0.9, 0.15, 0.15), 0.4, 0.3))
	_box(heli, Vector3(0, 0.9, 0), Vector3(0.08, 0.3, 0.08), _mat(Color(0.2, 0.2, 0.2), 0.5, 0.5))

	var rotor := Node3D.new()
	rotor.position = Vector3(0, 1.1, 0)
	heli.add_child(rotor)
	_box(rotor, Vector3.ZERO, Vector3(4.0, 0.05, 0.2), _mat(Color(0.15, 0.15, 0.15), 0.5, 0.5))
	_box(rotor, Vector3.ZERO, Vector3(0.2, 0.05, 4.0), _mat(Color(0.15, 0.15, 0.15), 0.5, 0.5))

	_label("AO VIVO: TRÂNSITO", Vector3(0, -1.3, 0), 44, 0.006, Color(1.0, 0.9, 0.3), Vector3.ZERO, heli).outline_size = 12

	var spin := create_tween()
	spin.tween_property(rotor, "rotation_degrees:y", 7200.0, 9.0)

	var fly := create_tween()
	fly.tween_property(heli, "position:x", 40.0, 9.0)
	fly.tween_callback(heli.queue_free)
