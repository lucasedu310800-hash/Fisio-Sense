# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioArraia
# ARRAIÁ DO CAOS: festa junina à noite, com fogueira, bandeirinhas por todo
# lado, barracas de pamonha/quentão/pipoca, cadeia de 5 reais, quadrilha
# dançando, sanfoneiro, balões subindo, igrejinha iluminada e fogos.

var _rng := RandomNumberGenerator.new()
var _flags: Array = []
var _balloons: Array = []
var _dancers: Array = []
var _accordion: Node3D
var _fire_light: OmniLight3D
var _event_timer: float = 7.0


func make_environment() -> Environment:

	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.03, 0.04, 0.13)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.25, 0.28, 0.5)
	env.ambient_light_energy = 0.8
	env.fog_enabled = true
	env.fog_light_color = Color(0.08, 0.08, 0.2)
	env.fog_density = 0.012
	env.glow_enabled = true
	env.glow_intensity = 1.0
	env.glow_hdr_threshold = 0.85
	env.ssao_enabled = true

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-50, 30, 0), Color(0.5, 0.6, 1.0), 0.4)

	_build_ground_and_sky()
	_build_flags()
	_build_bonfire()
	_build_stalls()
	_build_church()
	_build_dancers()
	_build_balloons()
	_build_jail_and_signs()

	_make_accent(Vector3(0, 4.5, -4.0), Color(1.0, 0.7, 0.4), 0.5, 12.0)

	_anim.append(_update)


func _build_ground_and_sky() -> void:

	_box(self, Vector3(0, -0.06, -8.0), Vector3(90, 0.1, 60), _mat(Color(0.20, 0.30, 0.13), 1.0, 0.0))

	# terreiro de terra batida onde rola a luta
	_cyl(self, Vector3(0, 0.005, -1.8), 5.2, 0.02, _mat(Color(0.48, 0.34, 0.20), 1.0, 0.0), Vector3.ZERO, 40)

	# palha espalhada
	var straw := _mat(Color(0.85, 0.72, 0.35), 1.0, 0.0)

	for i in range(18):
		var a: float = _rng.randf() * TAU
		var r: float = _rng.randf_range(2.0, 5.0)
		_box(self, Vector3(cos(a) * r, 0.03, -1.8 + sin(a) * r), Vector3(0.4, 0.01, 0.03), straw, Vector3(0, _rng.randf() * 180.0, 0))

	# lua e estrelas
	_no_shadow(_sphere(self, Vector3(-18.0, 26.0, -70.0), 3.0, _emit(Color(1.0, 0.98, 0.85), 2.0)))

	var star := _emit(Color(1, 1, 1), 2.0)

	for i in range(70):
		var a2: float = _rng.randf_range(0.0, TAU)
		var e: float = _rng.randf_range(0.15, 0.9)
		_no_shadow(_sphere(self, Vector3(cos(a2) * 80.0, 12.0 + e * 60.0, -80.0 - sin(a2) * 20.0), 0.15, star))

	# morros ao fundo
	var hill := _mat(Color(0.08, 0.14, 0.12), 1.0, 0.0)

	_sphere(self, Vector3(-30, -8, -60), 24.0, hill)
	_sphere(self, Vector3(25, -10, -64), 28.0, hill)


func _build_flags() -> void:

	var pole := _mat(Color(0.4, 0.3, 0.2), 0.8, 0.0)

	for z in [-2.5, -6.0, -9.0]:

		for px in [-9.0, 9.0]:
			_cyl(self, Vector3(px, 3.0, z), 0.07, 6.0, pole)

		_flags.append(_bunting(Vector3(-9.0, 5.8, z), Vector3(9.0, 5.8, z), 34, 0.9))
		_flags.append(_bunting(Vector3(-9.0, 5.0, z - 0.6), Vector3(9.0, 5.0, z - 0.6), 34, 0.7))

	# lampadinhas
	for i in range(14):
		_no_shadow(_sphere(self, Vector3(-8.5 + float(i) * 1.3, 4.6 - 0.4 * sin(float(i) * 0.5), -2.5), 0.08, _emit(Color(1.0, 0.9, 0.5), 2.4)))


func _build_bonfire() -> void:

	var root := Node3D.new()
	root.position = Vector3(-5.6, 0.0, -3.6)
	add_child(root)

	var wood := _mat(Color(0.32, 0.18, 0.09), 0.9, 0.0)

	for i in range(6):
		var a: float = float(i) * PI / 3.0
		_cyl(root, Vector3(cos(a) * 0.25, 0.3, sin(a) * 0.25), 0.07, 1.0, wood, Vector3(sin(a) * 30.0, 0, -cos(a) * 30.0))

	_no_shadow(_cone(root, Vector3(0, 0.6, 0), 0.4, 1.0, _emit(Color(1.0, 0.5, 0.1), 2.0), Vector3.ZERO, 8))

	# chamas e faíscas
	_particles(Vector3(-5.6, 0.7, -3.6), Vector3(0.25, 0.05, 0.25), 60, 1.0, Color(1.0, 0.55, 0.1, 0.9), 0.35, Vector3(0, 1.5, 0), 0.3, 0.8, true, Vector3(0, 1, 0), 12.0)
	_particles(Vector3(-5.6, 1.0, -3.6), Vector3(0.2, 0.05, 0.2), 20, 1.6, Color(1.0, 0.85, 0.3, 1.0), 0.06, Vector3(0, 0.8, 0), 0.8, 1.6, true, Vector3(0, 1, 0), 25.0)

	_fire_light = _omni(Vector3(-5.6, 1.2, -3.2), Color(1.0, 0.55, 0.2), 2.0, 9.0)


func _stall(x: float, title: String, roof_a: Color, roof_b: Color) -> void:

	var root := Node3D.new()
	root.position = Vector3(x, 0.0, -7.2)
	add_child(root)

	var wood := _mat(Color(0.45, 0.30, 0.16), 0.8, 0.0)

	for sx in [-1.3, 1.3]:
		_cyl(root, Vector3(sx, 1.3, 0), 0.07, 2.6, wood)

	_box(root, Vector3(0, 0.9, 0.2), Vector3(2.6, 0.12, 0.9), wood)
	_box(root, Vector3(0, 0.45, 0.2), Vector3(2.5, 0.9, 0.85), _mat(Color(0.35, 0.22, 0.12), 0.8, 0.0))

	for i in range(8):
		var c: Color = roof_a if i % 2 == 0 else roof_b
		_box(root, Vector3(-1.4 + float(i) * 0.4, 2.7, 0.15), Vector3(0.4, 0.06, 1.5), _mat(c, 0.8, 0.0), Vector3(-12, 0, 0))

	_label(title, Vector3(0, 3.3, 0.6), 60, 0.0055, Color(1.0, 0.95, 0.5), Vector3.ZERO, root).outline_size = 12

	_no_shadow(_sphere(root, Vector3(-0.9, 2.3, 0.7), 0.09, _emit(Color(1.0, 0.9, 0.5), 2.4)))
	_no_shadow(_sphere(root, Vector3(0.9, 2.3, 0.7), 0.09, _emit(Color(1.0, 0.9, 0.5), 2.4)))

	_person(root, Vector3(0.0, 0.0, -0.4), Color(0.9, 0.4, 0.3), Color(0.8, 0.58, 0.42), Color(0.2, 0.3, 0.5), Color(0.95, 0.85, 0.3))


func _build_stalls() -> void:

	_stall(-9.0, "PAMONHA", Color(0.95, 0.85, 0.2), Color(0.15, 0.6, 0.3))
	_stall(-3.2, "QUENTÃO", Color(0.85, 0.15, 0.15), Color(1, 1, 1))
	_stall(3.2, "PIPOCA", Color(0.98, 0.98, 0.9), Color(0.95, 0.4, 0.2))
	_stall(9.0, "CANJICA", Color(0.2, 0.45, 0.9), Color(0.95, 0.85, 0.2))


func _build_church() -> void:

	var white := _mat(Color(0.95, 0.94, 0.9), 0.85, 0.0)
	var roof := _mat(Color(0.65, 0.2, 0.12), 0.7, 0.0)
	var glow := _emit(Color(1.0, 0.85, 0.45), 1.4)

	_box(self, Vector3(0, 2.5, -18.0), Vector3(7.0, 5.0, 6.0), white)
	_box(self, Vector3(0, 6.0, -18.0), Vector3(7.4, 0.3, 6.4), roof, Vector3(0, 0, 0))
	_cone(self, Vector3(0, 6.8, -18.0), 4.4, 1.8, roof, Vector3.ZERO, 4).rotation_degrees = Vector3(0, 45, 0)

	_box(self, Vector3(3.6, 4.0, -18.6), Vector3(2.0, 8.0, 2.0), white)
	_cone(self, Vector3(3.6, 9.3, -18.6), 1.5, 2.2, roof, Vector3.ZERO, 4).rotation_degrees = Vector3(0, 45, 0)
	_box(self, Vector3(3.6, 10.6, -18.6), Vector3(0.1, 0.9, 0.1), white)
	_box(self, Vector3(3.6, 10.7, -18.6), Vector3(0.5, 0.1, 0.1), white)

	for wx in [-2.2, 0.0, 2.2]:
		_no_shadow(_box(self, Vector3(wx, 2.8, -14.95), Vector3(0.9, 1.6, 0.05), glow))

	_no_shadow(_box(self, Vector3(0, 1.2, -14.95), Vector3(1.4, 2.4, 0.05), glow))

	_omni(Vector3(0, 3.0, -13.0), Color(1.0, 0.85, 0.5), 1.4, 9.0)


func _build_dancers() -> void:

	# quadrilha: dois casais dançando em fila (chapéu de palha, roupa remendada)
	for i in range(6):

		var boy: bool = (i % 2 == 0)
		var shirt: Color = Color(0.9, 0.3, 0.3) if boy else Color(0.95, 0.85, 0.2)
		var pants: Color = Color(0.3, 0.4, 0.75) if boy else Color(0.9, 0.35, 0.55)

		var d: Dictionary = _person(self, Vector3(-4.0 + float(i) * 1.6, 0.0, -6.0), shirt, Color(0.78, 0.56, 0.4), pants, Color(0.9, 0.78, 0.35))

		# remendos
		var dn: Node3D = d["node"]
		_box(dn, Vector3(0.0, 0.9, 0.05), Vector3(0.16, 0.16, 0.16), _mat(Color(0.95, 0.9, 0.3), 0.8, 0.0))

		_dancers.append({"node": d["node"], "base": -4.0 + float(i) * 1.6, "phase": float(i) * 0.7, "arms": d["arms"], "legs": d["legs"]})

	# sanfoneiro
	var sf: Dictionary = _person(self, Vector3(6.0, 0.0, -5.2), Color(0.2, 0.55, 0.3), Color(0.72, 0.5, 0.36), Color(0.3, 0.25, 0.2), Color(0.9, 0.78, 0.35))
	var sn: Node3D = sf["node"]

	_accordion = Node3D.new()
	_accordion.position = Vector3(0.05, 1.15, 0.28)
	sn.add_child(_accordion)
	_box(_accordion, Vector3.ZERO, Vector3(0.5, 0.4, 0.3), _mat(Color(0.75, 0.1, 0.12), 0.5, 0.2))
	_box(_accordion, Vector3.ZERO, Vector3(0.44, 0.34, 0.5), _mat(Color(0.95, 0.9, 0.85), 0.6, 0.0))


func _build_balloons() -> void:

	for i in range(7):

		var b := Node3D.new()
		b.position = Vector3(_rng.randf_range(-16.0, 16.0), _rng.randf_range(2.0, 16.0), _rng.randf_range(-24.0, -8.0))
		add_child(b)

		var col := Color.from_hsv(_rng.randf_range(0.0, 0.12), 0.85, 1.0)

		_no_shadow(_sphere(b, Vector3.ZERO, 0.6, _emit(col, 1.6), Vector3(1.0, 1.25, 1.0)))
		_no_shadow(_sphere(b, Vector3(0, -0.85, 0), 0.12, _emit(Color(1.0, 0.85, 0.3), 3.0)))

		_balloons.append({"node": b, "speed": _rng.randf_range(0.4, 0.9), "phase": _rng.randf_range(0.0, 6.0)})


func _build_jail_and_signs() -> void:

	# cadeia (5 reais, prende seu amigo)
	var root := Node3D.new()
	root.position = Vector3(7.2, 0.0, -3.4)
	add_child(root)

	var bar := _mat(Color(0.15, 0.15, 0.17), 0.5, 0.6)

	for i in range(7):
		_cyl(root, Vector3(-0.9 + float(i) * 0.3, 1.0, 0.7), 0.03, 2.0, bar)
		_cyl(root, Vector3(-0.9 + float(i) * 0.3, 1.0, -0.7), 0.03, 2.0, bar)

	_box(root, Vector3(0, 2.0, 0), Vector3(2.0, 0.08, 1.6), bar)
	_box(root, Vector3(0, 0.05, 0), Vector3(2.0, 0.1, 1.6), _mat(Color(0.4, 0.3, 0.2), 0.9, 0.0))

	_person(root, Vector3(0.1, 0.1, 0.0), Color(0.3, 0.3, 0.8), Color(0.7, 0.5, 0.36), Color(0.25, 0.25, 0.3), Color(0.9, 0.78, 0.35))

	_plaque(Vector3(7.2, 2.7, -3.4), Vector2(3.0, 0.8), Color(0.95, 0.25, 0.2), "CADEIA: R$5\n(PRENDE SEU AMIGO)", Color(1, 1, 1), 32)
	_plaque(Vector3(-7.0, 2.4, -2.0), Vector2(2.8, 0.8), Color(0.95, 0.5, 0.75), "CORREIO ELEGANTE\n(ENVIE UM RECADO)", Color(1, 1, 1), 30, 0.0, true)
	_plaque(Vector3(0.0, 3.0, -8.4), Vector2(4.0, 0.7), Color(0.2, 0.45, 0.85), "CASAMENTO NA ROÇA - FILA À DIREITA", Color(1, 1, 1), 24)


func _update(t: float, dt: float) -> void:

	for i in range(_flags.size()):
		var f: Node3D = _flags[i]
		f.rotation_degrees.z = sin(t * 1.4 + float(i)) * 1.2

	for d in _dancers:
		var n: Node3D = d["node"]
		var ph: float = d["phase"]
		n.position.x = float(d["base"]) + sin(t * 1.2 + ph) * 0.5
		n.position.y = absf(sin(t * 3.0 + ph)) * 0.12
		n.rotation_degrees.y = sin(t * 1.2 + ph) * 25.0

		var arms: Array = d["arms"]
		var a0: Node3D = arms[0]
		var a1: Node3D = arms[1]
		a0.rotation_degrees.x = -110.0 + sin(t * 4.0 + ph) * 25.0
		a1.rotation_degrees.x = -110.0 - sin(t * 4.0 + ph) * 25.0

	if _accordion:
		_accordion.scale = Vector3(1.0, 1.0, 1.0 + 0.5 * absf(sin(t * 3.0)))

	for b in _balloons:
		var bn: Node3D = b["node"]
		bn.position.y += dt * float(b["speed"])
		bn.position.x += sin(t * 0.5 + float(b["phase"])) * dt * 0.4

		if bn.position.y > 20.0:
			bn.position.y = 1.0

	if _fire_light:
		_fire_light.light_energy = 1.7 + 0.5 * sin(t * 12.0) + 0.25 * sin(t * 27.0)

	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(8.0, 15.0)
		_event()


func _event() -> void:

	var r: int = _rng.randi() % 3

	if r == 0:
		var pos := Vector3(_rng.randf_range(-8.0, 8.0), _rng.randf_range(9.0, 13.0), -14.0)
		_burst(pos, Color.from_hsv(_rng.randf(), 0.8, 1.0), 55, 6.5)
		_toast("BOOM!", pos + Vector3(0, -1.5, 0), Color(1.0, 0.9, 0.3), 80)
	elif r == 1:
		_toast("ANARRIÊ!", Vector3(0.0, 4.2, -6.0), Color(1.0, 0.85, 0.3), 80)
	else:
		_toast("TLIM-TLIM (SINO)", Vector3(3.6, 12.0, -18.0), Color(1.0, 0.95, 0.7), 60)
