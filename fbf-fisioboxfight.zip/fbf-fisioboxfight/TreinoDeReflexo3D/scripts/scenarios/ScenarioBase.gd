# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node3D
class_name ScenarioBase
# Base dos cenários 3D do FBF (inspirados na variedade de arenas dos
# jogos de luta, mas todos originais e feitos por código: primitivas,
# materiais, luzes e partículas — nenhum arquivo externo).
#
# Como funciona: o Main.gd instancia UM cenário por vez, adiciona em
# world_root e usa make_environment() pra trocar o ambiente (céu, névoa,
# brilho...). O treinador e a câmera do jogo NÃO fazem parte do cenário
# (ficam em (0,0,-2.2) e (0,1.64,0.9)) — então a detecção de movimentos
# e o gameplay não mudam em nada. Área de luta livre: |x| < 1.6, z de
# -3 a 1. O cenário só desenha ao redor.
#
# Cada cenário sobrescreve _build() e make_environment(). Animações
# ambientes são funções registradas em _anim (chamadas todo frame com
# o tempo total e o delta).

var _t: float = 0.0
var _anim: Array = []

# luz de destaque que "pulsa" nos golpes certos (ver flash())
var accent_light: OmniLight3D
var _accent_base_energy: float = 0.5
var _accent_base_color: Color = Color(1, 1, 1)
var _flash_amt: float = 0.0
var _flash_col: Color = Color(1, 1, 1)


func make_environment() -> Environment:
	return Environment.new()


func _build() -> void:
	pass


func _ready() -> void:
	_build()


func _process(delta: float) -> void:

	_t += delta

	for a in _anim:
		a.call(_t, delta)

	if _flash_amt > 0.0:

		_flash_amt = maxf(0.0, _flash_amt - delta * 3.0)

		if accent_light:
			accent_light.light_energy = _accent_base_energy + 4.0 * _flash_amt
			accent_light.light_color = _accent_base_color.lerp(_flash_col, _flash_amt)


# Pulso de luz curto (golpe certo, nocaute...). Discreto de propósito:
# a clareza dos movimentos vem primeiro.
func flash(color: Color) -> void:

	_flash_amt = 1.0
	_flash_col = color


# Cenários com placar (arena) sobrescrevem isto.
func set_scoreboard(_time_text: String, _score: int, _precision: float) -> void:
	pass


func _make_accent(pos: Vector3, color: Color, energy: float, light_range: float) -> void:

	accent_light = OmniLight3D.new()
	accent_light.position = pos
	accent_light.light_color = color
	accent_light.light_energy = energy
	accent_light.omni_range = light_range
	add_child(accent_light)

	_accent_base_energy = energy
	_accent_base_color = color


# ------------------------------------------------------------
# Ferramentas de construção
# ------------------------------------------------------------

func _mat(color: Color, rough: float = 0.7, metal: float = 0.0) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()

	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal

	return m


func _emit(color: Color, energy: float) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()

	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy

	return m


func _glow_mat(color: Color) -> StandardMaterial3D:

	# translúcido aditivo, sem luz — usado em raios de luz e neblina falsa
	var m := StandardMaterial3D.new()

	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.albedo_color = color
	m.cull_mode = BaseMaterial3D.CULL_DISABLED

	return m


func _put(parent: Node3D, mi: MeshInstance3D, pos: Vector3, rot: Vector3, mat: Material) -> MeshInstance3D:

	mi.position = pos
	mi.rotation_degrees = rot
	mi.material_override = mat
	parent.add_child(mi)

	return mi


func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := BoxMesh.new()
	mesh.size = size

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _put(parent, mi, pos, rot, mat)


func _cyl(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, rot: Vector3 = Vector3.ZERO, segments: int = 20) -> MeshInstance3D:

	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = segments

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _put(parent, mi, pos, rot, mat)


func _cone(parent: Node3D, pos: Vector3, bottom_radius: float, height: float, mat: Material, rot: Vector3 = Vector3.ZERO, segments: int = 16) -> MeshInstance3D:

	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.0
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	mesh.radial_segments = segments

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _put(parent, mi, pos, rot, mat)


func _sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:

	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 20
	mesh.rings = 10

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.scale = scl

	return _put(parent, mi, pos, Vector3.ZERO, mat)


func _torus(parent: Node3D, pos: Vector3, inner: float, outer: float, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := TorusMesh.new()
	mesh.inner_radius = inner
	mesh.outer_radius = outer

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _put(parent, mi, pos, rot, mat)


func _plane(parent: Node3D, pos: Vector3, size: Vector2, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := PlaneMesh.new()
	mesh.size = size

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _put(parent, mi, pos, rot, mat)


func _no_shadow(mi: MeshInstance3D) -> MeshInstance3D:

	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	return mi


func _label(text: String, pos: Vector3, font_size: int, pixel_size: float, color: Color, rot: Vector3 = Vector3.ZERO, parent: Node3D = null) -> Label3D:

	var l := Label3D.new()

	l.text = text
	l.font_size = font_size
	l.pixel_size = pixel_size
	l.modulate = color
	l.outline_size = 12
	l.outline_modulate = Color(0.02, 0.02, 0.03, 1.0)
	l.shaded = false
	l.position = pos
	l.rotation_degrees = rot

	if parent == null:
		add_child(l)
	else:
		parent.add_child(l)

	return l


func _omni(pos: Vector3, color: Color, energy: float, light_range: float, parent: Node3D = null) -> OmniLight3D:

	var l := OmniLight3D.new()

	l.position = pos
	l.light_color = color
	l.light_energy = energy
	l.omni_range = light_range

	if parent == null:
		add_child(l)
	else:
		parent.add_child(l)

	return l


func _spot(pos: Vector3, color: Color, energy: float, light_range: float, angle: float, parent: Node3D = null) -> SpotLight3D:

	var l := SpotLight3D.new()

	l.position = pos
	l.light_color = color
	l.light_energy = energy
	l.spot_range = light_range
	l.spot_angle = angle

	if parent == null:
		add_child(l)
	else:
		parent.add_child(l)

	return l


func _sun(rot: Vector3, color: Color, energy: float, shadows: bool = true) -> DirectionalLight3D:

	var l := DirectionalLight3D.new()

	l.rotation_degrees = rot
	l.light_color = color
	l.light_energy = energy
	l.shadow_enabled = shadows

	add_child(l)

	return l


# Partículas leves (poeira, pétalas, fagulhas, vapor...). Usa CPUParticles3D
# (funciona em qualquer renderizador) e poucas unidades, pra não pesar.
func _particles(pos: Vector3, extents: Vector3, amount: int, lifetime: float, color: Color, size: float, gravity: Vector3, vel_min: float, vel_max: float, additive: bool = true, dir: Vector3 = Vector3(0, 1, 0), spread: float = 180.0) -> CPUParticles3D:

	var p := CPUParticles3D.new()

	p.position = pos
	p.amount = amount
	p.lifetime = lifetime
	p.preprocess = lifetime
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = extents
	p.direction = dir
	p.spread = spread
	p.gravity = gravity
	p.initial_velocity_min = vel_min
	p.initial_velocity_max = vel_max
	p.local_coords = false

	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.2, 0.8, 1.0])
	grad.colors = PackedColorArray([
		Color(color.r, color.g, color.b, 0.0),
		color,
		color,
		Color(color.r, color.g, color.b, 0.0),
	])
	p.color_ramp = grad

	var quad := QuadMesh.new()
	quad.size = Vector2(size, size)

	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.vertex_color_use_as_albedo = true

	if additive:
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD

	quad.material = m
	p.mesh = quad

	add_child(p)

	return p


# Textura de janelas acesas para prédios (pixel art procedural).
func _window_texture(seed_value: int, cols: int, rows: int, lit_chance: float) -> ImageTexture:

	var img := Image.create(cols * 4, rows * 6, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.025, 0.03, 0.05, 1.0))

	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	var palette := [
		Color(1.0, 0.85, 0.5),
		Color(1.0, 0.75, 0.4),
		Color(0.6, 0.85, 1.0),
		Color(1.0, 0.55, 0.85),
	]

	for cy in range(rows):
		for cx in range(cols):

			var c := Color(0.04, 0.05, 0.08, 1.0)

			if rng.randf() < lit_chance:
				c = palette[rng.randi() % palette.size()]

			for yy in range(3):
				for xx in range(2):
					img.set_pixel(cx * 4 + 1 + xx, cy * 6 + 1 + yy, c)

	return ImageTexture.create_from_image(img)


func _building_mat(seed_value: int, w: float, h: float, tint: Color, lit_chance: float = 0.5) -> StandardMaterial3D:

	var cols: int = maxi(2, int(w / 0.7))
	var rows: int = maxi(3, int(h / 0.9))

	var tex := _window_texture(seed_value, cols, rows, lit_chance)

	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.albedo_color = tint
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.roughness = 0.7
	m.emission_enabled = true
	m.emission_texture = tex
	m.emission = Color(1, 1, 1)
	m.emission_energy_multiplier = 1.3

	return m


# ------------------------------------------------------------
# Ferramentas extras (cenários "zoeira do Brasil")
# ------------------------------------------------------------

# Pessoa de primitivas: pernas e braços em pivôs (dá pra balançar).
# Devolve {"node", "legs", "arms", "head"}.
func _person(parent: Node3D, pos: Vector3, shirt: Color, skin: Color, pants: Color = Color(0.2, 0.22, 0.32), hat: Color = Color(0, 0, 0, 0), scl: float = 1.0) -> Dictionary:

	var p := Node3D.new()
	p.position = pos
	p.scale = Vector3(scl, scl, scl)
	parent.add_child(p)

	var legs: Array = []

	for lz in [-0.08, 0.08]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0, 0.85, lz)
		p.add_child(pivot)
		_box(pivot, Vector3(0, -0.4, 0), Vector3(0.14, 0.8, 0.14), _mat(pants, 0.8, 0.0))
		legs.append(pivot)

	_box(p, Vector3(0, 1.15, 0), Vector3(0.26, 0.6, 0.36), _mat(shirt, 0.8, 0.0))

	var arms: Array = []

	for az in [-0.22, 0.22]:
		var ap := Node3D.new()
		ap.position = Vector3(0, 1.4, az)
		p.add_child(ap)
		_box(ap, Vector3(0, -0.25, 0), Vector3(0.1, 0.52, 0.1), _mat(skin, 0.7, 0.0))
		arms.append(ap)

	var head := _sphere(p, Vector3(0, 1.62, 0), 0.17, _mat(skin, 0.6, 0.0))

	if hat.a > 0.0:
		_sphere(p, Vector3(0, 1.73, 0), 0.18, _mat(hat, 0.7, 0.0), Vector3(1.0, 0.55, 1.0))

	return {"node": p, "legs": legs, "arms": arms, "head": head}


# Segmento fino entre dois pontos (fios, cordas).
func _strand(parent: Node3D, a: Vector3, b: Vector3, mat: Material, thick: float) -> void:

	var dir: Vector3 = b - a
	var length: float = dir.length()

	if length < 0.001:
		return

	var mesh := BoxMesh.new()
	mesh.size = Vector3(thick, thick, length)

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)

	mi.transform = Transform3D(Basis.looking_at(dir.normalized(), Vector3.UP), (a + b) / 2.0)


# Varal de bandeirinhas coloridas (festa junina / laje).
func _bunting(a: Vector3, b: Vector3, count: int, sag: float) -> Node3D:

	var root := Node3D.new()
	add_child(root)

	var cols := [
		Color(0.9, 0.15, 0.15), Color(0.98, 0.85, 0.1), Color(0.15, 0.65, 0.3),
		Color(0.15, 0.4, 0.9), Color(0.95, 0.4, 0.7), Color(0.95, 0.55, 0.1),
	]
	var string_mat := _mat(Color(0.1, 0.1, 0.1), 0.8, 0.0)
	var prev: Vector3 = a

	for i in range(1, count + 1):

		var k: float = float(i) / float(count)
		var p: Vector3 = a.lerp(b, k)
		p.y -= sag * 4.0 * k * (1.0 - k)

		_strand(root, prev, p, string_mat, 0.02)

		var mid: Vector3 = (prev + p) / 2.0
		_cone(root, mid + Vector3(0, -0.15, 0), 0.13, 0.3, _mat(cols[i % cols.size()], 0.8, 0.0), Vector3(180, 0, 0), 3)

		prev = p

	return root


# Placa simples com texto (pernas opcionais até o chão).
func _plaque(pos: Vector3, size: Vector2, bg: Color, text: String, fg: Color, font_size: int, rot_y: float = 0.0, legs: bool = false) -> Label3D:

	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0, rot_y, 0)
	add_child(root)

	_box(root, Vector3.ZERO, Vector3(size.x, size.y, 0.06), _mat(bg, 0.6, 0.0))
	_box(root, Vector3(0, 0, 0.005), Vector3(size.x - 0.1, size.y - 0.1, 0.06), _mat(bg.darkened(0.1), 0.6, 0.0))

	if legs:
		var h: float = pos.y - size.y / 2.0
		var post := _mat(Color(0.25, 0.2, 0.15), 0.8, 0.2)
		_box(root, Vector3(-size.x / 2.0 + 0.2, -size.y / 2.0 - h / 2.0, -0.05), Vector3(0.08, h, 0.08), post)
		_box(root, Vector3(size.x / 2.0 - 0.2, -size.y / 2.0 - h / 2.0, -0.05), Vector3(0.08, h, 0.08), post)

	var l := _label(text, Vector3(0, 0, 0.05), font_size, 0.0045, fg, Vector3.ZERO, root)
	l.outline_size = 0

	return l


# Texto que "pula" no ar e some (buzinas, gritos, piadas).
func _toast(text: String, pos: Vector3, color: Color, font_size: int) -> void:

	var l := _label(text, pos, font_size, 0.006, color)
	l.outline_size = 16
	l.scale = Vector3(0.2, 0.2, 0.2)

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "scale", Vector3(1, 1, 1), 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "position:y", pos.y + 0.7, 1.4)
	tw.chain().tween_property(l, "modulate:a", 0.0, 0.4)
	tw.chain().tween_callback(l.queue_free)


# Explosão de partículas (fogos, fumaça de susto...).
func _burst(pos: Vector3, color: Color, amount: int = 40, speed: float = 6.0) -> void:

	var p := _particles(
		pos, Vector3(0.1, 0.1, 0.1), amount, 1.3, color, 0.25,
		Vector3(0, -2.5, 0), speed * 0.6, speed, true, Vector3(0, 1, 0), 180.0
	)

	p.one_shot = true
	p.explosiveness = 1.0
	p.preprocess = 0.0
	p.emitting = true

	var tw := create_tween()
	tw.tween_interval(2.2)
	tw.tween_callback(p.queue_free)
