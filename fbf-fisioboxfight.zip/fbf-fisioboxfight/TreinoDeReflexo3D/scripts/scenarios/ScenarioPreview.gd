# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name ScenarioPreview
# Miniatura ilustrada de cada cenário (desenhada por código) para os
# cartões da tela de seleção. Não precisa de imagens: é um "cartão-postal"
# estilizado de cada arena, com dois lutadores (luva vermelha e azul).

@export var kind: String = "gym"


func _draw() -> void:

	var s: Vector2 = size

	match kind:
		"city":
			_draw_city(s)
		"dojo":
			_draw_dojo(s)
		"arena":
			_draw_arena(s)
		"beach":
			_draw_beach(s)
		"factory":
			_draw_factory(s)
		"saopaulo":
			_draw_saopaulo(s)
		"laje":
			_draw_laje(s)
		"arraia":
			_draw_arraia(s)
		"farofa":
			_draw_farofa(s)
		"varzea":
			_draw_varzea(s)
		"buraco":
			_draw_buraco(s)
		"random":
			_draw_random(s)
		"locked":
			_draw_locked(s)
		_:
			_draw_gym(s)

	if kind != "locked" and kind != "random":
		_draw_fighters(s)

	# moldura
	draw_rect(Rect2(Vector2.ZERO, s), Color(0, 0, 0, 0.0), false, 2.0)
	draw_rect(Rect2(Vector2(1, 1), s - Vector2(2, 2)), Color(0.96, 0.75, 0.25, 0.9), false, 2.0)


func _grad(rect: Rect2, top: Color, bottom: Color) -> void:

	draw_polygon(
		PackedVector2Array([
			rect.position,
			rect.position + Vector2(rect.size.x, 0),
			rect.position + rect.size,
			rect.position + Vector2(0, rect.size.y),
		]),
		PackedColorArray([top, top, bottom, bottom])
	)


# dois lutadores de costas para a câmera, com luvas vermelha e azul
func _draw_fighters(s: Vector2) -> void:

	var ground: float = s.y * 0.86
	var dark := Color(0.05, 0.05, 0.08, 0.92)

	# treinador (centro-direita) e jogador (esquerda, menor)
	for f in [[0.58, 1.0, Color(0.85, 0.15, 0.15)], [0.36, 0.8, Color(0.2, 0.45, 1.0)]]:

		var fx: float = s.x * float(f[0])
		var k: float = float(f[1])
		var col: Color = f[2]

		draw_circle(Vector2(fx, ground - 46.0 * k), 8.0 * k, dark)
		draw_rect(Rect2(Vector2(fx - 9.0 * k, ground - 38.0 * k), Vector2(18.0 * k, 26.0 * k)), dark)
		draw_rect(Rect2(Vector2(fx - 8.0 * k, ground - 12.0 * k), Vector2(6.0 * k, 12.0 * k)), dark)
		draw_rect(Rect2(Vector2(fx + 2.0 * k, ground - 12.0 * k), Vector2(6.0 * k, 12.0 * k)), dark)
		draw_circle(Vector2(fx - 13.0 * k, ground - 38.0 * k), 6.0 * k, col)
		draw_circle(Vector2(fx + 13.0 * k, ground - 38.0 * k), 6.0 * k, col)


func _draw_city(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.7), Color(0.05, 0.03, 0.16), Color(0.30, 0.12, 0.38))

	var rng := RandomNumberGenerator.new()
	rng.seed = 5

	var x: float = -6.0

	while x < s.x:
		var w: float = rng.randf_range(24.0, 44.0)
		var h: float = rng.randf_range(s.y * 0.30, s.y * 0.68)
		draw_rect(Rect2(Vector2(x, s.y * 0.72 - h), Vector2(w, h)), Color(0.07, 0.07, 0.15))

		for i in range(int(h / 12.0)):
			for j in range(int(w / 10.0)):
				if rng.randf() < 0.4:
					draw_rect(Rect2(Vector2(x + 4.0 + float(j) * 10.0, s.y * 0.72 - h + 5.0 + float(i) * 12.0), Vector2(4, 5)), Color(1.0, 0.85, 0.45, 0.9))

		x += w + 3.0

	# neon
	draw_rect(Rect2(Vector2(s.x * 0.12, s.y * 0.22), Vector2(46, 14)), Color(1.0, 0.2, 0.75, 0.95))
	draw_rect(Rect2(Vector2(s.x * 0.62, s.y * 0.30), Vector2(40, 12)), Color(0.2, 0.9, 1.0, 0.95))
	draw_rect(Rect2(Vector2(s.x * 0.42, s.y * 0.14), Vector2(30, 12)), Color(0.4, 1.0, 0.4, 0.95))

	# rua molhada com reflexos
	_grad(Rect2(0, s.y * 0.72, s.x, s.y * 0.28), Color(0.09, 0.09, 0.14), Color(0.03, 0.03, 0.06))
	draw_rect(Rect2(Vector2(s.x * 0.12, s.y * 0.76), Vector2(46, 4)), Color(1.0, 0.2, 0.75, 0.35))
	draw_rect(Rect2(Vector2(s.x * 0.62, s.y * 0.78), Vector2(40, 4)), Color(0.2, 0.9, 1.0, 0.35))

	# carro
	draw_rect(Rect2(Vector2(s.x * 0.80, s.y * 0.62), Vector2(50, 14)), Color(0.75, 0.1, 0.12))
	draw_rect(Rect2(Vector2(s.x * 0.84, s.y * 0.55), Vector2(28, 10)), Color(0.08, 0.10, 0.16))


func _draw_dojo(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.6), Color(0.35, 0.55, 0.9), Color(1.0, 0.82, 0.58))

	# montanhas
	draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.2, s.y * 0.6), Vector2(s.x * 0.42, s.y * 0.18), Vector2(s.x * 0.66, s.y * 0.6)]), Color(0.42, 0.50, 0.68))
	draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.5, s.y * 0.6), Vector2(s.x * 0.72, s.y * 0.26), Vector2(s.x * 0.95, s.y * 0.6)]), Color(0.50, 0.58, 0.74))
	draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.38, s.y * 0.3), Vector2(s.x * 0.42, s.y * 0.18), Vector2(s.x * 0.46, s.y * 0.3)]), Color(0.96, 0.96, 1.0))

	# árvore de cerejeira
	draw_rect(Rect2(Vector2(s.x * 0.14, s.y * 0.42), Vector2(6, s.y * 0.2)), Color(0.25, 0.14, 0.09))
	draw_circle(Vector2(s.x * 0.15, s.y * 0.38), 22.0, Color(0.98, 0.68, 0.78))
	draw_circle(Vector2(s.x * 0.2, s.y * 0.44), 16.0, Color(0.95, 0.55, 0.70))

	# torii
	draw_rect(Rect2(Vector2(s.x * 0.6, s.y * 0.36), Vector2(4, s.y * 0.26)), Color(0.78, 0.1, 0.08))
	draw_rect(Rect2(Vector2(s.x * 0.74, s.y * 0.36), Vector2(4, s.y * 0.26)), Color(0.78, 0.1, 0.08))
	draw_rect(Rect2(Vector2(s.x * 0.57, s.y * 0.33), Vector2(s.x * 0.24, 6)), Color(0.08, 0.06, 0.06))

	# moldura de madeira do dojô (pilares e viga)
	draw_rect(Rect2(Vector2(0, 0), Vector2(s.x * 0.09, s.y)), Color(0.25, 0.15, 0.08))
	draw_rect(Rect2(Vector2(s.x * 0.91, 0), Vector2(s.x * 0.09, s.y)), Color(0.25, 0.15, 0.08))
	draw_rect(Rect2(Vector2(0, 0), Vector2(s.x, s.y * 0.1)), Color(0.30, 0.18, 0.09))

	# lanternas
	for lx in [0.22, 0.78]:
		draw_circle(Vector2(s.x * float(lx), s.y * 0.22), 10.0, Color(1.0, 0.62, 0.28, 0.35))
		draw_circle(Vector2(s.x * float(lx), s.y * 0.22), 6.0, Color(1.0, 0.7, 0.3))

	# piso
	_grad(Rect2(0, s.y * 0.62, s.x, s.y * 0.38), Color(0.62, 0.44, 0.27), Color(0.42, 0.28, 0.16))
	draw_rect(Rect2(Vector2(s.x * 0.25, s.y * 0.72), Vector2(s.x * 0.5, s.y * 0.2)), Color(0.64, 0.68, 0.42, 0.9))


func _draw_arena(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y), Color(0.02, 0.02, 0.07), Color(0.06, 0.06, 0.14))

	# arquibancada com torcida
	var rng := RandomNumberGenerator.new()
	rng.seed = 9

	for row in range(5):
		var y: float = s.y * (0.34 + float(row) * 0.09)
		draw_rect(Rect2(Vector2(0, y), Vector2(s.x, s.y * 0.09)), Color(0.10, 0.10, 0.15))
		for i in range(int(s.x / 9.0)):
			var c := Color.from_hsv(rng.randf(), 0.7, 0.9)
			draw_circle(Vector2(4.0 + float(i) * 9.0, y + 6.0), 3.0, c)

	# telão
	draw_rect(Rect2(Vector2(s.x * 0.32, s.y * 0.06), Vector2(s.x * 0.36, s.y * 0.2)), Color(0.05, 0.10, 0.28))
	draw_rect(Rect2(Vector2(s.x * 0.34, s.y * 0.09), Vector2(s.x * 0.32, 5)), Color(1.0, 0.8, 0.3))
	draw_rect(Rect2(Vector2(s.x * 0.34, s.y * 0.16), Vector2(s.x * 0.12, 4)), Color(0.4, 0.9, 1.0))
	draw_rect(Rect2(Vector2(s.x * 0.52, s.y * 0.16), Vector2(s.x * 0.12, 4)), Color(1, 1, 1))

	# feixes de holofote
	for bx in [0.12, 0.3, 0.7, 0.88]:
		var col := Color.from_hsv(fmod(float(bx) * 1.2, 1.0), 0.6, 1.0, 0.22)
		draw_colored_polygon(PackedVector2Array([Vector2(s.x * float(bx), 0), Vector2(s.x * 0.5 - 30.0, s.y * 0.86), Vector2(s.x * 0.5 + 30.0, s.y * 0.86)]), col)

	# plataforma com aro de LED
	draw_rect(Rect2(Vector2(0, s.y * 0.86), Vector2(s.x, s.y * 0.14)), Color(0.05, 0.05, 0.09))
	draw_arc(Vector2(s.x * 0.5, s.y * 0.9), s.x * 0.3, PI, TAU, 40, Color(0.2, 0.85, 1.0), 3.0)


func _draw_beach(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.5), Color(0.22, 0.32, 0.62), Color(1.0, 0.58, 0.28))

	# sol
	draw_circle(Vector2(s.x * 0.74, s.y * 0.42), 22.0, Color(1.0, 0.85, 0.5, 0.35))
	draw_circle(Vector2(s.x * 0.74, s.y * 0.42), 14.0, Color(1.0, 0.92, 0.65))

	# mar
	_grad(Rect2(0, s.y * 0.5, s.x, s.y * 0.2), Color(0.12, 0.45, 0.6), Color(0.22, 0.70, 0.72))

	for i in range(6):
		draw_line(Vector2(s.x * (0.05 + float(i) * 0.17), s.y * (0.56 + float(i % 2) * 0.05)), Vector2(s.x * (0.13 + float(i) * 0.17), s.y * (0.56 + float(i % 2) * 0.05)), Color(1, 1, 1, 0.5), 2.0)

	# areia
	_grad(Rect2(0, s.y * 0.7, s.x, s.y * 0.3), Color(0.93, 0.80, 0.56), Color(0.82, 0.66, 0.42))

	# palmeira
	draw_line(Vector2(s.x * 0.16, s.y * 0.85), Vector2(s.x * 0.2, s.y * 0.3), Color(0.35, 0.22, 0.12), 5.0)

	for a in [-2.5, -1.9, -1.2, -0.6, 0.1, 0.7]:
		var tip := Vector2(s.x * 0.2 + cos(float(a)) * 34.0, s.y * 0.3 + sin(float(a)) * 18.0 + 8.0)
		draw_line(Vector2(s.x * 0.2, s.y * 0.3), tip, Color(0.14, 0.5, 0.2), 4.0)

	# guarda-sol
	draw_line(Vector2(s.x * 0.86, s.y * 0.82), Vector2(s.x * 0.86, s.y * 0.6), Color(0.9, 0.9, 0.9), 2.0)
	draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.78, s.y * 0.62), Vector2(s.x * 0.86, s.y * 0.5), Vector2(s.x * 0.94, s.y * 0.62)]), Color(0.9, 0.2, 0.2))


func _draw_factory(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y), Color(0.09, 0.08, 0.09), Color(0.22, 0.19, 0.17))

	# janelas quebradas com luz azul
	for wx in [0.14, 0.42, 0.70]:
		draw_rect(Rect2(Vector2(s.x * float(wx), s.y * 0.1), Vector2(s.x * 0.16, s.y * 0.28)), Color(0.35, 0.5, 0.9, 0.85))
		draw_rect(Rect2(Vector2(s.x * float(wx), s.y * 0.1), Vector2(s.x * 0.16, s.y * 0.28)), Color(0.05, 0.05, 0.06), false, 3.0)
		draw_line(Vector2(s.x * float(wx) + s.x * 0.08, s.y * 0.1), Vector2(s.x * float(wx) + s.x * 0.08, s.y * 0.38), Color(0.05, 0.05, 0.06), 2.0)

	# tubulações
	draw_rect(Rect2(Vector2(0, s.y * 0.44), Vector2(s.x, 9)), Color(0.55, 0.16, 0.10))
	draw_rect(Rect2(Vector2(0, s.y * 0.52), Vector2(s.x, 7)), Color(0.30, 0.32, 0.34))
	draw_rect(Rect2(Vector2(0, s.y * 0.58), Vector2(s.x, 6)), Color(0.65, 0.50, 0.12))

	# giroflex vermelho com brilho
	draw_circle(Vector2(s.x * 0.9, s.y * 0.2), 24.0, Color(1.0, 0.1, 0.05, 0.25))
	draw_circle(Vector2(s.x * 0.9, s.y * 0.2), 8.0, Color(1.0, 0.2, 0.1))

	# engrenagem
	draw_arc(Vector2(s.x * 0.12, s.y * 0.66), 18.0, 0.0, TAU, 20, Color(0.55, 0.42, 0.12), 5.0)

	# chão com faixa amarela
	_grad(Rect2(0, s.y * 0.78, s.x, s.y * 0.22), Color(0.22, 0.22, 0.23), Color(0.12, 0.12, 0.13))
	draw_rect(Rect2(Vector2(s.x * 0.15, s.y * 0.8), Vector2(s.x * 0.7, 4)), Color(0.92, 0.72, 0.10))


func _draw_gym(s: Vector2) -> void:

	# parede de tijolos
	draw_rect(Rect2(Vector2.ZERO, s), Color(0.42, 0.18, 0.13))

	for row in range(int(s.y / 12.0)):
		var off: float = 0.0 if row % 2 == 0 else 14.0
		draw_line(Vector2(0, float(row) * 12.0), Vector2(s.x, float(row) * 12.0), Color(0.25, 0.10, 0.08), 1.0)
		for i in range(int(s.x / 28.0) + 1):
			draw_line(Vector2(float(i) * 28.0 + off, float(row) * 12.0), Vector2(float(i) * 28.0 + off, float(row + 1) * 12.0), Color(0.25, 0.10, 0.08), 1.0)

	# letreiro
	draw_rect(Rect2(Vector2(s.x * 0.34, s.y * 0.1), Vector2(s.x * 0.32, s.y * 0.2)), Color(0.05, 0.05, 0.07))
	draw_rect(Rect2(Vector2(s.x * 0.34, s.y * 0.1), Vector2(s.x * 0.32, s.y * 0.2)), Color(0.95, 0.74, 0.25), false, 2.0)

	# faixas de LED vermelha/azul e estofado
	draw_rect(Rect2(Vector2(0, s.y * 0.06), Vector2(s.x * 0.5, 4)), Color(1.0, 0.15, 0.15))
	draw_rect(Rect2(Vector2(s.x * 0.5, s.y * 0.06), Vector2(s.x * 0.5, 4)), Color(0.2, 0.45, 1.0))
	draw_rect(Rect2(Vector2(0, s.y * 0.6), Vector2(s.x, s.y * 0.18)), Color(0.07, 0.07, 0.09))

	# ringue
	draw_rect(Rect2(Vector2(s.x * 0.66, s.y * 0.55), Vector2(s.x * 0.3, s.y * 0.12)), Color(0.25, 0.30, 0.5))
	draw_line(Vector2(s.x * 0.66, s.y * 0.5), Vector2(s.x * 0.96, s.y * 0.5), Color(0.95, 0.95, 0.95), 2.0)
	draw_line(Vector2(s.x * 0.66, s.y * 0.44), Vector2(s.x * 0.96, s.y * 0.44), Color(0.9, 0.2, 0.2), 2.0)

	# saco de pancada
	draw_line(Vector2(s.x * 0.12, 0), Vector2(s.x * 0.12, s.y * 0.35), Color(0.6, 0.6, 0.6), 2.0)
	draw_rect(Rect2(Vector2(s.x * 0.12 - 10.0, s.y * 0.35), Vector2(20, 40)), Color(0.55, 0.15, 0.12))

	# piso
	_grad(Rect2(0, s.y * 0.78, s.x, s.y * 0.22), Color(0.14, 0.14, 0.16), Color(0.06, 0.06, 0.08))


func _ellipse(center: Vector2, rx: float, ry: float, color: Color) -> void:

	var pts := PackedVector2Array()

	for i in range(24):
		var a: float = float(i) * TAU / 24.0
		pts.append(center + Vector2(cos(a) * rx, sin(a) * ry))

	draw_colored_polygon(pts, color)


func _draw_saopaulo(s: Vector2) -> void:

	# céu de fim de tarde
	_grad(Rect2(0, 0, s.x, s.y * 0.66), Color(0.30, 0.42, 0.78), Color(1.0, 0.72, 0.46))

	# skyline
	var rng := RandomNumberGenerator.new()
	rng.seed = 21

	var x: float = -4.0

	while x < s.x:
		var w: float = rng.randf_range(14.0, 28.0)
		var h: float = rng.randf_range(s.y * 0.15, s.y * 0.42)
		draw_rect(Rect2(Vector2(x, s.y * 0.62 - h), Vector2(w, h)), Color(0.42, 0.30, 0.38))

		for i in range(int(h / 9.0)):
			if rng.randf() < 0.5:
				draw_rect(Rect2(Vector2(x + 3.0 + float(i % 2) * 8.0, s.y * 0.62 - h + 4.0 + float(i) * 9.0), Vector2(3, 4)), Color(1.0, 0.85, 0.5))

		x += w + 2.0

	# Ponte Estaiada: mastro em X + cabos + tabuleiro
	var bx: float = s.x * 0.66
	var top: float = s.y * 0.06
	var base: float = s.y * 0.62

	for k in range(7):
		var ty: float = top + 6.0 + float(k) * 4.0
		draw_line(Vector2(bx, ty), Vector2(bx + 20.0 + float(k) * 12.0, base - 10.0), Color(1, 1, 1, 0.55), 1.0)
		draw_line(Vector2(bx, ty), Vector2(bx - 20.0 - float(k) * 12.0, base - 10.0), Color(1, 1, 1, 0.55), 1.0)

	draw_line(Vector2(bx - 16.0, base), Vector2(bx + 12.0, top), Color(0.95, 0.85, 1.0), 5.0)
	draw_line(Vector2(bx + 16.0, base), Vector2(bx - 12.0, top), Color(0.85, 0.95, 1.0), 5.0)
	draw_line(Vector2(0, base - 10.0), Vector2(s.x, base - 10.0), Color(0.85, 0.85, 0.9), 4.0)

	# rio Tietê (verde-oliva) com patinho
	_grad(Rect2(0, base, s.x, s.y * 0.14), Color(0.30, 0.34, 0.15), Color(0.20, 0.24, 0.10))
	_ellipse(Vector2(s.x * 0.18, base + 9.0), 7.0, 5.0, Color(1.0, 0.85, 0.1))
	_ellipse(Vector2(s.x * 0.18 + 6.0, base + 4.0), 3.5, 3.5, Color(1.0, 0.85, 0.1))

	# rua com trânsito
	draw_rect(Rect2(Vector2(0, s.y * 0.76), Vector2(s.x, s.y * 0.24)), Color(0.20, 0.20, 0.22))

	var cols := [Color(0.85, 0.1, 0.12), Color(0.95, 0.85, 0.15), Color(0.15, 0.35, 0.85), Color(0.9, 0.9, 0.92), Color(0.2, 0.65, 0.35)]

	for i in range(9):
		draw_rect(Rect2(Vector2(4.0 + float(i) * 30.0, s.y * 0.78), Vector2(24, 10)), cols[i % cols.size()])
		draw_rect(Rect2(Vector2(8.0 + float(i) * 30.0, s.y * 0.75), Vector2(14, 5)), Color(0.08, 0.12, 0.18))

	# cachorro caramelo (com coroa)
	_ellipse(Vector2(s.x * 0.82, s.y * 0.72), 15.0, 9.0, Color(0.86, 0.55, 0.24))
	draw_circle(Vector2(s.x * 0.82 + 15.0, s.y * 0.66), 7.0, Color(0.86, 0.55, 0.24))
	_ellipse(Vector2(s.x * 0.82 + 8.0, s.y * 0.62), 3.0, 5.0, Color(0.62, 0.36, 0.15))
	draw_colored_polygon(PackedVector2Array([
		Vector2(s.x * 0.82 + 10.0, s.y * 0.56), Vector2(s.x * 0.82 + 13.0, s.y * 0.50), Vector2(s.x * 0.82 + 16.0, s.y * 0.56), Vector2(s.x * 0.82 + 19.0, s.y * 0.50), Vector2(s.x * 0.82 + 21.0, s.y * 0.56)
	]), Color(1.0, 0.8, 0.2))

	# fitas verde e amarela no canto (Seleção)
	draw_rect(Rect2(Vector2(0, 0), Vector2(s.x * 0.5, 5)), Color(0.0, 0.58, 0.24))
	draw_rect(Rect2(Vector2(s.x * 0.5, 0), Vector2(s.x * 0.5, 5)), Color(1.0, 0.86, 0.05))


func _draw_locked(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y), Color(0.10, 0.10, 0.16), Color(0.04, 0.04, 0.08))

	# interrogações de fundo
	for i in range(6):
		draw_string(ThemeDB.fallback_font, Vector2(14.0 + float(i) * (s.x / 6.0), 26.0 + float(i % 2) * 34.0), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color(1, 1, 1, 0.07))

	# cadeado
	var c := Vector2(s.x / 2.0, s.y * 0.58)

	draw_arc(c + Vector2(0, -14.0), 15.0, PI, TAU, 20, Color(0.80, 0.80, 0.85), 6.0)
	draw_rect(Rect2(c + Vector2(-24.0, -14.0), Vector2(48, 36)), Color(0.96, 0.75, 0.26))
	draw_rect(Rect2(c + Vector2(-24.0, -14.0), Vector2(48, 36)), Color(0.35, 0.25, 0.05), false, 2.0)
	draw_circle(c + Vector2(0, 0), 5.0, Color(0.15, 0.10, 0.02))
	draw_rect(Rect2(c + Vector2(-2.0, 0), Vector2(4, 12)), Color(0.15, 0.10, 0.02))


func _tri(a: Vector2, b: Vector2, c: Vector2, color: Color) -> void:

	draw_colored_polygon(PackedVector2Array([a, b, c]), color)


func _draw_random(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y), Color(0.20, 0.10, 0.35), Color(0.06, 0.04, 0.14))

	# miniaturas inclinadas ao fundo (várias arenas embaralhadas)
	var cols := [Color(1.0, 0.6, 0.3), Color(0.3, 0.8, 0.5), Color(0.3, 0.6, 1.0), Color(1.0, 0.3, 0.6), Color(0.95, 0.85, 0.2)]

	for i in range(5):
		var cx: float = s.x * (0.12 + float(i) * 0.19)
		var cy: float = s.y * (0.30 + float(i % 2) * 0.28)
		var c: Color = cols[i]
		draw_colored_polygon(PackedVector2Array([
			Vector2(cx - 22, cy - 14 + float(i) * 2.0), Vector2(cx + 22, cy - 18), Vector2(cx + 20, cy + 16), Vector2(cx - 24, cy + 18)
		]), Color(c.r, c.g, c.b, 0.55))

	# dado no centro
	var d := Rect2(Vector2(s.x / 2.0 - 26.0, s.y / 2.0 - 26.0), Vector2(52, 52))
	draw_rect(d, Color(0.97, 0.97, 0.97))
	draw_rect(d, Color(0.1, 0.1, 0.15), false, 3.0)

	for dot in [Vector2(-14, -14), Vector2(14, -14), Vector2(0, 0), Vector2(-14, 14), Vector2(14, 14)]:
		draw_circle(Vector2(s.x / 2.0, s.y / 2.0) + dot, 5.0, Color(0.1, 0.1, 0.15))


func _draw_laje(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.6), Color(0.28, 0.38, 0.75), Color(1.0, 0.66, 0.36))

	var rng := RandomNumberGenerator.new()
	rng.seed = 4

	var house_cols := [Color(1.0, 0.75, 0.6), Color(1.0, 0.9, 0.6), Color(0.7, 0.85, 1.0), Color(1.0, 0.7, 0.8), Color(0.75, 0.95, 0.7)]

	for row in range(3):
		var x: float = -6.0
		while x < s.x:
			var w: float = rng.randf_range(20.0, 34.0)
			var h: float = rng.randf_range(14.0, 26.0)
			var y: float = s.y * (0.42 + float(row) * 0.06)
			draw_rect(Rect2(Vector2(x, y - h + 8.0), Vector2(w, h)), house_cols[rng.randi() % house_cols.size()].darkened(0.1 * float(2 - row)))

			if rng.randf() < 0.4:
				draw_rect(Rect2(Vector2(x + w * 0.3, y - h), Vector2(8, 8)), Color(0.2, 0.45, 0.85))

			x += w + 2.0

	# laje em primeiro plano
	_grad(Rect2(0, s.y * 0.62, s.x, s.y * 0.38), Color(0.62, 0.60, 0.56), Color(0.45, 0.43, 0.40))

	# bandeirinhas
	for i in range(14):
		var fx: float = 6.0 + float(i) * (s.x - 12.0) / 13.0
		_tri(Vector2(fx - 5, 8 + 6 * sin(float(i) * 0.5)), Vector2(fx + 5, 8 + 6 * sin(float(i) * 0.5)), Vector2(fx, 20 + 6 * sin(float(i) * 0.5)), Color.from_hsv(float(i) * 0.13, 0.8, 1.0))

	# churrasqueira com brasa, paredão e piscina de flamingo
	draw_rect(Rect2(Vector2(s.x * 0.08, s.y * 0.66), Vector2(34, 18)), Color(0.62, 0.30, 0.22))
	draw_rect(Rect2(Vector2(s.x * 0.08 + 3.0, s.y * 0.66), Vector2(28, 4)), Color(1.0, 0.45, 0.1))
	draw_rect(Rect2(Vector2(s.x * 0.80, s.y * 0.58), Vector2(26, 38)), Color(0.06, 0.06, 0.07))
	draw_circle(Vector2(s.x * 0.80 + 13.0, s.y * 0.68), 8.0, Color(1.0, 0.2, 0.6))
	_ellipse(Vector2(s.x * 0.66, s.y * 0.82), 24.0, 8.0, Color(0.2, 0.55, 0.92))
	_ellipse(Vector2(s.x * 0.66 + 6.0, s.y * 0.8), 8.0, 4.0, Color(1.0, 0.45, 0.65))


func _draw_arraia(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y), Color(0.03, 0.04, 0.13), Color(0.12, 0.12, 0.30))

	var rng := RandomNumberGenerator.new()
	rng.seed = 8

	for i in range(24):
		draw_circle(Vector2(rng.randf() * s.x, rng.randf() * s.y * 0.5), 1.2, Color(1, 1, 1, 0.8))

	draw_circle(Vector2(s.x * 0.85, s.y * 0.18), 9.0, Color(1.0, 0.98, 0.85))

	# igrejinha iluminada
	draw_rect(Rect2(Vector2(s.x * 0.36, s.y * 0.38), Vector2(s.x * 0.28, s.y * 0.3)), Color(0.95, 0.94, 0.9))
	_tri(Vector2(s.x * 0.34, s.y * 0.38), Vector2(s.x * 0.5, s.y * 0.22), Vector2(s.x * 0.66, s.y * 0.38), Color(0.65, 0.2, 0.12))
	draw_rect(Rect2(Vector2(s.x * 0.44, s.y * 0.48), Vector2(9, 16)), Color(1.0, 0.85, 0.45))
	draw_rect(Rect2(Vector2(s.x * 0.54, s.y * 0.48), Vector2(9, 16)), Color(1.0, 0.85, 0.45))

	# bandeirinhas
	for r in range(3):
		for i in range(16):
			var fx: float = 4.0 + float(i) * (s.x - 8.0) / 15.0
			var fy: float = 10.0 + float(r) * 12.0 + 7.0 * sin(float(i) / 15.0 * PI)
			_tri(Vector2(fx - 4, fy), Vector2(fx + 4, fy), Vector2(fx, fy + 9), Color.from_hsv(fmod(float(i) * 0.15 + float(r) * 0.3, 1.0), 0.85, 1.0))

	# barracas listradas
	for i in range(4):
		var bx: float = s.x * (0.06 + float(i) * 0.24)
		for k in range(4):
			draw_rect(Rect2(Vector2(bx + float(k) * 8.0, s.y * 0.62), Vector2(8, 8)), Color(0.95, 0.25, 0.2) if k % 2 == 0 else Color(1, 1, 1))

		draw_rect(Rect2(Vector2(bx, s.y * 0.7), Vector2(32, 12)), Color(0.4, 0.26, 0.14))

	# fogueira
	_tri(Vector2(s.x * 0.5 - 12.0, s.y * 0.94), Vector2(s.x * 0.5, s.y * 0.74), Vector2(s.x * 0.5 + 12.0, s.y * 0.94), Color(1.0, 0.5, 0.1))
	_tri(Vector2(s.x * 0.5 - 6.0, s.y * 0.94), Vector2(s.x * 0.5, s.y * 0.82), Vector2(s.x * 0.5 + 6.0, s.y * 0.94), Color(1.0, 0.9, 0.3))


func _draw_farofa(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.4), Color(0.20, 0.45, 0.85), Color(0.75, 0.88, 1.0))
	draw_circle(Vector2(s.x * 0.85, s.y * 0.14), 12.0, Color(1.0, 0.97, 0.6))

	_grad(Rect2(0, s.y * 0.4, s.x, s.y * 0.22), Color(0.05, 0.5, 0.65), Color(0.3, 0.85, 0.8))
	_grad(Rect2(0, s.y * 0.62, s.x, s.y * 0.38), Color(0.95, 0.83, 0.6), Color(0.85, 0.7, 0.45))

	var rng := RandomNumberGenerator.new()
	rng.seed = 6

	# guarda-sóis e banhistas (lotado!)
	for i in range(16):
		var ux: float = rng.randf_range(10.0, s.x - 10.0)
		var uy: float = rng.randf_range(s.y * 0.66, s.y * 0.92)
		var c := Color.from_hsv(rng.randf(), 0.8, 1.0)
		_tri(Vector2(ux - 12, uy), Vector2(ux + 12, uy), Vector2(ux, uy - 10), c)
		draw_line(Vector2(ux, uy - 10), Vector2(ux, uy + 10), Color(0.9, 0.9, 0.9), 1.5)
		draw_circle(Vector2(ux + 8, uy + 8), 3.0, Color(0.95, 0.75, 0.6))

	# calçadão de ondas
	for i in range(int(s.x / 8.0)):
		draw_rect(Rect2(Vector2(float(i) * 8.0, s.y * 0.60), Vector2(4, 4)), Color(0.12, 0.12, 0.14) if i % 2 == 0 else Color(0.95, 0.94, 0.9))


func _draw_varzea(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.5), Color(0.32, 0.55, 0.88), Color(0.92, 0.92, 0.85))

	# casinhas e morro ao fundo
	_ellipse(Vector2(s.x * 0.3, s.y * 0.5), 70.0, 24.0, Color(0.28, 0.48, 0.28))

	for i in range(9):
		draw_rect(Rect2(Vector2(6.0 + float(i) * 32.0, s.y * 0.36 - float(i % 3) * 5.0), Vector2(22, 16)), Color(0.95, 0.85, 0.75))

	# gramado com terra e linhas
	_grad(Rect2(0, s.y * 0.5, s.x, s.y * 0.5), Color(0.38, 0.55, 0.22), Color(0.30, 0.45, 0.18))
	_ellipse(Vector2(s.x * 0.62, s.y * 0.78), 30.0, 10.0, Color(0.55, 0.4, 0.24))
	draw_arc(Vector2(s.x * 0.5, s.y * 0.76), 30.0, 0.0, TAU, 24, Color(0.95, 0.95, 0.9), 2.0)
	draw_line(Vector2(0, s.y * 0.76), Vector2(s.x, s.y * 0.76), Color(0.95, 0.95, 0.9), 2.0)

	# gol torto
	draw_line(Vector2(s.x * 0.42, s.y * 0.5), Vector2(s.x * 0.43, s.y * 0.36), Color(0.95, 0.95, 0.92), 3.0)
	draw_line(Vector2(s.x * 0.58, s.y * 0.5), Vector2(s.x * 0.575, s.y * 0.38), Color(0.95, 0.95, 0.92), 3.0)
	draw_line(Vector2(s.x * 0.43, s.y * 0.36), Vector2(s.x * 0.575, s.y * 0.38), Color(0.95, 0.95, 0.92), 3.0)

	# alambrado + torcida
	for i in range(int(s.x / 10.0)):
		draw_line(Vector2(float(i) * 10.0, s.y * 0.6), Vector2(float(i) * 10.0, s.y * 0.7), Color(0.6, 0.62, 0.65), 1.0)
		draw_circle(Vector2(float(i) * 10.0 + 5.0, s.y * 0.56), 3.0, Color.from_hsv(float(i) * 0.11, 0.6, 0.95))

	# vaquinha
	_ellipse(Vector2(s.x * 0.86, s.y * 0.86), 12.0, 6.0, Color(0.96, 0.96, 0.94))
	draw_circle(Vector2(s.x * 0.86 + 11.0, s.y * 0.82), 4.0, Color(0.96, 0.96, 0.94))
	_ellipse(Vector2(s.x * 0.86 - 2.0, s.y * 0.85), 4.0, 3.0, Color(0.1, 0.1, 0.1))


func _draw_buraco(s: Vector2) -> void:

	_grad(Rect2(0, 0, s.x, s.y * 0.5), Color(0.35, 0.45, 0.75), Color(1.0, 0.7, 0.4))

	# serras
	draw_rect(Rect2(Vector2(s.x * 0.05, s.y * 0.32), Vector2(s.x * 0.3, s.y * 0.18)), Color(0.55, 0.32, 0.22))
	draw_rect(Rect2(Vector2(s.x * 0.5, s.y * 0.36), Vector2(s.x * 0.4, s.y * 0.14)), Color(0.5, 0.3, 0.2))

	# terra vermelha e rodovia
	draw_rect(Rect2(Vector2(0, s.y * 0.5), Vector2(s.x, s.y * 0.5)), Color(0.62, 0.36, 0.2))
	draw_rect(Rect2(Vector2(0, s.y * 0.56), Vector2(s.x, s.y * 0.34)), Color(0.17, 0.17, 0.19))
	draw_line(Vector2(0, s.y * 0.72), Vector2(s.x, s.y * 0.72), Color(0.95, 0.78, 0.1), 2.0)
	draw_line(Vector2(0, s.y * 0.74), Vector2(s.x, s.y * 0.74), Color(0.95, 0.78, 0.1), 2.0)

	# crateras
	_ellipse(Vector2(s.x * 0.2, s.y * 0.82), 22.0, 7.0, Color(0.05, 0.04, 0.04))
	_ellipse(Vector2(s.x * 0.7, s.y * 0.66), 26.0, 7.0, Color(0.05, 0.04, 0.04))
	_ellipse(Vector2(s.x * 0.7, s.y * 0.66), 16.0, 4.0, Color(0.35, 0.25, 0.15))

	# caminhão de melancia
	draw_rect(Rect2(Vector2(s.x * 0.34, s.y * 0.56), Vector2(60, 20)), Color(0.55, 0.38, 0.2))
	draw_rect(Rect2(Vector2(s.x * 0.34 + 60.0, s.y * 0.58), Vector2(22, 18)), Color(0.85, 0.1, 0.1))

	for i in range(5):
		draw_circle(Vector2(s.x * 0.34 + 8.0 + float(i) * 11.0, s.y * 0.55), 6.0, Color(0.15, 0.55, 0.2))

	# placa "ponte caiu"
	draw_rect(Rect2(Vector2(s.x * 0.06, s.y * 0.44), Vector2(70, 22)), Color(0.95, 0.75, 0.1))
	draw_string(ThemeDB.fallback_font, Vector2(s.x * 0.06 + 6.0, s.y * 0.44 + 15.0), "PONTE CAIU", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.1, 0.05, 0.02))
