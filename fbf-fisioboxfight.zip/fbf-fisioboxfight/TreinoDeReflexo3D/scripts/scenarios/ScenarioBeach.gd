# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioBeach
# PRAIA TROPICAL: areia, mar com ondas animadas (shader), palmeiras
# balançando, pôr do sol alaranjado, rochas, cabana, guarda-sóis, rede de
# vôlei, gaivotas e nuvens passando.

var _palms: Array = []
var _fronds: Array = []

const WATER_SHADER := """
shader_type spatial;

uniform vec4 deep_color : source_color = vec4(0.04, 0.28, 0.42, 1.0);
uniform vec4 shallow_color : source_color = vec4(0.22, 0.70, 0.72, 1.0);
uniform vec4 sun_tint : source_color = vec4(1.0, 0.6, 0.3, 1.0);

varying float wave_h;

void vertex() {
	float w = sin(VERTEX.x * 0.55 + TIME * 1.1) * 0.10
		+ sin(VERTEX.z * 0.80 + TIME * 0.8) * 0.08
		+ sin((VERTEX.x + VERTEX.z) * 0.35 + TIME * 0.6) * 0.12;
	VERTEX.y += w;
	wave_h = w;
}

void fragment() {
	float f = clamp(wave_h * 3.5 + 0.5, 0.0, 1.0);
	vec3 col = mix(deep_color.rgb, shallow_color.rgb, f);
	col = mix(col, sun_tint.rgb, 0.12);
	col += vec3(0.20) * smoothstep(0.24, 0.32, wave_h);
	ALBEDO = col;
	ROUGHNESS = 0.06;
	METALLIC = 0.15;
	SPECULAR = 0.9;
}
"""


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.22, 0.32, 0.62)
	sky_mat.sky_horizon_color = Color(1.0, 0.58, 0.28)
	sky_mat.ground_horizon_color = Color(0.95, 0.6, 0.35)
	sky_mat.ground_bottom_color = Color(0.4, 0.3, 0.22)
	sky_mat.sun_angle_max = 30.0

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.62, 0.5)
	env.ambient_light_energy = 0.85

	env.fog_enabled = true
	env.fog_light_color = Color(1.0, 0.68, 0.45)
	env.fog_density = 0.005

	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_hdr_threshold = 1.0

	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.2

	return env


func _build() -> void:

	# sol baixo, atrás e à direita (ele aparece no céu)
	_sun(Vector3(-11, 150, 0), Color(1.0, 0.62, 0.32), 1.6)

	# luz de preenchimento suave vinda da frente (rosada)
	_sun(Vector3(-35, -20, 0), Color(0.9, 0.55, 0.6), 0.35, false)

	_build_sand_and_sea()
	_build_palms()
	_build_rocks()
	_build_hut()
	_build_props()
	_build_sky_life()

	_make_accent(Vector3(0.0, 3.0, -2.5), Color(1.0, 0.7, 0.4), 0.5, 9.0)

	# palmeiras balançando ao vento
	_anim.append(func(t: float, _dt: float):
		for i in range(_palms.size()):
			var p: Node3D = _palms[i]
			p.rotation_degrees.z = sin(t * 0.8 + float(i) * 1.6) * 1.8
		for i in range(_fronds.size()):
			var f: Node3D = _fronds[i]
			f.rotation_degrees.x = sin(t * 1.6 + float(i) * 0.7) * 4.0
	)


# ------------------------------------------------------------
# Areia, faixa molhada, mar (ondas por shader) e espuma
# ------------------------------------------------------------

func _build_sand_and_sea() -> void:

	var sand := _mat(Color(0.90, 0.76, 0.52), 1.0, 0.0)
	var wet := _mat(Color(0.62, 0.50, 0.34), 0.55, 0.0)

	_box(self, Vector3(0, -0.06, -2.8), Vector3(70, 0.12, 13.6), sand)
	_box(self, Vector3(0, 0.001, -8.6), Vector3(70, 0.004, 2.0), wet)

	# ondulações na areia (dunas suaves)
	for i in range(7):
		var x: float = -9.0 + float(i) * 3.0
		_sphere(self, Vector3(x, -0.12, 0.6 - float(i % 3) * 1.0), 1.6, sand, Vector3(2.0, 0.14, 1.0))

	# mar
	var shader := Shader.new()
	shader.code = WATER_SHADER

	var water := ShaderMaterial.new()
	water.shader = shader

	var sea_mesh := PlaneMesh.new()
	sea_mesh.size = Vector2(140, 90)
	sea_mesh.subdivide_width = 90
	sea_mesh.subdivide_depth = 60

	var sea := MeshInstance3D.new()
	sea.mesh = sea_mesh
	_put(self, sea, Vector3(0, -0.04, -53.6), Vector3.ZERO, water)
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	# espuma na beira (vai e volta)
	var foam_mat := StandardMaterial3D.new()
	foam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	foam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	foam_mat.albedo_color = Color(1, 1, 1, 0.55)

	var foam := _no_shadow(_plane(self, Vector3(0, 0.012, -9.2), Vector2(70, 0.5), foam_mat))
	var foam2 := _no_shadow(_plane(self, Vector3(0, 0.013, -10.4), Vector2(70, 0.3), foam_mat))

	_anim.append(func(t: float, _dt: float):
		foam.position.z = -9.2 + sin(t * 0.9) * 0.55
		foam2.position.z = -10.4 + sin(t * 0.9 + 1.2) * 0.6
		foam_mat.albedo_color.a = 0.35 + 0.25 * (0.5 + 0.5 * sin(t * 0.9))
	)


# ------------------------------------------------------------
# Palmeiras
# ------------------------------------------------------------

func _palm(pos: Vector3, height: float, lean: float) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	var bark := _mat(Color(0.42, 0.28, 0.16), 0.9, 0.0)
	var leaf := _mat(Color(0.14, 0.50, 0.20), 0.8, 0.0)
	var leaf2 := _mat(Color(0.22, 0.60, 0.25), 0.8, 0.0)

	var segs: int = 6
	var top := Vector3.ZERO

	for i in range(segs):

		var seg_h: float = height / float(segs)
		var y: float = seg_h * (float(i) + 0.5)
		var x: float = lean * pow(float(i) / float(segs), 2.0)

		_cyl(root, Vector3(x, y, 0), 0.17 - float(i) * 0.012, seg_h * 1.05, bark, Vector3(0, 0, -lean * 9.0 * float(i) / float(segs)))
		top = Vector3(x, seg_h * float(i + 1), 0)

	var crown := Node3D.new()
	crown.position = top
	root.add_child(crown)

	# cocos
	_sphere(crown, Vector3(0.12, -0.1, 0.1), 0.11, _mat(Color(0.35, 0.22, 0.1), 0.8, 0.0))
	_sphere(crown, Vector3(-0.1, -0.12, 0.08), 0.11, _mat(Color(0.35, 0.22, 0.1), 0.8, 0.0))

	# folhas: 8 folhas em leque
	for k in range(8):

		var pivot := Node3D.new()
		pivot.rotation_degrees = Vector3(0, float(k) * 45.0, 0)
		crown.add_child(pivot)

		var droop := Node3D.new()
		droop.rotation_degrees = Vector3(28.0, 0, 0)
		pivot.add_child(droop)
		_fronds.append(droop)

		var m: StandardMaterial3D = leaf if k % 2 == 0 else leaf2

		_box(droop, Vector3(0, 0, -0.9), Vector3(0.34, 0.03, 1.8), m)
		_box(droop, Vector3(0, -0.14, -2.0), Vector3(0.26, 0.03, 0.9), m, Vector3(22, 0, 0))

	_palms.append(root)


func _build_palms() -> void:

	_palm(Vector3(-4.6, 0, -5.0), 4.6, 0.6)
	_palm(Vector3(5.4, 0, -6.0), 5.2, -0.7)
	_palm(Vector3(-8.8, 0, -3.6), 4.2, 0.5)
	_palm(Vector3(9.6, 0, -3.2), 4.8, -0.5)
	_palm(Vector3(-13.0, 0, -6.0), 5.4, 0.7)
	_palm(Vector3(13.5, 0, -7.0), 5.0, -0.6)

	# vegetação rasteira (arbustos)
	var bush := _mat(Color(0.12, 0.42, 0.20), 0.9, 0.0)

	for p in [Vector3(-3.0, 0.3, -5.6), Vector3(3.4, 0.3, -6.4), Vector3(-6.4, 0.3, -4.4), Vector3(7.0, 0.3, -4.6)]:
		_sphere(self, p, 0.6, bush, Vector3(1.4, 0.8, 1.1))


# ------------------------------------------------------------
# Rochas, cabana, guarda-sóis...
# ------------------------------------------------------------

func _build_rocks() -> void:

	var rock := _mat(Color(0.40, 0.36, 0.33), 0.95, 0.0)
	var rock2 := _mat(Color(0.32, 0.29, 0.28), 0.95, 0.0)

	var specs := [
		[Vector3(7.8, 0.5, -6.6), 1.5, Vector3(1.2, 0.9, 1.0)],
		[Vector3(9.4, 0.4, -5.6), 1.0, Vector3(1.0, 0.8, 1.2)],
		[Vector3(-7.4, 0.4, -7.6), 1.3, Vector3(1.3, 0.8, 1.0)],
		[Vector3(-10.0, 0.6, -6.4), 1.7, Vector3(1.1, 1.0, 1.1)],
		[Vector3(3.2, 0.3, -8.4), 0.9, Vector3(1.4, 0.7, 1.0)],
	]

	for i in range(specs.size()):
		var p: Vector3 = specs[i][0]
		var r: float = specs[i][1]
		var s: Vector3 = specs[i][2]
		var m: StandardMaterial3D = rock if i % 2 == 0 else rock2
		_sphere(self, p, r, m, s)


func _build_hut() -> void:

	var root := Node3D.new()
	root.position = Vector3(-7.6, 0, -7.0)
	root.rotation_degrees = Vector3(0, 12, 0)
	add_child(root)

	var wood := _mat(Color(0.55, 0.36, 0.20), 0.8, 0.0)
	var dark := _mat(Color(0.30, 0.19, 0.10), 0.8, 0.0)
	var thatch := _mat(Color(0.72, 0.58, 0.28), 1.0, 0.0)

	for sx in [-1.6, 1.6]:
		for sz in [-1.2, 1.2]:
			_cyl(root, Vector3(sx, 1.2, sz), 0.09, 2.4, dark)

	_box(root, Vector3(0, 0.55, 0), Vector3(3.4, 0.16, 2.6), wood)
	_box(root, Vector3(0, 0.95, 1.2), Vector3(3.3, 0.9, 0.1), wood)

	# telhado de palha
	_cone(root, Vector3(0, 2.9, 0), 3.0, 1.2, thatch, Vector3.ZERO, 4).rotation_degrees = Vector3(0, 45, 0)

	_label("SURF BAR", Vector3(0, 2.15, 1.3), 70, 0.0055, Color(1.0, 0.9, 0.6), Vector3.ZERO, root)

	# pranchas de surfe espetadas na areia
	var board_cols := [Color(0.9, 0.2, 0.3), Color(0.2, 0.7, 0.9), Color(0.95, 0.8, 0.2)]

	for i in range(3):
		var b := _sphere(root, Vector3(-2.3 + float(i) * 0.4, 1.0, 1.6), 0.35, _mat(board_cols[i], 0.4, 0.1), Vector3(0.5, 2.6, 0.12))
		b.rotation_degrees = Vector3(0, 0, float(i - 1) * 6.0)


func _umbrella(pos: Vector3, color: Color) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	_cyl(root, Vector3(0, 1.1, 0), 0.03, 2.2, _mat(Color(0.85, 0.85, 0.85), 0.5, 0.5))
	_cone(root, Vector3(0, 2.15, 0), 1.25, 0.5, _mat(color, 0.8, 0.0), Vector3.ZERO, 8)
	_cone(root, Vector3(0, 2.2, 0), 1.0, 0.45, _mat(Color(0.98, 0.98, 0.98), 0.8, 0.0), Vector3.ZERO, 8).scale = Vector3(1.0, 1.0, 1.0)


func _lounger(pos: Vector3, yaw: float, color: Color) -> void:

	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0, yaw, 0)
	add_child(root)

	var m := _mat(color, 0.8, 0.0)

	_box(root, Vector3(0, 0.22, 0), Vector3(0.7, 0.08, 1.4), m)
	_box(root, Vector3(0, 0.5, -0.62), Vector3(0.7, 0.08, 0.7), m, Vector3(-55, 0, 0))


func _build_props() -> void:

	_umbrella(Vector3(-5.0, 0, -2.0), Color(0.9, 0.2, 0.2))
	_umbrella(Vector3(6.2, 0, -1.6), Color(0.2, 0.6, 0.9))
	_umbrella(Vector3(-9.0, 0, -0.6), Color(0.95, 0.75, 0.15))

	_lounger(Vector3(-4.2, 0, -1.0), 10.0, Color(0.95, 0.95, 0.95))
	_lounger(Vector3(5.4, 0, -0.6), -14.0, Color(0.95, 0.95, 0.95))

	# rede de vôlei
	var pole := _mat(Color(0.85, 0.85, 0.85), 0.5, 0.4)
	var net := _mat(Color(0.95, 0.95, 0.95, 0.5), 1.0, 0.0)
	net.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

	_cyl(self, Vector3(-2.4, 1.2, -4.4), 0.045, 2.4, pole)
	_cyl(self, Vector3(2.4, 1.2, -4.4), 0.045, 2.4, pole)
	_box(self, Vector3(0, 1.85, -4.4), Vector3(4.8, 0.7, 0.01), net)
	_box(self, Vector3(0, 2.2, -4.4), Vector3(4.8, 0.06, 0.03), _mat(Color(0.95, 0.95, 0.95), 0.6, 0.0))

	# bola de vôlei
	_sphere(self, Vector3(1.4, 0.16, -3.6), 0.16, _mat(Color(0.98, 0.9, 0.3), 0.5, 0.0))

	# torre de salva-vidas ao longe
	var tower := Node3D.new()
	tower.position = Vector3(11.0, 0, -7.6)
	add_child(tower)

	for sx in [-0.6, 0.6]:
		for sz in [-0.6, 0.6]:
			_cyl(tower, Vector3(sx, 1.1, sz), 0.06, 2.2, _mat(Color(0.95, 0.95, 0.95), 0.6, 0.0))

	_box(tower, Vector3(0, 2.3, 0), Vector3(1.6, 0.12, 1.6), _mat(Color(0.95, 0.35, 0.2), 0.6, 0.0))
	_box(tower, Vector3(0, 2.9, -0.6), Vector3(1.6, 1.0, 0.08), _mat(Color(0.95, 0.95, 0.95), 0.6, 0.0))
	_box(tower, Vector3(0, 3.5, 0), Vector3(2.0, 0.1, 2.0), _mat(Color(0.95, 0.35, 0.2), 0.6, 0.0))


# ------------------------------------------------------------
# Céu: nuvens à deriva e gaivotas voando em círculo
# ------------------------------------------------------------

func _build_sky_life() -> void:

	var cloud_mat := StandardMaterial3D.new()
	cloud_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cloud_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	cloud_mat.albedo_color = Color(1.0, 0.78, 0.62, 0.75)

	var clouds: Array = []

	for i in range(6):

		var c := Node3D.new()
		c.position = Vector3(-40.0 + float(i) * 16.0, 16.0 + float(i % 3) * 3.0, -60.0 - float(i % 2) * 14.0)
		add_child(c)

		_no_shadow(_sphere(c, Vector3(0, 0, 0), 4.0, cloud_mat, Vector3(2.4, 0.5, 1.0)))
		_no_shadow(_sphere(c, Vector3(4.0, 0.6, 0), 3.0, cloud_mat, Vector3(2.0, 0.55, 1.0)))
		_no_shadow(_sphere(c, Vector3(-4.5, 0.3, 0), 3.2, cloud_mat, Vector3(2.0, 0.5, 1.0)))

		clouds.append(c)

	var gulls: Array = []
	var wings: Array = []
	var gull_mat := _mat(Color(0.97, 0.97, 0.97), 0.6, 0.0)

	for i in range(3):

		var g := Node3D.new()
		add_child(g)

		var lw := Node3D.new()
		g.add_child(lw)
		_box(lw, Vector3(-0.35, 0, 0), Vector3(0.7, 0.02, 0.14), gull_mat)

		var rw := Node3D.new()
		g.add_child(rw)
		_box(rw, Vector3(0.35, 0, 0), Vector3(0.7, 0.02, 0.14), gull_mat)

		gulls.append(g)
		wings.append([lw, rw])

	_anim.append(func(t: float, dt: float):

		for i in range(clouds.size()):
			var c2: Node3D = clouds[i]
			c2.position.x += dt * (0.5 + float(i % 3) * 0.25)
			if c2.position.x > 55.0:
				c2.position.x = -55.0

		for i in range(gulls.size()):
			var g2: Node3D = gulls[i]
			var a: float = t * (0.25 + float(i) * 0.05) + float(i) * 2.1
			g2.position = Vector3(cos(a) * (8.0 + float(i) * 3.0), 8.0 + float(i) * 1.6 + sin(a * 2.0), -22.0 + sin(a) * 5.0)
			g2.rotation_degrees.y = -rad_to_deg(a) + 90.0

			var flap: float = sin(t * 5.0 + float(i)) * 25.0
			var pair: Array = wings[i]
			var l2: Node3D = pair[0]
			var r2: Node3D = pair[1]
			l2.rotation_degrees.z = flap
			r2.rotation_degrees.z = -flap
	)
