# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioCity
# CIDADE À NOITE: rua molhada refletindo neon, prédios altos com janelas
# acesas, letreiros piscando, carros estacionados, poste de luz, vapor do
# bueiro e um pessoal assistindo a luta da calçada.


func make_environment() -> Environment:

	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.02, 0.02, 0.07)

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.22, 0.24, 0.42)
	env.ambient_light_energy = 0.8

	env.fog_enabled = true
	env.fog_light_color = Color(0.10, 0.07, 0.20)
	env.fog_density = 0.016

	env.glow_enabled = true
	env.glow_intensity = 0.95
	env.glow_hdr_threshold = 0.85

	# reflexos na rua molhada (só no Forward+; nos outros é ignorado)
	env.ssr_enabled = true
	env.ssr_max_steps = 48
	env.ssr_fade_in = 0.15
	env.ssr_fade_out = 2.0
	env.ssr_depth_tolerance = 0.25

	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.5

	return env


func _build() -> void:

	_sun(Vector3(-50, -30, 0), Color(0.55, 0.60, 1.0), 0.55)

	_build_street()
	_build_buildings()
	_build_signs()
	_build_lamps()
	_build_cars()
	_build_crowd()
	_build_steam()

	# luzes coloridas dos letreiros nos lutadores (rosa e ciano)
	_omni(Vector3(-4.0, 2.6, -1.2), Color(1.0, 0.25, 0.7), 1.7, 8.0)
	_omni(Vector3(4.0, 2.6, -1.2), Color(0.2, 0.85, 1.0), 1.7, 8.0)

	_make_accent(Vector3(0.0, 3.6, -3.5), Color(0.8, 0.45, 1.0), 0.6, 10.0)


# ------------------------------------------------------------
# Rua e calçada
# ------------------------------------------------------------

func _build_street() -> void:

	var asphalt := _mat(Color(0.05, 0.05, 0.07), 0.16, 0.25)

	_box(self, Vector3(0, -0.05, -6.0), Vector3(44, 0.1, 26), asphalt)

	# calçada elevada ao fundo
	var side := _mat(Color(0.16, 0.16, 0.19), 0.6, 0.0)
	_box(self, Vector3(0, 0.08, -6.6), Vector3(44, 0.16, 3.2), side)
	_box(self, Vector3(0, 0.09, -4.98), Vector3(44, 0.18, 0.12), _mat(Color(0.32, 0.32, 0.36), 0.5, 0.0))

	# faixa amarela tracejada
	var paint := _mat(Color(0.95, 0.78, 0.12), 0.35, 0.0)

	for i in range(-8, 9):
		_box(self, Vector3(float(i) * 2.4, 0.006, -3.9), Vector3(1.2, 0.006, 0.12), paint)

	# poças (reflexos fortes)
	var puddle := _mat(Color(0.02, 0.03, 0.06), 0.02, 0.7)
	var pud_pos := [
		Vector3(-2.2, 0.004, -0.9), Vector3(1.9, 0.004, -0.3),
		Vector3(0.6, 0.004, -3.0), Vector3(-4.2, 0.004, -2.6), Vector3(3.8, 0.004, -2.5),
	]
	var pud_r := [0.9, 0.7, 1.1, 0.8, 0.9]

	for i in range(pud_pos.size()):
		var r: float = pud_r[i]
		_cyl(self, pud_pos[i], r, 0.004, puddle, Vector3.ZERO, 24)


# ------------------------------------------------------------
# Prédios (janelas acesas por textura) — fileira de trás + skyline
# ------------------------------------------------------------

func _build_buildings() -> void:

	var rng := RandomNumberGenerator.new()
	rng.seed = 424242

	var x: float = -19.0
	var idx: int = 0

	while x < 19.0:

		var w: float = rng.randf_range(3.0, 4.4)
		var h: float = rng.randf_range(9.0, 21.0)
		var tint := Color(0.75, 0.78, 0.95).lerp(Color(0.9, 0.75, 0.85), rng.randf())

		var m := _building_mat(1000 + idx, w, h, tint, 0.5)

		_box(self, Vector3(x + w / 2.0, h / 2.0, -11.0), Vector3(w, h, 4.0), m)

		x += w + rng.randf_range(0.1, 0.5)
		idx += 1

	# skyline distante (mais alto, mais escuro, some na névoa)
	var xf: float = -36.0
	var jdx: int = 0

	while xf < 36.0:

		var wf: float = rng.randf_range(4.0, 6.5)
		var hf: float = rng.randf_range(18.0, 40.0)

		var mf := _building_mat(5000 + jdx, wf, hf, Color(0.45, 0.48, 0.65), 0.4)

		_box(self, Vector3(xf + wf / 2.0, hf / 2.0, -27.0), Vector3(wf, hf, 6.0), mf)

		xf += wf + rng.randf_range(0.2, 1.2)
		jdx += 1


# ------------------------------------------------------------
# Letreiros de neon (alguns piscam)
# ------------------------------------------------------------

func _neon_sign(x: float, y: float, text: String, color: Color, w: float, h: float, font_size: int, flicker: int) -> void:

	var z: float = -8.93

	_box(self, Vector3(x, y, z - 0.03), Vector3(w, h, 0.06), _mat(Color(0.03, 0.03, 0.05), 0.5, 0.2))

	var frame_mat := _emit(color, 3.0)
	var frame: Array = []

	frame.append(_no_shadow(_box(self, Vector3(x, y + h / 2.0, z), Vector3(w, 0.05, 0.05), frame_mat)))
	frame.append(_no_shadow(_box(self, Vector3(x, y - h / 2.0, z), Vector3(w, 0.05, 0.05), frame_mat)))
	frame.append(_no_shadow(_box(self, Vector3(x - w / 2.0, y, z), Vector3(0.05, h, 0.05), frame_mat)))
	frame.append(_no_shadow(_box(self, Vector3(x + w / 2.0, y, z), Vector3(0.05, h, 0.05), frame_mat)))

	var lbl := _label(text, Vector3(x, y, z + 0.02), font_size, 0.0075, color)
	lbl.outline_size = 6

	var light := _omni(Vector3(x, y, -7.4), color, 1.4, 6.5)

	if flicker > 0:

		var phase: float = float(flicker) * 1.7

		_anim.append(func(t: float, _dt: float):
			var f: float = 1.0
			if sin(t * 21.0 + phase) * sin(t * 6.3 + phase) < -0.55:
				f = 0.2
			lbl.modulate = Color(color.r, color.g, color.b, 0.35 + 0.65 * f)
			frame_mat.emission_energy_multiplier = 0.6 + 2.4 * f
			light.light_energy = 0.3 + 1.1 * f
		)


func _build_signs() -> void:

	_neon_sign(-6.0, 4.4, "BOXE", Color(1.0, 0.2, 0.75), 3.0, 1.1, 96, 1)
	_neon_sign(5.6, 3.8, "RAMEN", Color(0.2, 0.9, 1.0), 3.2, 1.0, 84, 0)
	_neon_sign(-1.2, 6.0, "24H", Color(0.4, 1.0, 0.4), 1.9, 0.9, 92, 2)
	_neon_sign(9.0, 5.6, "FIGHT", Color(1.0, 0.55, 0.15), 2.9, 1.0, 88, 3)
	_neon_sign(-11.0, 3.6, "BAR", Color(1.0, 0.35, 0.5), 2.0, 0.9, 92, 0)
	_neon_sign(13.0, 7.2, "HOTEL", Color(0.4, 0.55, 1.0), 3.0, 1.0, 88, 0)


# ------------------------------------------------------------
# Postes de luz
# ------------------------------------------------------------

func _build_lamps() -> void:

	var metal := _mat(Color(0.10, 0.10, 0.12), 0.5, 0.6)
	var bulb := _emit(Color(1.0, 0.85, 0.55), 3.0)

	for sx in [-6.8, 6.8]:

		var x: float = sx

		_box(self, Vector3(x, 2.4, -5.2), Vector3(0.12, 4.8, 0.12), metal)
		_box(self, Vector3(x - 0.5 * signf(x), 4.75, -5.2), Vector3(1.1, 0.1, 0.1), metal)

		var head_x: float = x - 1.0 * signf(x)

		_no_shadow(_box(self, Vector3(head_x, 4.68, -5.2), Vector3(0.5, 0.1, 0.24), bulb))

		var sp := _spot(Vector3(head_x, 4.6, -5.2), Color(1.0, 0.85, 0.6), 4.5, 9.0, 55.0)
		sp.rotation_degrees = Vector3(-90, 0, 0)


# ------------------------------------------------------------
# Carros estacionados
# ------------------------------------------------------------

func _car(pos: Vector3, color: Color, flip: bool) -> void:

	var root := Node3D.new()
	root.position = pos

	if flip:
		root.rotation_degrees = Vector3(0, 180, 0)

	add_child(root)

	var paint := _mat(color, 0.25, 0.5)
	var glass := _mat(Color(0.05, 0.07, 0.10), 0.05, 0.8)
	var rubber := _mat(Color(0.03, 0.03, 0.04), 0.8, 0.0)
	var head := _emit(Color(1.0, 0.95, 0.8), 3.0)
	var tail := _emit(Color(1.0, 0.1, 0.1), 2.5)

	_box(root, Vector3(0, 0.48, 0), Vector3(2.1, 0.55, 0.95), paint)
	_box(root, Vector3(-0.1, 0.98, 0), Vector3(1.15, 0.48, 0.85), glass)
	_box(root, Vector3(-0.1, 1.24, 0), Vector3(1.0, 0.05, 0.8), paint)

	for wx in [-0.68, 0.68]:
		for wz in [-0.48, 0.48]:
			_cyl(root, Vector3(wx, 0.27, wz), 0.27, 0.18, rubber, Vector3(90, 0, 0), 14)

	for zz in [-0.3, 0.3]:
		_no_shadow(_box(root, Vector3(1.06, 0.55, zz), Vector3(0.05, 0.1, 0.22), head))
		_no_shadow(_box(root, Vector3(-1.06, 0.55, zz), Vector3(0.05, 0.1, 0.22), tail))


func _build_cars() -> void:

	_car(Vector3(-4.6, 0.0, -4.4), Color(0.75, 0.08, 0.10), false)
	_car(Vector3(4.9, 0.0, -4.5), Color(0.10, 0.25, 0.75), true)
	_car(Vector3(-9.2, 0.0, -4.4), Color(0.85, 0.8, 0.15), true)
	_car(Vector3(9.6, 0.0, -4.4), Color(0.6, 0.6, 0.65), false)


# ------------------------------------------------------------
# Torcida na calçada (pulam de leve)
# ------------------------------------------------------------

func _build_crowd() -> void:

	var rng := RandomNumberGenerator.new()
	rng.seed = 777

	var jackets := [
		Color(0.85, 0.15, 0.25), Color(0.15, 0.45, 0.9), Color(0.95, 0.75, 0.15),
		Color(0.2, 0.75, 0.45), Color(0.6, 0.25, 0.85), Color(0.9, 0.9, 0.95),
	]
	var skins := [Color(0.95, 0.75, 0.6), Color(0.75, 0.55, 0.4), Color(0.5, 0.35, 0.25), Color(0.35, 0.24, 0.18)]

	for i in range(18):

		var px: float = rng.randf_range(-9.5, 9.5)

		if absf(px) < 1.9:
			px += 4.0 * signf(px + 0.01)

		var pz: float = rng.randf_range(-7.4, -5.9)

		var person := Node3D.new()
		person.position = Vector3(px, 0.16, pz)
		add_child(person)

		var body := CapsuleMesh.new()
		body.radius = 0.17
		body.height = 1.05

		var bmi := MeshInstance3D.new()
		bmi.mesh = body
		_put(person, bmi, Vector3(0, 0.62, 0), Vector3.ZERO, _mat(jackets[rng.randi() % jackets.size()], 0.7))

		_sphere(person, Vector3(0, 1.32, 0), 0.13, _mat(skins[rng.randi() % skins.size()], 0.6))

		# bracinhos levantados (torcendo)
		var arm_mat := _mat(jackets[rng.randi() % jackets.size()], 0.7)
		_box(person, Vector3(-0.22, 1.05, 0), Vector3(0.07, 0.4, 0.07), arm_mat, Vector3(0, 0, -20))
		_box(person, Vector3(0.22, 1.05, 0), Vector3(0.07, 0.4, 0.07), arm_mat, Vector3(0, 0, 20))

		var phase: float = rng.randf_range(0.0, 6.28)
		var speed: float = rng.randf_range(3.0, 6.0)
		var base_y: float = person.position.y

		_anim.append(func(t: float, _dt: float):
			person.position.y = base_y + maxf(0.0, sin(t * speed + phase)) * 0.09
		)


# ------------------------------------------------------------
# Vapor do bueiro
# ------------------------------------------------------------

func _build_steam() -> void:

	_cyl(self, Vector3(2.7, 0.006, -2.9), 0.32, 0.01, _mat(Color(0.08, 0.08, 0.1), 0.4, 0.7))

	var steam := _particles(
		Vector3(2.7, 0.15, -2.9), Vector3(0.12, 0.02, 0.12),
		34, 3.2, Color(0.75, 0.78, 0.9, 0.22), 0.7,
		Vector3(0.05, 0.25, 0.0), 0.35, 0.6, false, Vector3(0, 1, 0), 12.0
	)

	steam.scale_amount_min = 0.6
	steam.scale_amount_max = 1.8
