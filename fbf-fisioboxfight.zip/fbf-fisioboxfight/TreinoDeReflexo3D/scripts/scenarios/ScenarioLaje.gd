# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioLaje
# LAJE DO CHURRASCO: laje de casa no fim de tarde, com o tio da churrasqueira,
# paredão de som pulsando, piscina de plástico com boia de flamingo, varal,
# bandeirinhas, caixa-d'água azul, vergalhão sobrando (obra eterna) e um
# morro de casinhas coloridas até o horizonte.

var _rng := RandomNumberGenerator.new()
var _flags: Array = []
var _clothes: Array = []
var _cones: Array = []
var _tio_arm: Node3D
var _flamingo: Node3D
var _kite: Node3D
var _fire_mat: StandardMaterial3D
var _fire_light: OmniLight3D
var _cat_tail: Node3D
var _event_timer: float = 8.0


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.28, 0.38, 0.75)
	sky_mat.sky_horizon_color = Color(1.0, 0.66, 0.36)
	sky_mat.ground_horizon_color = Color(0.9, 0.62, 0.4)
	sky_mat.ground_bottom_color = Color(0.4, 0.3, 0.25)
	sky_mat.sun_angle_max = 28.0

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.66, 0.55)
	env.ambient_light_energy = 0.9
	env.fog_enabled = true
	env.fog_light_color = Color(0.95, 0.72, 0.55)
	env.fog_density = 0.007
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_hdr_threshold = 1.0
	env.ssao_enabled = true

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-13, 145, 0), Color(1.0, 0.66, 0.35), 1.5)
	_sun(Vector3(-35, -25, 0), Color(0.8, 0.6, 0.7), 0.35, false)

	_build_slab()
	_build_neighborhood()
	_build_bbq()
	_build_speaker()
	_build_pool()
	_build_table()
	_build_clothesline()
	_build_flags()
	_build_extras()

	_make_accent(Vector3(0, 3.0, -3.0), Color(1.0, 0.75, 0.5), 0.45, 9.0)

	_anim.append(_update)


func _build_slab() -> void:

	var concrete := _mat(Color(0.62, 0.60, 0.56), 0.95, 0.0)
	var brick := _mat(Color(0.72, 0.36, 0.26), 0.9, 0.0)

	_box(self, Vector3(0, -0.05, -2.5), Vector3(17.6, 0.1, 13.4), concrete)

	# muretas de tijolo aparente
	_box(self, Vector3(0, 0.55, -9.0), Vector3(17.6, 1.1, 0.3), brick)
	_box(self, Vector3(-8.8, 0.55, -2.5), Vector3(0.3, 1.1, 13.4), brick)
	_box(self, Vector3(8.8, 0.55, -2.5), Vector3(0.3, 1.1, 13.4), brick)

	# obra eterna: pilares com vergalhão sobrando
	var rust := _mat(Color(0.45, 0.22, 0.12), 0.7, 0.5)

	for px in [-8.6, 8.6]:
		_box(self, Vector3(px, 1.5, -9.0), Vector3(0.45, 3.0, 0.45), concrete)

		for k in range(4):
			_cyl(self, Vector3(px - 0.15 + float(k) * 0.1, 3.4, -9.0), 0.012, 0.9, rust)


func _build_neighborhood() -> void:

	var tints := [
		Color(1.0, 0.75, 0.6), Color(1.0, 0.9, 0.6), Color(0.7, 0.85, 1.0),
		Color(0.85, 0.85, 0.8), Color(0.75, 0.95, 0.7), Color(1.0, 0.7, 0.8),
	]

	for r in range(6):

		var x: float = -36.0
		var idx: int = 0

		while x < 36.0:

			var w: float = _rng.randf_range(3.0, 5.0)
			var h: float = _rng.randf_range(3.0, 6.0)
			var y0: float = float(r) * 1.4 - 0.6
			var z: float = -12.0 - float(r) * 5.5

			var m := _building_mat(3000 + r * 100 + idx, w, h, tints[_rng.randi() % tints.size()], 0.35)
			_box(self, Vector3(x + w / 2.0, y0 + h / 2.0, z), Vector3(w, h, 4.5), m)

			var roll: float = _rng.randf()

			if roll < 0.45:
				_cyl(self, Vector3(x + w / 2.0, y0 + h + 0.45, z), 0.45, 0.8, _mat(Color(0.2, 0.45, 0.85), 0.5, 0.0))
			elif roll < 0.7:
				for k in range(3):
					_cyl(self, Vector3(x + w / 2.0 - 0.3 + float(k) * 0.3, y0 + h + 0.4, z), 0.012, 0.8, _mat(Color(0.45, 0.22, 0.12), 0.7, 0.5))

			x += w + _rng.randf_range(0.2, 0.7)
			idx += 1


func _build_bbq() -> void:

	var bbq := Node3D.new()
	bbq.position = Vector3(-5.2, 0.0, -5.6)
	add_child(bbq)

	var brick := _mat(Color(0.62, 0.30, 0.22), 0.9, 0.0)
	var metal := _mat(Color(0.25, 0.25, 0.28), 0.5, 0.6)

	_box(bbq, Vector3(0, 0.45, 0), Vector3(1.7, 0.9, 0.75), brick)
	_box(bbq, Vector3(0, 0.93, 0), Vector3(1.5, 0.05, 0.6), metal)

	_fire_mat = _emit(Color(1.0, 0.45, 0.1), 2.2)
	_no_shadow(_box(bbq, Vector3(0, 0.86, 0), Vector3(1.4, 0.06, 0.5), _fire_mat))

	for i in range(6):
		_box(bbq, Vector3(-0.6 + float(i) * 0.24, 1.0, 0), Vector3(0.03, 0.03, 0.9), metal)
		_box(bbq, Vector3(-0.6 + float(i) * 0.24, 1.03, 0.1), Vector3(0.14, 0.1, 0.14), _mat(Color(0.65, 0.2, 0.15), 0.7, 0.0))

	_particles(
		Vector3(-5.2, 1.4, -5.6), Vector3(0.5, 0.1, 0.2), 30, 2.4,
		Color(0.85, 0.85, 0.85, 0.28), 0.6,
		Vector3(0.15, 0.7, 0.0), 0.3, 0.6, false, Vector3(0, 1, 0), 15.0
	)

	_fire_light = _omni(Vector3(-5.2, 1.3, -5.0), Color(1.0, 0.55, 0.2), 1.3, 5.0)

	# o tio do churrasco (avental, boné, espeto)
	var tio: Dictionary = _person(bbq, Vector3(0, 0, 0.85), Color(0.95, 0.95, 0.95), Color(0.85, 0.62, 0.48), Color(0.25, 0.25, 0.45), Color(0.9, 0.2, 0.2), 1.1)
	var tio_node: Node3D = tio["node"]
	_box(tio_node, Vector3(0, 1.05, 0.2), Vector3(0.3, 0.55, 0.02), _mat(Color(0.85, 0.15, 0.15), 0.7, 0.0))

	var arms: Array = tio["arms"]
	_tio_arm = arms[1]
	_box(_tio_arm, Vector3(0, -0.5, -0.4), Vector3(0.03, 0.03, 0.9), metal)

	_plaque(Vector3(-5.2, 2.6, -6.6), Vector2(3.0, 0.9), Color(0.98, 0.85, 0.15), "CHURRASCO NA LAJE\nTRAGA 1KG (E A CADEIRA)", Color(0.15, 0.05, 0.02), 34)


func _build_speaker() -> void:

	var root := Node3D.new()
	root.position = Vector3(5.6, 0.0, -5.3)
	add_child(root)

	_box(root, Vector3(0, 1.15, 0), Vector3(1.7, 2.3, 1.0), _mat(Color(0.06, 0.06, 0.07), 0.6, 0.3))

	for spec in [[0.65, 0.55], [1.6, 0.36]]:

		var y: float = spec[0]
		var r: float = spec[1]

		var cone := Node3D.new()
		cone.position = Vector3(0, y, 0.52)
		root.add_child(cone)
		_cones.append(cone)

		_cyl(cone, Vector3.ZERO, r, 0.1, _mat(Color(0.12, 0.12, 0.14), 0.5, 0.4), Vector3(90, 0, 0), 24)
		_no_shadow(_torus(cone, Vector3(0, 0, 0.03), r * 0.9, r * 1.0, _emit(Color(1.0, 0.2, 0.6), 2.0), Vector3(90, 0, 0)))

	_label("PAREDÃO", Vector3(0, 2.1, 0.53), 44, 0.004, Color(1.0, 0.9, 0.3), Vector3.ZERO, root).outline_size = 8

	_particles(
		Vector3(5.6, 2.6, -5.0), Vector3(0.6, 0.1, 0.3), 14, 2.2,
		Color(1.0, 0.85, 0.35, 0.9), 0.2,
		Vector3(0.1, 0.5, 0.0), 0.3, 0.6, true, Vector3(0, 1, 0), 35.0
	)


func _build_pool() -> void:

	var root := Node3D.new()
	root.position = Vector3(5.7, 0.0, -1.9)
	add_child(root)

	_cyl(root, Vector3(0, 0.25, 0), 1.4, 0.5, _mat(Color(0.2, 0.55, 0.92), 0.5, 0.0), Vector3.ZERO, 28)
	_cyl(root, Vector3(0, 0.46, 0), 1.25, 0.02, _mat(Color(0.5, 0.88, 1.0), 0.1, 0.3), Vector3.ZERO, 28)

	# boia de flamingo
	_flamingo = Node3D.new()
	_flamingo.position = Vector3(0.3, 0.55, 0.1)
	root.add_child(_flamingo)

	var pink := _mat(Color(1.0, 0.45, 0.65), 0.5, 0.0)
	_sphere(_flamingo, Vector3(0, 0.1, 0), 0.4, pink, Vector3(1.4, 0.7, 1.0))
	_box(_flamingo, Vector3(0.5, 0.5, 0), Vector3(0.1, 0.7, 0.1), pink)
	_sphere(_flamingo, Vector3(0.55, 0.9, 0), 0.13, pink)
	_box(_flamingo, Vector3(0.75, 0.87, 0), Vector3(0.22, 0.05, 0.08), _mat(Color(0.1, 0.1, 0.1), 0.5, 0.0))

	# banhista de óculos escuros
	_sphere(root, Vector3(-0.5, 0.5, 0.2), 0.17, _mat(Color(0.85, 0.62, 0.48), 0.6, 0.0))
	_box(root, Vector3(-0.5, 0.53, 0.35), Vector3(0.28, 0.06, 0.03), _mat(Color(0.02, 0.02, 0.02), 0.2, 0.5))

	_plaque(Vector3(5.7, 1.2, 0.0), Vector2(2.4, 0.6), Color(0.15, 0.5, 0.85), "PISCINA 1000L\n(ÁGUA DA MANGUEIRA)", Color(1, 1, 1), 26, 0.0, true)


func _build_table() -> void:

	var root := Node3D.new()
	root.position = Vector3(-6.2, 0.0, -1.6)
	add_child(root)

	var white := _mat(Color(0.96, 0.96, 0.94), 0.5, 0.0)

	_cyl(root, Vector3(0, 0.74, 0), 0.65, 0.05, white, Vector3.ZERO, 20)
	_cyl(root, Vector3(0, 0.37, 0), 0.05, 0.74, white)

	for a in range(4):
		var ang: float = float(a) * PI / 2.0 + 0.4
		var c := Node3D.new()
		c.position = Vector3(cos(ang) * 1.05, 0, sin(ang) * 1.05)
		c.rotation_degrees = Vector3(0, -rad_to_deg(ang) - 90.0, 0)
		root.add_child(c)
		_box(c, Vector3(0, 0.45, 0), Vector3(0.45, 0.05, 0.45), white)
		_box(c, Vector3(0, 0.75, 0.2), Vector3(0.45, 0.5, 0.05), white)
		for lx in [-0.18, 0.18]:
			_box(c, Vector3(lx, 0.22, 0.18), Vector3(0.04, 0.45, 0.04), white)
			_box(c, Vector3(lx, 0.22, -0.18), Vector3(0.04, 0.45, 0.04), white)

	# latinhas na mesa e isopor
	for i in range(4):
		_cyl(root, Vector3(-0.3 + float(i) * 0.2, 0.83, 0.0), 0.04, 0.12, _mat(Color.from_hsv(_rng.randf(), 0.7, 0.9), 0.3, 0.6))

	_box(root, Vector3(1.6, 0.27, 1.5), Vector3(0.95, 0.55, 0.6), white)
	_label("GELADA", Vector3(1.6, 0.3, 1.81), 30, 0.0035, Color(0.1, 0.35, 0.8), Vector3.ZERO, root).outline_size = 0

	var p1: Dictionary = _person(root, Vector3(-0.9, 0.0, -0.9), Color(0.2, 0.6, 0.9), Color(0.7, 0.5, 0.36))
	var arms: Array = p1["arms"]
	var a0: Node3D = arms[0]
	a0.rotation_degrees.x = -140.0


func _build_clothesline() -> void:

	var pole := _mat(Color(0.35, 0.3, 0.28), 0.8, 0.3)

	for px in [-6.8, 6.8]:
		_cyl(self, Vector3(px, 1.3, -7.6), 0.05, 2.6, pole)

	_box(self, Vector3(0, 2.55, -7.6), Vector3(13.6, 0.025, 0.025), _mat(Color(0.9, 0.9, 0.9), 0.6, 0.0))

	for i in range(9):
		var piv := Node3D.new()
		piv.position = Vector3(-6.0 + float(i) * 1.5, 2.55, -7.6)
		add_child(piv)
		_box(piv, Vector3(0, -0.35, 0), Vector3(0.5, 0.7, 0.03), _mat(Color.from_hsv(_rng.randf(), 0.6, 0.95), 0.9, 0.0))
		_clothes.append(piv)


func _build_flags() -> void:

	for z in [-1.0, -5.0]:
		for px in [-8.4, 8.4]:
			_cyl(self, Vector3(px, 1.9, z), 0.05, 3.8, _mat(Color(0.4, 0.3, 0.2), 0.8, 0.0))

		_flags.append(_bunting(Vector3(-8.4, 3.75, z), Vector3(8.4, 3.75, z), 30, 0.55))

	# lâmpadas de festa
	for i in range(8):
		_no_shadow(_sphere(self, Vector3(-7.0 + float(i) * 2.0, 3.55, -3.0), 0.08, _emit(Color(1.0, 0.92, 0.6), 2.2)))


func _build_extras() -> void:

	# caixa-d'água azul
	_box(self, Vector3(-7.5, 0.3, -7.6), Vector3(1.5, 0.6, 1.5), _mat(Color(0.6, 0.6, 0.58), 0.9, 0.0))
	_cyl(self, Vector3(-7.5, 1.3, -7.6), 0.85, 1.4, _mat(Color(0.15, 0.42, 0.88), 0.5, 0.0), Vector3.ZERO, 24)
	_label("FBF", Vector3(-7.5, 1.3, -6.75), 60, 0.005, Color(1, 1, 1), Vector3.ZERO).outline_size = 0

	# antena parabólica
	_cyl(self, Vector3(7.5, 1.2, -7.7), 0.04, 2.4, _mat(Color(0.5, 0.5, 0.5), 0.5, 0.6))
	_sphere(self, Vector3(7.5, 2.5, -7.4), 0.6, _mat(Color(0.9, 0.9, 0.9), 0.4, 0.5), Vector3(1.0, 1.0, 0.25))

	# gatinho na mureta
	var fur := _mat(Color(0.95, 0.6, 0.25), 0.9, 0.0)
	_sphere(self, Vector3(2.5, 1.32, -8.9), 0.2, fur, Vector3(1.3, 0.9, 0.9))
	_sphere(self, Vector3(2.75, 1.45, -8.9), 0.13, fur)

	for sz in [-1.0, 1.0]:
		_cone(self, Vector3(2.78, 1.6, -8.9 + sz * 0.07), 0.04, 0.09, fur)

	_cat_tail = Node3D.new()
	_cat_tail.position = Vector3(2.3, 1.32, -8.9)
	add_child(_cat_tail)
	_box(_cat_tail, Vector3(-0.15, 0.1, 0), Vector3(0.3, 0.05, 0.05), fur, Vector3(0, 0, 30))

	# pipa no céu
	_kite = Node3D.new()
	add_child(_kite)
	_box(_kite, Vector3.ZERO, Vector3(1.0, 1.0, 0.03), _mat(Color(0.95, 0.2, 0.5), 0.8, 0.0), Vector3(0, 0, 45))
	_box(_kite, Vector3(0, -1.6, 0), Vector3(0.03, 1.4, 0.03), _mat(Color(0.95, 0.95, 0.95), 0.8, 0.0))

	_plaque(Vector3(0.0, 1.0, -8.7), Vector2(3.4, 0.5), Color(0.95, 0.95, 0.9), "PROIBIDO PISAR NA LAJE MOLHADA (JÁ PISOU)", Color(0.6, 0.05, 0.05), 20)


func _update(t: float, dt: float) -> void:

	for i in range(_flags.size()):
		var f: Node3D = _flags[i]
		f.rotation_degrees.z = sin(t * 1.3 + float(i)) * 1.6

	for i in range(_clothes.size()):
		var c: Node3D = _clothes[i]
		c.rotation_degrees.z = sin(t * 1.8 + float(i) * 0.9) * 9.0

	var beat: float = pow(maxf(0.0, sin(t * 9.0)), 4.0)

	for c2 in _cones:
		var cn: Node3D = c2
		var k: float = 1.0 + 0.09 * beat
		cn.scale = Vector3(k, k, 1.0)

	if _tio_arm:
		_tio_arm.rotation_degrees.x = -70.0 + sin(t * 3.0) * 25.0

	if _flamingo:
		_flamingo.position.y = 0.55 + sin(t * 1.4) * 0.05
		_flamingo.rotation_degrees.z = sin(t * 1.1) * 4.0

	if _cat_tail:
		_cat_tail.rotation_degrees.y = sin(t * 2.5) * 30.0

	if _kite:
		_kite.position = Vector3(sin(t * 0.3) * 7.0, 10.0 + sin(t * 0.6) * 1.5, -18.0)
		_kite.rotation_degrees.z = sin(t * 0.9) * 12.0

	if _fire_light:
		_fire_light.light_energy = 1.1 + 0.3 * sin(t * 13.0) + 0.15 * sin(t * 29.0)

	if _fire_mat:
		_fire_mat.emission_energy_multiplier = 1.8 + 0.6 * sin(t * 11.0)

	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(9.0, 17.0)
		_fire_event()


func _fire_event() -> void:

	var r: int = _rng.randi() % 3

	if r == 0:
		var col := Color.from_hsv(_rng.randf(), 0.8, 1.0)
		var pos := Vector3(_rng.randf_range(-6.0, 6.0), _rng.randf_range(9.0, 13.0), -16.0)
		_burst(pos, col, 50, 6.0)
		_toast("É CHURRAS!", pos + Vector3(0, -1.5, 0), Color(1.0, 0.9, 0.3), 70)
	elif r == 1:
		_toast("SAÚDE!", Vector3(-5.2, 2.6, -4.8), Color(1.0, 0.85, 0.3), 70)
	else:
		_toast("APAGÃO!", Vector3(0.0, 4.6, -6.0), Color(1.0, 0.4, 0.3), 80)

		if accent_light:
			var tw := create_tween()
			tw.tween_property(accent_light, "light_energy", 0.0, 0.1)
			tw.tween_interval(0.5)
			tw.tween_property(accent_light, "light_energy", _accent_base_energy, 0.2)
