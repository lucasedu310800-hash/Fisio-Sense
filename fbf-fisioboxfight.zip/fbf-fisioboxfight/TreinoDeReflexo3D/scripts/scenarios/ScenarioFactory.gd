# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioFactory
# FÁBRICA ABANDONADA: galpão industrial com estrutura de aço, tubulações,
# máquinas com engrenagens girando, esteira, tanques, janelas quebradas
# deixando entrar luz azulada, giroflex vermelho girando, lâmpadas
# amarelas piscando, poeira no ar e faíscas de um cabo solto. Iluminação
# dramática, sombras marcadas — um "ringue clandestino" fictício.

var _gears: Array = []
var _beacon: Node3D
var _crates: Array = []


func make_environment() -> Environment:

	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.03, 0.03, 0.035)

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.26, 0.22, 0.20)
	env.ambient_light_energy = 0.55

	env.fog_enabled = true
	env.fog_light_color = Color(0.16, 0.13, 0.11)
	env.fog_density = 0.022

	env.glow_enabled = true
	env.glow_intensity = 0.8
	env.glow_hdr_threshold = 0.9

	env.ssao_enabled = true
	env.ssao_radius = 1.4
	env.ssao_intensity = 2.2

	return env


func _build() -> void:

	# luz fria entrando pelas janelas quebradas (sombras marcadas)
	_sun(Vector3(-38, 200, 0), Color(0.55, 0.68, 1.0), 0.9)

	_build_floor_and_walls()
	_build_structure()
	_build_pipes_and_tanks()
	_build_machines()
	_build_conveyor()
	_build_clutter()
	_build_lights()
	_build_particles()

	_make_accent(Vector3(0.0, 3.4, -3.5), Color(1.0, 0.45, 0.25), 0.45, 10.0)

	_anim.append(func(t: float, dt: float):

		for i in range(_gears.size()):
			var g: Node3D = _gears[i]
			var dir: float = 1.0 if i % 2 == 0 else -1.0
			g.rotation_degrees.z += dt * 24.0 * dir

		if _beacon:
			_beacon.rotation_degrees.y += dt * 220.0

		# caixas andando na esteira
		for i in range(_crates.size()):
			var c: Node3D = _crates[i]
			c.position.x += dt * 0.45
			if c.position.x > 7.5:
				c.position.x = -7.5
	)


# ------------------------------------------------------------
# Chão, paredes desgastadas e janelas quebradas
# ------------------------------------------------------------

func _build_floor_and_walls() -> void:

	var concrete := _mat(Color(0.24, 0.24, 0.25), 0.88, 0.05)

	_box(self, Vector3(0, -0.05, -4.0), Vector3(40, 0.1, 30), concrete)

	# manchas de óleo
	var oil := _mat(Color(0.06, 0.06, 0.07), 0.15, 0.4)

	for p in [Vector3(-2.4, 0.004, -0.6), Vector3(2.1, 0.004, -1.6), Vector3(-0.4, 0.004, -3.4), Vector3(3.6, 0.004, -3.0)]:
		_cyl(self, p, 0.8, 0.004, oil, Vector3.ZERO, 20)

	# faixa de segurança amarela em volta da área de luta
	var yellow := _mat(Color(0.92, 0.72, 0.10), 0.5, 0.0)
	var black := _mat(Color(0.06, 0.06, 0.06), 0.6, 0.0)

	_box(self, Vector3(0, 0.006, -4.5), Vector3(7.0, 0.006, 0.14), yellow)
	_box(self, Vector3(0, 0.006, 1.2), Vector3(7.0, 0.006, 0.14), yellow)
	_box(self, Vector3(-3.5, 0.006, -1.65), Vector3(0.14, 0.006, 5.8), yellow)
	_box(self, Vector3(3.5, 0.006, -1.65), Vector3(0.14, 0.006, 5.8), yellow)

	for i in range(14):
		_box(self, Vector3(-3.4 + float(i) * 0.52, 0.007, -4.5), Vector3(0.22, 0.006, 0.15), black, Vector3(0, 35, 0))

	# parede do fundo (tijolo/concreto velho)
	var wall := _mat(Color(0.30, 0.24, 0.20), 0.95, 0.0)

	_box(self, Vector3(0, 4.0, -9.0), Vector3(40, 8.0, 0.4), wall)
	_box(self, Vector3(-9.0, 4.0, -4.0), Vector3(0.4, 8.0, 30), wall)
	_box(self, Vector3(9.0, 4.0, -4.0), Vector3(0.4, 8.0, 30), wall)
	_box(self, Vector3(0, 8.1, -4.0), Vector3(40, 0.3, 30), _mat(Color(0.10, 0.09, 0.09), 0.9, 0.0))

	# manchas de umidade/ferrugem na parede
	var stain := _mat(Color(0.18, 0.12, 0.09), 1.0, 0.0)

	for i in range(6):
		_box(self, Vector3(-7.5 + float(i) * 3.0, 3.0 + float(i % 3) * 0.8, -8.78), Vector3(1.4 + float(i % 2), 2.6, 0.02), stain)

	# janelas quebradas (moldura + cacos) com luz azulada
	var frame := _mat(Color(0.08, 0.08, 0.09), 0.6, 0.6)
	var sky := _emit(Color(0.35, 0.5, 0.9), 1.6)
	var shard := _mat(Color(0.7, 0.85, 1.0, 0.35), 0.05, 0.0)
	shard.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

	for wx in [-5.0, 0.0, 5.0]:

		var x: float = wx

		_no_shadow(_box(self, Vector3(x, 5.2, -8.78), Vector3(2.4, 2.2, 0.05), sky))

		_box(self, Vector3(x, 6.35, -8.72), Vector3(2.6, 0.12, 0.12), frame)
		_box(self, Vector3(x, 4.05, -8.72), Vector3(2.6, 0.12, 0.12), frame)
		_box(self, Vector3(x - 1.25, 5.2, -8.72), Vector3(0.12, 2.4, 0.12), frame)
		_box(self, Vector3(x + 1.25, 5.2, -8.72), Vector3(0.12, 2.4, 0.12), frame)
		_box(self, Vector3(x, 5.2, -8.72), Vector3(0.08, 2.3, 0.08), frame)
		_box(self, Vector3(x, 5.2, -8.72), Vector3(2.4, 0.08, 0.08), frame)

		# cacos de vidro que sobraram na moldura
		_box(self, Vector3(x - 0.7, 6.05, -8.70), Vector3(0.6, 0.5, 0.02), shard, Vector3(0, 0, 25))
		_box(self, Vector3(x + 0.8, 4.4, -8.70), Vector3(0.5, 0.4, 0.02), shard, Vector3(0, 0, -30))

		# feixe de luz azul entrando (fake)
		var beam := _box(self, Vector3(x + 0.6, 2.7, -6.2), Vector3(1.0, 0.03, 5.6), _glow_mat(Color(0.5, 0.65, 1.0, 0.05)), Vector3(38, 0, 0))
		_no_shadow(beam)

	_omni(Vector3(0, 5.0, -7.2), Color(0.45, 0.6, 1.0), 1.4, 12.0)

	# letreiro de perigo
	_box(self, Vector3(6.6, 2.4, -8.7), Vector3(1.8, 0.9, 0.05), _mat(Color(0.95, 0.75, 0.10), 0.5, 0.0))
	_label("PERIGO", Vector3(6.6, 2.4, -8.66), 70, 0.0060, Color(0.08, 0.08, 0.08))


# ------------------------------------------------------------
# Estrutura de aço, passarela
# ------------------------------------------------------------

func _build_structure() -> void:

	var steel := _mat(Color(0.20, 0.21, 0.23), 0.55, 0.7)
	var rust := _mat(Color(0.35, 0.19, 0.10), 0.85, 0.3)

	# colunas em "I"
	for cx in [-5.0, -2.8, 2.8, 5.0]:

		var x: float = cx

		_box(self, Vector3(x, 3.9, -6.2), Vector3(0.36, 7.8, 0.12), steel)
		_box(self, Vector3(x, 3.9, -6.2), Vector3(0.12, 7.8, 0.5), steel)

	# vigas horizontais no alto
	for hz in [-6.2, -3.0, 0.2]:
		_box(self, Vector3(0, 7.4, hz), Vector3(18, 0.3, 0.3), steel)

	# passarela (catwalk) com guarda-corpo
	_box(self, Vector3(0, 3.4, -7.2), Vector3(17, 0.1, 1.6), steel)

	for i in range(17):
		_box(self, Vector3(-8.0 + float(i) * 1.0, 3.95, -6.42), Vector3(0.05, 1.0, 0.05), steel)

	_box(self, Vector3(0, 4.45, -6.42), Vector3(17, 0.06, 0.06), steel)
	_box(self, Vector3(0, 4.05, -6.42), Vector3(17, 0.04, 0.04), steel)

	# escada enferrujada
	for i in range(9):
		_box(self, Vector3(-8.2, 0.2 + float(i) * 0.36, -6.4 - float(i) * 0.1), Vector3(1.0, 0.06, 0.3), rust)

	# vigas caídas / detritos pendurados
	_box(self, Vector3(4.6, 5.8, -4.0), Vector3(0.2, 3.2, 0.2), rust, Vector3(0, 0, 18))


# ------------------------------------------------------------
# Tubulações e tanques
# ------------------------------------------------------------

func _build_pipes_and_tanks() -> void:

	var pipe_cols := [Color(0.55, 0.16, 0.10), Color(0.30, 0.32, 0.34), Color(0.65, 0.5, 0.12)]

	for i in range(5):

		var m := _mat(pipe_cols[i % 3], 0.5, 0.6)
		var y: float = 6.2 - float(i) * 0.32
		var z: float = -6.0 + float(i) * 1.2

		_cyl(self, Vector3(0, y, z), 0.16 + float(i % 2) * 0.05, 18.0, m, Vector3(0, 0, 90))

		for fx in [-6.0, -2.0, 2.0, 6.0]:
			_cyl(self, Vector3(fx, y, z), 0.24 + float(i % 2) * 0.05, 0.12, _mat(Color(0.15, 0.15, 0.16), 0.5, 0.7), Vector3(0, 0, 90))

	# tubo vertical descendo
	_cyl(self, Vector3(-6.0, 3.6, -4.6), 0.2, 7.2, _mat(Color(0.3, 0.32, 0.34), 0.5, 0.6))

	# tanques
	var tank := _mat(Color(0.32, 0.30, 0.28), 0.5, 0.6)

	_cyl(self, Vector3(-7.4, 2.2, -6.8), 1.3, 4.4, tank, Vector3.ZERO, 28)
	_cyl(self, Vector3(-7.4, 4.5, -6.8), 1.3, 0.12, _mat(Color(0.15, 0.15, 0.16), 0.5, 0.7), Vector3.ZERO, 28)
	_cyl(self, Vector3(7.6, 1.8, -7.0), 1.0, 3.6, tank, Vector3.ZERO, 28)


# ------------------------------------------------------------
# Máquinas com engrenagens que giram
# ------------------------------------------------------------

func _gear(parent: Node3D, pos: Vector3, radius: float, color: Color) -> Node3D:

	var g := Node3D.new()
	g.position = pos
	parent.add_child(g)

	var m := _mat(color, 0.4, 0.8)

	_cyl(g, Vector3.ZERO, radius, 0.16, m, Vector3(90, 0, 0), 24)
	_cyl(g, Vector3(0, 0, 0.1), radius * 0.28, 0.2, _mat(Color(0.1, 0.1, 0.11), 0.5, 0.7), Vector3(90, 0, 0), 12)

	for k in range(10):
		var a: float = float(k) * TAU / 10.0
		_box(g, Vector3(cos(a) * radius, sin(a) * radius, 0), Vector3(radius * 0.32, radius * 0.22, 0.16), m, Vector3(0, 0, rad_to_deg(a)))

	_gears.append(g)

	return g


func _build_machines() -> void:

	var body := _mat(Color(0.20, 0.24, 0.26), 0.5, 0.5)
	var panel := _mat(Color(0.10, 0.10, 0.11), 0.6, 0.4)

	# máquina grande à esquerda
	var m1 := Node3D.new()
	m1.position = Vector3(-6.2, 0, -4.0)
	add_child(m1)

	_box(m1, Vector3(0, 1.2, 0), Vector3(2.6, 2.4, 1.8), body)
	_box(m1, Vector3(0, 2.6, 0), Vector3(1.8, 0.8, 1.4), panel)
	_gear(m1, Vector3(-0.5, 1.4, 0.95), 0.55, Color(0.55, 0.42, 0.12))
	_gear(m1, Vector3(0.6, 1.0, 0.95), 0.4, Color(0.6, 0.18, 0.12))

	# luzes do painel
	_no_shadow(_box(m1, Vector3(0.7, 2.6, 0.72), Vector3(0.12, 0.12, 0.04), _emit(Color(1.0, 0.15, 0.1), 2.5)))
	_no_shadow(_box(m1, Vector3(0.95, 2.6, 0.72), Vector3(0.12, 0.12, 0.04), _emit(Color(0.2, 1.0, 0.3), 2.0)))

	# máquina à direita
	var m2 := Node3D.new()
	m2.position = Vector3(5.8, 0, -4.6)
	add_child(m2)

	_box(m2, Vector3(0, 1.0, 0), Vector3(2.2, 2.0, 1.6), body)
	_cyl(m2, Vector3(0, 2.4, 0), 0.6, 0.8, panel, Vector3.ZERO, 16)
	_gear(m2, Vector3(0.2, 1.1, 0.85), 0.6, Color(0.42, 0.44, 0.48))


func _build_conveyor() -> void:

	var belt := _mat(Color(0.08, 0.08, 0.09), 0.9, 0.0)
	var steel := _mat(Color(0.22, 0.23, 0.25), 0.5, 0.7)
	var crate := _mat(Color(0.55, 0.38, 0.20), 0.85, 0.0)

	_box(self, Vector3(0, 0.75, -5.6), Vector3(15, 0.14, 1.1), belt)

	for lx in range(-7, 8, 3):
		_box(self, Vector3(float(lx), 0.36, -5.6), Vector3(0.12, 0.72, 0.9), steel)

	for i in range(4):

		var c := Node3D.new()
		c.position = Vector3(-7.5 + float(i) * 3.8, 1.1, -5.6)
		add_child(c)

		_box(c, Vector3.ZERO, Vector3(0.7, 0.55, 0.7), crate)
		_box(c, Vector3(0, 0.0, 0.36), Vector3(0.7, 0.1, 0.02), _mat(Color(0.3, 0.2, 0.1), 0.9, 0.0))

		_crates.append(c)


# ------------------------------------------------------------
# Barris, paletes, caixas, entulho
# ------------------------------------------------------------

func _build_clutter() -> void:

	var red := _mat(Color(0.70, 0.12, 0.08), 0.5, 0.4)
	var yellow := _mat(Color(0.85, 0.65, 0.10), 0.5, 0.4)
	var grey := _mat(Color(0.30, 0.32, 0.33), 0.5, 0.5)
	var wood := _mat(Color(0.45, 0.32, 0.18), 0.9, 0.0)
	var concrete := _mat(Color(0.35, 0.34, 0.33), 0.95, 0.0)

	var barrels := [
		[Vector3(-4.6, 0.5, -3.2), red], [Vector3(-4.0, 0.5, -3.6), yellow], [Vector3(-4.3, 0.5, -2.7), grey],
		[Vector3(4.6, 0.5, -3.4), red], [Vector3(5.2, 0.5, -3.0), grey],
		[Vector3(-8.0, 0.5, -1.8), yellow],
	]

	for b in barrels:
		var p: Vector3 = b[0]
		var m: StandardMaterial3D = b[1]
		_cyl(self, p, 0.3, 1.0, m, Vector3.ZERO, 14)
		_cyl(self, p + Vector3(0, 0.2, 0), 0.31, 0.05, _mat(Color(0.1, 0.1, 0.1), 0.6, 0.5), Vector3.ZERO, 14)

	# paletes e caixas
	_box(self, Vector3(6.6, 0.08, -1.6), Vector3(1.2, 0.16, 1.2), wood)
	_box(self, Vector3(6.6, 0.55, -1.6), Vector3(1.0, 0.8, 1.0), _mat(Color(0.55, 0.40, 0.22), 0.9, 0.0))
	_box(self, Vector3(6.4, 1.15, -1.5), Vector3(0.7, 0.5, 0.7), _mat(Color(0.5, 0.36, 0.2), 0.9, 0.0), Vector3(0, 20, 0))

	# entulho / concreto quebrado
	for p in [Vector3(-2.8, 0.14, -4.1), Vector3(2.9, 0.12, -4.2), Vector3(-5.6, 0.18, -1.2), Vector3(4.0, 0.15, 0.6)]:
		_box(self, p, Vector3(0.5, 0.28, 0.4), concrete, Vector3(0, 30, 8))

	# vergalhões saindo do concreto
	for i in range(4):
		_cyl(self, Vector3(-2.8 + float(i) * 0.08, 0.5, -4.1), 0.012, 0.8, _mat(Color(0.35, 0.2, 0.12), 0.7, 0.6), Vector3(0, 0, 10.0 * float(i - 1)))


# ------------------------------------------------------------
# Iluminação dramática: lâmpadas piscando, giroflex e refletor
# ------------------------------------------------------------

func _work_lamp(pos: Vector3, phase: float, color: Color) -> void:

	var shade := _mat(Color(0.12, 0.12, 0.13), 0.5, 0.6)
	var bulb := _emit(color, 3.0)

	_cyl(self, pos + Vector3(0, 0.9, 0), 0.02, 1.8, shade)
	_cone(self, pos + Vector3(0, 0.05, 0), 0.4, 0.3, shade)
	_no_shadow(_sphere(self, pos + Vector3(0, -0.12, 0), 0.1, bulb))

	var sp := _spot(pos + Vector3(0, -0.1, 0), color, 4.5, 9.0, 50.0)
	sp.rotation_degrees = Vector3(-90, 0, 0)
	sp.shadow_enabled = true

	_anim.append(func(t: float, _dt: float):
		var f: float = 1.0
		if sin(t * 13.0 + phase) * sin(t * 3.1 + phase * 2.0) < -0.62:
			f = 0.15
		sp.light_energy = 4.5 * f
		bulb.emission_energy_multiplier = 0.4 + 2.6 * f
	)


func _build_lights() -> void:

	_work_lamp(Vector3(-3.0, 5.4, -2.6), 0.0, Color(1.0, 0.82, 0.35))
	_work_lamp(Vector3(3.2, 5.6, -3.4), 2.3, Color(1.0, 0.72, 0.28))

	# giroflex vermelho girando
	_beacon = Node3D.new()
	_beacon.position = Vector3(7.4, 4.6, -7.6)
	add_child(_beacon)

	_cyl(self, Vector3(7.4, 4.35, -7.6), 0.22, 0.3, _mat(Color(0.1, 0.1, 0.11), 0.5, 0.6))
	_no_shadow(_sphere(self, Vector3(7.4, 4.65, -7.6), 0.22, _emit(Color(1.0, 0.1, 0.05), 2.4), Vector3(1.0, 0.8, 1.0)))

	var bsp := _spot(Vector3.ZERO, Color(1.0, 0.12, 0.08), 6.0, 16.0, 40.0, _beacon)
	bsp.rotation_degrees = Vector3(0, 0, 0)

	var bcone_mesh := CylinderMesh.new()
	bcone_mesh.top_radius = 1.2
	bcone_mesh.bottom_radius = 0.05
	bcone_mesh.height = 7.0

	var bcone := MeshInstance3D.new()
	bcone.mesh = bcone_mesh
	_put(_beacon, bcone, Vector3(0, 0, -3.6), Vector3(-90, 0, 0), _glow_mat(Color(1.0, 0.15, 0.1, 0.06)))
	_no_shadow(bcone)

	# luz vermelha de emergência geral (respira)
	var red_omni := _omni(Vector3(-6.5, 4.0, -3.0), Color(1.0, 0.15, 0.10), 1.4, 9.0)

	_anim.append(func(t: float, _dt: float):
		red_omni.light_energy = 0.9 + 0.7 * (0.5 + 0.5 * sin(t * 2.4))
	)


# ------------------------------------------------------------
# Poeira no ar, faíscas do cabo solto e vapor
# ------------------------------------------------------------

func _build_particles() -> void:

	_particles(
		Vector3(0, 3.0, -3.0), Vector3(7.0, 2.8, 4.5),
		90, 8.0, Color(1.0, 0.9, 0.7, 0.35), 0.045,
		Vector3(0.02, -0.02, 0.0), 0.02, 0.12, true, Vector3(0, 1, 0), 180.0
	)

	# cabo solto soltando faíscas
	_cyl(self, Vector3(3.6, 5.2, -4.6), 0.02, 2.0, _mat(Color(0.05, 0.05, 0.05), 0.6, 0.0), Vector3(0, 0, 8))

	var sparks := _particles(
		Vector3(3.6, 4.2, -4.6), Vector3(0.05, 0.05, 0.05),
		18, 0.9, Color(1.0, 0.65, 0.15, 1.0), 0.05,
		Vector3(0.0, -6.0, 0.0), 0.8, 2.2, true, Vector3(0, -0.2, 0), 70.0
	)

	sparks.preprocess = 0.0
	sparks.explosiveness = 0.35

	# vapor saindo de um cano
	_particles(
		Vector3(-6.0, 0.4, -4.6), Vector3(0.1, 0.05, 0.1),
		28, 3.0, Color(0.85, 0.85, 0.85, 0.16), 0.9,
		Vector3(0.0, 0.3, 0.0), 0.4, 0.8, false, Vector3(0, 1, 0), 14.0
	)
