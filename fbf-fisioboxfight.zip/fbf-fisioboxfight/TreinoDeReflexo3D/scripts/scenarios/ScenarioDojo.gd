# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioDojo
# DOJÔ JAPONÊS: salão de madeira com portas shoji e a porta central aberta
# pro jardim (cerejeiras, torii, lanternas de pedra, montanhas ao longe),
# luz quente de fim de tarde, lanternas de papel piscando e pétalas caindo.

var _canopies: Array = []


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.30, 0.50, 0.85)
	sky_mat.sky_horizon_color = Color(0.99, 0.80, 0.58)
	sky_mat.ground_horizon_color = Color(0.85, 0.70, 0.55)
	sky_mat.ground_bottom_color = Color(0.35, 0.28, 0.20)

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.78, 0.64, 0.52)
	env.ambient_light_energy = 0.8

	env.fog_enabled = true
	env.fog_light_color = Color(0.95, 0.80, 0.62)
	env.fog_density = 0.006

	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_hdr_threshold = 1.0

	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.3

	return env


func _build() -> void:

	# sol baixo, vindo de trás e da direita (entra pela porta aberta)
	_sun(Vector3(-18, 148, 0), Color(1.0, 0.78, 0.5), 1.5)

	_build_floor()
	_build_ceiling_and_pillars()
	_build_walls()
	_build_garden()
	_build_mountains()
	_build_interior_props()
	_build_lanterns()
	_build_light_shafts()

	_particles(
		Vector3(0, 5.5, -8.0), Vector3(9.0, 0.5, 5.0),
		70, 9.0, Color(1.0, 0.72, 0.82, 0.9), 0.09,
		Vector3(0.25, -0.45, 0.1), 0.05, 0.2, false, Vector3(0, -1, 0), 40.0
	)

	_particles(
		Vector3(0, 3.6, -3.5), Vector3(4.5, 0.4, 2.5),
		22, 8.0, Color(1.0, 0.72, 0.82, 0.9), 0.08,
		Vector3(0.2, -0.35, 0.1), 0.05, 0.15, false, Vector3(0, -1, 0), 40.0
	)

	_make_accent(Vector3(0.0, 2.6, -3.0), Color(1.0, 0.75, 0.45), 0.55, 9.0)

	_anim.append(func(t: float, _dt: float):
		for i in range(_canopies.size()):
			var c: Node3D = _canopies[i]
			c.rotation_degrees.z = sin(t * 0.7 + float(i) * 1.3) * 1.6
			c.rotation_degrees.x = sin(t * 0.5 + float(i) * 0.9) * 1.0
	)


# ------------------------------------------------------------
# Piso de madeira, tatame e teto
# ------------------------------------------------------------

func _wood_texture() -> ImageTexture:

	var img := Image.create(128, 128, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 91

	for px in range(8):

		var base: float = rng.randf_range(0.85, 1.1)

		for x in range(16):
			for y in range(128):

				var v: float = base * (1.0 + rng.randf_range(-0.05, 0.05))

				if x == 0:
					v *= 0.55

				var c := Color(0.62 * v, 0.44 * v, 0.27 * v, 1.0)
				img.set_pixel(px * 16 + x, y, c)

	return ImageTexture.create_from_image(img)


func _build_floor() -> void:

	var wood := StandardMaterial3D.new()
	wood.albedo_texture = _wood_texture()
	wood.roughness = 0.45
	wood.uv1_scale = Vector3(2.0, 2.0, 1.0)

	_box(self, Vector3(0, -0.05, -2.2), Vector3(12.4, 0.1, 9.4), wood)

	# tatame no centro (área de luta)
	var tatami := _mat(Color(0.64, 0.68, 0.42), 0.9, 0.0)
	var edge := _mat(Color(0.10, 0.09, 0.07), 0.8, 0.0)

	_box(self, Vector3(0, 0.011, -1.8), Vector3(6.0, 0.022, 4.4), tatami)

	for xx in [-1.0, 1.0]:
		_box(self, Vector3(xx, 0.024, -1.8), Vector3(0.04, 0.004, 4.4), edge)

	_box(self, Vector3(0, 0.024, -1.8), Vector3(6.0, 0.004, 0.04), edge)

	# borda escura ao redor do tatame
	_box(self, Vector3(0, 0.024, -1.8 - 2.2), Vector3(6.1, 0.004, 0.08), edge)
	_box(self, Vector3(0, 0.024, -1.8 + 2.2), Vector3(6.1, 0.004, 0.08), edge)
	_box(self, Vector3(-3.0, 0.024, -1.8), Vector3(0.08, 0.004, 4.4), edge)
	_box(self, Vector3(3.0, 0.024, -1.8), Vector3(0.08, 0.004, 4.4), edge)


func _build_ceiling_and_pillars() -> void:

	var dark_wood := _mat(Color(0.22, 0.13, 0.07), 0.55, 0.0)
	var mid_wood := _mat(Color(0.34, 0.21, 0.11), 0.6, 0.0)

	_box(self, Vector3(0, 3.95, -2.2), Vector3(12.6, 0.15, 9.6), mid_wood)

	for z in [1.5, 0.0, -1.5, -3.0, -4.5, -6.0]:
		_box(self, Vector3(0, 3.72, z), Vector3(12.4, 0.24, 0.24), dark_wood)

	for x in [-4.0, -1.3, 1.3, 4.0]:
		_box(self, Vector3(x, 3.75, -2.2), Vector3(0.2, 0.2, 9.2), dark_wood)

	# pilares do fundo (moldura da porta aberta) e das laterais
	for px in [-2.7, 2.7]:
		_box(self, Vector3(px, 1.9, -6.1), Vector3(0.3, 3.8, 0.3), dark_wood)

	_box(self, Vector3(0, 3.42, -6.1), Vector3(5.7, 0.3, 0.3), dark_wood)
	_box(self, Vector3(0, 0.15, -6.1), Vector3(5.4, 0.3, 0.3), dark_wood)

	for pz in [-6.1, -2.0, 1.6]:
		for sx in [-6.1, 6.1]:
			_box(self, Vector3(sx, 1.9, pz), Vector3(0.3, 3.8, 0.3), dark_wood)


# ------------------------------------------------------------
# Portas de correr (shoji) — papel quente com grade de madeira
# ------------------------------------------------------------

func _shoji(parent: Node3D, length: float, height: float) -> void:

	var paper := _mat(Color(0.98, 0.92, 0.78), 0.9, 0.0)
	paper.emission_enabled = true
	paper.emission = Color(0.95, 0.75, 0.45)
	paper.emission_energy_multiplier = 0.35

	var bar := _mat(Color(0.20, 0.12, 0.07), 0.6, 0.0)

	_box(parent, Vector3(0, height / 2.0 + 0.3, 0), Vector3(length, height, 0.05), paper)

	var cols: int = maxi(1, int(length / 1.1))

	for i in range(cols + 1):
		var x: float = -length / 2.0 + float(i) * length / float(cols)
		_box(parent, Vector3(x, height / 2.0 + 0.3, 0.02), Vector3(0.05, height, 0.07), bar)

	for j in range(5):
		var y: float = 0.3 + float(j) * height / 4.0
		_box(parent, Vector3(0, y, 0.02), Vector3(length, 0.05, 0.07), bar)

	# rodapé de madeira
	_box(parent, Vector3(0, 0.3, 0.02), Vector3(length, 0.6, 0.09), bar)


func _build_walls() -> void:

	# fundo: dois painéis, com a porta central aberta
	var left := Node3D.new()
	left.position = Vector3(-4.4, 0, -6.15)
	add_child(left)
	_shoji(left, 3.2, 3.1)

	var right := Node3D.new()
	right.position = Vector3(4.4, 0, -6.15)
	add_child(right)
	_shoji(right, 3.2, 3.1)

	# laterais (fechadas)
	var lw := Node3D.new()
	lw.position = Vector3(-6.15, 0, -2.2)
	lw.rotation_degrees = Vector3(0, 90, 0)
	add_child(lw)
	_shoji(lw, 9.0, 3.1)

	var rw := Node3D.new()
	rw.position = Vector3(6.15, 0, -2.2)
	rw.rotation_degrees = Vector3(0, -90, 0)
	add_child(rw)
	_shoji(rw, 9.0, 3.1)


# ------------------------------------------------------------
# Jardim lá fora: cascalho, cerejeiras, pinheiros, torii, lanternas
# ------------------------------------------------------------

func _cherry_tree(pos: Vector3, scale_f: float) -> void:

	var root := Node3D.new()
	root.position = pos
	root.scale = Vector3(scale_f, scale_f, scale_f)
	add_child(root)

	var bark := _mat(Color(0.20, 0.12, 0.08), 0.9, 0.0)
	var pink := _mat(Color(0.98, 0.68, 0.78), 0.8, 0.0)
	var pink2 := _mat(Color(0.95, 0.55, 0.70), 0.8, 0.0)

	_cyl(root, Vector3(0, 1.3, 0), 0.2, 2.6, bark)
	_cyl(root, Vector3(0.5, 2.6, 0), 0.09, 1.3, bark, Vector3(0, 0, -40))
	_cyl(root, Vector3(-0.5, 2.7, 0.1), 0.09, 1.2, bark, Vector3(0, 0, 40))

	var canopy := Node3D.new()
	canopy.position = Vector3(0, 3.2, 0)
	root.add_child(canopy)

	_sphere(canopy, Vector3(0, 0.4, 0), 1.5, pink)
	_sphere(canopy, Vector3(1.2, 0.0, 0.3), 1.1, pink2)
	_sphere(canopy, Vector3(-1.2, 0.1, -0.2), 1.2, pink)
	_sphere(canopy, Vector3(0.2, 1.1, 0.4), 1.0, pink2)

	_canopies.append(canopy)


func _pine(pos: Vector3, h: float) -> void:

	var green := _mat(Color(0.10, 0.28, 0.16), 0.9, 0.0)
	var bark := _mat(Color(0.18, 0.11, 0.07), 0.9, 0.0)

	_cyl(self, pos + Vector3(0, h * 0.2, 0), 0.14, h * 0.4, bark)

	for i in range(4):
		var r: float = 1.5 - float(i) * 0.3
		_cone(self, pos + Vector3(0, h * 0.35 + float(i) * h * 0.18, 0), r, h * 0.3, green)


func _stone_lantern(pos: Vector3) -> void:

	var stone := _mat(Color(0.55, 0.55, 0.52), 0.9, 0.0)
	var lamp := _emit(Color(1.0, 0.75, 0.4), 2.2)

	_box(self, pos + Vector3(0, 0.12, 0), Vector3(0.6, 0.24, 0.6), stone)
	_cyl(self, pos + Vector3(0, 0.6, 0), 0.11, 0.72, stone)
	_box(self, pos + Vector3(0, 1.1, 0), Vector3(0.5, 0.12, 0.5), stone)
	_no_shadow(_box(self, pos + Vector3(0, 1.3, 0), Vector3(0.3, 0.3, 0.3), lamp))
	_cone(self, pos + Vector3(0, 1.62, 0), 0.5, 0.3, stone, Vector3.ZERO, 4)

	_omni(pos + Vector3(0, 1.3, 0.2), Color(1.0, 0.7, 0.4), 0.9, 4.0)


func _torii(pos: Vector3) -> void:

	var red := _mat(Color(0.78, 0.10, 0.08), 0.5, 0.0)
	var black := _mat(Color(0.06, 0.05, 0.05), 0.6, 0.0)

	for sx in [-2.0, 2.0]:
		_cyl(self, pos + Vector3(sx, 2.2, 0), 0.22, 4.4, red)

	_box(self, pos + Vector3(0, 4.35, 0), Vector3(6.2, 0.32, 0.5), black)
	_box(self, pos + Vector3(0, 4.55, 0), Vector3(6.6, 0.16, 0.6), black)
	_box(self, pos + Vector3(0, 3.6, 0), Vector3(4.7, 0.24, 0.32), red)


func _build_garden() -> void:

	var gravel := _mat(Color(0.78, 0.75, 0.69), 0.95, 0.0)

	_box(self, Vector3(0, -0.08, -28.0), Vector3(90, 0.1, 44), gravel)

	# linhas de rastelo no cascalho
	var rake := _mat(Color(0.66, 0.63, 0.57), 0.95, 0.0)

	for i in range(6):
		_box(self, Vector3(0, -0.02, -7.6 - float(i) * 0.7), Vector3(9.0, 0.02, 0.06), rake)

	# pedras do caminho
	var stone := _mat(Color(0.45, 0.45, 0.43), 0.9, 0.0)

	for i in range(5):
		var off: float = 0.35 if i % 2 == 0 else -0.35
		_cyl(self, Vector3(off, 0.0, -7.2 - float(i) * 1.1), 0.42, 0.06, stone, Vector3.ZERO, 12)

	_cherry_tree(Vector3(-4.6, 0, -9.0), 1.0)
	_cherry_tree(Vector3(5.4, 0, -10.5), 1.15)
	_cherry_tree(Vector3(-9.5, 0, -13.5), 1.3)
	_cherry_tree(Vector3(10.0, 0, -14.5), 1.2)
	_cherry_tree(Vector3(1.8, 0, -19.0), 1.4)

	_pine(Vector3(-7.0, 0, -8.0), 5.0)
	_pine(Vector3(7.6, 0, -8.8), 4.6)
	_pine(Vector3(-13.0, 0, -11.0), 6.0)
	_pine(Vector3(14.0, 0, -12.0), 5.6)

	_stone_lantern(Vector3(-2.3, 0, -8.4))
	_stone_lantern(Vector3(2.3, 0, -8.4))

	_torii(Vector3(0, 0, -15.0))


func _build_mountains() -> void:

	var rock := _mat(Color(0.36, 0.42, 0.58), 1.0, 0.0)
	var far_rock := _mat(Color(0.48, 0.54, 0.70), 1.0, 0.0)
	var snow := _mat(Color(0.96, 0.96, 1.0), 0.9, 0.0)

	var specs := [
		[Vector3(-30, 0, -72), 22.0, 26.0],
		[Vector3(-4, 0, -85), 28.0, 34.0],
		[Vector3(26, 0, -70), 20.0, 24.0],
		[Vector3(52, 0, -80), 24.0, 28.0],
		[Vector3(-58, 0, -78), 24.0, 22.0],
	]

	for i in range(specs.size()):

		var p: Vector3 = specs[i][0]
		var r: float = specs[i][1]
		var h: float = specs[i][2]
		var m: StandardMaterial3D = rock if i % 2 == 0 else far_rock

		_cone(self, p + Vector3(0, h / 2.0 - 0.5, 0), r, h, m, Vector3.ZERO, 8)
		_cone(self, p + Vector3(0, h * 0.82, 0), r * 0.22, h * 0.36, snow, Vector3.ZERO, 8)

	# colinas verdes mais perto
	var hill := _mat(Color(0.25, 0.42, 0.33), 1.0, 0.0)

	_sphere(self, Vector3(-18, -6, -45), 14.0, hill)
	_sphere(self, Vector3(20, -7, -48), 16.0, hill)


# ------------------------------------------------------------
# Decoração interna
# ------------------------------------------------------------

func _build_interior_props() -> void:

	var wood := _mat(Color(0.30, 0.18, 0.09), 0.6, 0.0)
	var red := _mat(Color(0.65, 0.08, 0.08), 0.5, 0.0)
	var paper := _mat(Color(0.92, 0.89, 0.80), 0.9, 0.0)

	# pergaminho na parede do fundo (sol vermelho)
	_box(self, Vector3(-4.4, 2.1, -6.05), Vector3(0.8, 1.7, 0.03), paper)
	_box(self, Vector3(-4.4, 2.98, -6.03), Vector3(0.9, 0.06, 0.06), wood)
	_box(self, Vector3(-4.4, 1.22, -6.03), Vector3(0.9, 0.06, 0.06), wood)
	_cyl(self, Vector3(-4.4, 2.3, -6.02), 0.22, 0.02, red, Vector3(90, 0, 0), 24)

	# rack de bokken na parede direita
	_box(self, Vector3(5.95, 1.2, -3.2), Vector3(0.1, 0.12, 1.6), wood)
	_box(self, Vector3(5.95, 0.8, -3.2), Vector3(0.1, 0.12, 1.6), wood)

	for i in range(4):
		var z: float = -3.8 + float(i) * 0.4
		_box(self, Vector3(5.85, 1.0, z), Vector3(0.05, 1.3, 0.05), _mat(Color(0.5, 0.33, 0.18), 0.6, 0.0), Vector3(0, 0, 10))

	# makiwara (poste de treino)
	_box(self, Vector3(-5.4, 0.7, -2.0), Vector3(0.22, 1.4, 0.22), wood)
	_cyl(self, Vector3(-5.4, 1.1, -2.0), 0.16, 0.3, _mat(Color(0.75, 0.65, 0.4), 0.9, 0.0))

	# taiko
	var drum_root := Node3D.new()
	drum_root.position = Vector3(4.6, 0.0, -5.2)
	add_child(drum_root)

	_cyl(drum_root, Vector3(0, 0.75, 0), 0.5, 0.7, red, Vector3(90, 0, 0), 24)
	_cyl(drum_root, Vector3(0, 0.75, 0.36), 0.47, 0.03, _mat(Color(0.92, 0.85, 0.7), 0.8, 0.0), Vector3(90, 0, 0), 24)
	_box(drum_root, Vector3(-0.42, 0.3, 0), Vector3(0.1, 0.6, 0.6), wood)
	_box(drum_root, Vector3(0.42, 0.3, 0), Vector3(0.1, 0.6, 0.6), wood)

	# almofadas (zabuton)
	for sx in [-4.2, 4.2]:
		_box(self, Vector3(sx, 0.06, -1.2), Vector3(0.7, 0.12, 0.7), _mat(Color(0.55, 0.10, 0.14), 0.9, 0.0))


func _paper_lantern(pos: Vector3, phase: float) -> void:

	var glow := _emit(Color(1.0, 0.62, 0.28), 2.4)
	var black := _mat(Color(0.05, 0.05, 0.05), 0.6, 0.0)

	_cyl(self, pos + Vector3(0, 0.5, 0), 0.01, 0.6, black)
	_cyl(self, pos + Vector3(0, 0.2, 0), 0.17, 0.04, black)
	_sphere(self, pos, 0.28, glow, Vector3(1.0, 1.3, 1.0))
	_cyl(self, pos + Vector3(0, -0.4, 0), 0.15, 0.04, black)

	var l := _omni(pos, Color(1.0, 0.65, 0.3), 1.3, 6.5)

	_anim.append(func(t: float, _dt: float):
		var f: float = 0.92 + 0.08 * sin(t * 8.0 + phase) + 0.04 * sin(t * 21.0 + phase * 2.0)
		l.light_energy = 1.3 * f
		glow.emission_energy_multiplier = 2.4 * f
	)


func _build_lanterns() -> void:

	_paper_lantern(Vector3(-3.6, 2.9, -4.5), 0.0)
	_paper_lantern(Vector3(3.6, 2.9, -4.5), 1.7)
	_paper_lantern(Vector3(-4.8, 2.9, -0.6), 3.1)
	_paper_lantern(Vector3(4.8, 2.9, -0.6), 4.4)
	_paper_lantern(Vector3(0.0, 3.1, -5.6), 2.2)


# Raios de sol falsos entrando pela porta (translúcidos, pulsam devagar).
func _build_light_shafts() -> void:

	var xs := [-1.6, 0.3, 1.9]
	var mats: Array = []

	for i in range(xs.size()):

		var x: float = xs[i]
		var m := _glow_mat(Color(1.0, 0.82, 0.5, 0.07))
		mats.append(m)

		var mi := _box(self, Vector3(x, 1.7, -3.6), Vector3(0.9 + float(i) * 0.15, 0.02, 5.8), m, Vector3(35, 0, 0))
		_no_shadow(mi)

	_anim.append(func(t: float, _dt: float):
		for i in range(mats.size()):
			var m2: StandardMaterial3D = mats[i]
			m2.albedo_color.a = 0.055 + 0.03 * sin(t * 0.5 + float(i) * 1.7)
	)
