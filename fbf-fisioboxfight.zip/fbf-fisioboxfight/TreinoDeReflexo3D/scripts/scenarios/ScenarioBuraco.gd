# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioBuraco
# BR DO BURACO: rodovia esburacada no fim da tarde, cerrado seco ao redor.
# Caminhões de melancia, ônibus, carros pulando nas crateras, placa "PONTE
# CAIU - SIGA EM FRENTE", posto pirata, barraca de fruta, vacas
# atravessando e o funcionário do tapa-buraco (em breve).

var _rng := RandomNumberGenerator.new()
var _vehicles: Array = []
var _holes: Array = []
var _cows: Array = []
var _event_timer: float = 8.0


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.35, 0.45, 0.75)
	sky_mat.sky_horizon_color = Color(1.0, 0.7, 0.4)
	sky_mat.ground_horizon_color = Color(0.9, 0.65, 0.4)
	sky_mat.ground_bottom_color = Color(0.5, 0.35, 0.25)
	sky_mat.sun_angle_max = 28.0

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.9, 0.7, 0.55)
	env.ambient_light_energy = 0.9
	env.fog_enabled = true
	env.fog_light_color = Color(0.95, 0.72, 0.5)
	env.fog_density = 0.009
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.ssao_enabled = true

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-12, 150, 0), Color(1.0, 0.68, 0.36), 1.6)
	_sun(Vector3(-30, -20, 0), Color(0.85, 0.65, 0.6), 0.3, false)

	_build_road()
	_build_holes()
	_build_vehicles()
	_build_roadside()
	_build_signs()
	_build_cows_and_worker()
	_build_landscape()

	_particles(Vector3(0, 1.5, -6.0), Vector3(14.0, 1.2, 6.0), 50, 6.0, Color(0.9, 0.7, 0.45, 0.25), 0.7, Vector3(0.3, 0.05, 0), 0.1, 0.3, false, Vector3(1, 0, 0), 60.0)

	_make_accent(Vector3(0, 3.5, -3.0), Color(1.0, 0.75, 0.5), 0.4, 10.0)

	_anim.append(_update)


func _build_road() -> void:

	var asphalt := _mat(Color(0.17, 0.17, 0.19), 0.85, 0.05)

	# terra vermelha do cerrado em volta
	_box(self, Vector3(0, -0.08, -14.0), Vector3(120, 0.1, 70), _mat(Color(0.62, 0.36, 0.2), 1.0, 0.0))

	# a pista (as duas faixas correm no sentido X; a luta é no acostamento da frente)
	_box(self, Vector3(0, -0.04, -4.5), Vector3(120, 0.08, 12.0), asphalt)

	var yellow := _mat(Color(0.95, 0.78, 0.1), 0.6, 0.0)
	var white := _mat(Color(0.94, 0.94, 0.9), 0.6, 0.0)

	# faixa dupla amarela + laterais de acostamento
	_box(self, Vector3(0, 0.001, -6.4), Vector3(120, 0.006, 0.1), yellow)
	_box(self, Vector3(0, 0.001, -6.6), Vector3(120, 0.006, 0.1), yellow)
	_box(self, Vector3(0, 0.001, 0.4), Vector3(120, 0.006, 0.12), white)
	_box(self, Vector3(0, 0.001, -10.2), Vector3(120, 0.006, 0.12), white)

	# rachaduras
	var crack := _mat(Color(0.05, 0.05, 0.06), 0.9, 0.0)

	for i in range(14):
		var p := Vector3(_rng.randf_range(-12.0, 12.0), 0.003, _rng.randf_range(-9.5, 0.0))
		_box(self, p, Vector3(_rng.randf_range(0.6, 1.8), 0.004, 0.03), crack, Vector3(0, _rng.randf_range(-40.0, 40.0), 0))


func _build_holes() -> void:

	var dark := _mat(Color(0.05, 0.04, 0.04), 1.0, 0.0)
	var rim := _mat(Color(0.3, 0.3, 0.32), 0.9, 0.0)
	var water := _mat(Color(0.35, 0.25, 0.15), 0.05, 0.5)

	# buracos gigantes; os veículos "pulam" ao passar (x,z,raio)
	var specs := [
		[-6.5, -3.0, 1.0], [-3.8, -8.4, 1.3], [1.6, -8.8, 1.1], [5.6, -2.6, 1.4], [8.8, -8.0, 0.9], [-9.4, -1.6, 0.8],
	]

	for sp in specs:
		var x: float = sp[0]
		var z: float = sp[1]
		var r: float = sp[2]

		_cyl(self, Vector3(x, 0.002, z), r + 0.15, 0.01, rim, Vector3.ZERO, 20)
		_cyl(self, Vector3(x, 0.004, z), r, 0.01, dark, Vector3.ZERO, 20)
		_cyl(self, Vector3(x, 0.006, z), r * 0.7, 0.01, water, Vector3.ZERO, 16)

		_holes.append({"x": x, "z": z, "r": r})

	# um cone dentro do buraco (sinalização oficial)
	_cone(self, Vector3(5.6, 0.4, -2.6), 0.22, 0.8, _mat(Color(1.0, 0.45, 0.1), 0.6, 0.0))


func _make_truck(color: Color) -> Node3D:

	var root := Node3D.new()
	add_child(root)

	var cab := _mat(color, 0.4, 0.3)
	var black := _mat(Color(0.05, 0.05, 0.06), 0.9, 0.0)

	_box(root, Vector3(2.2, 1.4, 0), Vector3(1.6, 1.7, 1.9), cab)
	_box(root, Vector3(2.75, 1.7, 0), Vector3(0.05, 0.7, 1.6), _mat(Color(0.1, 0.14, 0.2), 0.05, 0.8))
	_box(root, Vector3(-0.6, 0.85, 0), Vector3(4.6, 0.2, 2.0), _mat(Color(0.3, 0.3, 0.32), 0.7, 0.4))
	_box(root, Vector3(-0.6, 1.5, 1.0), Vector3(4.6, 1.0, 0.08), _mat(Color(0.55, 0.38, 0.2), 0.9, 0.0))
	_box(root, Vector3(-0.6, 1.5, -1.0), Vector3(4.6, 1.0, 0.08), _mat(Color(0.55, 0.38, 0.2), 0.9, 0.0))

	# carga de melancia
	var green := _mat(Color(0.15, 0.55, 0.2), 0.6, 0.0)

	for i in range(12):
		_sphere(root, Vector3(-2.4 + float(i % 6) * 0.8, 1.7, -0.45 + float(i / 6) * 0.9), 0.4, green, Vector3(1.0, 0.85, 1.0))

	for wx in [-2.2, -0.6, 2.4]:
		for wz in [-1.0, 1.0]:
			_cyl(root, Vector3(wx, 0.45, wz), 0.45, 0.3, black, Vector3(90, 0, 0), 14)

	_no_shadow(_box(root, Vector3(2.99, 0.9, 0.6), Vector3(0.05, 0.16, 0.3), _emit(Color(1.0, 0.95, 0.75), 2.0)))
	_no_shadow(_box(root, Vector3(2.99, 0.9, -0.6), Vector3(0.05, 0.16, 0.3), _emit(Color(1.0, 0.95, 0.75), 2.0)))

	_label("DEUS É FIEL", Vector3(-0.6, 1.5, 1.06), 46, 0.0045, Color(1.0, 0.95, 0.4), Vector3.ZERO, root).outline_size = 8

	return root


func _make_bus() -> Node3D:

	var root := Node3D.new()
	add_child(root)

	_box(root, Vector3(0, 1.6, 0), Vector3(9.0, 2.6, 2.6), _mat(Color(0.95, 0.95, 0.92), 0.4, 0.2))
	_box(root, Vector3(0, 0.8, 0), Vector3(9.05, 0.35, 2.62), _mat(Color(0.85, 0.1, 0.1), 0.4, 0.2))
	_no_shadow(_box(root, Vector3(0, 2.2, 1.31), Vector3(8.0, 0.9, 0.04), _emit(Color(0.95, 0.8, 0.5), 0.6)))

	for wx in [-3.0, 3.0]:
		for wz in [-1.3, 1.3]:
			_cyl(root, Vector3(wx, 0.5, wz), 0.5, 0.3, _mat(Color(0.03, 0.03, 0.04), 0.9, 0.0), Vector3(90, 0, 0), 14)

	_box(root, Vector3(0, 2.95, 1.32), Vector3(4.0, 0.5, 0.05), _mat(Color(0.05, 0.05, 0.05), 0.6, 0.0))
	_label("BR-116 EXPRESSO (SEM PRESSA)", Vector3(0, 2.95, 1.36), 34, 0.0034, Color(1.0, 0.75, 0.15), Vector3.ZERO, root).outline_size = 0

	return root


func _make_car(color: Color) -> Node3D:

	var root := Node3D.new()
	add_child(root)

	_box(root, Vector3(0, 0.5, 0), Vector3(2.3, 0.62, 1.05), _mat(color, 0.3, 0.4))
	_box(root, Vector3(-0.1, 1.0, 0), Vector3(1.2, 0.5, 0.95), _mat(Color(0.08, 0.12, 0.18), 0.05, 0.8))

	for wx in [-0.72, 0.72]:
		for wz in [-0.5, 0.5]:
			_cyl(root, Vector3(wx, 0.27, wz), 0.28, 0.2, _mat(Color(0.03, 0.03, 0.04), 0.9, 0.0), Vector3(90, 0, 0), 12)

	_no_shadow(_box(root, Vector3(1.16, 0.6, 0.34), Vector3(0.05, 0.11, 0.24), _emit(Color(1.0, 0.95, 0.75), 2.0)))
	_no_shadow(_box(root, Vector3(1.16, 0.6, -0.34), Vector3(0.05, 0.11, 0.24), _emit(Color(1.0, 0.95, 0.75), 2.0)))

	return root


func _build_vehicles() -> void:

	var cols := [Color(0.85, 0.1, 0.1), Color(0.15, 0.4, 0.85), Color(0.95, 0.85, 0.15), Color(0.9, 0.9, 0.92), Color(0.2, 0.6, 0.3)]

	# faixa de trás (indo pra direita) e da frente (indo pra esquerda)
	for i in range(7):

		var lane_back: bool = (i % 2 == 0)
		var node: Node3D

		if i == 0 or i == 3:
			node = _make_truck(cols[i % cols.size()])
		elif i == 5:
			node = _make_bus()
		else:
			node = _make_car(cols[i % cols.size()])

		var z: float = -8.4 if lane_back else -4.6
		var speed: float = _rng.randf_range(2.0, 3.4)

		node.position = Vector3(-30.0 + float(i) * 9.0, 0.0, z)

		if not lane_back:
			node.rotation_degrees = Vector3(0, 180, 0)
			speed = -speed

		_vehicles.append({"node": node, "speed": speed, "z": z})


func _build_roadside() -> void:

	# barraca de melancia
	var b := Node3D.new()
	b.position = Vector3(9.5, 0.0, 2.6)
	add_child(b)

	var wood := _mat(Color(0.5, 0.34, 0.2), 0.9, 0.0)

	for sx in [-1.4, 1.4]:
		_cyl(b, Vector3(sx, 1.2, 0), 0.06, 2.4, wood)

	_box(b, Vector3(0, 0.7, 0.2), Vector3(3.0, 0.1, 1.0), wood)

	for i in range(8):
		_sphere(b, Vector3(-1.1 + float(i % 4) * 0.7, 0.98, 0.1 + float(i / 4) * 0.4), 0.3, _mat(Color(0.15, 0.55, 0.2), 0.6, 0.0), Vector3(1.0, 0.85, 1.0))

	for i in range(7):
		var c: Color = Color(0.9, 0.15, 0.15) if i % 2 == 0 else Color(1.0, 0.95, 0.9)
		_box(b, Vector3(-1.5 + float(i) * 0.5, 2.5, 0.15), Vector3(0.5, 0.05, 1.4), _mat(c, 0.8, 0.0), Vector3(-10, 0, 0))

	_label("MELANCIA R$5", Vector3(0, 3.0, 0.6), 50, 0.005, Color(1.0, 0.9, 0.3), Vector3.ZERO, b).outline_size = 10

	_person(b, Vector3(0.0, 0.0, -0.5), Color(0.95, 0.95, 0.9), Color(0.7, 0.5, 0.36), Color(0.3, 0.25, 0.2), Color(0.9, 0.78, 0.35))

	# posto pirata
	var p := Node3D.new()
	p.position = Vector3(-10.5, 0.0, 2.2)
	add_child(p)

	_box(p, Vector3(0, 2.6, 0), Vector3(5.0, 0.3, 3.0), _mat(Color(0.85, 0.15, 0.12), 0.5, 0.2))
	_box(p, Vector3(0, 2.86, 0), Vector3(5.0, 0.24, 3.0), _mat(Color(0.98, 0.98, 0.95), 0.5, 0.2))

	for sx in [-2.2, 2.2]:
		_cyl(p, Vector3(sx, 1.3, 0), 0.12, 2.6, _mat(Color(0.9, 0.9, 0.9), 0.5, 0.3))

	_box(p, Vector3(0, 0.6, 0), Vector3(0.7, 1.2, 0.5), _mat(Color(0.2, 0.3, 0.7), 0.5, 0.3))
	_label("POSTO PIRATA", Vector3(0, 3.4, 1.55), 60, 0.005, Color(0.95, 0.15, 0.1), Vector3.ZERO, p).outline_size = 10
	_plaque(Vector3(-10.5, 1.4, 4.2), Vector2(2.6, 0.9), Color(0.05, 0.05, 0.08), "GASOLINA: R$ 9,99\n(PREÇO DE OURO)", Color(1.0, 0.85, 0.2), 24, 0.0, true)


func _build_signs() -> void:

	_plaque(Vector3(-3.0, 3.6, -11.2), Vector2(6.0, 2.0), Color(0.95, 0.75, 0.1), "PONTE CAIU\nSIGA EM FRENTE ->", Color(0.1, 0.05, 0.02), 70, 0.0, true)
	_plaque(Vector3(6.0, 2.4, -11.0), Vector2(3.8, 1.2), Color(0.95, 0.75, 0.1), "BURACO A 100m\n(É MENTIRA, É AGORA)", Color(0.1, 0.05, 0.02), 34, 0.0, true)
	_plaque(Vector3(-7.0, 1.4, 4.0), Vector2(3.0, 0.9), Color(0.1, 0.45, 0.25), "BR-116 KM 67\nRADAR: SÓ FOTOGRAFA O BURACO", Color(1, 1, 1), 22, 0.0, true)


func _build_cows_and_worker() -> void:

	var white := _mat(Color(0.96, 0.96, 0.94), 0.9, 0.0)
	var spot := _mat(Color(0.12, 0.1, 0.1), 0.9, 0.0)

	for i in range(3):

		var c := Node3D.new()
		c.position = Vector3(-8.0 + float(i) * 8.0, 0.0, -15.0 - float(i % 2) * 2.5)
		c.rotation_degrees = Vector3(0, _rng.randf_range(-40.0, 40.0), 0)
		add_child(c)

		_box(c, Vector3(0, 0.95, 0), Vector3(1.9, 0.8, 0.8), white)
		_box(c, Vector3(-0.3, 1.0, 0.41), Vector3(0.6, 0.5, 0.02), spot)
		_box(c, Vector3(1.15, 1.1, 0), Vector3(0.55, 0.4, 0.4), white)

		for lx in [-0.75, 0.75]:
			for lz in [-0.28, 0.28]:
				_box(c, Vector3(lx, 0.3, lz), Vector3(0.14, 0.6, 0.14), white)

		_cows.append(c)

	# funcionário do tapa-buraco (em breve), com sombra... e cadeira
	var w: Dictionary = _person(self, Vector3(-4.6, 0.0, 1.8), Color(1.0, 0.55, 0.1), Color(0.7, 0.5, 0.36), Color(0.15, 0.2, 0.45), Color(0.95, 0.85, 0.2))
	var wn: Node3D = w["node"]
	wn.rotation_degrees.x = -8.0

	_cyl(self, Vector3(-4.3, 0.9, 1.7), 0.03, 1.8, _mat(Color(0.5, 0.35, 0.2), 0.9, 0.0), Vector3(0, 0, 8))
	_plaque(Vector3(-4.6, 2.3, 1.6), Vector2(2.8, 0.7), Color(1.0, 0.55, 0.1), "TAPA-BURACO: EM BREVE", Color(0.1, 0.05, 0.02), 24)


func _build_landscape() -> void:

	# cerrado: árvores tortas, buritis e serras ao longe
	var bark := _mat(Color(0.3, 0.2, 0.12), 0.9, 0.0)
	var dry := _mat(Color(0.5, 0.45, 0.18), 0.9, 0.0)

	for i in range(16):
		var x: float = _rng.randf_range(-40.0, 40.0)
		var z: float = _rng.randf_range(-22.0, -50.0)
		var h: float = _rng.randf_range(2.5, 5.0)

		_cyl(self, Vector3(x, h / 2.0, z), 0.16, h, bark, Vector3(0, 0, _rng.randf_range(-12.0, 12.0)))
		_sphere(self, Vector3(x, h + 0.6, z), 1.6, dry, Vector3(1.3, 0.6, 1.3))

	for i in range(5):
		var x2: float = -50.0 + float(i) * 25.0
		var m := _mat(Color(0.55, 0.32, 0.22), 1.0, 0.0)
		_box(self, Vector3(x2, 6.0, -75.0), Vector3(20.0, 12.0, 8.0), m)
		_box(self, Vector3(x2, 12.4, -75.0), Vector3(22.0, 0.8, 9.0), _mat(Color(0.45, 0.28, 0.2), 1.0, 0.0))


func _update(t: float, dt: float) -> void:

	for v in _vehicles:

		var n: Node3D = v["node"]
		n.position.x += dt * float(v["speed"])

		if n.position.x > 34.0:
			n.position.x = -34.0
		elif n.position.x < -34.0:
			n.position.x = 34.0

		# balança e pula ao passar por um buraco
		var bounce: float = 0.0

		for h in _holes:
			if absf(float(h["z"]) - float(v["z"])) < 1.8 and absf(n.position.x - float(h["x"])) < 1.6:
				bounce = maxf(bounce, 0.35 * (1.0 - absf(n.position.x - float(h["x"])) / 1.6))

		n.position.y = bounce
		n.rotation_degrees.z = sin(t * 14.0) * 3.0 * (1.0 if bounce > 0.0 else 0.15)

	# vacas caminham devagar
	for i in range(_cows.size()):
		var c: Node3D = _cows[i]
		c.position.x += dt * 0.15 * (1.0 if i % 2 == 0 else -1.0)

	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(8.0, 15.0)
		_event()


func _event() -> void:

	var r: int = _rng.randi() % 3

	if r == 0 and not _vehicles.is_empty():
		var v: Dictionary = _vehicles[_rng.randi() % _vehicles.size()]
		var n: Node3D = v["node"]
		_toast("PÓÓÓÓÓ!", n.position + Vector3(0, 3.6, 0), Color(1.0, 0.7, 0.3), 80)
	elif r == 1 and not _cows.is_empty():
		var c: Node3D = _cows[_rng.randi() % _cows.size()]
		_toast("MUUUUU!", c.position + Vector3(0, 2.4, 0), Color(1.0, 0.95, 0.85), 80)
	else:
		_toast("AI, MEU EIXO!", Vector3(_rng.randf_range(-6.0, 6.0), 3.2, -6.0), Color(1.0, 0.4, 0.3), 80)
