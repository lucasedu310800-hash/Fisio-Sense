# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioArena
# ARENA DE CAMPEONATO: plataforma de luta com aro de LED, arquibancadas
# lotadas (torcida que "faz a ola"), estrutura metálica com holofotes
# varrendo o centro, telões com o placar da partida e faixas de LED.

const LOGO_PATH := "res://assets/textures/logo_fbf.png"

var _lbl_time: Label3D
var _lbl_score: Label3D
var _lbl_prec: Label3D


func make_environment() -> Environment:

	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.01, 0.01, 0.03)

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.16, 0.17, 0.28)
	env.ambient_light_energy = 0.8

	env.fog_enabled = true
	env.fog_light_color = Color(0.04, 0.04, 0.10)
	env.fog_density = 0.012

	env.glow_enabled = true
	env.glow_intensity = 1.1
	env.glow_hdr_threshold = 0.8

	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.4

	return env


func _build() -> void:

	_sun(Vector3(-62, 20, 0), Color(0.55, 0.60, 0.9), 0.45)

	_build_platform()
	_build_stands()
	_build_truss_and_beams()
	_build_screens()
	_build_led_ribbon()

	_particles(
		Vector3(0, 3.0, -4.0), Vector3(7.0, 2.5, 4.0),
		60, 7.0, Color(0.9, 0.95, 1.0, 0.5), 0.05,
		Vector3(0.0, 0.05, 0.0), 0.05, 0.25, true, Vector3(0, 1, 0), 180.0
	)

	_make_accent(Vector3(0.0, 5.0, -2.5), Color(0.85, 0.9, 1.0), 0.55, 13.0)


# ------------------------------------------------------------
# Plataforma central com aro de LED que muda de cor
# ------------------------------------------------------------

func _build_platform() -> void:

	var steel := _mat(Color(0.07, 0.07, 0.10), 0.35, 0.7)

	_box(self, Vector3(0, -0.35, -4.0), Vector3(70, 0.1, 50), _mat(Color(0.03, 0.03, 0.05), 0.5, 0.5))
	_cyl(self, Vector3(0, -0.15, -2.2), 5.2, 0.3, steel, Vector3.ZERO, 48)

	var ring_mat := _emit(Color(0.2, 0.8, 1.0), 3.0)
	var ring := _no_shadow(_torus(self, Vector3(0, 0.005, -2.2), 5.12, 5.28, ring_mat))
	ring.scale = Vector3(1.0, 1.0, 1.0)

	var inner_mat := _emit(Color(1.0, 0.25, 0.4), 2.2)
	_no_shadow(_torus(self, Vector3(0, 0.006, -2.2), 3.55, 3.63, inner_mat))

	# logo do jogo no chão, sob os lutadores
	if ResourceLoader.exists(LOGO_PATH):

		var tex: Texture2D = load(LOGO_PATH) as Texture2D

		var logo := Sprite3D.new()
		logo.texture = tex
		logo.pixel_size = 3.2 / float(tex.get_width())
		logo.shaded = false
		logo.modulate = Color(1, 1, 1, 0.85)
		logo.position = Vector3(0, 0.02, -2.2)
		logo.rotation_degrees = Vector3(-90, 0, 0)
		add_child(logo)

	_anim.append(func(t: float, _dt: float):
		var c1 := Color.from_hsv(fmod(t * 0.06, 1.0), 0.85, 1.0)
		var c2 := Color.from_hsv(fmod(t * 0.06 + 0.5, 1.0), 0.85, 1.0)
		ring_mat.emission = c1
		ring_mat.albedo_color = c1
		inner_mat.emission = c2
		inner_mat.albedo_color = c2
	)


# ------------------------------------------------------------
# Arquibancadas (torcida em MultiMesh — leve — com "ola")
# ------------------------------------------------------------

func _crowd_tier(parent: Node3D, count: int, length: float, y: float, seed_value: int) -> Node3D:

	var tier := Node3D.new()
	parent.add_child(tier)

	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.24
	body_mesh.height = 0.95

	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.17
	head_mesh.height = 0.34

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.8

	var mm_body := MultiMesh.new()
	mm_body.transform_format = MultiMesh.TRANSFORM_3D
	mm_body.use_colors = true
	mm_body.mesh = body_mesh
	mm_body.instance_count = count

	var mm_head := MultiMesh.new()
	mm_head.transform_format = MultiMesh.TRANSFORM_3D
	mm_head.use_colors = true
	mm_head.mesh = head_mesh
	mm_head.instance_count = count

	var shirts := [
		Color(0.85, 0.15, 0.2), Color(0.15, 0.4, 0.9), Color(0.95, 0.8, 0.2),
		Color(0.9, 0.9, 0.95), Color(0.2, 0.7, 0.4), Color(0.6, 0.25, 0.85), Color(0.1, 0.1, 0.14),
	]
	var skins := [Color(0.95, 0.76, 0.62), Color(0.76, 0.56, 0.42), Color(0.52, 0.36, 0.26), Color(0.36, 0.25, 0.19)]

	for i in range(count):

		var x: float = -length / 2.0 + (float(i) + rng.randf_range(-0.25, 0.25)) * length / float(count)

		mm_body.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(x, y + 0.42, 0)))
		mm_body.set_instance_color(i, shirts[rng.randi() % shirts.size()])

		mm_head.set_instance_transform(i, Transform3D(Basis.IDENTITY, Vector3(x, y + 1.06, 0)))
		mm_head.set_instance_color(i, skins[rng.randi() % skins.size()])

	var bi := MultiMeshInstance3D.new()
	bi.multimesh = mm_body
	bi.material_override = mat
	tier.add_child(bi)

	var hi := MultiMeshInstance3D.new()
	hi.multimesh = mm_head
	hi.material_override = mat
	tier.add_child(hi)

	return tier


# Uma arquibancada em degraus. Local: degraus sobem em direção a -Z.
func _bank(pos: Vector3, yaw: float, length: float, tiers: int, seed_base: int) -> void:

	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0, yaw, 0)
	add_child(root)

	var concrete := _mat(Color(0.10, 0.10, 0.14), 0.7, 0.1)
	var count: int = int(length / 0.85)

	var crowd_tiers: Array = []

	for i in range(tiers):

		var top: float = 0.8 * float(i + 1)

		_box(root, Vector3(0, top / 2.0, -1.5 * float(i)), Vector3(length, top, 1.5), concrete)

		var tier := _crowd_tier(root, count, length - 1.0, top, seed_base + i)
		tier.position = Vector3(0, 0, -1.5 * float(i))
		crowd_tiers.append(tier)

	_anim.append(func(t: float, _dt: float):
		for i in range(crowd_tiers.size()):
			var tr: Node3D = crowd_tiers[i]
			# "ola": a onda sobe os degraus, com pulinhos por fileira
			tr.position.y = maxf(0.0, sin(t * 3.0 - float(i) * 0.9)) * 0.12
	)


func _build_stands() -> void:

	_bank(Vector3(0, 0, -8.6), 0.0, 36.0, 6, 100)
	_bank(Vector3(-9.0, 0, -1.0), 90.0, 15.0, 5, 200)
	_bank(Vector3(9.0, 0, -1.0), -90.0, 15.0, 5, 300)


# ------------------------------------------------------------
# Estrutura metálica + holofotes que varrem a arena
# ------------------------------------------------------------

func _build_truss_and_beams() -> void:

	var metal := _mat(Color(0.20, 0.21, 0.25), 0.4, 0.8)

	# aro de treliça suspenso
	_torus(self, Vector3(0, 7.6, -3.0), 7.0, 7.25, metal)
	_torus(self, Vector3(0, 7.2, -3.0), 7.0, 7.12, metal)

	for a in range(6):
		var ang: float = float(a) * TAU / 6.0
		_box(self, Vector3(sin(ang) * 7.1, 8.6, -3.0 + cos(ang) * 7.1), Vector3(0.1, 2.0, 0.1), metal)

	# 6 holofotes apontando pro centro, com feixes visíveis
	var beam_colors := [
		Color(0.9, 0.95, 1.0), Color(1.0, 0.3, 0.7), Color(0.3, 0.85, 1.0),
		Color(1.0, 0.75, 0.25), Color(0.6, 0.4, 1.0), Color(0.9, 0.95, 1.0),
	]
	var wobblers: Array = []

	for i in range(6):

		var ang: float = float(i) * TAU / 6.0 + 0.3
		var pos := Vector3(sin(ang) * 6.6, 7.4, -3.0 + cos(ang) * 6.6)

		var root := Node3D.new()
		root.position = pos
		add_child(root)
		root.look_at(Vector3(0, 0.8, -2.2), Vector3.UP)

		var col: Color = beam_colors[i]

		var aim := Node3D.new()
		root.add_child(aim)
		wobblers.append(aim)

		_cyl(aim, Vector3(0, 0, -0.2), 0.16, 0.4, _mat(Color(0.05, 0.05, 0.07), 0.5, 0.6), Vector3(90, 0, 0))
		_no_shadow(_cyl(aim, Vector3(0, 0, -0.42), 0.12, 0.03, _emit(col, 3.0), Vector3(90, 0, 0)))

		# feixe de luz falso (cone aditivo)
		var beam_mesh := CylinderMesh.new()
		beam_mesh.top_radius = 1.1
		beam_mesh.bottom_radius = 0.05
		beam_mesh.height = 9.0
		beam_mesh.radial_segments = 16

		var beam := MeshInstance3D.new()
		beam.mesh = beam_mesh
		_put(aim, beam, Vector3(0, 0, -4.7), Vector3(-90, 0, 0), _glow_mat(Color(col.r, col.g, col.b, 0.07)))
		_no_shadow(beam)

		# luz de verdade só em 3 dos 6 (desempenho)
		if i % 2 == 0:
			var sp := _spot(Vector3(0, 0, -0.5), col, 3.2, 14.0, 24.0, aim)
			sp.spot_attenuation = 0.8

	_anim.append(func(t: float, _dt: float):
		for i in range(wobblers.size()):
			var w: Node3D = wobblers[i]
			w.rotation_degrees.x = sin(t * 0.7 + float(i) * 1.1) * 7.0
			w.rotation_degrees.z = sin(t * 0.5 + float(i) * 0.7) * 7.0
	)


# ------------------------------------------------------------
# Telões (placar ao vivo) e banners
# ------------------------------------------------------------

func _screen_frame(pos: Vector3, size: Vector2, yaw: float) -> Node3D:

	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0, yaw, 0)
	add_child(root)

	var frame := _mat(Color(0.08, 0.08, 0.11), 0.4, 0.7)
	var face := _emit(Color(0.03, 0.06, 0.16), 0.9)

	_box(root, Vector3(0, 0, 0), Vector3(size.x + 0.3, size.y + 0.3, 0.25), frame)
	_no_shadow(_box(root, Vector3(0, 0, 0.14), Vector3(size.x, size.y, 0.02), face))

	return root


func _build_screens() -> void:

	# telão principal (placar ao vivo)
	var main_screen := _screen_frame(Vector3(0, 8.4, -14.0), Vector2(9.0, 3.6), 0.0)

	_label("FBF CHAMPIONSHIP", Vector3(0, 1.15, 0.17), 96, 0.0072, Color(1.0, 0.8, 0.3), Vector3.ZERO, main_screen)

	_lbl_time = _label("TEMPO 01:30", Vector3(-2.6, -0.2, 0.17), 80, 0.0072, Color(0.4, 0.9, 1.0), Vector3.ZERO, main_screen)
	_lbl_score = _label("PONTOS 0", Vector3(2.4, -0.2, 0.17), 80, 0.0072, Color(1.0, 1.0, 1.0), Vector3.ZERO, main_screen)
	_lbl_prec = _label("PRECISÃO 100%", Vector3(0, -1.25, 0.17), 64, 0.0072, Color(0.5, 1.0, 0.6), Vector3.ZERO, main_screen)

	# telões laterais
	var left_screen := _screen_frame(Vector3(-11.5, 6.6, -10.5), Vector2(4.2, 2.4), 28.0)
	_label("ROUND 1", Vector3(0, 0.35, 0.17), 90, 0.0065, Color(1.0, 0.35, 0.35), Vector3.ZERO, left_screen)
	_label("FIGHT!", Vector3(0, -0.5, 0.17), 80, 0.0065, Color(1, 1, 1), Vector3.ZERO, left_screen)

	var right_screen := _screen_frame(Vector3(11.5, 6.6, -10.5), Vector2(4.2, 2.4), -28.0)

	if ResourceLoader.exists(LOGO_PATH):

		var tex: Texture2D = load(LOGO_PATH) as Texture2D

		var logo := Sprite3D.new()
		logo.texture = tex
		logo.pixel_size = 2.0 / float(tex.get_height())
		logo.shaded = false
		logo.position = Vector3(0, 0, 0.17)
		right_screen.add_child(logo)

	# pisca-pisca do telão principal (dá vida ao placar)
	_anim.append(func(t: float, _dt: float):
		var k: float = 0.75 + 0.25 * sin(t * 2.0)
		if _lbl_time:
			_lbl_time.modulate = Color(0.4 * k + 0.3, 0.9, 1.0, 1.0)
	)


func _build_led_ribbon() -> void:

	var segs: int = 28
	var mats: Array = []

	for i in range(segs):

		var m := _emit(Color(1, 0, 0), 2.6)
		mats.append(m)

		var x: float = -13.5 + float(i) * (27.0 / float(segs - 1))

		_no_shadow(_box(self, Vector3(x, 0.55, -7.8), Vector3(0.9, 0.14, 0.06), m))

	_anim.append(func(t: float, _dt: float):
		for i in range(mats.size()):
			var m2: StandardMaterial3D = mats[i]
			var c := Color.from_hsv(fmod(t * 0.15 + float(i) / 28.0, 1.0), 0.9, 1.0)
			m2.emission = c
			m2.albedo_color = c
	)


# Chamado pelo Main a cada frame: mantém o placar do telão atualizado.
func set_scoreboard(time_text: String, score: int, precision: float) -> void:

	if _lbl_time:
		_lbl_time.text = "TEMPO " + time_text

	if _lbl_score:
		_lbl_score.text = "PONTOS %d" % score

	if _lbl_prec:
		_lbl_prec.text = "PRECISÃO %.0f%%" % precision
