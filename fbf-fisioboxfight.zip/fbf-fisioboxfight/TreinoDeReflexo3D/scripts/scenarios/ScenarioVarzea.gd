# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends ScenarioBase
class_name ScenarioVarzea
# ESTÁDIO DE VÁRZEA: campinho de terra e grama rala, gol com trave torta e
# rede furada, luta no círculo central, torcida no alambrado, arquibancada
# de madeira, churrasquinho, placar pintado à mão, pelada rolando ao fundo,
# uma vaca pastando no campo e um cachorro que rouba a bola.

var _rng := RandomNumberGenerator.new()
var _fans: Array = []
var _players: Array = []
var _ball: Node3D
var _cow: Node3D
var _cow_head: Node3D
var _dog: Node3D
var _dog_active: bool = false
var _event_timer: float = 9.0


func make_environment() -> Environment:

	var env := Environment.new()

	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.32, 0.55, 0.88)
	sky_mat.sky_horizon_color = Color(0.92, 0.92, 0.85)
	sky_mat.ground_horizon_color = Color(0.7, 0.7, 0.55)
	sky_mat.ground_bottom_color = Color(0.4, 0.4, 0.3)

	var sky := Sky.new()
	sky.sky_material = sky_mat

	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.8, 0.8, 0.75)
	env.ambient_light_energy = 0.95
	env.fog_enabled = true
	env.fog_light_color = Color(0.85, 0.88, 0.85)
	env.fog_density = 0.006
	env.glow_enabled = true
	env.glow_intensity = 0.4
	env.ssao_enabled = true

	return env


func _build() -> void:

	_rng.randomize()

	_sun(Vector3(-52, -35, 0), Color(1.0, 0.95, 0.82), 1.6)

	_build_pitch()
	_build_goal()
	_build_fence_and_fans()
	_build_bleachers()
	_build_stand_and_board()
	_build_pelada()
	_build_cow_and_dog()
	_build_scenery()

	_make_accent(Vector3(0, 4.0, -3.0), Color(1.0, 0.95, 0.85), 0.3, 10.0)

	_anim.append(_update)


func _build_pitch() -> void:

	_box(self, Vector3(0, -0.06, -6.0), Vector3(50, 0.1, 40), _mat(Color(0.34, 0.5, 0.2), 1.0, 0.0))

	# manchas de terra (campo judiado)
	var dirt := _mat(Color(0.55, 0.4, 0.24), 1.0, 0.0)

	for p in [Vector3(0, 0.003, -2.2), Vector3(-5.0, 0.003, -9.0), Vector3(5.0, 0.003, -11.0), Vector3(-3.0, 0.003, 2.0)]:
		_cyl(self, p, _rng.randf_range(1.6, 3.4), 0.006, dirt, Vector3.ZERO, 20)

	# linhas de cal + círculo central (onde rola a luta)
	var line := _mat(Color(0.95, 0.95, 0.92), 0.9, 0.0)

	_torus(self, Vector3(0, 0.02, -2.2), 3.1, 3.25, line)
	_box(self, Vector3(0, 0.012, -2.2), Vector3(14.0, 0.006, 0.14), line)
	_box(self, Vector3(-7.0, 0.012, -6.0), Vector3(0.14, 0.006, 16.0), line)
	_box(self, Vector3(7.0, 0.012, -6.0), Vector3(0.14, 0.006, 16.0), line)
	_box(self, Vector3(0, 0.012, -14.0), Vector3(14.0, 0.006, 0.14), line)
	_box(self, Vector3(0, 0.012, 3.0), Vector3(14.0, 0.006, 0.14), line)

	# poças
	var puddle := _mat(Color(0.35, 0.28, 0.2), 0.05, 0.4)

	for p2 in [Vector3(-4.6, 0.004, -0.6), Vector3(4.4, 0.004, -4.6)]:
		_cyl(self, p2, 0.9, 0.006, puddle, Vector3.ZERO, 16)

	# bandeirinha de escanteio
	for cx in [-7.0, 7.0]:
		_cyl(self, Vector3(cx, 0.75, -14.0), 0.02, 1.5, _mat(Color(0.9, 0.9, 0.9), 0.5, 0.0))
		_box(self, Vector3(cx + 0.15, 1.35, -14.0), Vector3(0.3, 0.2, 0.02), _mat(Color(0.95, 0.85, 0.1), 0.8, 0.0))


func _build_goal() -> void:

	var wood := _mat(Color(0.85, 0.85, 0.82), 0.7, 0.0)
	var net := _mat(Color(0.95, 0.95, 0.95, 0.45), 1.0, 0.0)
	net.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA

	# trave torta (uma trave é maior que a outra)
	_box(self, Vector3(-2.6, 1.2, -14.4), Vector3(0.14, 2.4, 0.14), wood, Vector3(0, 0, 4))
	_box(self, Vector3(2.7, 1.1, -14.4), Vector3(0.14, 2.2, 0.14), wood, Vector3(0, 0, -6))
	_box(self, Vector3(0.05, 2.35, -14.4), Vector3(5.6, 0.14, 0.14), wood, Vector3(0, 0, 3))
	_box(self, Vector3(0, 1.2, -15.6), Vector3(5.4, 2.3, 0.02), net)

	# rombo na rede (furo)
	_box(self, Vector3(1.4, 0.9, -15.58), Vector3(0.7, 0.7, 0.03), _mat(Color(0.34, 0.5, 0.2), 1.0, 0.0), Vector3(0, 0, 45))

	_plaque(Vector3(0, 3.0, -14.4), Vector2(3.4, 0.6), Color(0.95, 0.95, 0.9), "GOL COM REDE FURADA (BOLA VAZA)", Color(0.5, 0.05, 0.05), 20)


func _build_fence_and_fans() -> void:

	var metal := _mat(Color(0.55, 0.57, 0.6), 0.4, 0.7)
	var shirts := [Color(0.9, 0.15, 0.15), Color(0.15, 0.4, 0.9), Color(0.95, 0.85, 0.15), Color(0.95, 0.95, 0.95), Color(0.15, 0.6, 0.3)]
	var skins := [Color(0.98, 0.78, 0.65), Color(0.78, 0.56, 0.42), Color(0.55, 0.38, 0.28)]

	# alambrado dos dois lados
	for sx in [-9.0, 9.0]:

		for i in range(-2, 8):
			_cyl(self, Vector3(sx, 1.0, -float(i) * 2.0), 0.05, 2.0, metal)

		_box(self, Vector3(sx, 1.95, -6.0), Vector3(0.05, 0.05, 20.0), metal)
		_box(self, Vector3(sx, 1.0, -6.0), Vector3(0.02, 1.9, 20.0), _mat(Color(0.7, 0.72, 0.75, 0.25), 0.4, 0.5))

	# torcida atrás do alambrado da direita, gritando
	for i in range(14):
		var p: Dictionary = _person(self, Vector3(9.9 + _rng.randf_range(0.0, 1.0), 0.0, -float(i) * 1.15 + 1.5), shirts[_rng.randi() % shirts.size()], skins[_rng.randi() % skins.size()], Color(0.25, 0.28, 0.4))
		var arms: Array = p["arms"]
		_fans.append({"node": p["node"], "arms": arms, "phase": _rng.randf_range(0.0, 6.0)})


func _build_bleachers() -> void:

	var wood := _mat(Color(0.5, 0.34, 0.2), 0.9, 0.0)
	var shirts := [Color(0.9, 0.15, 0.15), Color(0.15, 0.4, 0.9), Color(0.95, 0.85, 0.15)]
	var skins := [Color(0.98, 0.78, 0.65), Color(0.78, 0.56, 0.42), Color(0.55, 0.38, 0.28)]

	# arquibancada de madeira à esquerda
	for i in range(3):
		_box(self, Vector3(-11.2 - float(i) * 0.9, 0.3 + float(i) * 0.5, -5.0), Vector3(0.9, 0.6 + float(i) * 1.0, 10.0), wood)

	for i in range(10):
		var row: int = i % 3
		var p: Dictionary = _person(self, Vector3(-11.2 - float(row) * 0.9, 0.6 + float(row) * 0.5, -1.0 - float(i) * 0.9), shirts[_rng.randi() % shirts.size()], skins[_rng.randi() % skins.size()], Color(0.25, 0.28, 0.4))
		_fans.append({"node": p["node"], "arms": p["arms"], "phase": _rng.randf_range(0.0, 6.0)})


func _build_stand_and_board() -> void:

	# churrasquinho
	var q := Node3D.new()
	q.position = Vector3(8.0, 0.0, 3.0)
	add_child(q)
	_box(q, Vector3(0, 0.5, 0), Vector3(1.2, 0.6, 0.6), _mat(Color(0.2, 0.2, 0.22), 0.5, 0.4))
	_box(q, Vector3(0, 0.82, 0), Vector3(1.1, 0.05, 0.5), _emit(Color(1.0, 0.4, 0.1), 1.6))
	_label("CHURRASQUINHO R$5", Vector3(0, 2.0, 0), 40, 0.0048, Color(1.0, 0.9, 0.4), Vector3.ZERO, q).outline_size = 10
	_particles(Vector3(8.0, 1.3, 3.0), Vector3(0.3, 0.05, 0.2), 14, 2.0, Color(0.9, 0.9, 0.9, 0.25), 0.4, Vector3(0.1, 0.6, 0), 0.3, 0.5, false, Vector3(0, 1, 0), 15.0)

	# placar pintado à mão
	var bx: float = -7.6
	_box(self, Vector3(bx, 1.4, -10.5), Vector3(0.15, 2.8, 0.15), _mat(Color(0.4, 0.3, 0.2), 0.9, 0.0))
	_box(self, Vector3(bx + 1.6, 1.4, -10.5), Vector3(0.15, 2.8, 0.15), _mat(Color(0.4, 0.3, 0.2), 0.9, 0.0))
	_plaque(Vector3(bx + 0.8, 2.8, -10.4), Vector2(2.6, 1.0), Color(0.2, 0.3, 0.2), "CASA 0 x 0 VISITANTE\n(ÁRBITRO É PRIMO DO DONO)", Color(0.95, 0.95, 0.8), 22)

	# alto-falante no poste
	_cyl(self, Vector3(6.6, 2.4, -10.5), 0.06, 4.8, _mat(Color(0.4, 0.4, 0.4), 0.6, 0.4))
	_cone(self, Vector3(6.6, 4.7, -10.3), 0.4, 0.6, _mat(Color(0.7, 0.7, 0.72), 0.5, 0.5), Vector3(90, 0, 0), 12)

	_plaque(Vector3(4.2, 1.6, 2.4), Vector2(3.0, 0.9), Color(0.9, 0.2, 0.2), "PROIBIDO CHUTAR BOLA PRO MATO\n(MULTA: A BOLA)", Color(1, 1, 1), 22, 0.0, true)


func _build_pelada() -> void:

	var teams := [Color(0.9, 0.15, 0.15), Color(0.15, 0.4, 0.9)]

	for i in range(8):

		var p: Dictionary = _person(self, Vector3(_rng.randf_range(-5.0, 5.0), 0.0, _rng.randf_range(-13.0, -8.0)), teams[i % 2], Color(0.75, 0.55, 0.4), Color(0.95, 0.95, 0.95))
		_players.append({"node": p["node"], "legs": p["legs"], "cx": _rng.randf_range(-4.0, 4.0), "cz": _rng.randf_range(-12.5, -8.5), "phase": _rng.randf_range(0.0, 6.0), "spd": _rng.randf_range(0.5, 1.1)})

	_ball = Node3D.new()
	add_child(_ball)
	_sphere(_ball, Vector3.ZERO, 0.2, _mat(Color(0.98, 0.98, 0.98), 0.5, 0.0))
	_sphere(_ball, Vector3(0.08, 0.1, 0.14), 0.07, _mat(Color(0.1, 0.1, 0.1), 0.5, 0.0))


func _build_cow_and_dog() -> void:

	# vaca pastando no campo (invadiu)
	_cow = Node3D.new()
	_cow.position = Vector3(5.6, 0.0, -9.0)
	add_child(_cow)

	var white := _mat(Color(0.96, 0.96, 0.94), 0.9, 0.0)
	var spot := _mat(Color(0.12, 0.1, 0.1), 0.9, 0.0)

	_box(_cow, Vector3(0, 0.95, 0), Vector3(1.9, 0.8, 0.8), white)
	_box(_cow, Vector3(-0.3, 1.0, 0.41), Vector3(0.6, 0.5, 0.02), spot)
	_box(_cow, Vector3(0.5, 0.9, -0.41), Vector3(0.5, 0.4, 0.02), spot)

	for lx in [-0.75, 0.75]:
		for lz in [-0.28, 0.28]:
			_box(_cow, Vector3(lx, 0.3, lz), Vector3(0.14, 0.6, 0.14), white)

	_cow_head = Node3D.new()
	_cow_head.position = Vector3(1.0, 1.15, 0)
	_cow.add_child(_cow_head)
	_box(_cow_head, Vector3(0.3, 0, 0), Vector3(0.55, 0.4, 0.4), white)
	_box(_cow_head, Vector3(0.55, -0.1, 0), Vector3(0.2, 0.2, 0.32), _mat(Color(0.95, 0.7, 0.7), 0.8, 0.0))

	for sz in [-1.0, 1.0]:
		_box(_cow_head, Vector3(0.05, 0.25, sz * 0.15), Vector3(0.05, 0.2, 0.05), _mat(Color(0.9, 0.85, 0.6), 0.6, 0.0))

	# cachorro vira-lata (aparece no evento e rouba a bola)
	_dog = Node3D.new()
	_dog.position = Vector3(-20.0, 0.0, -6.0)
	add_child(_dog)

	var fur := _mat(Color(0.86, 0.55, 0.24), 0.9, 0.0)
	_box(_dog, Vector3(0, 0.4, 0), Vector3(0.7, 0.3, 0.3), fur)
	_sphere(_dog, Vector3(0.45, 0.55, 0), 0.17, fur)
	_box(_dog, Vector3(-0.42, 0.55, 0), Vector3(0.3, 0.06, 0.06), fur, Vector3(0, 0, 30))

	for lx in [-0.25, 0.25]:
		for lz in [-0.1, 0.1]:
			_box(_dog, Vector3(lx, 0.15, lz), Vector3(0.07, 0.3, 0.07), fur)


func _build_scenery() -> void:

	# casinhas e morros ao fundo
	for i in range(18):
		var w: float = _rng.randf_range(3.0, 5.0)
		var h: float = _rng.randf_range(3.0, 7.0)
		var m := _building_mat(7000 + i, w, h, Color(0.95, 0.85, 0.75), 0.25)
		_box(self, Vector3(-40.0 + float(i) * 4.6, h / 2.0, -26.0 - _rng.randf_range(0.0, 8.0)), Vector3(w, h, 4.0), m)

	_sphere(self, Vector3(-28, -6, -50), 20.0, _mat(Color(0.28, 0.48, 0.28), 1.0, 0.0))
	_sphere(self, Vector3(24, -7, -54), 24.0, _mat(Color(0.3, 0.5, 0.3), 1.0, 0.0))

	# mangueiras
	for tx in [-15.0, 14.0, -18.0]:
		_cyl(self, Vector3(tx, 1.6, -12.0), 0.25, 3.2, _mat(Color(0.3, 0.2, 0.12), 0.9, 0.0))
		_sphere(self, Vector3(tx, 4.2, -12.0), 2.4, _mat(Color(0.15, 0.45, 0.2), 0.9, 0.0), Vector3(1.2, 0.9, 1.2))


func _update(t: float, dt: float) -> void:

	for f in _fans:
		var n: Node3D = f["node"]
		var ph: float = f["phase"]
		n.rotation_degrees.z = sin(t * 4.0 + ph) * 3.0

		var arms: Array = f["arms"]
		var a0: Node3D = arms[0]
		var a1: Node3D = arms[1]
		a0.rotation_degrees.x = -150.0 + sin(t * 5.0 + ph) * 20.0
		a1.rotation_degrees.x = -150.0 - sin(t * 5.0 + ph) * 20.0

	# pelada ao fundo: todo mundo correndo atrás da bola
	var bx: float = sin(t * 0.6) * 4.0
	var bz: float = -10.5 + cos(t * 0.9) * 2.0

	if _ball and not _dog_active:
		_ball.position = Vector3(bx, 0.2, bz)

	for p in _players:
		var pn: Node3D = p["node"]
		var ph2: float = p["phase"]
		var tx: float = lerpf(float(p["cx"]), bx, 0.55) + sin(t * float(p["spd"]) + ph2) * 1.2
		var tz: float = lerpf(float(p["cz"]), bz, 0.55) + cos(t * float(p["spd"]) + ph2) * 1.0
		pn.position.x = lerpf(pn.position.x, tx, 0.05)
		pn.position.z = lerpf(pn.position.z, clampf(tz, -13.5, -7.5), 0.05)

		var lg: Array = p["legs"]
		var l0: Node3D = lg[0]
		var l1: Node3D = lg[1]
		var sw: float = sin(t * 9.0 + ph2) * 0.7
		l0.rotation.z = sw
		l1.rotation.z = -sw

	if _cow_head:
		_cow_head.rotation_degrees.z = -25.0 + sin(t * 0.8) * 15.0

	_event_timer -= dt

	if _event_timer <= 0.0:
		_event_timer = _rng.randf_range(10.0, 18.0)
		_event()


func _event() -> void:

	var r: int = _rng.randi() % 3

	if r == 0:
		_toast("MUUUUU!", _cow.position + Vector3(0, 2.4, 0), Color(1.0, 0.95, 0.85), 80)
	elif r == 1:
		_toast("GOOOOOL! (FOI IMPEDIDO)", Vector3(0, 4.2, -9.0), Color(1.0, 0.9, 0.3), 70)
	else:
		_event_dog()


# Cachorro entra correndo, pega a bola e sai com ela (o time inteiro atrás).
func _event_dog() -> void:

	if _dog_active or _dog == null or _ball == null:
		return

	_dog_active = true

	_dog.position = Vector3(-20.0, 0.0, -9.5)
	_toast("O CACHORRO PEGOU A BOLA!", Vector3(0, 4.4, -9.0), Color(1.0, 0.8, 0.3), 60)

	var tw := create_tween()
	tw.tween_property(_dog, "position:x", bx_ball(), 2.5)
	tw.tween_property(_dog, "position:x", 22.0, 3.0)
	tw.parallel().tween_method(_carry_ball, 0.0, 1.0, 3.0)
	tw.tween_callback(
		func():
			_dog_active = false
			_dog.position = Vector3(-20.0, 0.0, -6.0)
	)


func bx_ball() -> float:

	return _ball.position.x if _ball else 0.0


func _carry_ball(_v: float) -> void:

	if _ball and _dog:
		_ball.position = _dog.position + Vector3(0.6, 0.3, 0.0)
