# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Entrada por câmera (webcam) — detecção de golpes por
# diferença de quadros, SEM plugin externo (GDScript puro).
#
# ============================================================
# COMO FICAR NA FRENTE DA CÂMERA
# ============================================================
# - Rosto no MEIO da imagem, cabeça na parte de cima (a prévia no
#   canto da tela mostra guias).
# - Mãos na guarda, na altura do queixo, aparecendo na imagem.
# - Uns 1 a 1,5 m da câmera, com luz boa no rosto.
#
# GESTOS (lados sempre do SEU ponto de vista):
#   Soco esquerda/direita -> soque pra frente com AQUELA mão, rápido.
#   Esquiva esquerda/direita -> incline cabeça e tronco pra AQUELE lado.
#   Defesa alta -> suba as DUAS mãos juntas na frente do nariz.
#
# ============================================================
# COMO FUNCIONA (e por que não confunde os lados)
# ============================================================
# 1) Cada quadro é reduzido pra ~64 px de largura (média de verdade, em
#    etapas de 2x — tira muito ruído), vira tons de cinza e é
#    ESPELHADO: assim a esquerda da imagem = SUA esquerda (como um
#    espelho). Se a câmera do seu sistema já vier espelhada, aperte M
#    durante o jogo pra inverter (a prévia vira junto, pra conferir).
# 2) Compara com o quadro anterior (compensando mudança de brilho
#    automática da câmera). O limiar se adapta ao ruído da câmera, e
#    pixels "piscando" sozinhos são descartados.
# 3) Classificação:
#    - ESQUIVA: o TOPO da cabeça se mexe e o centro do movimento anda
#      pro lado. O detector integra a posição da cabeça em relação ao
#      centro — então VOLTAR pro meio depois de uma esquiva nunca é
#      lido como esquiva pro outro lado.
#    - SOCO: movimento forte e largo (não uma linha fina) em UM lado
#      só (a faixa do meio é ignorada, porque o punho cruza o centro
#      ao vir pra câmera), com a cabeça parada.
#    - DEFESA ALTA: movimento dos DOIS lados ao mesmo tempo, subindo
#      em direção ao rosto, com a cabeça parada. Abaixar a guarda
#      depois (movimento descendo) não conta de novo.
#    - Depois de cada gesto, espera o corpo parar antes de ler o
#      próximo (o recolher do braço não vira outro soco).
#
# Tudo isso foi testado num simulador (jogador virtual com cabeça,
# tronco e luvas, ruído de câmera e variação de brilho): parado por
# 20 s -> 0 detecções falsas; 8 partidas aleatórias -> 96% dos gestos
# certos, nenhum lado trocado. Ainda assim é visão por movimento, não
# reconhecimento de esqueleto: luz ruim ou fundo muito agitado (gente
# passando atrás) atrapalham.
#
# SUPORTE POR PLATAFORMA: depende do Godot (CameraServer). Se nenhuma
# câmera for encontrada ou nenhuma imagem chegar, o Main.gd volta
# sozinho pro teclado.
#
# Contrato de sample(): igual a InputHandler.sample() — devolve
# "dodge_left" | "dodge_right" | "duck" | "punch_left" | "punch_right"
# ou "" (nada).

signal gesture_seen(gesture: String)

# ------------------------------------------------------------
# AJUSTES (calibrados no simulador; resolução de referência 64x48)
# ------------------------------------------------------------
const TARGET_WIDTH := 64
const REF_PIXELS := 64.0 * 48.0
const SAMPLE_INTERVAL_MS := 40          # ~25 quadros/s de análise
const DETECTION_FRESH_MS := 250         # por quanto tempo um gesto detectado fica "valendo"

const DIFF_T := 22.0            # diferença mínima (0-255) pra um pixel contar como movimento
const NOISE_K := 3.5            # limiar sobe se a câmera for ruidosa (x mediana da diferença)

const MIN_U_PIX := 10           # pixels mínimos mexendo na parte de cima pra medir o centro
const DODGE_WIN := 8            # quadros usados pra medir o deslocamento lateral
const DODGE_DISP := 0.07        # deslocamento mínimo (fração da largura) pra esquiva
const DODGE_TOP_MIN := 0.015    # topo da cabeça tem que estar se mexendo
const DODGE_POS := 0.07         # quão fora do centro a cabeça precisa estar
const POS_STEP_MAX := 0.06
const POS_DECAY_AFTER := 30     # quadros parado até a posição começar a voltar pro 0
const POS_DECAY := 0.9

const PUNCH_PEAK := 12          # pixels num quadro, de um lado
const PUNCH_COLS := 4           # largura mínima (colunas) — punho é mancha, não linha
const PUNCH_SUM := 30           # soma em 5 quadros
const PUNCH_RATIO := 2.2        # quanto um lado tem que dominar o outro
const PUNCH_SPIKE := 2.0        # quanto tem que superar o "normal" recente
const HEAD_GATE := 0.015        # cabeça parada (fração do topo mexendo)

const GUARD_FRAC := 0.04        # atividade mínima na zona do rosto
const GUARD_BAL := 0.45         # equilíbrio esquerda/direita (as duas mãos)
const GUARD_PIX := 30
const GUARD_RISE := 0.04        # tem que estar SUBINDO
const GUARD_BOTH := 6

const COOLDOWN := 0.30
const SETTLE_FRAC := 0.012
const SETTLE_SIDE := 8
const SETTLE_MAX := 0.9
const SAME_BLOCK := 1.0         # mesmo gesto não repete em menos de 1 s

# Zonas (frações da imagem, já espelhada = ponto de vista do jogador)
const TOP_Y := 0.22             # faixa do topo da cabeça
const UPPER_Y := 0.45           # parte de cima (cabeça/ombros)
const BAND_Y := 0.30            # daqui pra baixo: mãos
const SIDE_L := 0.45            # lado esquerdo = x < 0.45
const SIDE_R := 0.55            # lado direito = x >= 0.55 (faixa do meio ignorada)
const FACE_X0 := 0.30
const FACE_X1 := 0.70
const FACE_Y0 := 0.25
const FACE_Y1 := 0.65

var active: bool = false

# true = imagem espelhada (esquerda da imagem = esquerda do jogador).
# Tecla M no jogo inverte.
var mirror: bool = true

var _feed: CameraFeed = null
var _camera_texture: CameraTexture = null
var _got_first_frame: bool = false
var _last_sample_time: int = 0

var _w := 0
var _h := 0
var _prev: PackedFloat32Array = PackedFloat32Array()
var _prev_mean := 0.0

var _hist: Array = []
var _t := 0.0
var _cool_until := 0.0
var _last_by_gesture := {}
var _settling := false
var _settle_since := 0.0
var _still := 0
var _pos := 0.0
var _prev_cx := -1.0
var _head_still := 0

var _pending := ""
var _pending_time := 0


func _ready() -> void:
	# Godot 4.4+: as câmeras só aparecem com o monitoramento ligado.
	if "monitoring_feeds" in CameraServer:
		CameraServer.set("monitoring_feeds", true)


func has_feed() -> bool:
	return CameraServer.get_feed_count() > 0


# Liga a primeira câmera. Devolve { "ok": bool, "message": String }.
func try_start() -> Dictionary:
	stop()

	if "monitoring_feeds" in CameraServer:
		CameraServer.set("monitoring_feeds", true)

	if CameraServer.get_feed_count() == 0:
		return {
			"ok": false,
			"message": "Nenhuma câmera encontrada pelo Godot nesta plataforma. Usando teclado."
		}

	_feed = CameraServer.get_feed(0)

	# Godot 4.4+: escolhe um formato de imagem (prefere ~640 px, leve)
	if _feed.has_method("get_formats") and _feed.has_method("set_format"):
		var formats: Array = _feed.call("get_formats")
		if formats.size() > 0:
			var best := 0
			var best_score := 1.0e9
			for i in range(formats.size()):
				var f = formats[i]
				var fw: float = float(f.get("width", 640)) if f is Dictionary else 640.0
				var score: float = abs(fw - 640.0)
				if score < best_score:
					best_score = score
					best = i
			_feed.call("set_format", best, {})

	_feed.feed_is_active = true

	_camera_texture = CameraTexture.new()
	_camera_texture.camera_feed_id = _feed.get_id()
	_camera_texture.which_feed = CameraServer.FEED_RGBA_IMAGE

	_reset_state()
	active = true

	return { "ok": true, "message": "Câmera conectada: %s  (M = inverter lados)" % _feed.get_name() }


func stop() -> void:
	active = false
	if _feed:
		_feed.feed_is_active = false
	_feed = null
	_camera_texture = null
	_got_first_frame = false


func _reset_state() -> void:
	_got_first_frame = false
	_last_sample_time = 0
	_prev = PackedFloat32Array()
	_hist.clear()
	_t = 0.0
	_cool_until = 0.0
	_last_by_gesture.clear()
	_settling = false
	_still = 0
	_pos = 0.0
	_prev_cx = -1.0
	_head_still = 0
	_pending = ""


func toggle_mirror() -> void:
	mirror = not mirror
	_prev = PackedFloat32Array()   # evita comparar quadro normal com espelhado
	_hist.clear()
	_pos = 0.0


func has_valid_frame() -> bool:
	return _got_first_frame


func get_preview_texture() -> CameraTexture:
	return _camera_texture


# Mesmo contrato do teclado: devolve o gesto detectado há pouco (e
# "consome"), ou "".
func sample() -> String:
	if _pending == "":
		return ""
	if Time.get_ticks_msec() - _pending_time > DETECTION_FRESH_MS:
		_pending = ""
		return ""
	var g := _pending
	_pending = ""
	return g


# ============================================================
# LOOP — analisa a câmera continuamente (não só quando o jogo pede),
# pra nunca comparar um quadro novo com um quadro velho.
# ============================================================

func _process(_delta: float) -> void:

	if not active or _camera_texture == null:
		return

	var now := Time.get_ticks_msec()
	if now - _last_sample_time < SAMPLE_INTERVAL_MS:
		return
	var dt: float = 0.04 if _last_sample_time == 0 else float(now - _last_sample_time) / 1000.0
	_last_sample_time = now

	var img: Image = _camera_texture.get_image()
	if img == null or img.is_empty():
		return

	var g := _analyze(img, min(dt, 0.2))
	if g != "":
		_pending = g
		_pending_time = now
		gesture_seen.emit(g)


func _px(n: float) -> float:
	# limiares em pixels foram calibrados em 64x48
	return n * float(_w * _h) / REF_PIXELS


func _analyze(src: Image, dt: float) -> String:

	var img := src.duplicate() as Image

	if img.is_compressed():
		return ""

	# Reduz em etapas de 2x (cada etapa = média 2x2 de verdade -> tira
	# ruído), depois ajusta pro tamanho final mantendo a proporção.
	while img.get_width() >= TARGET_WIDTH * 2 and img.get_height() >= 8:
		img.resize(img.get_width() / 2, img.get_height() / 2, Image.INTERPOLATE_BILINEAR)

	var tw := TARGET_WIDTH
	var th: int = max(24, int(round(float(TARGET_WIDTH) * float(src.get_height()) / float(max(1, src.get_width())))))
	img.resize(tw, th, Image.INTERPOLATE_BILINEAR)
	img.convert(Image.FORMAT_L8)

	if mirror:
		img.flip_x()

	var data: PackedByteArray = img.get_data()
	var n := tw * th
	if data.size() < n:
		return ""

	var cur := PackedFloat32Array()
	cur.resize(n)
	var sum := 0.0
	for i in range(n):
		var v := float(data[i])
		cur[i] = v
		sum += v
	var mean := sum / float(n)

	_got_first_frame = true

	if _prev.size() != n or _w != tw or _h != th:
		_w = tw
		_h = th
		_prev = cur
		_prev_mean = mean
		_hist.clear()
		return ""

	_t += dt

	# ---------- diferença compensando brilho ----------
	var diff := PackedFloat32Array()
	diff.resize(n)
	for i in range(n):
		diff[i] = abs((cur[i] - mean) - (_prev[i] - _prev_mean))
	_prev = cur
	_prev_mean = mean

	var sorted := diff.duplicate()
	sorted.sort()
	var med: float = sorted[n / 2]
	var thr: float = max(DIFF_T, NOISE_K * med)

	var m0 := PackedByteArray()
	m0.resize(n)
	for i in range(n):
		m0[i] = 1 if diff[i] > thr else 0

	# ---------- features ----------
	var y_top := int(_h * TOP_Y)
	var y_up := int(_h * UPPER_Y)
	var y_band := int(_h * BAND_Y)
	var x_l := int(_w * SIDE_L)
	var x_r := int(_w * SIDE_R)
	var fx0 := int(_w * FACE_X0)
	var fx1 := int(_w * FACE_X1)
	var fy0 := int(_h * FACE_Y0)
	var fy1 := int(_h * FACE_Y1)

	var top_cnt := 0
	var u_cnt := 0
	var u_sumx := 0.0
	var face_cnt := 0
	var ol := 0
	var orr := 0
	var band_cnt := 0
	var band_sumy := 0.0
	var tot := 0
	var col_l := PackedByteArray()
	col_l.resize(_w)
	var col_r := PackedByteArray()
	col_r.resize(_w)

	for y in range(_h):
		var row := y * _w
		for x in range(_w):
			var i := row + x
			if m0[i] == 0:
				continue
			# precisa de pelo menos 1 vizinho mexendo (tira ruído isolado)
			var has_nb := false
			if x > 0 and m0[i - 1] == 1:
				has_nb = true
			elif x < _w - 1 and m0[i + 1] == 1:
				has_nb = true
			elif y > 0 and m0[i - _w] == 1:
				has_nb = true
			elif y < _h - 1 and m0[i + _w] == 1:
				has_nb = true
			if not has_nb:
				continue

			tot += 1
			if y < y_top:
				top_cnt += 1
			if y < y_up:
				u_cnt += 1
				u_sumx += x
			if y >= fy0 and y < fy1 and x >= fx0 and x < fx1:
				face_cnt += 1
			if y >= y_band:
				band_cnt += 1
				band_sumy += y
				if x < x_l:
					ol += 1
					col_l[x] = 1
				elif x >= x_r:
					orr += 1
					col_r[x] = 1

	var olc := 0
	var orc := 0
	for x in range(_w):
		olc += col_l[x]
		orc += col_r[x]

	var fe := {
		"top": float(top_cnt) / float(max(1, y_top * _w)),
		"u": u_cnt,
		"cx": (u_sumx / float(u_cnt)) / float(_w) if u_cnt > 0 else -1.0,
		"face": float(face_cnt) / float(max(1, (fy1 - fy0) * (fx1 - fx0))),
		"ol": ol,
		"orr": orr,
		"olc": olc,
		"orc": orc,
		"cym": (band_sumy / float(band_cnt)) / float(_h) if band_cnt >= int(_px(6)) else -1.0,
		"tot": float(tot) / float(n),
	}

	# ---------- posição da cabeça em relação ao centro ----------
	var head_moving: bool = u_cnt >= _px(MIN_U_PIX) and fe["top"] >= DODGE_TOP_MIN * 0.5
	if head_moving:
		if _prev_cx >= 0.0:
			_pos += clamp(fe["cx"] - _prev_cx, -POS_STEP_MAX, POS_STEP_MAX)
		_prev_cx = fe["cx"]
		_head_still = 0
	else:
		_prev_cx = -1.0
		_head_still += 1
		if _head_still > POS_DECAY_AFTER:
			_pos *= POS_DECAY

	_hist.append(fe)
	while _hist.size() > 10:
		_hist.pop_front()

	# ---------- espera o corpo parar depois de um gesto ----------
	if _settling:
		if fe["tot"] < SETTLE_FRAC and max(ol, orr) < _px(SETTLE_SIDE):
			_still += 1
		else:
			_still = 0
		if _still >= 2 or _t - _settle_since > SETTLE_MAX:
			_settling = false
			_hist = [_hist[_hist.size() - 1]]
		else:
			return ""

	if _t < _cool_until:
		return ""

	var g := _classify()
	if g == "":
		return ""
	if _t - float(_last_by_gesture.get(g, -9.0)) < SAME_BLOCK:
		return ""

	_last_by_gesture[g] = _t
	_cool_until = _t + COOLDOWN
	_settling = true
	_settle_since = _t
	_still = 0
	_hist.clear()
	return g


func _dodge_displacement() -> Array:
	# [deslocamento lateral do centro do movimento, média do topo]
	var start: int = max(0, _hist.size() - DODGE_WIN)
	var win: Array = []
	var top_sum := 0.0
	for i in range(start, _hist.size()):
		var h: Dictionary = _hist[i]
		top_sum += h["top"]
		if h["u"] >= _px(MIN_U_PIX):
			win.append(h)
	if win.size() < 3:
		return [0.0, 0.0]
	var a: float = (win[0]["cx"] + win[1]["cx"]) * 0.5
	var b: float = (win[win.size() - 2]["cx"] + win[win.size() - 1]["cx"]) * 0.5
	return [b - a, top_sum / float(_hist.size() - start)]


func _classify() -> String:

	if _hist.size() < 3:
		return ""

	var dd := _dodge_displacement()
	var dsp: float = dd[0]
	var topm: float = dd[1]

	# 1) ESQUIVA
	if abs(dsp) > DODGE_DISP and topm > DODGE_TOP_MIN:
		var d := 1.0 if dsp > 0.0 else -1.0
		if _pos * d > DODGE_POS:
			return "dodge_right" if d > 0.0 else "dodge_left"
		return ""   # só voltando pro centro

	var n := _hist.size()
	var r3: Array = _hist.slice(n - 3, n)
	var r5: Array = _hist.slice(max(0, n - 5), n)
	var base: Array = _hist.slice(max(0, n - 10), max(0, n - 5))

	var head := 0.0
	for x in r3:
		head = max(head, x["top"])

	# corpo ainda deslocado pro lado (dentro de uma esquiva) -> nada
	if abs(_pos) > DODGE_POS:
		return ""

	# 2) SOCO
	if head < HEAD_GATE:
		for side in [-1, 1]:
			var k := "ol" if side < 0 else "orr"
			var o := "orr" if side < 0 else "ol"
			var kc := "olc" if side < 0 else "orc"
			var peak_ok := false
			for x in r3:
				if x[k] >= _px(PUNCH_PEAK) and x[k] >= PUNCH_RATIO * x[o] + 2 and x[kc] >= PUNCH_COLS:
					peak_ok = true
			var total := 0.0
			for x in r5:
				total += x[k]
			var bs := 0.0
			if base.size() > 0:
				for x in base:
					bs += x[k]
				bs = bs / float(base.size()) * 5.0
			if peak_ok and total >= _px(PUNCH_SUM) and total >= PUNCH_SPIKE * bs:
				return "punch_left" if side < 0 else "punch_right"

	# 3) DEFESA ALTA
	var a5 := 0.0
	var b5 := 0.0
	var fz := 0.0
	var headm := 0.0
	var cy: Array = []
	for x in r5:
		a5 += x["ol"]
		b5 += x["orr"]
		fz += x["face"]
		headm = max(headm, x["top"])
		if x["cym"] >= 0.0:
			cy.append(x["cym"])
	fz /= float(r5.size())
	var both := 0
	for i in range(max(0, r5.size() - 4), r5.size()):
		if r5[i]["ol"] >= _px(GUARD_BOTH) and r5[i]["orr"] >= _px(GUARD_BOTH):
			both += 1
	var rising := false
	if cy.size() >= 3:
		var first: float = (cy[0] + cy[1]) * 0.5
		var last: float = (cy[cy.size() - 2] + cy[cy.size() - 1]) * 0.5
		rising = (first - last) > GUARD_RISE
	var lo: float = min(a5, b5)
	var hi: float = max(a5, b5)
	if lo >= _px(GUARD_PIX) and hi > 0.0 and lo / hi > GUARD_BAL and both >= 3 and fz > GUARD_FRAC and rising and headm < HEAD_GATE:
		return "duck"

	return ""


# ============================================================
# ENTRADA EXTERNA (aditivo) — usada por CameraInputUDP.gd quando o
# modo de controle é "camera_mediapipe" (webcam + MediaPipe rodando
# num processo Python externo) em vez da detecção por diferença de
# quadros feita neste arquivo. Com _camera_texture nulo, o _process()
# acima já retorna sem fazer nada, então isso não interfere em nada da
# detecção interna.
# ============================================================

func activate_external_source() -> void:
	active = true
	_got_first_frame = true


func report_external_gesture(gesture: String) -> void:
	_pending = gesture
	_pending_time = Time.get_ticks_msec()
	gesture_seen.emit(gesture)
