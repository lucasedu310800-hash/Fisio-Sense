# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name ImpactRing
# Anel de choque que se expande (usado no impacto do "67" da animação
# secreta). Anime `progress` de 0 a 1 com um Tween.

var progress: float = 0.0:
	set(v):
		progress = v
		queue_redraw()

var ring_color: Color = Color(1.0, 0.85, 0.3)
var max_radius: float = 700.0


func _draw() -> void:

	if progress <= 0.0 or progress >= 1.0:
		return

	var c: Vector2 = size / 2.0
	var r: float = max_radius * progress
	var a: float = 1.0 - progress

	draw_arc(c, r, 0.0, TAU, 96, Color(ring_color.r, ring_color.g, ring_color.b, a), 18.0 * a + 2.0, true)
	draw_arc(c, r * 0.82, 0.0, TAU, 96, Color(1, 1, 1, a * 0.6), 5.0, true)
