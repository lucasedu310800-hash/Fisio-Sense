# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Ponte entre o processo Python externo (movimentos.py +
# tools/ponte_jogo.py, detecção via MediaPipe) e o CameraInput.gd deste
# jogo. Só é usada quando o modo de controle "🎥 Câmera (Python)"
# (control_mode == "camera_mediapipe") é escolhido no menu — nos outros
# modos (teclado, câmera nativa do Godot) fica parada e não abre porta
# nenhuma.
#
# ponte_jogo.py manda o rótulo cru do detector por UDP, texto puro:
#   "SOCO ESQUERDO", "SOCO DIREITO", "DEFESA ALTA",
#   "ESQUIVA ESQUERDA", "ESQUIVA DIREITA", "AGACHAR", "NEUTRO"
# Aqui a gente traduz pro vocabulário que o jogo já usa (mesmo do
# teclado e do CameraInput.gd) e repassa pro
# CameraInput.report_external_gesture() — dali em diante o jogo trata
# igual a qualquer outra fonte de entrada.

# Gesto da "balança" (minijogo secreto 67): a ponte manda "BALANCA ESQ" (mão
# esquerda em cima), "BALANCA DIR" (direita em cima) ou "BALANCA NEUTRO", na
# mudança e a cada ~0,8 s (batida de vida). Não afeta o jogo normal.
signal balanca_changed(estado: String)

const PORTA := 5555

# Câmera DENTRO do jogo: o detector manda cada quadro (JPEG pequeno, ~15/s) por UDP
# nesta porta e o HUD mostra a imagem no canto superior esquerdo.
const VIDEO_PORTA := 5556

const TRADUCAO := {
	"SOCO ESQUERDO": "punch_left",
	"SOCO DIREITO": "punch_right",
	"DEFESA ALTA": "duck",
	"ESQUIVA ESQUERDA": "dodge_left",
	"ESQUIVA DIREITA": "dodge_right",
	# Agachar reativado: conta como "duck" (mesma resposta da defesa
	# alta, que continua funcionando do jeito que já funcionava).
	"AGACHAR": "duck",
	# "NEUTRO" chega mas não tem correspondente — o jogo só espera
	# EVENTOS (gesto aconteceu), não um estado contínuo, então é
	# ignorado de propósito.
}

var _udp := PacketPeerUDP.new()
var _video_udp := PacketPeerUDP.new()
var _video_ligado: bool = false
var ligado: bool = false

# último quadro da webcam recebido (ImageTexture reaproveitada: só atualiza os pixels)
var video_texture: ImageTexture
var last_video_msec: int = 0

# Último rótulo CRU recebido do detector (ex.: "DEFESA ALTA" ou "AGACHAR").
# Os dois viram "duck" pro jogo, mas o boneco do jogador precisa saber qual
# dos dois foi pra fazer a animação certa (guarda alta x agachar).
var last_label: String = ""

var balanca_state: String = "neutro"
var last_balanca_msec: int = 0
var last_packet_msec: int = 0 # qualquer pacote (movimento ou batida de vida) — mostra se a câmera está viva


func iniciar() -> Dictionary:
	if ligado:
		return {"ok": true, "message": "Detector Python já conectado."}

	var erro := _udp.bind(PORTA, "127.0.0.1")
	if erro != OK:
		return {
			"ok": false,
			"message": "Não consegui abrir a porta %d (erro %d). Feche outro programa usando essa porta e tente de novo." % [PORTA, erro],
		}

	ligado = true

	if not _video_ligado:
		_video_ligado = _video_udp.bind(VIDEO_PORTA, "127.0.0.1") == OK

	return {
		"ok": true,
		"message": "Aguardando o detector Python (rode movimentos.py + tools\\ponte_jogo.py).",
	}


func parar() -> void:
	if ligado:
		_udp.close()

	if _video_ligado:
		_video_udp.close()
		_video_ligado = false

	video_texture = null
	last_video_msec = 0
	ligado = false


func _process(_delta: float) -> void:
	if not ligado:
		return

	_poll_video()

	while _udp.get_available_packet_count() > 0:
		var bytes: PackedByteArray = _udp.get_packet()
		var rotulo := bytes.get_string_from_utf8().strip_edges()
		last_packet_msec = Time.get_ticks_msec()

		if rotulo.begins_with("BALANCA "):
			var estado: String = rotulo.substr(8).to_lower()
			last_balanca_msec = Time.get_ticks_msec()

			if estado != balanca_state:
				balanca_state = estado
				balanca_changed.emit(estado)

			continue

		if TRADUCAO.has(rotulo):
			last_label = rotulo
			CameraInput.report_external_gesture(TRADUCAO[rotulo])


# Pega o quadro de vídeo mais recente (descarta os atrasados) e atualiza a textura.
func _poll_video() -> void:
	if not _video_ligado:
		return

	var latest: PackedByteArray = PackedByteArray()

	while _video_udp.get_available_packet_count() > 0:
		latest = _video_udp.get_packet()

	if latest.is_empty():
		return

	var img := Image.new()

	if img.load_jpg_from_buffer(latest) != OK:
		return

	if video_texture == null or video_texture.get_size() != Vector2(img.get_size()):
		video_texture = ImageTexture.create_from_image(img)
	else:
		video_texture.update(img)

	last_video_msec = Time.get_ticks_msec()
