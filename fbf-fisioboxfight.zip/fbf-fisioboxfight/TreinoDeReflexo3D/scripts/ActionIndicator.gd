# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name ActionIndicator
# Indicador de ação do HUD (V-FBF): círculo GRANDE e translúcido com o
# desenho do movimento dentro e um rótulo embaixo. Tudo por código.
#
# Estados (set_state):
#   "idle" — apagado (fica visível, só mais fraco).
#   "prep" — PISCA devagar: o treinador está se preparando, é ESTA a
#            ação que vai ser pedida.
#   "now"  — PISCA rápido, cresce e anel dourado: FAÇA AGORA.
#   "ok"   — verde com ✓: reconhecido e correto.
#   "miss" — vermelho: tempo esgotado / errado.
#
# flash(cor) dá um brilho rápido por cima de qualquer estado — mostra
# que a câmera (ou tecla) reconheceu ESTE movimento.
#
# Cor: `ring_color` (vermelho = esquerda, azul = direita, ciano = agachar).

const CIRCLE := 150.0
const BLINK_PREP_HZ := 3.0
const BLINK_NOW_HZ := 6.5

var action: String = "punch_left"
var caption: String = ""
var ring_color: Color = Color(0.95, 0.28, 0.28)

var _state: String = "idle"
var _t: float = 0.0
var _flash: float = 0.0
var _flash_color: Color = Color(1, 1, 1)
var _token: int = 0
var _icon: SignIcon
var _label: Label


func _ready() -> void:

	custom_minimum_size = Vector2(CIRCLE + 40.0, CIRCLE + 38.0)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	_icon = SignIcon.new()
	_icon.sign_type = action
	_icon.tint = ring_color
	_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_icon)

	_label = Label.new()
	_label.text = caption
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 20)
	_label.add_theme_color_override("font_color", Color(1.0, 0.97, 0.90))
	_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	_label.add_theme_constant_override("outline_size", 7)
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_label)

	resized.connect(_layout)
	_layout()
	_apply_icon_alpha()


func _layout() -> void:

	if _icon == null or _label == null:
		return

	var icon_size: float = CIRCLE * 0.80

	_icon.size = Vector2(icon_size, icon_size)
	_icon.position = Vector2(
		size.x / 2.0 - icon_size / 2.0,
		2.0 + CIRCLE / 2.0 - icon_size / 2.0
	)

	_label.position = Vector2(0.0, CIRCLE + 6.0)
	_label.size = Vector2(size.x, 30.0)

	# o "pulo" de escala cresce a partir do centro
	pivot_offset = size / 2.0


func set_state(new_state: String, revert_after: float = 0.0) -> void:

	_token += 1
	_state = new_state
	_apply_icon_alpha()
	queue_redraw()

	if revert_after > 0.0 and is_inside_tree():

		var my_token: int = _token

		get_tree().create_timer(revert_after).timeout.connect(
			func():
				if my_token == _token:
					set_state("idle")
		)


func flash(color: Color) -> void:

	_flash = 1.0
	_flash_color = color
	queue_redraw()


func _apply_icon_alpha() -> void:

	if _icon == null:
		return

	# no "ok" o desenho some pra dar lugar ao ✓ grande
	_icon.modulate.a = 0.15 if _state == "ok" else 1.0


func _process(delta: float) -> void:

	_t += delta

	if _flash > 0.0:
		_flash = max(0.0, _flash - delta * 2.4)

	# ---- PISCAR (transparência do indicador inteiro) + pulo de escala ----
	var a: float = 0.55
	var k: float = 1.0

	match _state:
		"prep":
			var w: float = 0.5 + 0.5 * sin(_t * TAU * BLINK_PREP_HZ)
			a = 0.30 + 0.70 * w
		"now":
			var w2: float = 0.5 + 0.5 * sin(_t * TAU * BLINK_NOW_HZ)
			a = 0.45 + 0.55 * w2
			k = 1.0 + 0.10 * w2
		"ok", "miss":
			a = 1.0
			k = 1.08

	modulate.a = a
	scale = Vector2(k, k)

	if _state != "idle" or _flash > 0.0:
		queue_redraw()


func _draw() -> void:

	var c := Vector2(size.x / 2.0, 2.0 + CIRCLE / 2.0)
	var r: float = CIRCLE / 2.0

	# fundo escuro translúcido (o desenho colorido precisa de contraste)
	var fill := Color(0.03, 0.03, 0.06, 0.55)
	var ring := Color(ring_color.r, ring_color.g, ring_color.b, 0.75)
	var width: float = 5.0

	match _state:
		"prep":
			ring = Color(ring_color.r, ring_color.g, ring_color.b, 1.0)
			width = 7.0
		"now":
			ring = Color(1.0, 0.92, 0.45, 1.0)
			fill = Color(0.10, 0.08, 0.02, 0.70)
			width = 10.0
		"ok":
			ring = Color(0.35, 0.92, 0.5, 1.0)
			fill = Color(0.10, 0.35, 0.16, 0.75)
			width = 10.0
		"miss":
			ring = Color(0.95, 0.28, 0.28, 1.0)
			fill = Color(0.40, 0.08, 0.08, 0.75)
			width = 10.0

	draw_circle(c, r, fill)

	# halo colorido por fora quando ativo
	if _state == "prep" or _state == "now":
		var halo: Color = ring
		draw_arc(c, r + 5.0, 0.0, TAU, 64, Color(halo.r, halo.g, halo.b, 0.35), 6.0, true)

	draw_arc(c, r - width / 2.0, 0.0, TAU, 64, ring, width, true)

	if _flash > 0.0:
		draw_circle(
			c,
			r,
			Color(_flash_color.r, _flash_color.g, _flash_color.b, 0.55 * _flash)
		)

	if _state == "ok":
		draw_polyline(
			PackedVector2Array([
				c + Vector2(-r * 0.42, r * 0.02),
				c + Vector2(-r * 0.10, r * 0.36),
				c + Vector2(r * 0.46, -r * 0.34),
			]),
			Color(1, 1, 1, 0.97),
			13.0,
			true
		)
