# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Toca sons a partir de res://assets/sounds/<nome>.ogg (ou .wav).
# Se o arquivo ainda não existir, simplesmente não toca nada — o jogo
# funciona normalmente sem áudio. Basta adicionar os arquivos depois.

var _players: Dictionary = {}

func play(name: String) -> void:
	var stream: AudioStream = _load_stream(name)
	if stream == null:
		return

	var player: AudioStreamPlayer
	if _players.has(name):
		player = _players[name]
	else:
		player = AudioStreamPlayer.new()
		add_child(player)
		_players[name] = player

	player.stream = stream
	player.play()

func _load_stream(name: String) -> AudioStream:
	for ext in ["ogg", "wav", "mp3"]:
		var path := "res://assets/sounds/%s.%s" % [name, ext]
		if ResourceLoader.exists(path):
			return load(path)
	return null
