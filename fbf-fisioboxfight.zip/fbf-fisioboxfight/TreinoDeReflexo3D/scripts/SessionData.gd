# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Resource
class_name SessionData
# Estrutura de dados de UMA sessão de treino, pensada para uso futuro
# em fisioterapia (histórico do paciente, comparação entre sessões,
# gráficos de evolução, relatórios). Este arquivo NÃO faz nenhum tipo
# de diagnóstico médico — apenas registra o desempenho do usuário
# durante o exercício, para ser lido/analisado depois por quem
# acompanha o paciente.
#
# Como estender no futuro (sugestões, sem tocar no resto do jogo):
#   - Guardar uma lista de SessionData (ex.: um Array salvo com
#     ResourceSaver.save() em res://user_data/sessions/, um arquivo
#     por sessão, com data/hora no nome) para formar o histórico.
#   - Comparar summary_dict() de duas sessões para calcular evolução
#     (ex.: precisão subiu/desceu, tempo médio de reação melhorou).
#   - Alimentar um gráfico (linha do tempo de "score" ou "precisão"
#     por sessão) lendo o histórico salvo.

@export var timestamp_unix: int = 0
@export var duration_sec: float = 0.0
@export var score: int = 0
@export var hits: int = 0
@export var misses: int = 0
@export var precision: float = 0.0
@export var avg_reaction_ms: float = 0.0
@export var best_reaction_ms: float = 0.0
@export var dodges_correct: int = 0
@export var dodges_wrong: int = 0
@export var punches_correct: int = 0
@export var punches_wrong: int = 0
@export var best_combo: int = 0
@export var max_phase: int = 1

static func from_summary(summary: Dictionary) -> SessionData:
	var s := SessionData.new()
	s.timestamp_unix = Time.get_unix_time_from_system()
	s.duration_sec = summary.get("duration_sec", 0.0)
	s.score = summary.get("score", 0)
	s.hits = summary.get("hits", 0)
	s.misses = summary.get("misses", 0)
	s.precision = summary.get("precision", 0.0)
	s.avg_reaction_ms = summary.get("avg_reaction_ms", 0.0)
	s.best_reaction_ms = summary.get("best_reaction_ms", 0.0)
	s.dodges_correct = summary.get("dodges_correct", 0)
	s.dodges_wrong = summary.get("dodges_wrong", 0)
	s.punches_correct = summary.get("punches_correct", 0)
	s.punches_wrong = summary.get("punches_wrong", 0)
	s.best_combo = summary.get("best_combo", 0)
	s.max_phase = summary.get("max_phase", 1)
	return s

func summary_dict() -> Dictionary:
	return {
		"timestamp_unix": timestamp_unix,
		"duration_sec": duration_sec,
		"score": score,
		"hits": hits,
		"misses": misses,
		"precision": precision,
		"avg_reaction_ms": avg_reaction_ms,
		"best_reaction_ms": best_reaction_ms,
		"dodges_correct": dodges_correct,
		"dodges_wrong": dodges_wrong,
		"punches_correct": punches_correct,
		"punches_wrong": punches_wrong,
		"best_combo": best_combo,
		"max_phase": max_phase,
	}
