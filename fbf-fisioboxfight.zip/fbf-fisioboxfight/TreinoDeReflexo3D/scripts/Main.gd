# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node

# ============================================================
# TREINO DE REFLEXO — BOXE 3D
# ============================================================

enum State { MENU, PLAYING, PAUSED, GAMEOVER }

const COLOR_GOLD := Color(0.96, 0.72, 0.26)
const COLOR_GREEN := Color(0.35, 0.92, 0.5)
const COLOR_RED := Color(0.95, 0.28, 0.28)
const COLOR_CYAN := Color(0.55, 0.88, 0.98)

# Braços do paciente (primeira pessoa) e treinador são feitos 100% por
# código (ver scripts/PlayerArms3D.gd e scripts/BoxerRig3D.gd) — sem
# arquivos 3D externos.

# Resultado da luta: no fim da sessão (2:00), com precisão igual ou acima
# deste valor você NOCAUTEIA o treinador; abaixo, você é NOCAUTEADO.
# (A sessão tem sempre a mesma duração — bom pros dados da
# fisioterapia — o nocaute é o "final" da luta.)
const WIN_PRECISION := 60.0

# Cores das luvas/indicadores (desenho "visão do jogo": esquerda =
# vermelha, direita = azul). Trocou de lado? É só inverter aqui e em
# PlayerAvatar.gd (LEFT_GLOVE_COLOR / RIGHT_GLOVE_COLOR).
const HAND_LEFT_COLOR := Color(0.95, 0.28, 0.28)
const HAND_RIGHT_COLOR := Color(0.25, 0.50, 1.0)

const RESPONSE_LABELS := {
	"dodge_left": "Esquive para a ESQUERDA",
	"dodge_right": "Esquive para a DIREITA",
	"duck": "DEFESA ALTA (ou agache)",
	"punch_left": "Soque com a ESQUERDA",
	"punch_right": "Soque com a DIREITA",
}


# ============================================================
# ESTADO
# ============================================================

var state: int = State.MENU

var session_elapsed: float = 0.0
var current_sequence: Array = []

# ============================================================
# AUTO-LANCAMENTO DA CAMERA (modo "Camera Python")
# ============================================================
# PIDs dos dois processos auxiliares que o modo "Camera (Python)"
# precisa (o detector de gestos e a ponte que manda pro jogo por
# UDP). Ficam -1 enquanto nao foram lancados nesta sessao do jogo.
var _pid_detector: int = -1
var _pid_ponte: int = -1

# botão "ABRIR CÂMERA" (abre/fecha o detector Python sozinho) e chip do HUD
var camera_autostart: bool = true
var _camera_launch_msec: int = 0
var _camera_autostart_ready: bool = false
var btn_camera_open: Button
var btn_camera_auto: Button
var camera_status_label: Label
var hud_camera_chip: Button
var _camera_state_shown: String = ""
var _camera_error: String = ""

# câmera dentro do jogo (no lugar do bonequinho do canto superior esquerdo)
var camera_in_game: bool = true
var camera_window_visible: bool = false
var camera_view: TextureRect
var camera_view_size: int = 1 # 0 = pequena (208×117), 1 = média (256×144)
var btn_camera_size: Button
var _camera_dir_used: String = ""
var _camera_script_old: bool = false
var _camera_ok_since_msec: int = 0
var camera_view_live: Label
var portrait_who: Control
var btn_camera_ingame: Button
var btn_camera_window: Button
var _seq_index: int = 0
var current_challenge: Dictionary = {}
var challenge_started_at: float = 0.0
var _challenge_subphase: String = ""
var _last_phase_shown: int = 0

var last_session: SessionData = null


# ============================================================
# MUNDO 3D
# ============================================================

var world_root: Node3D
var camera: Camera3D
var base_camera_pos: Vector3 = Vector3.ZERO
var base_camera_rot: Vector3 = Vector3.ZERO

var trainer_actor: BoxerRig3D

# Braços do próprio paciente, em primeira pessoa (procedurais).
var player_arms: PlayerArms3D

var _camera_pose_tween: Tween

# Controle da sequência de nocaute do fim da luta.
var _ko_id: int = 0
var results_title_label: Label

var hit_particles: GPUParticles3D
var hit_particles_mat: ParticleProcessMaterial

var flash_rect: ColorRect
var feedback_label: Label

var prompt_icon: SignIcon
var prompt_panel_ref: PanelContainer

# MENU (V-FBF): páginas do menu lateral, configurações e cena 3D do menu.
const CONFIG_PATH := "user://fbf_config.cfg"

# SEGREDO (easter egg): minijogo "67". Não aparece no menu. A palavra secreta é
# "pesca" e só funciona em RESGATAR CÓDIGO (aceita maiúsculas/minúsculas). Depois
# de desbloqueado, a mesma palavra entra direto no minijogo.
const SECRET_CODE := "pesca"
const ACHIEVEMENTS := {
	"escolhido67": {
		"name": "O escolhido do 67",
		"desc": "Chegou ao 67 no minijogo secreto.",
	},
}

# CENÁRIOS (V-FBF): a academia original + 5 arenas novas (scripts/scenarios/)
const SCENARIO_ORDER := ["random", "gym", "city", "dojo", "arena", "beach", "factory", "laje", "arraia", "farofa", "varzea", "buraco", "saopaulo"]
const SCENARIOS := {
	"random": {
		"name": "ALEATÓRIO",
		"desc": "Sorteia uma arena diferente a cada partida. Surpresa!",
	},
	"gym": {
		"name": "ACADEMIA",
		"desc": "O ringue clássico de treino: tijolos, LEDs vermelho e azul e equipamentos.",
	},
	"city": {
		"name": "CIDADE À NOITE",
		"desc": "Rua molhada, neon, prédios altos, carros e uma torcida na calçada.",
	},
	"dojo": {
		"name": "DOJÔ JAPONÊS",
		"desc": "Salão de madeira, lanternas, cerejeiras, torii e montanhas ao entardecer.",
	},
	"arena": {
		"name": "ARENA DE CAMPEONATO",
		"desc": "Arquibancadas lotadas, holofotes, telões com o placar e luzes de estádio.",
	},
	"beach": {
		"name": "PRAIA TROPICAL",
		"desc": "Pôr do sol, mar com ondas, palmeiras, cabana e rochas. Clima descontraído.",
	},
	"factory": {
		"name": "FÁBRICA ABANDONADA",
		"desc": "Aço, tubulações, máquinas, giroflex vermelho, poeira e faíscas. Intenso.",
	},
	"laje": {
		"name": "LAJE DO CHURRASCO",
		"desc": "Churrasco, paredão, piscina de plástico com flamingo e obra eterna.",
		"secret": true,
	},
	"arraia": {
		"name": "ARRAIÁ DO CAOS",
		"desc": "Fogueira, bandeirinhas, quadrilha, balões e a cadeia de R$5.",
		"secret": true,
	},
	"farofa": {
		"name": "PRAIA DA FAROFA",
		"desc": "Praia lotada, futevôlei, queijo coalho e 40 graus na sombra.",
		"secret": true,
	},
	"varzea": {
		"name": "ESTÁDIO DE VÁRZEA",
		"desc": "Trave torta, rede furada, torcida no alambrado e uma vaca no campo.",
		"secret": true,
	},
	"buraco": {
		"name": "BR DO BURACO",
		"desc": "Rodovia esburacada, caminhão de melancia e a placa \"ponte caiu\".",
		"secret": true,
	},
	"saopaulo": {
		"name": "SÃO PAULO: CIDADE DO CAOS",
		"desc": "Ponte Estaiada, Rio Tietê, trânsito, motoboys e o caramelo. Treinador de Seleção!",
		"secret": true,
	},
}

# Códigos de resgate (o texto é normalizado: minúsculas, sem espaços/hífens).
# "lipe 67", "LIPE-67" e "lipe67" valem o mesmo código.
const REDEEM_CODES := {
	"lipe67": ["saopaulo", "laje", "arraia", "farofa", "varzea", "buraco"],
}
const LOGO_PATH := "res://assets/textures/logo_fbf.png"
const HISTORY_PATH := "user://fbf_history.json"
const REPORT_DIR := "user://reports"
const MOVE_ORDER := ["punch_left", "punch_right", "dodge_left", "dodge_right", "duck"]
const MOVE_NAMES := {
	"punch_left": "Soco esquerdo",
	"punch_right": "Soco direito",
	"dodge_left": "Defesa esquerda",
	"dodge_right": "Defesa direita",
	"duck": "Defesa alta / agachar",
}
const CREDIT_LINE_1 := "by FisioSense"
const CREDIT_LINE_2 := "From Next-FIAP"
const DIFFICULTY_NAMES := {"facil": "FÁCIL", "normal": "NORMAL", "dificil": "DIFÍCIL"}
const DIFFICULTY_HINTS := {
	"facil": "Mais tempo para reagir. Bom para começar.",
	"normal": "O ritmo padrão do treino.",
	"dificil": "Golpes rápidos e seguidos.",
}
const MODE_NAMES := {"keyboard": "TECLADO", "camera": "CÂMERA", "camera_mediapipe": "CÂMERA (PYTHON)"}
# câmera do menu: perto do treinador, olhando um pouco pra esquerda dele
# (assim ele aparece do lado direito da tela e o menu fica à esquerda)
const MENU_CAM_POS := Vector3(0.0, 1.52, -0.75)
const MENU_CAM_LOOK := Vector3(-0.65, 1.42, -2.2)

# relatório do treino (V-FBF)
var last_report_data: Dictionary = {}
var last_report_recs: Array = []
var results_sub_label: Label
var results_recs_label: RichTextLabel
var chart_grade: ReportCharts
var chart_moves: ReportCharts
var chart_timeline: ReportCharts
var chart_balance: ReportCharts
var results_confetti: CPUParticles2D
var results_charts_flow: HFlowContainer
var _combo_clean: bool = true
var combo_label: Label
var _combo_tween: Tween
var _rep: Dictionary = {}
var report_text_label: RichTextLabel
var report_path_label: Label
var report_plain: String = ""

# cenários
var scenario_key: String = "gym"
var menu_scenario: String = "gym"
var scenario_node: ScenarioBase
var gym_root: Node3D
var world_env_node: WorldEnvironment
var gym_env: Environment
var btn_menu_scenario: Button
var scenario_card_buttons: Dictionary = {}
var scenario_card_ui: Dictionary = {}
var unlocked: Dictionary = {}
var redeem_input: LineEdit
var redeem_msg: Label
var banner_label: Label
var _banner_tween: Tween

# gráficos / desempenho
const QUALITY_NAMES := {"baixa": "BAIXA", "media": "MÉDIA", "alta": "ALTA"}
const QUALITY_HINTS := {
	"baixa": "Mais leve: sem sombras nem brilho, resolução 3D reduzida. Use se estiver travando.",
	"media": "Equilibrado (recomendado): sem SSAO/reflexos, sombras só do sol, resolução 90%.",
	"alta": "Tudo ligado (SSAO, reflexos, sombras). Pede uma placa de vídeo boa.",
}
var quality: String = "media"
var quality_buttons: Dictionary = {}
var quality_hint_label: Label
var fps_label: Label

# segredo 67
var unlocked67: bool = false
var best67_score: int = 0
var achievements: Dictionary = {}
var minigame67: Minigame67
var sfx: SynthSfx
var achievement_toast: PanelContainer
var achievement_toast_title: Label
var achievement_toast_desc: Label
var achievements_list: VBoxContainer
var _secret_busy: bool = false
var _mg_started_udp: bool = false

# navegação (botão "voltar pra página anterior")
const NAV_SCREENS := ["menu", "howto", "scenarios", "report", "results", "minigame67"]
var current_screen: String = ""
var _screen_history: Array = []
var _menu_current_page: String = "main"
var _menu_page_stack: Array = []
var global_back_btn: Button

var splash_box: Control
var _splash_active: bool = false
var _splash_tween: Tween

var menu_pages: Dictionary = {}
var menu_difficulty: String = "normal"
var menu_volume: float = 1.0
var btn_menu_control: Button
var diff_buttons: Dictionary = {}
var diff_hint_label: Label
var vol_slider: HSlider
var vol_label: Label
var _menu_scene_active: bool = false
var _menu_camera_tween: Tween

# HUD (V-FBF): boneco do jogador + indicadores laterais de ação.
# indicators: resposta ("punch_left", "dodge_right", "duck"...) -> ActionIndicator
var avatar: PlayerAvatar
var indicators: Dictionary = {}


# ============================================================
# UI
# ============================================================

var ui_layer: CanvasLayer
var screens: Dictionary = {}

var hud_time: Label
var hud_score: Label
var hud_combo: Label
var hud_precision: Label

var phase_toast_label: Label
var results_labels: Dictionary = {}


# ============================================================
# TIMERS
# ============================================================

var spawn_timer: Timer
var gap_timer: Timer


# ============================================================
# CONTROLE
# ============================================================

var control_mode: String = "keyboard"

var btn_mode_keyboard: Button
var btn_mode_camera: Button
var btn_mode_camera_mediapipe: Button

var camera_preview_rect: TextureRect
var camera_guide: CameraGuide
var status_label: Label
var status_timer: Timer

var _camera_started_at: int = 0
var _camera_watchdog_done: bool = false


# ============================================================
# READY
# ============================================================

func _ready() -> void:

	randomize()

	process_mode = Node.PROCESS_MODE_ALWAYS

	# efeitos sonoros sintetizados (minijogo secreto e animação de desbloqueio)
	sfx = SynthSfx.new()
	add_child(sfx)

	_build_ui()
	_build_world()
	_apply_scenario(menu_scenario)
	_apply_quality()
	call_deferred("_camera_autostart_check")


	spawn_timer = Timer.new()
	spawn_timer.one_shot = true
	spawn_timer.timeout.connect(_on_spawn_timeout)
	add_child(spawn_timer)


	gap_timer = Timer.new()
	gap_timer.one_shot = true
	gap_timer.timeout.connect(_on_gap_timeout)
	add_child(gap_timer)


	status_timer = Timer.new()
	status_timer.one_shot = true
	status_timer.wait_time = 3.5
	status_timer.timeout.connect(
		func():
			status_label.visible = false
	)

	add_child(status_timer)


	GameManager.hud_changed.connect(_on_hud_changed)

	_start_splash()


# ============================================================
# MUNDO 3D
# ============================================================

# ============================================================
# CENÁRIOS (V-FBF)
# ============================================================

func _group_gym_nodes() -> void:

	gym_root = Node3D.new()
	gym_root.name = "GymRoot"
	world_root.add_child(gym_root)

	for c in world_root.get_children():

		if c == gym_root or c == world_env_node or c == camera or c == trainer_actor or c == hit_particles:
			continue

		c.reparent(gym_root)


func _create_scenario(key: String) -> ScenarioBase:

	match key:
		"city":
			return ScenarioCity.new()
		"dojo":
			return ScenarioDojo.new()
		"arena":
			return ScenarioArena.new()
		"beach":
			return ScenarioBeach.new()
		"factory":
			return ScenarioFactory.new()
		"saopaulo":
			return ScenarioSaoPaulo.new()
		"laje":
			return ScenarioLaje.new()
		"arraia":
			return ScenarioArraia.new()
		"farofa":
			return ScenarioFarofa.new()
		"varzea":
			return ScenarioVarzea.new()
		"buraco":
			return ScenarioBuraco.new()

	return null


# Troca a arena ao vivo. O treinador e a câmera do jogo não são tocados:
# só muda o que está ao redor (e o ambiente: céu, névoa, brilho).
func _apply_scenario(key: String) -> void:

	if world_root == null:
		return

	# ALEATÓRIO: sorteia uma arena liberada (diferente da atual, se der)
	if key == "random":
		key = _pick_random_scenario()

	if not SCENARIOS.has(key) or not _is_unlocked(key):
		key = "gym"

	scenario_key = key

	# fantasia do treinador: camisa da Seleção só na arena São Paulo
	if trainer_actor:
		trainer_actor.set_costume("brasil" if key == "saopaulo" else "")

	if scenario_node:
		scenario_node.queue_free()
		scenario_node = null

	if gym_root:
		gym_root.visible = (key == "gym")

	if key == "gym":

		if world_env_node and gym_env:
			world_env_node.environment = gym_env
			_tune_environment(gym_env)

	else:

		var sc := _create_scenario(key)

		if sc:
			world_root.add_child(sc)
			scenario_node = sc

			if world_env_node:
				world_env_node.environment = sc.make_environment()
				_tune_environment(world_env_node.environment)

			_tune_scene(sc)

	if btn_menu_scenario:
		btn_menu_scenario.text = "CENÁRIO: %s" % SCENARIOS[menu_scenario]["name"] if menu_scenario == "random" else "CENÁRIO: %s" % SCENARIOS[key]["name"]

	_refresh_scenario_cards()


func _pick_random_scenario() -> String:

	var pool: Array = []

	for k in SCENARIO_ORDER:
		if k != "random" and k != scenario_key and _is_unlocked(k):
			pool.append(k)

	if pool.is_empty():
		return "gym"

	return pool[randi() % pool.size()]


func _is_unlocked(key: String) -> bool:

	if not SCENARIOS.has(key):
		return false

	if not SCENARIOS[key].get("secret", false):
		return true

	return bool(unlocked.get(key, false))


func _refresh_scenario_cards() -> void:

	for key in scenario_card_ui.keys():

		var ui: Dictionary = scenario_card_ui[key]
		var open: bool = _is_unlocked(key)

		var name_label: Label = ui["name"]
		var desc_label: Label = ui["desc"]
		var preview: ScenarioPreview = ui["preview"]
		var button: Button = ui["button"]

		name_label.text = str(SCENARIOS[key]["name"]) if open else "??? BLOQUEADO"

		if open:
			desc_label.text = str(SCENARIOS[key]["desc"])
		else:
			desc_label.text = "Cenário secreto! Digite um código em RESGATAR CÓDIGO, no menu."

		preview.kind = key if open else "locked"
		preview.queue_redraw()

		button.disabled = not open

		if not open:
			button.text = "BLOQUEADO"
			button.modulate = Color(0.6, 0.6, 0.6)
		elif key == menu_scenario:
			button.text = "✔ SELECIONADO"
			button.modulate = Color(1, 1, 1)
		else:
			button.text = "SELECIONAR"
			button.modulate = Color(0.85, 0.85, 0.85)


func _normalize_code(raw: String) -> String:

	var n: String = raw.strip_edges().to_lower()

	for ch in [" ", "-", "_", ".", "\t"]:
		n = n.replace(ch, "")

	return n


# Resgatar código: desbloqueia (e já seleciona) o cenário do código.
func _redeem_code(raw: String) -> void:

	if redeem_msg == null:
		return

	var n: String = _normalize_code(raw)

	# a palavra do segredo também funciona aqui
	if n == SECRET_CODE:
		redeem_msg.text = "Hmm... esse código é diferente de todos os outros."
		redeem_msg.add_theme_color_override("font_color", Color(0.85, 0.7, 1.0))

		if redeem_input:
			redeem_input.text = ""

		_secret_from_word()
		return

	if n == "":
		redeem_msg.text = "Digite um código."
		redeem_msg.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5))
		return

	if REDEEM_CODES.has(n):

		var keys: Array = REDEEM_CODES[n]
		var fresh: int = 0
		var names: PackedStringArray = PackedStringArray()

		for k in keys:

			if not bool(unlocked.get(k, false)):
				fresh += 1

			unlocked[k] = true
			names.append(str(SCENARIOS[k]["name"]))

		if fresh == 0:
			redeem_msg.text = "Você já resgatou este código! Todas as arenas secretas já estão liberadas."
		else:
			redeem_msg.text = "CÓDIGO ACEITO! %d arenas desbloqueadas: %s. Em São Paulo o treinador joga de camisa da Seleção!" % [fresh, ", ".join(names)]

		_save_settings()
		_select_scenario(str(keys[0]))

		redeem_msg.add_theme_color_override("font_color", Color(0.35, 0.95, 0.5))

		redeem_msg.pivot_offset = redeem_msg.size / 2.0
		redeem_msg.scale = Vector2(0.85, 0.85)

		var tw := create_tween()
		tw.tween_property(redeem_msg, "scale", Vector2(1, 1), 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

		if redeem_input:
			redeem_input.text = ""

	else:

		redeem_msg.text = "Código inválido. Confira e tente de novo."
		redeem_msg.add_theme_color_override("font_color", Color(1.0, 0.4, 0.4))


# ------------------------------------------------------------
# DESEMPENHO: qualidade gráfica (Baixa / Média / Alta)
# ------------------------------------------------------------
# Reduz o custo de renderização sem mexer no jogo: resolução 3D, SSAO, reflexos
# (SSR), brilho (glow), sombras (luzes e peças pequenas). Os valores originais
# ficam guardados em metadados, então dá pra voltar pra ALTA a qualquer hora.

func _apply_quality() -> void:

	var vp: Viewport = get_viewport()

	match quality:
		"alta":
			vp.scaling_3d_scale = 1.0
		"media":
			vp.scaling_3d_scale = 0.9
		_:
			vp.scaling_3d_scale = 0.7

	vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR

	if world_env_node and world_env_node.environment:
		_tune_environment(world_env_node.environment)

	if gym_root:
		_tune_scene(gym_root)

	if scenario_node:
		_tune_scene(scenario_node)


func _tune_environment(env: Environment) -> void:

	if not env.has_meta("_q_orig"):
		env.set_meta("_q_orig", {"ssao": env.ssao_enabled, "ssr": env.ssr_enabled, "glow": env.glow_enabled})

	var o: Dictionary = env.get_meta("_q_orig")

	env.ssao_enabled = bool(o["ssao"]) and quality == "alta"
	env.ssr_enabled = bool(o["ssr"]) and quality == "alta"
	env.glow_enabled = bool(o["glow"]) and quality != "baixa"


func _tune_scene(root: Node) -> void:

	# luzes: sombras só do sol (média) ou nenhuma (baixa)
	for n in root.find_children("*", "Light3D", true, false):

		var l: Light3D = n

		if not l.has_meta("_q_shadow"):
			l.set_meta("_q_shadow", l.shadow_enabled)

		var want: bool = bool(l.get_meta("_q_shadow"))

		if quality == "baixa":
			want = false
		elif quality == "media" and not (l is DirectionalLight3D):
			want = false

		l.shadow_enabled = want

		if l is DirectionalLight3D:
			var dl: DirectionalLight3D = l
			dl.directional_shadow_mode = (
				DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if quality == "alta"
				else DirectionalLight3D.SHADOW_ORTHOGONAL
			)
			dl.directional_shadow_max_distance = 100.0 if quality == "alta" else 40.0

	# peças: na média, só as grandes projetam sombra; na baixa, nenhuma
	for n in root.find_children("*", "MeshInstance3D", true, false):

		var mi: MeshInstance3D = n

		if not mi.has_meta("_q_cast"):
			mi.set_meta("_q_cast", int(mi.cast_shadow))

		var orig: int = int(mi.get_meta("_q_cast"))
		var cast: int = orig

		if quality == "baixa":
			cast = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		elif quality == "media" and mi.mesh != null and orig != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF:
			var a: AABB = mi.mesh.get_aabb()
			var longest: float = maxf(maxf(a.size.x * mi.scale.x, a.size.y * mi.scale.y), a.size.z * mi.scale.z)

			if longest < 0.8:
				cast = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

		mi.cast_shadow = cast as GeometryInstance3D.ShadowCastingSetting

	# partículas: metade na baixa
	for n in root.find_children("*", "CPUParticles3D", true, false):

		var ps: CPUParticles3D = n

		if not ps.has_meta("_q_amount"):
			ps.set_meta("_q_amount", ps.amount)

		var amt: int = int(ps.get_meta("_q_amount"))

		ps.amount = maxi(4, amt / 2) if quality == "baixa" else amt


func _select_quality(q: String, save: bool = true) -> void:

	if not QUALITY_NAMES.has(q):
		return

	quality = q

	for key in quality_buttons.keys():
		var b: Button = quality_buttons[key]
		b.modulate = Color(1, 1, 1) if key == q else Color(0.55, 0.55, 0.55)

	if quality_hint_label:
		quality_hint_label.text = QUALITY_HINTS[q]

	_apply_quality()

	if save:
		_save_settings()


func _select_scenario(key: String) -> void:

	menu_scenario = key
	_apply_scenario(key)
	_save_settings()


# Anúncio de início de partida (não bloqueia nada: o treino já está rodando).
func _show_round_banner() -> void:

	if banner_label == null:
		return

	_kill_tween(_banner_tween)

	banner_label.text = "%s\nVAI!" % SCENARIOS[scenario_key]["name"]
	banner_label.modulate.a = 0.0
	banner_label.scale = Vector2(0.6, 0.6)
	banner_label.pivot_offset = banner_label.size / 2.0

	_banner_tween = create_tween()
	_banner_tween.set_parallel(true)
	_banner_tween.tween_property(banner_label, "modulate:a", 1.0, 0.25)
	_banner_tween.tween_property(banner_label, "scale", Vector2(1.0, 1.0), 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_banner_tween.chain().tween_interval(0.9)
	_banner_tween.chain().tween_property(banner_label, "modulate:a", 0.0, 0.4)


func _build_world() -> void:

	world_root = Node3D.new()
	add_child(world_root)


	# AMBIENTE
	var env := Environment.new()

	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.05, 0.05, 0.08)

	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.30, 0.28, 0.34)
	env.ambient_light_energy = 0.9

	env.fog_enabled = true
	env.fog_light_color = Color(0.05, 0.05, 0.08)
	env.fog_density = 0.012

	# acabamento de imagem: brilho nos LEDs/luzes e sombras de contato
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_hdr_threshold = 1.0
	env.ssao_enabled = true
	env.ssao_radius = 1.0
	env.ssao_intensity = 1.6


	var world_env := WorldEnvironment.new()
	world_env.environment = env

	world_root.add_child(world_env)

	world_env_node = world_env
	gym_env = env


	# LUZ PRINCIPAL
	var key_light := DirectionalLight3D.new()

	key_light.rotation_degrees = Vector3(-55, -25, 0)
	key_light.light_energy = 1.1
	key_light.shadow_enabled = true

	world_root.add_child(key_light)


	# LUZ DE FUNDO
	var rim_light := OmniLight3D.new()

	rim_light.position = Vector3(0, 3.0, -2.4)
	rim_light.light_color = Color(0.55, 0.5, 0.85)
	rim_light.light_energy = 2.2
	rim_light.omni_range = 6.0

	world_root.add_child(rim_light)


	# ========================================================
	# CONSTANTES DO CENÁRIO
	# ========================================================

	const ROOM_MIN_X := -5.2
	const ROOM_MAX_X := 5.2
	const ROOM_MIN_Z := -6.2
	const ROOM_MAX_Z := 3.0
	const ROOM_HEIGHT := 4.2

	const RING_CENTER := Vector3(2.6, 0, -3.4)  # ajustável — puxe mais pro centro (x menor) se sair do campo de visão
	const RING_HALF := 1.25
	const RING_APRON_H := 0.5
	const RING_POST_H := 1.55


	# PISO
	var floor_mesh := MeshInstance3D.new()
	var floor_plane := PlaneMesh.new()

	floor_plane.size = Vector2(ROOM_MAX_X - ROOM_MIN_X, ROOM_MAX_Z - ROOM_MIN_Z)

	floor_mesh.mesh = floor_plane
	floor_mesh.position = Vector3(
		(ROOM_MIN_X + ROOM_MAX_X) / 2.0,
		0,
		(ROOM_MIN_Z + ROOM_MAX_Z) / 2.0
	)
	floor_mesh.material_override = _tex_mat("rubber_floor", Vector2(9, 8))

	world_root.add_child(floor_mesh)


	# TETO
	var ceiling_mesh := MeshInstance3D.new()
	var ceiling_plane := PlaneMesh.new()

	ceiling_plane.size = floor_plane.size

	ceiling_mesh.mesh = ceiling_plane
	ceiling_mesh.position = Vector3(floor_mesh.position.x, ROOM_HEIGHT, floor_mesh.position.z)
	ceiling_mesh.rotation_degrees = Vector3(180, 0, 0)
	ceiling_mesh.material_override = _static_mat(Color(0.05, 0.05, 0.07))

	world_root.add_child(ceiling_mesh)

	_build_ceiling_trusses(ROOM_MIN_X, ROOM_MAX_X, ROOM_MIN_Z, ROOM_MAX_Z, ROOM_HEIGHT)
	_build_ceiling_lights(ROOM_MIN_X, ROOM_MAX_X, ROOM_MIN_Z, ROOM_MAX_Z, ROOM_HEIGHT)


	# PAREDES (tijolo)
	_build_wall(
		Vector3((ROOM_MIN_X + ROOM_MAX_X) / 2.0, ROOM_HEIGHT / 2.0, ROOM_MIN_Z),
		Vector3(0, 0, 0),
		ROOM_MAX_X - ROOM_MIN_X, ROOM_HEIGHT
	) # parede de fundo

	_build_wall(
		Vector3(ROOM_MIN_X, ROOM_HEIGHT / 2.0, (ROOM_MIN_Z + ROOM_MAX_Z) / 2.0),
		Vector3(0, 90, 0),
		ROOM_MAX_Z - ROOM_MIN_Z, ROOM_HEIGHT
	) # parede esquerda

	_build_wall(
		Vector3(ROOM_MAX_X, ROOM_HEIGHT / 2.0, (ROOM_MIN_Z + ROOM_MAX_Z) / 2.0),
		Vector3(0, -90, 0),
		ROOM_MAX_Z - ROOM_MIN_Z, ROOM_HEIGHT
	) # parede direita


	# JANELAS (parede esquerda, mostrando a rua)
	for wz in [-4.6, -2.0, 1.0]:
		_build_window(Vector3(ROOM_MIN_X + 0.05, 2.05, wz), 90.0)


	# PÔSTERES (parede direita + fundo)
	_build_poster(Vector3(ROOM_MAX_X - 0.05, 2.3, -4.4), -90.0, "poster_glove")
	_build_poster(Vector3(ROOM_MAX_X - 0.05, 2.3, -1.8), -90.0, "poster_motivational")
	_build_poster(Vector3(-3.0, 2.3, ROOM_MIN_Z + 0.05), 0.0, "poster_badge")


	# RINGUE DECORATIVO
	_build_ring(RING_CENTER, RING_HALF, RING_APRON_H, RING_POST_H)


	# SACOS DE PANCADA (perto da parede esquerda/janelas)
	_build_punching_bag(Vector3(-4.1, 0, -4.8))
	_build_punching_bag(Vector3(-4.1, 0, -3.2))
	_build_punching_bag(Vector3(-4.1, 0, -1.6))


	# BANCOS DE MUSCULAÇÃO (chão aberto, não bloqueando a linha de visão central)
	_build_bench(Vector3(-1.6, 0, -1.4), Vector3(0, 20, 0))
	_build_bench(Vector3(1.6, 0, -1.5), Vector3(0, -25, 0))


	# DECORAÇÃO EXTRA DA ACADEMIA (GymDecor.gd): estofado nas paredes,
	# letreiro FBF, LEDs vermelho/azul, halteres, racks, espelho, tapete...
	var gym_decor := GymDecor.new()
	gym_decor.name = "GymDecor"
	world_root.add_child(gym_decor)


	# LUZ DE DESTAQUE EXTRA no ringue (além da rim_light já existente)
	var ring_light := OmniLight3D.new()
	ring_light.position = RING_CENTER + Vector3(0, 2.4, 0)
	ring_light.light_color = Color(0.95, 0.9, 0.75)
	ring_light.light_energy = 3.0
	ring_light.omni_range = 5.0
	world_root.add_child(ring_light)


	# ========================================================
	# CÂMERA DO PACIENTE
	# ========================================================

	camera = Camera3D.new()

	camera.position = Vector3(0, 1.64, 0.9)
	camera.current = true

	world_root.add_child(camera)

	camera.look_at(
		Vector3(0, 1.5, -2.2),
		Vector3.UP
	)

	base_camera_pos = camera.position
	base_camera_rot = camera.rotation_degrees


	# ========================================================
	# BRAÇOS DO PACIENTE (primeira pessoa) — construídos por código,
	# com ombro/cotovelo/punho articulados (PlayerArms3D.gd).
	# ========================================================

	_build_player_arms()


	# ========================================================
	# TREINADOR
	# ========================================================

	trainer_actor = BoxerRig3D.new()

	trainer_actor.body_color = Color(0.82, 0.14, 0.14)

	world_root.add_child(trainer_actor)

	trainer_actor.set_base_transform(
		Vector3(0, 0, -2.2),
		Vector3(0, 180, 0)
	)

	trainer_actor.set_guard()


	# ========================================================
	# PARTÍCULAS
	# ========================================================

	hit_particles = GPUParticles3D.new()

	hit_particles.amount = 18
	hit_particles.lifetime = 0.45
	hit_particles.one_shot = true
	hit_particles.explosiveness = 1.0
	hit_particles.emitting = false


	var pmat := ParticleProcessMaterial.new()

	pmat.direction = Vector3(0, 1, 0)
	pmat.spread = 180.0
	pmat.gravity = Vector3(0, -3.0, 0)

	pmat.initial_velocity_min = 1.2
	pmat.initial_velocity_max = 2.6

	pmat.scale_min = 0.6
	pmat.scale_max = 1.2

	pmat.color = Color(1, 1, 1)

	hit_particles.process_material = pmat
	hit_particles_mat = pmat


	var draw_mesh := SphereMesh.new()

	draw_mesh.radius = 0.04
	draw_mesh.height = 0.08


	var particle_mesh_mat := StandardMaterial3D.new()

	particle_mesh_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	particle_mesh_mat.vertex_color_use_as_albedo = true
	particle_mesh_mat.albedo_color = Color(1, 1, 1)

	draw_mesh.material = particle_mesh_mat

	hit_particles.draw_pass_1 = draw_mesh

	world_root.add_child(hit_particles)


	# ========================================================
	# FLASH
	# ========================================================

	flash_rect = ColorRect.new()

	flash_rect.color = Color(1, 1, 1, 0)

	flash_rect.set_anchors_preset(
		Control.PRESET_FULL_RECT
	)

	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE

	ui_layer.add_child(flash_rect)


	# ========================================================
	# AVISO CENTRAL
	# ========================================================

	var prompt_panel := PanelContainer.new()

	prompt_panel.set_anchors_preset(
		Control.PRESET_CENTER_TOP
	)

	prompt_panel.offset_top = 190
	prompt_panel.offset_left = -95
	prompt_panel.offset_right = 95
	prompt_panel.offset_bottom = 380


	var prompt_style := StyleBoxFlat.new()

	prompt_style.bg_color = Color(0.05, 0.05, 0.07, 0.78)
	prompt_style.border_color = COLOR_GOLD

	prompt_style.set_border_width_all(3)
	prompt_style.set_corner_radius_all(14)

	prompt_style.content_margin_left = 16
	prompt_style.content_margin_right = 16
	prompt_style.content_margin_top = 16
	prompt_style.content_margin_bottom = 16

	prompt_panel.add_theme_stylebox_override(
		"panel",
		prompt_style
	)

	prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	prompt_panel.modulate.a = 0.0

	# O sinal grande no centro tapava o personagem: agora quem diz o que
	# fazer são os indicadores laterais (ver _build_hud). O nó continua
	# existindo (o resto do código mexe nele), só não aparece.
	prompt_panel.visible = false

	ui_layer.add_child(prompt_panel)


	prompt_icon = SignIcon.new()

	prompt_icon.custom_minimum_size = Vector2(158, 158)
	prompt_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE

	prompt_panel.add_child(prompt_icon)

	prompt_panel_ref = prompt_panel


	# ========================================================
	# FEEDBACK
	# ========================================================

	feedback_label = Label.new()

	feedback_label.set_anchors_preset(
		Control.PRESET_TOP_WIDE
	)

	feedback_label.offset_top = 150
	feedback_label.offset_bottom = 210

	feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	feedback_label.add_theme_font_size_override(
		"font_size",
		40
	)

	feedback_label.add_theme_color_override(
		"font_outline_color",
		Color(0, 0, 0)
	)

	feedback_label.add_theme_constant_override(
		"outline_size",
		7
	)

	feedback_label.modulate.a = 0.0
	feedback_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

	ui_layer.add_child(feedback_label)


# ============================================================
# BRAÇOS DO PACIENTE (procedurais)
# ============================================================


	# CENÁRIOS: junta tudo o que é "academia" num único nó, pra poder
	# esconder quando outro cenário estiver ativo. O treinador, a câmera, as
	# partículas de golpe e o ambiente ficam de fora (não mudam).
	_group_gym_nodes()


func _build_player_arms() -> void:

	player_arms = PlayerArms3D.new()
	player_arms.name = "PlayerArms"
	camera.add_child(player_arms)
	player_arms.raise_guard_intro()


# ============================================================
# MATERIAL
# ============================================================

func _static_mat(color: Color) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()

	m.albedo_color = color
	m.roughness = 0.85

	return m


# Material com textura de assets/textures/<nome>.png, repetida
# uv_repeat vezes por cima da superfície (pra tijolo/piso não
# esticarem numa parede/chão grande). Se a textura não existir por
# algum motivo, cai pra um material cinza simples em vez de dar erro.
func _tex_mat(texture_name: String, uv_repeat: Vector2 = Vector2(1, 1)) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()
	var path := "res://assets/textures/%s.png" % texture_name

	if ResourceLoader.exists(path):
		m.albedo_texture = load(path)
	else:
		m.albedo_color = Color(0.4, 0.4, 0.42)

	m.uv1_scale = Vector3(uv_repeat.x, uv_repeat.y, 1.0)
	m.roughness = 0.9

	return m


# Painel plano (janela/pôster) embutido numa parede. wall_yaw_deg deve
# ser o MESMO ângulo Y usado pra construir aquela parede (0 = parede
# de fundo, 90 = parede esquerda, -90 = parede direita), pra o painel
# ficar de frente pra dentro da sala.
func _build_flat_panel(center: Vector3, wall_yaw_deg: float, width: float, height: float, texture_name: String, emissive: bool = false) -> MeshInstance3D:

	var panel := MeshInstance3D.new()
	var plane := PlaneMesh.new()

	plane.size = Vector2(width, height)

	panel.mesh = plane
	panel.position = center
	panel.rotation_degrees = Vector3(90, wall_yaw_deg, 0)

	var mat := _tex_mat(texture_name)

	if emissive:
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.emission_enabled = true
		mat.emission_texture = mat.albedo_texture
		mat.emission_energy_multiplier = 0.6

	panel.material_override = mat

	world_root.add_child(panel)

	return panel


func _build_wall(center: Vector3, rot_deg: Vector3, width: float, height: float) -> void:

	var wall := MeshInstance3D.new()
	var box := BoxMesh.new()

	box.size = Vector3(width, height, 0.15)

	wall.mesh = box
	wall.position = center
	wall.rotation_degrees = rot_deg
	wall.material_override = _tex_mat("brick_wall", Vector2(width / 2.0, height / 2.0))

	world_root.add_child(wall)


func _build_window(center: Vector3, wall_yaw_deg: float) -> void:

	var w := 1.3
	var h := 1.5

	_build_flat_panel(center, wall_yaw_deg, w, h, "street_view", true)

	# moldura simples (barras finas em cima e embaixo do vidro)
	var frame_mat := _static_mat(Color(0.07, 0.07, 0.08))

	for dy in [h / 2.0 + 0.05, -h / 2.0 - 0.05]:
		var bar := MeshInstance3D.new()
		var bm := BoxMesh.new()

		bm.size = Vector3(w + 0.15, 0.07, 0.07)

		bar.mesh = bm
		bar.position = center + Vector3(0, dy, 0)
		bar.rotation_degrees = Vector3(0, wall_yaw_deg, 0)
		bar.material_override = frame_mat

		world_root.add_child(bar)


func _build_poster(center: Vector3, wall_yaw_deg: float, texture_name: String) -> void:

	_build_flat_panel(center, wall_yaw_deg, 0.85, 1.15, texture_name, false)

	# molduras finas ao redor do pôster
	var frame_mat := _static_mat(Color(0.06, 0.06, 0.07))
	var frame := MeshInstance3D.new()
	var box := BoxMesh.new()

	box.size = Vector3(0.95, 1.25, 0.04)

	frame.mesh = box
	frame.position = center + Vector3(0, 0, 0)
	frame.rotation_degrees = Vector3(0, wall_yaw_deg, 0)
	frame.position -= Vector3(sin(deg_to_rad(wall_yaw_deg)), 0, cos(deg_to_rad(wall_yaw_deg))) * 0.03
	frame.material_override = frame_mat

	world_root.add_child(frame)


func _build_ring(center: Vector3, half: float, apron_h: float, post_h: float) -> void:

	# TAPETE/AVENTAL (skirt) do ringue
	var apron := MeshInstance3D.new()
	var apron_mesh := BoxMesh.new()

	apron_mesh.size = Vector3(half * 2.0 + 0.3, apron_h, half * 2.0 + 0.3)

	apron.mesh = apron_mesh
	apron.position = center + Vector3(0, apron_h / 2.0, 0)
	apron.material_override = _static_mat(Color(0.08, 0.07, 0.08))

	world_root.add_child(apron)


	# LONA (topo)
	var canvas := MeshInstance3D.new()
	var canvas_mesh := BoxMesh.new()

	canvas_mesh.size = Vector3(half * 2.0, 0.04, half * 2.0)

	canvas.mesh = canvas_mesh
	canvas.position = center + Vector3(0, apron_h + 0.02, 0)
	canvas.material_override = _tex_mat("ring_canvas", Vector2(1, 1))

	world_root.add_child(canvas)


	# POSTES + CORDAS
	var post_colors := [Color(0.65, 0.08, 0.08), Color(0.1, 0.2, 0.65), Color(0.65, 0.08, 0.08), Color(0.1, 0.2, 0.65)]
	var corners := [
		center + Vector3(-half, apron_h, -half),
		center + Vector3(half, apron_h, -half),
		center + Vector3(half, apron_h, half),
		center + Vector3(-half, apron_h, half),
	]

	for i in range(4):
		var post := MeshInstance3D.new()
		var post_mesh := CylinderMesh.new()

		post_mesh.top_radius = 0.055
		post_mesh.bottom_radius = 0.07
		post_mesh.height = post_h

		post.mesh = post_mesh
		post.position = corners[i] + Vector3(0, post_h / 2.0, 0)
		post.material_override = _static_mat(post_colors[i])

		world_root.add_child(post)

	var rope_mat := _static_mat(Color(0.88, 0.85, 0.88))

	for rope_h in [post_h * 0.28, post_h * 0.55, post_h * 0.82]:
		for i in range(4):
			var a: Vector3 = corners[i] + Vector3(0, rope_h, 0)
			var b: Vector3 = corners[(i + 1) % 4] + Vector3(0, rope_h, 0)
			_build_rope_segment(a, b, rope_mat)


	# ESCADINHA de acesso (lado voltado pro centro da sala, -X)
	var step_count := 3
	for s in range(step_count):
		var step := MeshInstance3D.new()
		var step_mesh := BoxMesh.new()
		var step_h: float = apron_h / step_count

		step_mesh.size = Vector3(0.5, step_h, 0.55)

		step.mesh = step_mesh
		step.position = center + Vector3(
			-half - 0.3 - s * 0.02,
			step_h / 2.0 + s * step_h,
			0
		)
		step.material_override = _static_mat(Color(0.12, 0.12, 0.13))

		world_root.add_child(step)


func _build_rope_segment(a: Vector3, b: Vector3, mat: StandardMaterial3D) -> void:

	var mid := (a + b) / 2.0
	var length := a.distance_to(b)

	var rope := MeshInstance3D.new()
	var rope_mesh := BoxMesh.new()

	rope_mesh.size = Vector3(length, 0.035, 0.035)

	rope.mesh = rope_mesh
	rope.position = mid
	rope.material_override = mat

	if absf(a.x - b.x) < 0.01:
		rope.rotation_degrees = Vector3(0, 90, 0)

	world_root.add_child(rope)


func _build_punching_bag(base_pos: Vector3) -> void:

	var chain := MeshInstance3D.new()
	var chain_mesh := CylinderMesh.new()

	chain_mesh.top_radius = 0.02
	chain_mesh.bottom_radius = 0.02
	chain_mesh.height = 1.0

	chain.mesh = chain_mesh
	chain.position = base_pos + Vector3(0, 3.6, 0)
	chain.material_override = _static_mat(Color(0.15, 0.15, 0.16))

	world_root.add_child(chain)

	var bag := MeshInstance3D.new()
	var bag_mesh := CapsuleMesh.new()

	bag_mesh.radius = 0.26
	bag_mesh.height = 1.05

	bag.mesh = bag_mesh
	bag.position = base_pos + Vector3(0, 2.55, 0)
	bag.material_override = _static_mat(Color(0.30, 0.14, 0.11))

	world_root.add_child(bag)

	var strap := MeshInstance3D.new()
	var strap_mesh := BoxMesh.new()

	strap_mesh.size = Vector3(0.32, 0.05, 0.32)

	strap.mesh = strap_mesh
	strap.position = base_pos + Vector3(0, 3.06, 0)
	strap.material_override = _static_mat(Color(0.05, 0.05, 0.05))

	world_root.add_child(strap)


func _build_bench(pos: Vector3, rot_deg: Vector3) -> void:

	var bench_root := Node3D.new()
	bench_root.position = pos
	bench_root.rotation_degrees = rot_deg
	world_root.add_child(bench_root)

	# banco (assento estofado)
	var pad := MeshInstance3D.new()
	var pad_mesh := BoxMesh.new()

	pad_mesh.size = Vector3(1.15, 0.12, 0.36)

	pad.mesh = pad_mesh
	pad.position = Vector3(0, 0.46, 0)
	pad.material_override = _static_mat(Color(0.55, 0.08, 0.08))

	bench_root.add_child(pad)

	var leg_mat := _static_mat(Color(0.14, 0.14, 0.15))

	for lx in [-0.42, 0.42]:
		var leg := MeshInstance3D.new()
		var leg_mesh := BoxMesh.new()

		leg_mesh.size = Vector3(0.08, 0.46, 0.3)

		leg.mesh = leg_mesh
		leg.position = Vector3(lx, 0.23, 0)
		leg.material_override = leg_mat

		bench_root.add_child(leg)

	# suporte + barra com anilhas numa ponta (silhueta de peso)
	var rack := MeshInstance3D.new()
	var rack_mesh := BoxMesh.new()

	rack_mesh.size = Vector3(0.12, 0.85, 0.12)

	rack.mesh = rack_mesh
	rack.position = Vector3(0.85, 0.42, 0)
	rack.material_override = leg_mat

	bench_root.add_child(rack)

	var bar := MeshInstance3D.new()
	var bar_mesh := CylinderMesh.new()

	bar_mesh.top_radius = 0.025
	bar_mesh.bottom_radius = 0.025
	bar_mesh.height = 1.5

	bar.mesh = bar_mesh
	bar.position = Vector3(0.85, 0.78, 0)
	bar.rotation_degrees = Vector3(0, 0, 90)
	bar.material_override = _static_mat(Color(0.35, 0.35, 0.37))

	bench_root.add_child(bar)

	var plate_mat := _static_mat(Color(0.05, 0.05, 0.06))

	for pz in [-0.68, 0.68]:
		var plate := MeshInstance3D.new()
		var plate_mesh := CylinderMesh.new()

		plate_mesh.top_radius = 0.22
		plate_mesh.bottom_radius = 0.22
		plate_mesh.height = 0.06

		plate.mesh = plate_mesh
		plate.position = Vector3(0.85, 0.78, pz)
		plate.rotation_degrees = Vector3(0, 0, 90)
		plate.material_override = plate_mat

		bench_root.add_child(plate)


func _build_ceiling_trusses(min_x: float, max_x: float, min_z: float, max_z: float, room_h: float) -> void:

	var truss_mat := _static_mat(Color(0.04, 0.04, 0.05))
	var truss_y := room_h - 0.12

	var z := min_z + 0.8
	while z < max_z:

		var beam := MeshInstance3D.new()
		var beam_mesh := BoxMesh.new()

		beam_mesh.size = Vector3(max_x - min_x, 0.1, 0.12)

		beam.mesh = beam_mesh
		beam.position = Vector3((min_x + max_x) / 2.0, truss_y, z)
		beam.material_override = truss_mat

		world_root.add_child(beam)

		# diagonais simples (treliça) abaixo de cada viga
		for dx in [-1.6, 0.0, 1.6]:
			var brace := MeshInstance3D.new()
			var brace_mesh := BoxMesh.new()

			brace_mesh.size = Vector3(0.08, 0.5, 0.08)

			brace.mesh = brace_mesh
			brace.position = Vector3(dx, truss_y - 0.3, z)
			brace.rotation_degrees = Vector3(0, 0, 35)
			brace.material_override = truss_mat

			world_root.add_child(brace)

		z += 1.6


func _build_ceiling_lights(min_x: float, max_x: float, min_z: float, max_z: float, room_h: float) -> void:

	var light_mat := StandardMaterial3D.new()
	light_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	light_mat.emission_enabled = true
	light_mat.emission = Color(0.95, 0.97, 1.0)
	light_mat.emission_energy_multiplier = 3.0

	var z := min_z + 1.4
	var i := 0
	while z < max_z - 0.4:

		for lx in [(min_x + max_x) / 2.0 - 1.6, (min_x + max_x) / 2.0 + 1.6]:

			var strip := MeshInstance3D.new()
			var strip_mesh := BoxMesh.new()

			strip_mesh.size = Vector3(1.4, 0.06, 0.18)

			strip.mesh = strip_mesh
			strip.position = Vector3(lx, room_h - 0.22, z)
			strip.material_override = light_mat

			world_root.add_child(strip)

			var strip_light := OmniLight3D.new()
			strip_light.position = strip.position + Vector3(0, -0.15, 0)
			strip_light.light_color = Color(0.95, 0.97, 1.0)
			strip_light.light_energy = 1.1
			strip_light.omni_range = 4.0

			world_root.add_child(strip_light)

		z += 2.2
		i += 1


# ============================================================
# INTERFACE
# ============================================================

func _panel_style() -> StyleBoxFlat:

	var sb := StyleBoxFlat.new()

	sb.bg_color = Color(0.07, 0.05, 0.06, 0.95)
	sb.border_color = COLOR_GOLD

	sb.set_border_width_all(2)
	sb.set_corner_radius_all(10)

	sb.content_margin_left = 36
	sb.content_margin_right = 36
	sb.content_margin_top = 28
	sb.content_margin_bottom = 28

	return sb


func _hud_panel_style() -> StyleBoxFlat:

	var sb := StyleBoxFlat.new()

	sb.bg_color = Color(0.55, 0.06, 0.08, 0.85)
	sb.border_color = COLOR_GOLD

	sb.set_border_width_all(2)
	sb.set_corner_radius_all(6)

	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6

	return sb


func _make_screen(name: String) -> Control:

	var screen := Control.new()

	screen.name = name

	screen.set_anchors_preset(
		Control.PRESET_FULL_RECT
	)

	screen.visible = false

	ui_layer.add_child(screen)

	screens[name] = screen

	return screen


func _center_box(screen: Control) -> VBoxContainer:

	var center := CenterContainer.new()

	center.set_anchors_preset(
		Control.PRESET_FULL_RECT
	)

	screen.add_child(center)


	var panel := PanelContainer.new()

	panel.add_theme_stylebox_override(
		"panel",
		_panel_style()
	)

	center.add_child(panel)


	var vbox := VBoxContainer.new()

	vbox.add_theme_constant_override(
		"separation",
		12
	)

	vbox.custom_minimum_size = Vector2(440, 0)

	panel.add_child(vbox)

	return vbox


func _make_title(
	text: String,
	size: int = 28,
	color: Color = Color(1, 1, 1)
) -> Label:

	var l := Label.new()

	l.text = text

	l.add_theme_font_size_override(
		"font_size",
		size
	)

	l.add_theme_color_override(
		"font_color",
		color
	)

	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD

	return l


func _make_button(text: String) -> Button:

	var b := Button.new()

	b.text = text
	b.custom_minimum_size = Vector2(0, 44)

	return b


# ============================================================
# MENU
# ============================================================

func _build_ui() -> void:

	ui_layer = CanvasLayer.new()

	ui_layer.layer = 1
	ui_layer.process_mode = Node.PROCESS_MODE_ALWAYS

	add_child(ui_layer)

	_build_splash_screen()
	_build_menu_screen()
	_build_howto_screen()
	_build_hud()
	_build_pause_screen()
	_build_results_screen()
	_build_report_screen()
	_build_scenario_screen()
	_build_minigame_screen()
	_build_achievement_toast()
	_build_fps_label()
	_build_global_back()


# ------------------------------------------------------------
# Tela de seleção de cenário (cartões com miniatura, nome e descrição)
# ------------------------------------------------------------

func _build_scenario_screen() -> void:

	var screen := _make_screen("scenarios")

	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.03, 0.06, 0.93)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(bg)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen.add_child(center)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	center.add_child(vbox)

	vbox.add_child(_make_title("ESCOLHA A ARENA", 30, COLOR_GOLD))

	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 12)

	var scenario_scroll := ScrollContainer.new()
	scenario_scroll.custom_minimum_size = Vector2(1236, 470)
	scenario_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scenario_scroll)
	scenario_scroll.add_child(grid)

	scenario_card_buttons.clear()
	scenario_card_ui.clear()

	for key in SCENARIO_ORDER:

		var card := PanelContainer.new()

		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.08, 0.08, 0.13, 0.96)
		sb.border_color = COLOR_GOLD
		sb.set_border_width_all(2)
		sb.set_corner_radius_all(8)
		sb.content_margin_left = 10
		sb.content_margin_right = 10
		sb.content_margin_top = 10
		sb.content_margin_bottom = 10
		card.add_theme_stylebox_override("panel", sb)

		grid.add_child(card)

		var cv := VBoxContainer.new()
		cv.add_theme_constant_override("separation", 6)
		card.add_child(cv)

		var preview := ScenarioPreview.new()
		preview.kind = key
		preview.custom_minimum_size = Vector2(270, 92)
		cv.add_child(preview)

		var name_label := _make_title(SCENARIOS[key]["name"], 14, COLOR_GOLD)
		cv.add_child(name_label)

		var desc := Label.new()
		desc.text = SCENARIOS[key]["desc"]
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD
		desc.custom_minimum_size = Vector2(270, 40)
		desc.add_theme_font_size_override("font_size", 11)
		desc.add_theme_color_override("font_color", Color(0.9, 0.9, 0.95))
		cv.add_child(desc)

		var pick := _menu_button("SELECIONAR", 16)
		pick.alignment = HORIZONTAL_ALIGNMENT_CENTER
		pick.custom_minimum_size = Vector2(270, 36)

		var key_copy: String = key

		pick.pressed.connect(
			func():
				_select_scenario(key_copy)
				show_screen("menu")
		)

		cv.add_child(pick)

		scenario_card_buttons[key] = pick
		scenario_card_ui[key] = {"name": name_label, "desc": desc, "preview": preview, "button": pick}

	var back := _menu_button("◀  VOLTAR", 20)
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	back.custom_minimum_size = Vector2(240, 46)
	back.pressed.connect(
		func():
			show_screen("menu")
	)

	var back_row := CenterContainer.new()
	back_row.add_child(back)
	vbox.add_child(back_row)


# ============================================================
# SEGREDO: MINIJOGO "67" (easter egg) + CONQUISTA
# ============================================================
# Desbloqueio: SÓ pelo menu RESGATAR CÓDIGO, digitando a palavra "pesca". Ao
# descobrir, toca a animação de desbloqueio (tela escurece, mensagem misteriosa,
# o 67 cai com impacto, anel de choque, flash e som) e o minijogo abre. O
# desbloqueio é salvo (user://fbf_config.cfg): depois disso, digitar "pesca"
# de novo em RESGATAR CÓDIGO entra direto no minijogo.
# A conquista "O escolhido do 67" vem ao chegar ao 67 pela primeira vez.
# Tudo independe do jogo principal (câmera, golpes, cronômetro, pontuação).

func _minigame_camera_on() -> void:

	if CameraInputUDP.ligado:
		return

	var r: Dictionary = CameraInputUDP.iniciar()
	_mg_started_udp = bool(r.get("ok", false))


func _minigame_camera_off() -> void:

	if _mg_started_udp:
		CameraInputUDP.parar()
		_mg_started_udp = false


func _build_minigame_screen() -> void:

	var screen := _make_screen("minigame67")

	minigame67 = Minigame67.new()
	minigame67.sfx = sfx
	minigame67.best_score = best67_score
	minigame67.back_requested.connect(
		func():
			show_screen("menu")
	)
	minigame67.run_finished.connect(_on_minigame_finished)
	minigame67.reached_67.connect(_on_minigame_reached67)
	CameraInputUDP.balanca_changed.connect(minigame67.on_balance)
	screen.add_child(minigame67)


func _build_fps_label() -> void:

	fps_label = Label.new()
	fps_label.visible = false
	fps_label.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	fps_label.offset_left = -520
	fps_label.offset_top = -52
	fps_label.offset_right = -8
	fps_label.offset_bottom = -6
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	fps_label.add_theme_font_size_override("font_size", 14)
	fps_label.add_theme_color_override("font_color", Color(0.4, 1.0, 0.5))
	fps_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	fps_label.add_theme_constant_override("outline_size", 5)
	fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_layer.add_child(fps_label)


func _build_achievement_toast() -> void:

	achievement_toast = PanelContainer.new()
	achievement_toast.set_anchors_preset(Control.PRESET_CENTER_TOP)
	achievement_toast.offset_left = -240
	achievement_toast.offset_right = 240
	achievement_toast.offset_top = -120
	achievement_toast.offset_bottom = -20
	achievement_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.04, 0.12, 0.96)
	sb.border_color = COLOR_GOLD
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	achievement_toast.add_theme_stylebox_override("panel", sb)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	achievement_toast.add_child(v)

	v.add_child(_make_title("CONQUISTA DESBLOQUEADA", 12, Color(1.0, 0.85, 0.3)))

	achievement_toast_title = _make_title("", 22, Color(1, 1, 1))
	v.add_child(achievement_toast_title)

	achievement_toast_desc = _make_title("", 12, Color(0.85, 0.85, 0.92))
	v.add_child(achievement_toast_desc)

	# fica acima de todas as telas
	ui_layer.add_child(achievement_toast)


func _secret_from_word() -> void:

	if _secret_busy:
		return

	if unlocked67:
		_secret_launch()
	else:
		_secret_unlock_sequence()


# Já desbloqueado: entra direto, com um "zum" rápido.
func _secret_launch() -> void:

	if _secret_busy:
		return

	if sfx:
		sfx.play("whoosh", 1.2, -6.0)
		sfx.play("coin", 1.0, -8.0)

	show_screen("minigame67")

	minigame67.best_score = best67_score
	minigame67.start()


func _type_text(label: Label, duration: float) -> void:

	var n: int = label.text.length()

	label.visible_characters = 0

	for i in range(n):

		label.visible_characters = i + 1

		if i % 2 == 0 and sfx:
			sfx.play("tick", 1.0 + randf() * 0.5, -14.0)

		await get_tree().create_timer(duration / float(maxi(n, 1)), true).timeout


# Animação especial do primeiro desbloqueio.
func _secret_unlock_sequence() -> void:

	_secret_busy = true

	var overlay := Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	ui_layer.add_child(overlay)

	var black := ColorRect.new()
	black.color = Color(0, 0, 0, 0)
	black.set_anchors_preset(Control.PRESET_FULL_RECT)
	black.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(black)

	var ring := ImpactRing.new()
	ring.set_anchors_preset(Control.PRESET_FULL_RECT)
	ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(ring)

	var num := Label.new()
	num.text = "67"
	num.set_anchors_preset(Control.PRESET_CENTER)
	num.offset_left = -400
	num.offset_right = 400
	num.offset_top = -210
	num.offset_bottom = 210
	num.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	num.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	num.add_theme_font_size_override("font_size", 340)
	num.add_theme_color_override("font_color", Color(1.0, 0.85, 0.25))
	num.add_theme_color_override("font_outline_color", Color(0.45, 0.05, 0.1))
	num.add_theme_constant_override("outline_size", 44)
	num.pivot_offset = Vector2(400, 210)
	num.modulate.a = 0.0
	num.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(num)

	var msg := Label.new()
	msg.set_anchors_preset(Control.PRESET_CENTER)
	msg.offset_left = -520
	msg.offset_right = 520
	msg.offset_top = -50
	msg.offset_bottom = 50
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	msg.autowrap_mode = TextServer.AUTOWRAP_WORD
	msg.add_theme_font_size_override("font_size", 34)
	msg.add_theme_color_override("font_color", Color(0.85, 0.82, 1.0))
	msg.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	msg.add_theme_constant_override("outline_size", 6)
	msg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(msg)

	var flash := ColorRect.new()
	flash.color = Color(1, 1, 1, 0)
	flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(flash)

	# 1) a tela escurece, com um rumor grave
	if sfx:
		sfx.play("rumble", 1.0, -4.0)

	var fade := create_tween()
	fade.tween_property(black, "color:a", 1.0, 1.0)
	await fade.finished

	# 2) mensagem misteriosa
	msg.text = "...você não deveria estar aqui."
	await _type_text(msg, 1.6)
	await get_tree().create_timer(0.9, true).timeout

	msg.text = "alguém pescou algo estranho no fundo do FBF..."
	await _type_text(msg, 2.0)
	await get_tree().create_timer(0.8, true).timeout

	# 3) glitch
	for i in range(5):
		if sfx:
			sfx.play("glitch", 0.8 + 0.2 * float(i), -8.0)
		black.color = Color(0.25, 0.0, 0.3, 1.0) if i % 2 == 0 else Color(0, 0, 0, 1.0)
		msg.modulate = Color(1, 0.3, 0.6) if i % 2 == 0 else Color(1, 1, 1)
		await get_tree().create_timer(0.08, true).timeout

	black.color = Color(0, 0, 0, 1)
	msg.modulate = Color(1, 1, 1)
	msg.text = ""

	# 4) o 67 cai com impacto
	if sfx:
		sfx.play("whoosh", 1.0, -2.0)

	num.scale = Vector2(6.0, 6.0)
	num.modulate.a = 0.0

	var fall := create_tween()
	fall.set_parallel(true)
	fall.tween_property(num, "scale", Vector2(1, 1), 0.3).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	fall.tween_property(num, "modulate:a", 1.0, 0.2)
	await fall.finished

	if sfx:
		sfx.play("boom", 1.0, 0.0)

	flash.color = Color(1, 1, 1, 1)

	var boom := create_tween()
	boom.set_parallel(true)
	boom.tween_property(flash, "color:a", 0.0, 0.55)
	boom.tween_property(ring, "progress", 1.0, 0.9)

	for i in range(12):
		var sk := Vector2(randf_range(-16.0, 16.0), randf_range(-16.0, 16.0))
		overlay.offset_left = sk.x
		overlay.offset_right = sk.x
		overlay.offset_top = sk.y
		overlay.offset_bottom = sk.y
		await get_tree().create_timer(0.03, true).timeout

	overlay.offset_left = 0.0
	overlay.offset_right = 0.0
	overlay.offset_top = 0.0
	overlay.offset_bottom = 0.0

	# 5) revela o minijogo
	msg.offset_top = 170
	msg.offset_bottom = 250
	msg.text = "MINIJOGO SECRETO DESBLOQUEADO"
	msg.add_theme_color_override("font_color", Color(1.0, 0.9, 0.3))
	msg.visible_characters = -1

	if sfx:
		sfx.play("win", 1.0, -2.0)

	await get_tree().create_timer(1.9, true).timeout

	# salva: a descoberta não se perde ao fechar o jogo
	unlocked67 = true
	_save_settings()

	show_screen("minigame67")

	minigame67.best_score = best67_score
	minigame67.start()

	var out := create_tween()
	out.tween_property(overlay, "modulate:a", 0.0, 0.8)
	await out.finished

	overlay.queue_free()
	_secret_busy = false


func _on_minigame_finished(score: int) -> void:

	if score > best67_score:
		best67_score = score

	_save_settings()


# Passou do 67 durante a rodada: conquista "O escolhido do 67".
func _on_minigame_reached67() -> void:

	_award_achievement("escolhido67")


func _award_achievement(key: String) -> void:

	if bool(achievements.get(key, false)):
		return

	achievements[key] = true
	_save_settings()

	if not ACHIEVEMENTS.has(key):
		return

	achievement_toast_title.text = str(ACHIEVEMENTS[key]["name"])
	achievement_toast_desc.text = str(ACHIEVEMENTS[key]["desc"])

	if sfx:
		sfx.play("coin", 1.0, -4.0)

	var tw := create_tween()
	tw.tween_property(achievement_toast, "offset_top", 14.0, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(achievement_toast, "offset_bottom", 114.0, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_interval(3.4)
	tw.tween_property(achievement_toast, "offset_top", -120.0, 0.4)
	tw.parallel().tween_property(achievement_toast, "offset_bottom", -20.0, 0.4)


func _refresh_achievements() -> void:

	if achievements_list == null:
		return

	for c in achievements_list.get_children():
		c.queue_free()

	for key in ACHIEVEMENTS.keys():

		var got: bool = bool(achievements.get(key, false))

		if got:
			achievements_list.add_child(_menu_label("★ %s" % ACHIEVEMENTS[key]["name"], 22, Color(1.0, 0.85, 0.3)))
			achievements_list.add_child(_menu_label(str(ACHIEVEMENTS[key]["desc"]), 14, Color(0.9, 0.9, 0.95)))
		else:
			achievements_list.add_child(_menu_label("???  (conquista secreta)", 20, Color(0.6, 0.6, 0.68)))


# ------------------------------------------------------------
# Abertura: logo do jogo + "by FisioSense / From Next-FIAP"
# ------------------------------------------------------------

func _load_logo() -> Texture2D:

	if ResourceLoader.exists(LOGO_PATH):
		return load(LOGO_PATH) as Texture2D

	return null


func _build_splash_screen() -> void:

	var screen := _make_screen("splash")

	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.03, 1.0)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(bg)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(center)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 8)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(box)

	splash_box = box

	var logo_tex := _load_logo()

	if logo_tex:

		var logo := TextureRect.new()
		logo.texture = logo_tex
		logo.custom_minimum_size = Vector2(360, 366)
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(logo)

	else:

		box.add_child(_make_title("FBF", 72, COLOR_GOLD))
		box.add_child(_make_title("FisioBoxFight", 26))

	box.add_child(_make_title(CREDIT_LINE_1, 34, COLOR_GOLD))
	box.add_child(_make_title(CREDIT_LINE_2, 22))


func _start_splash() -> void:

	_splash_active = true

	show_screen("splash")

	splash_box.modulate.a = 0.0

	_splash_tween = create_tween()
	_splash_tween.tween_property(splash_box, "modulate:a", 1.0, 0.7)
	_splash_tween.tween_interval(2.3)
	_splash_tween.tween_property(splash_box, "modulate:a", 0.0, 0.5)
	_splash_tween.tween_callback(_finish_splash)


func _finish_splash() -> void:

	if not _splash_active:
		return

	_splash_active = false

	_kill_tween(_splash_tween)

	show_screen("menu")


# Botão "de gibi": vermelho, borda escura, letra grande branca com
# contorno (amarela ao passar o mouse) — no estilo da referência.
func _menu_button(text: String, font_size: int = 26) -> Button:

	var b := Button.new()

	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(340, 58)
	b.focus_mode = Control.FOCUS_NONE

	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", Color(1, 1, 1))
	b.add_theme_color_override("font_hover_color", Color(1.0, 0.92, 0.15))
	b.add_theme_color_override("font_pressed_color", Color(1.0, 0.92, 0.15))
	b.add_theme_color_override("font_outline_color", Color(0.10, 0.0, 0.02))
	b.add_theme_constant_override("outline_size", 7)

	var bg_colors := {
		"normal": Color(0.78, 0.08, 0.10),
		"hover": Color(0.95, 0.17, 0.14),
		"pressed": Color(0.55, 0.05, 0.07),
	}

	for key in bg_colors.keys():

		var sb := StyleBoxFlat.new()

		sb.bg_color = bg_colors[key]
		sb.border_color = Color(0.10, 0.0, 0.02)
		sb.set_border_width_all(4)
		sb.set_corner_radius_all(5)
		sb.content_margin_left = 22
		sb.content_margin_right = 14
		sb.content_margin_top = 6
		sb.content_margin_bottom = 6
		sb.shadow_color = Color(0, 0, 0, 0.45)
		sb.shadow_size = 5
		sb.shadow_offset = Vector2(3, 4)

		b.add_theme_stylebox_override(key, sb)

	b.mouse_entered.connect(func(): _menu_hover(b, true))
	b.mouse_exited.connect(func(): _menu_hover(b, false))

	return b


func _menu_label(text: String, size: int, color: Color = Color(1, 1, 1)) -> Label:

	var l := Label.new()

	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 6)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD
	l.custom_minimum_size = Vector2(340, 0)

	return l


func _menu_page(name: String) -> VBoxContainer:

	var page := VBoxContainer.new()

	page.add_theme_constant_override("separation", 14)
	page.visible = false

	menu_pages[name] = page

	return page


func _menu_show_page(name: String, record: bool = true) -> void:

	if name == "main":
		_menu_page_stack.clear()
	elif record and _menu_current_page != name and menu_pages.has(_menu_current_page):
		_menu_page_stack.append(_menu_current_page)

	_menu_current_page = name

	for key in menu_pages.keys():

		var pg: Control = menu_pages[key]
		var show_it: bool = (key == name)

		if show_it and not pg.visible:
			# entra com um fade rápido
			pg.modulate.a = 0.0
			pg.visible = true
			create_tween().tween_property(pg, "modulate:a", 1.0, 0.15)
		else:
			pg.visible = show_it


# Volta pra página anterior do menu (a de onde você veio).
func _menu_back() -> void:

	if _menu_page_stack.is_empty():
		_menu_show_page("main", false)
	else:
		var prev: String = _menu_page_stack.pop_back()
		_menu_show_page(prev, false)


# Título de página com uma linha dourada embaixo.
func _menu_page_title(page: VBoxContainer, text: String) -> void:

	page.add_child(_menu_label(text, 30, COLOR_GOLD))

	var line := ColorRect.new()
	line.color = Color(0.96, 0.75, 0.26, 0.85)
	line.custom_minimum_size = Vector2(340, 3)
	page.add_child(line)


# Efeito ao passar o mouse nos botões do menu: cresce um pouco e faz "tick".
func _menu_hover(b: Button, on: bool) -> void:

	if b == null:
		return

	b.pivot_offset = Vector2(0.0, b.size.y / 2.0)

	var tw := create_tween()
	tw.tween_property(b, "scale", Vector2(1.04, 1.04) if on else Vector2(1.0, 1.0), 0.1)

	if on and sfx and not b.disabled:
		sfx.play("tick", 1.3, -18.0)


func _build_menu_screen() -> void:

	var screen := _make_screen("menu")

	menu_pages.clear()
	diff_buttons.clear()

	_load_settings()


	# ========================================================
	# Degradê escuro à esquerda (o texto precisa de contraste
	# sobre o cenário)
	# ========================================================

	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(0, 0, 0, 0.82), Color(0, 0, 0, 0.0)])
	grad.offsets = PackedFloat32Array([0.0, 1.0])

	var grad_tex := GradientTexture2D.new()
	grad_tex.gradient = grad
	grad_tex.fill_from = Vector2(0, 0)
	grad_tex.fill_to = Vector2(1, 0)
	grad_tex.width = 256
	grad_tex.height = 16

	var shade := TextureRect.new()
	shade.texture = grad_tex
	shade.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	shade.anchor_right = 0.55
	shade.offset_right = 0
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(shade)


	# ========================================================
	# Logo do jogo + créditos (se a imagem faltar, cai no título em texto)
	# ========================================================

	var logo_tex := _load_logo()

	if logo_tex:

		var logo := TextureRect.new()

		logo.texture = logo_tex
		logo.set_anchors_preset(Control.PRESET_TOP_LEFT)
		logo.offset_left = 34
		logo.offset_top = 6
		logo.offset_right = 34 + 196
		logo.offset_bottom = 6 + 200
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
		screen.add_child(logo)

	else:

		var title_box := VBoxContainer.new()

		title_box.set_anchors_preset(Control.PRESET_TOP_LEFT)
		title_box.offset_left = 40
		title_box.offset_top = 22
		title_box.offset_right = 420
		title_box.add_theme_constant_override("separation", -6)
		title_box.mouse_filter = Control.MOUSE_FILTER_IGNORE

		var big := _menu_label("FBF", 88, COLOR_GOLD)
		big.add_theme_constant_override("outline_size", 12)
		title_box.add_child(big)

		title_box.add_child(_menu_label("FisioBoxFight", 28, Color(1, 1, 1)))

		screen.add_child(title_box)

	var credit_box := VBoxContainer.new()

	credit_box.set_anchors_preset(Control.PRESET_TOP_LEFT)
	credit_box.offset_left = 40
	credit_box.offset_top = 208
	credit_box.offset_right = 40 + 340
	credit_box.add_theme_constant_override("separation", -2)
	credit_box.mouse_filter = Control.MOUSE_FILTER_IGNORE

	credit_box.add_child(_menu_label(CREDIT_LINE_1, 22, COLOR_GOLD))
	credit_box.add_child(_menu_label(CREDIT_LINE_2, 16, Color(1, 1, 1)))

	screen.add_child(credit_box)


	# ========================================================
	# Coluna de opções (à esquerda)
	# ========================================================

	# painel translúcido (altura fixa, com rolagem se a página for grande)
	var menu_panel := PanelContainer.new()

	menu_panel.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	menu_panel.offset_left = 24
	menu_panel.offset_right = 24 + 392
	menu_panel.offset_top = 262
	menu_panel.offset_bottom = -16

	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.0, 0.0, 0.0, 0.40)
	panel_style.border_color = Color(0.96, 0.75, 0.26, 0.55)
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(14)
	panel_style.content_margin_left = 14
	panel_style.content_margin_right = 14
	panel_style.content_margin_top = 12
	panel_style.content_margin_bottom = 12
	menu_panel.add_theme_stylebox_override("panel", panel_style)
	screen.add_child(menu_panel)

	var menu_scroll := ScrollContainer.new()
	menu_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	menu_panel.add_child(menu_scroll)

	var column := VBoxContainer.new()
	column.custom_minimum_size = Vector2(340, 0)
	menu_scroll.add_child(column)

	var menu_hint := _menu_label("ESC: voltar  •  F3: FPS", 12, Color(0.85, 0.85, 0.92))
	menu_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	menu_hint.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	menu_hint.offset_left = -360
	menu_hint.offset_right = -16
	menu_hint.offset_top = -30
	menu_hint.offset_bottom = -8
	screen.add_child(menu_hint)


	# ---------- página principal ----------
	var main_page := _menu_page("main")
	column.add_child(main_page)

	var start_btn := _menu_button("COMEÇAR TREINO (%s)" % _duration_text())
	start_btn.pressed.connect(start_game)
	main_page.add_child(start_btn)

	btn_menu_scenario = _menu_button("CENÁRIO: ACADEMIA", 22)
	btn_menu_scenario.pressed.connect(
		func():
			show_screen("scenarios")
	)
	main_page.add_child(btn_menu_scenario)

	btn_menu_control = _menu_button("CONTROLE: TECLADO")
	btn_menu_control.pressed.connect(
		func():
			_menu_show_page("control")
	)
	main_page.add_child(btn_menu_control)

	var config_btn := _menu_button("CONFIGURAÇÕES")
	config_btn.pressed.connect(
		func():
			_menu_show_page("config")
	)
	main_page.add_child(config_btn)

	var redeem_btn := _menu_button("RESGATAR CÓDIGO")
	redeem_btn.pressed.connect(
		func():
			_menu_show_page("redeem")
			if redeem_input:
				redeem_input.grab_focus()
	)
	main_page.add_child(redeem_btn)

	var howto_btn := _menu_button("TUTORIAL")
	howto_btn.pressed.connect(
		func():
			show_screen("howto")
	)
	main_page.add_child(howto_btn)


	# ---------- página CONTROLE (teclado / câmera) ----------
	var control_page := _menu_page("control")
	column.add_child(control_page)

	_menu_page_title(control_page, "CONTROLE")

	btn_mode_keyboard = _menu_button("⌨  TECLADO", 24)
	btn_mode_keyboard.pressed.connect(
		func():
			_select_mode("keyboard")
	)
	control_page.add_child(btn_mode_keyboard)

	btn_mode_camera = _menu_button("📷  CÂMERA", 24)
	btn_mode_camera.pressed.connect(
		func():
			_select_mode("camera")
	)
	control_page.add_child(btn_mode_camera)

	btn_mode_camera_mediapipe = _menu_button("🎥  CÂMERA (PYTHON)", 24)
	btn_mode_camera_mediapipe.tooltip_text = "Webcam + MediaPipe via um processo Python externo (mais preciso, funciona no Windows). Rode movimentos.py e tools\\ponte_jogo.py antes de começar — veja COMO_USAR_CAMERA_PYTHON.txt."
	btn_mode_camera_mediapipe.pressed.connect(
		func():
			_select_mode("camera_mediapipe")
	)
	control_page.add_child(btn_mode_camera_mediapipe)

	# Botão que ABRE (e fecha) a câmera Python sozinho — sem precisar do JOGAR.bat
	btn_camera_open = _menu_button("📷  ABRIR CÂMERA AGORA", 20)
	btn_camera_open.tooltip_text = "Abre o detector de movimentos (webcam) e a ponte sozinhos, sem janela de terminal. A janela da webcam aparece no canto inferior direito da tela, sempre na frente. Clique de novo para fechar."
	btn_camera_open.pressed.connect(_on_camera_open_pressed)
	control_page.add_child(btn_camera_open)

	camera_status_label = _menu_label("Câmera: desligada.", 14, Color(0.85, 0.85, 0.9))
	control_page.add_child(camera_status_label)

	btn_camera_auto = _menu_button("", 16)
	btn_camera_auto.pressed.connect(
		func():
			camera_autostart = not camera_autostart
			_save_settings()
			_refresh_camera_buttons()
	)
	control_page.add_child(btn_camera_auto)

	btn_camera_ingame = _menu_button("", 16)
	btn_camera_ingame.tooltip_text = "Mostra a webcam ao vivo no canto superior esquerdo do jogo, no lugar do bonequinho (ótimo pra jogar em tela cheia)."
	btn_camera_ingame.pressed.connect(
		func():
			camera_in_game = not camera_in_game
			_on_camera_view_settings_changed()
	)
	control_page.add_child(btn_camera_ingame)

	btn_camera_window = _menu_button("", 16)
	btn_camera_window.tooltip_text = "Abre também a janela separada da webcam (útil pra depurar a detecção)."
	btn_camera_window.pressed.connect(
		func():
			camera_window_visible = not camera_window_visible
			_on_camera_view_settings_changed()
	)
	control_page.add_child(btn_camera_window)

	btn_camera_size = _menu_button("", 16)
	btn_camera_size.pressed.connect(
		func():
			camera_view_size = 1 - camera_view_size
			_save_settings()
			_apply_camera_view_size()
			_refresh_camera_buttons()
	)
	control_page.add_child(btn_camera_size)
	_refresh_camera_buttons()

	# No Windows o Godot não tem webcam nativa: avisa e deixa claro que
	# o teclado (ou a câmera Python) é a opção que funciona.
	if OS.get_name() == "Windows":

		btn_mode_camera.tooltip_text = "No Windows, a câmera depende da versão do Godot. Se não funcionar, o jogo volta pro teclado sozinho."

		var win_note := _menu_label(
			"Windows: a câmera direta depende da versão do Godot. Se falhar, o jogo usa o teclado sozinho. A opção PYTHON é a mais precisa.",
			13,
			Color(1.0, 0.85, 0.7)
		)
		control_page.add_child(win_note)

	var control_back := _menu_button("◀  VOLTAR", 22)
	control_back.pressed.connect(
		func():
			_menu_back()
	)
	control_page.add_child(control_back)


	# ---------- página RESGATAR CÓDIGO ----------
	var redeem_page := _menu_page("redeem")
	column.add_child(redeem_page)

	_menu_page_title(redeem_page, "RESGATAR CÓDIGO")
	redeem_page.add_child(_menu_label("Tem um código secreto? Digite abaixo para desbloquear surpresas.", 14, Color(0.95, 0.95, 1.0)))

	redeem_input = LineEdit.new()
	redeem_input.placeholder_text = "digite o código"
	redeem_input.custom_minimum_size = Vector2(340, 48)
	redeem_input.add_theme_font_size_override("font_size", 22)
	redeem_input.max_length = 24
	redeem_input.text_submitted.connect(_redeem_code)
	redeem_page.add_child(redeem_input)

	var redeem_ok := _menu_button("RESGATAR", 24)
	redeem_ok.pressed.connect(
		func():
			_redeem_code(redeem_input.text)
	)
	redeem_page.add_child(redeem_ok)

	redeem_msg = _menu_label("", 16, Color(1, 1, 1))
	redeem_page.add_child(redeem_msg)

	var ach_btn := _menu_button("CONQUISTAS", 22)
	ach_btn.pressed.connect(
		func():
			_refresh_achievements()
			_menu_show_page("achievements")
	)
	redeem_page.add_child(ach_btn)

	var redeem_back := _menu_button("◀  VOLTAR", 22)
	redeem_back.pressed.connect(
		func():
			_menu_back()
	)
	redeem_page.add_child(redeem_back)


	# ---------- página CONQUISTAS ----------
	var ach_page := _menu_page("achievements")
	column.add_child(ach_page)

	_menu_page_title(ach_page, "CONQUISTAS")

	achievements_list = VBoxContainer.new()
	achievements_list.add_theme_constant_override("separation", 10)
	ach_page.add_child(achievements_list)

	var ach_back := _menu_button("◀  VOLTAR", 22)
	ach_back.pressed.connect(
		func():
			_menu_back()
	)
	ach_page.add_child(ach_back)


	# ---------- página CONFIGURAÇÕES (som e dificuldade) ----------
	var config_page := _menu_page("config")
	column.add_child(config_page)

	_menu_page_title(config_page, "CONFIGURAÇÕES")

	vol_label = _menu_label("SOM: %d%%" % int(round(menu_volume * 100.0)), 22)
	config_page.add_child(vol_label)

	vol_slider = HSlider.new()
	vol_slider.min_value = 0
	vol_slider.max_value = 100
	vol_slider.step = 5
	vol_slider.value = round(menu_volume * 100.0)
	vol_slider.custom_minimum_size = Vector2(340, 34)
	vol_slider.value_changed.connect(_on_volume_changed)
	vol_slider.drag_ended.connect(
		func(_changed: bool):
			_save_settings()
			AudioManager.play("punch_hit")
	)
	config_page.add_child(vol_slider)

	config_page.add_child(_menu_label("DIFICULDADE", 22))

	var diff_row := HBoxContainer.new()
	diff_row.add_theme_constant_override("separation", 6)
	config_page.add_child(diff_row)

	for d in ["facil", "normal", "dificil"]:

		var db := _menu_button(DIFFICULTY_NAMES[d], 17)
		db.custom_minimum_size = Vector2(110, 52)

		var d_copy: String = d
		db.pressed.connect(
			func():
				_select_difficulty(d_copy)
		)

		diff_row.add_child(db)
		diff_buttons[d] = db

	diff_hint_label = _menu_label("", 14, Color(1.0, 0.95, 0.8))
	config_page.add_child(diff_hint_label)

	config_page.add_child(_menu_label("GRÁFICOS (DESEMPENHO)", 22))

	var quality_row := HBoxContainer.new()
	quality_row.add_theme_constant_override("separation", 6)
	config_page.add_child(quality_row)

	quality_buttons.clear()

	for qk in ["baixa", "media", "alta"]:

		var qb := _menu_button(QUALITY_NAMES[qk], 17)
		qb.custom_minimum_size = Vector2(110, 48)

		var qk_copy: String = qk
		qb.pressed.connect(
			func():
				_select_quality(qk_copy)
		)

		quality_row.add_child(qb)
		quality_buttons[qk] = qb

	quality_hint_label = _menu_label("", 13, Color(1.0, 0.95, 0.8))
	config_page.add_child(quality_hint_label)

	var config_back := _menu_button("◀  VOLTAR", 22)
	config_back.pressed.connect(
		func():
			_save_settings()
			_menu_back()
	)
	config_page.add_child(config_back)


	_select_difficulty(menu_difficulty, false)
	_select_quality(quality, false)
	_select_mode(control_mode) # o modo salvo (teclado ou Câmera Python)
	_menu_show_page("main")


# ------------------------------------------------------------
# Configurações (som e dificuldade) — salvas em user://
# ------------------------------------------------------------

# Primeira execução (sem config salva): se a placa de vídeo parece fraca (Intel
# integrada, software...), já começa em BAIXA pra não travar.
func _auto_quality() -> String:

	var adapter: String = RenderingServer.get_video_adapter_name().to_lower()

	for w in ["llvmpipe", "swiftshader", "software", "basic render", "microsoft", "intel", "uhd", "iris", "radeon(tm) graphics", "radeon graphics", "vega"]:
		if adapter.contains(w):
			return "baixa"

	return "media"


func _load_settings() -> void:

	quality = _auto_quality()

	var cfg := ConfigFile.new()

	if cfg.load(CONFIG_PATH) == OK:

		menu_volume = clamp(float(cfg.get_value("audio", "volume", 1.0)), 0.0, 1.0)

		var d: String = str(cfg.get_value("game", "difficulty", "normal"))

		if DIFFICULTY_NAMES.has(d):
			menu_difficulty = d

		# Os desbloqueios por código (lipe 67 / pesca) NÃO são lembrados: ao
		# fechar o jogo tudo volta a ficar bloqueado e o código precisa ser
		# digitado de novo em RESGATAR CÓDIGO.

		var q_saved: String = str(cfg.get_value("game", "quality", "media"))

		if QUALITY_NAMES.has(q_saved):
			quality = q_saved

		var sc_key: String = str(cfg.get_value("game", "scenario", "gym"))

		# arena secreta salva não vale: sem o código ela volta pra academia
		if SCENARIOS.has(sc_key) and not bool(SCENARIOS[sc_key].get("secret", false)):
			menu_scenario = sc_key

		# câmera: lembra se o modo era "Câmera (Python)" e se abre sozinha
		camera_autostart = bool(cfg.get_value("camera", "autostart", true))
		camera_in_game = bool(cfg.get_value("camera", "in_game", true))
		camera_window_visible = bool(cfg.get_value("camera", "window", false))
		camera_view_size = clampi(int(cfg.get_value("camera", "view_size", 1)), 0, 1)

		if str(cfg.get_value("camera", "mode", "keyboard")) == "camera_mediapipe":
			control_mode = "camera_mediapipe"

		best67_score = int(cfg.get_value("secrets", "best67score", 0))
		achievements["escolhido67"] = bool(cfg.get_value("secrets", "ach_escolhido67", false))

	_apply_volume()
	Trainer.difficulty = menu_difficulty


func _save_settings() -> void:

	var cfg := ConfigFile.new()

	cfg.set_value("audio", "volume", menu_volume)
	cfg.set_value("game", "difficulty", menu_difficulty)
	cfg.set_value("game", "quality", quality)
	cfg.set_value("game", "scenario", menu_scenario)


	cfg.set_value("camera", "autostart", camera_autostart)
	cfg.set_value("camera", "in_game", camera_in_game)
	cfg.set_value("camera", "window", camera_window_visible)
	cfg.set_value("camera", "view_size", camera_view_size)
	cfg.set_value("camera", "mode", "camera_mediapipe" if control_mode == "camera_mediapipe" else "keyboard")

	cfg.set_value("secrets", "best67score", best67_score)
	cfg.set_value("secrets", "ach_escolhido67", bool(achievements.get("escolhido67", false)))
	cfg.save(CONFIG_PATH)


func _apply_volume() -> void:

	var bus: int = AudioServer.get_bus_index("Master")

	AudioServer.set_bus_mute(bus, menu_volume <= 0.001)
	AudioServer.set_bus_volume_db(bus, linear_to_db(max(menu_volume, 0.001)))


func _on_volume_changed(v: float) -> void:

	menu_volume = v / 100.0

	if vol_label:
		vol_label.text = "SOM: %d%%" % int(v)

	_apply_volume()


func _select_difficulty(d: String, save: bool = true) -> void:

	if not DIFFICULTY_NAMES.has(d):
		return

	menu_difficulty = d
	Trainer.difficulty = d

	for key in diff_buttons.keys():

		var b: Button = diff_buttons[key]

		b.modulate = Color(1, 1, 1) if key == d else Color(0.55, 0.55, 0.55)

	if diff_hint_label:
		diff_hint_label.text = DIFFICULTY_HINTS[d]

	if save:
		_save_settings()


# ------------------------------------------------------------
# Cena 3D do menu: treinador de frente, olhando e apontando
# ------------------------------------------------------------

func _enter_menu_scene() -> void:

	if _menu_scene_active:
		return

	if camera == null or trainer_actor == null:
		return

	_menu_scene_active = true

	if world_root:
		world_root.visible = true

	if player_arms:
		player_arms.visible = false

	_kill_tween(_menu_camera_tween)

	camera.position = MENU_CAM_POS
	camera.look_at(MENU_CAM_LOOK, Vector3.UP)

	# pequena "aproximação" de câmera ao abrir o menu
	camera.position = MENU_CAM_POS + Vector3(0.35, 0.03, 0.5)

	_menu_camera_tween = create_tween()
	_menu_camera_tween.tween_property(
		camera,
		"position",
		MENU_CAM_POS,
		0.9
	).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)

	trainer_actor.menu_point()


func _exit_menu_scene() -> void:

	if not _menu_scene_active:
		return

	_menu_scene_active = false

	_kill_tween(_menu_camera_tween)

	if camera:
		camera.position = base_camera_pos
		camera.rotation_degrees = base_camera_rot

	if player_arms:
		player_arms.visible = true


func _select_mode(mode: String) -> void:

	control_mode = mode

	if _camera_autostart_ready:
		_save_settings()

		# escolheu "Câmera (Python)": abre o detector sozinho (se estiver ligado o automático)
		if mode == "camera_mediapipe" and camera_autostart and _pid_detector == -1:
			_start_camera()

	if btn_menu_control:
		btn_menu_control.text = "CONTROLE: %s" % MODE_NAMES.get(mode, mode)

	if btn_mode_keyboard and btn_mode_camera:

		btn_mode_keyboard.modulate = (
			Color(1, 1, 1)
			if mode == "keyboard"
			else Color(0.6, 0.6, 0.6)
		)

		btn_mode_camera.modulate = (
			Color(1, 1, 1)
			if mode == "camera"
			else Color(0.6, 0.6, 0.6)
		)

	if btn_mode_camera_mediapipe:

		btn_mode_camera_mediapipe.modulate = (
			Color(1, 1, 1)
			if mode == "camera_mediapipe"
			else Color(0.6, 0.6, 0.6)
		)


# ============================================================
# TUTORIAL
# ============================================================

func _legend_row(
	sign_type: String,
	description: String
) -> HBoxContainer:

	var row := HBoxContainer.new()

	row.add_theme_constant_override(
		"separation",
		14
	)


	var icon_box := PanelContainer.new()

	var icon_style := StyleBoxFlat.new()

	icon_style.bg_color = Color(
		0.05,
		0.05,
		0.07,
		0.9
	)

	icon_style.border_color = COLOR_GOLD

	icon_style.set_border_width_all(2)
	icon_style.set_corner_radius_all(8)

	icon_box.add_theme_stylebox_override(
		"panel",
		icon_style
	)


	var icon := SignIcon.new()

	icon.sign_type = sign_type
	icon.custom_minimum_size = Vector2(56, 56)

	icon_box.add_child(icon)
	row.add_child(icon_box)


	var label := _make_title(
		description,
		12
	)

	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	row.add_child(label)

	return row


func _build_howto_screen() -> void:

	var screen := _make_screen("howto")

	var vbox := _center_box(screen)

	vbox.add_child(
		_make_title(
			"Tutorial",
			22,
			COLOR_GOLD
		)
	)

	vbox.add_child(
		_make_title(
			"Nos lados da tela: SOCO e DEFESA de cada mão (esquerda = vermelho, direita = azul). O boneco do centro repete o seu movimento.",
			12
		)
	)


	vbox.add_child(
		_legend_row(
			"dodge_left",
			"Esquive para a ESQUERDA"
		)
	)

	vbox.add_child(
		_legend_row(
			"dodge_right",
			"Esquive para a DIREITA"
		)
	)

	vbox.add_child(
		_legend_row(
			"duck",
			"Defesa ALTA (as duas mãos no rosto)"
		)
	)

	vbox.add_child(
		_legend_row(
			"crouch",
			"ou AGACHE (o corpo desce)"
		)
	)

	vbox.add_child(
		_legend_row(
			"punch_left",
			"Soque com a ESQUERDA"
		)
	)

	vbox.add_child(
		_legend_row(
			"punch_right",
			"Soque com a DIREITA"
		)
	)


	vbox.add_child(
		_make_title(
			"Setas azuis = defesa. Luva laranja = ataque.",
			12
		)
	)


	vbox.add_child(
		_make_title(
			"Teclado:",
			13
		)
	)


	var lines_kb := [
		"← ou A — esquivar para a esquerda",
		"→ ou D — esquivar para a direita",
		"↓ ou S — agachar / defesa alta",
		"Z — soco com a esquerda",
		"X — soco com a direita"
	]


	for line in lines_kb:

		vbox.add_child(
			_make_title(
				line,
				12
			)
		)


	vbox.add_child(
		_make_title(
			"Câmera: fique com o rosto no meio da imagem e as mãos na guarda. Soco = soque pra frente com AQUELA mão. Esquiva = incline cabeça e tronco pro lado. Agachar = abaixe o corpo (dobre os joelhos); Defesa alta também vale = suba as DUAS mãos na frente do nariz. Se os lados saírem trocados, aperte M.",
			12
		)
	)


	vbox.add_child(
		_make_title(
			"O treinador prepara o golpe antes de atacar. A luta dura 2 minutos e fica mais rápida com o tempo. De vez em quando ele solta um COMBO de 2 a 4 golpes: acerte todos para ganhar pontos extras!",
			12
		)
	)


	var rumor := _make_title("Rumor: o FBF esconde um código que ninguém anuncia... dizem que quem \"pesca\" a palavra certa em RESGATAR CÓDIGO encontra algo raro.", 10, Color(0.6, 0.6, 0.7))
	vbox.add_child(rumor)

	var back_btn := _make_button(
		"Voltar"
	)

	back_btn.pressed.connect(
		func():
			show_screen("menu")
	)

	vbox.add_child(back_btn)


# ============================================================
# HUD
# ============================================================

func _hud_stat_block(
	caption: String,
	initial_value: String
) -> Dictionary:

	var box := PanelContainer.new()

	box.add_theme_stylebox_override(
		"panel",
		_hud_panel_style()
	)


	var vb := VBoxContainer.new()

	vb.add_theme_constant_override(
		"separation",
		0
	)

	box.add_child(vb)


	var cap := Label.new()

	cap.text = caption

	cap.add_theme_font_size_override(
		"font_size",
		10
	)

	cap.add_theme_color_override(
		"font_color",
		Color(0.95, 0.85, 0.75)
	)

	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	vb.add_child(cap)


	var val := Label.new()

	val.text = initial_value

	val.add_theme_font_size_override(
		"font_size",
		22
	)

	val.add_theme_color_override(
		"font_color",
		COLOR_GOLD
	)

	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	vb.add_child(val)


	return {
		"box": box,
		"value": val
	}


func _make_indicator(
	action: String,
	caption: String,
	ring: Color
) -> ActionIndicator:

	var ind := ActionIndicator.new()

	ind.action = action
	ind.caption = caption
	ind.ring_color = ring

	indicators[action] = ind

	return ind


func _make_indicator_column(
	preset: Control.LayoutPreset,
	margin: float
) -> VBoxContainer:

	var col := VBoxContainer.new()

	col.set_anchors_preset(preset)

	col.offset_top = -205
	col.offset_bottom = 205

	if preset == Control.PRESET_CENTER_LEFT:
		col.offset_left = margin
		col.offset_right = margin + 190
	else:
		col.offset_left = -margin - 190
		col.offset_right = -margin

	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 16)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE

	return col


func _build_hud() -> void:

	var screen := _make_screen("hud")

	screen.mouse_filter = Control.MOUSE_FILTER_IGNORE

	indicators.clear()


	# Anúncio de início: nome da arena + "VAI!" (só visual, não atrasa nada)
	banner_label = Label.new()
	banner_label.text = ""
	banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	banner_label.add_theme_font_size_override("font_size", 52)
	banner_label.add_theme_color_override("font_color", COLOR_GOLD)
	banner_label.add_theme_color_override("font_outline_color", Color(0.05, 0.0, 0.0))
	banner_label.add_theme_constant_override("outline_size", 14)
	banner_label.set_anchors_preset(Control.PRESET_CENTER)
	banner_label.offset_left = -400
	banner_label.offset_right = 400
	banner_label.offset_top = -190
	banner_label.offset_bottom = -40
	banner_label.modulate.a = 0.0
	banner_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(banner_label)

	# Anúncio de COMBO de ataques (aparece de vez em quando, acima do treinador)
	combo_label = Label.new()
	combo_label.text = ""
	combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_label.add_theme_font_size_override("font_size", 34)
	combo_label.add_theme_color_override("font_color", Color(1.0, 0.55, 0.15))
	combo_label.add_theme_color_override("font_outline_color", Color(0.1, 0.0, 0.0))
	combo_label.add_theme_constant_override("outline_size", 10)
	combo_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	combo_label.offset_left = -300
	combo_label.offset_right = 300
	combo_label.offset_top = 205
	combo_label.offset_bottom = 255
	combo_label.modulate.a = 0.0
	combo_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(combo_label)


	# ========================================================
	# TOPO — cronômetro no centro
	# ========================================================

	var top := CenterContainer.new()

	top.set_anchors_preset(Control.PRESET_TOP_WIDE)

	top.offset_top = 10
	top.offset_bottom = 84

	top.mouse_filter = Control.MOUSE_FILTER_IGNORE

	screen.add_child(top)


	var time_block := _hud_stat_block(
		"TEMPO",
		_duration_text(true)
	)

	hud_time = time_block["value"]

	hud_time.add_theme_font_size_override(
		"font_size",
		38
	)

	var time_box: PanelContainer = time_block["box"]

	time_box.custom_minimum_size = Vector2(170, 0)

	top.add_child(time_box)


	var pause_btn := _make_button("II")

	pause_btn.custom_minimum_size = Vector2(44, 44)

	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)

	pause_btn.offset_left = -60
	pause_btn.offset_top = 14
	pause_btn.offset_right = -16
	pause_btn.offset_bottom = 58

	pause_btn.pressed.connect(pause_game)

	screen.add_child(pause_btn)

	# chip da câmera: ponto verde piscando = a câmera está ligada e mandando dados.
	# Clicar nele liga/desliga a câmera Python.
	hud_camera_chip = _make_button("")
	hud_camera_chip.custom_minimum_size = Vector2(190, 32)
	hud_camera_chip.add_theme_font_size_override("font_size", 13)
	hud_camera_chip.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	hud_camera_chip.offset_left = -214
	hud_camera_chip.offset_top = 64
	hud_camera_chip.offset_right = -16
	hud_camera_chip.offset_bottom = 96
	hud_camera_chip.visible = false
	hud_camera_chip.pressed.connect(_on_camera_open_pressed)
	screen.add_child(hud_camera_chip)


	phase_toast_label = Label.new()

	phase_toast_label.add_theme_font_size_override(
		"font_size",
		16
	)

	phase_toast_label.add_theme_color_override(
		"font_color",
		COLOR_GOLD
	)

	phase_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	phase_toast_label.set_anchors_preset(
		Control.PRESET_TOP_WIDE
	)

	phase_toast_label.offset_top = 88
	phase_toast_label.offset_bottom = 112

	phase_toast_label.modulate.a = 0.0

	phase_toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

	screen.add_child(phase_toast_label)


	status_label = Label.new()

	status_label.add_theme_font_size_override(
		"font_size",
		13
	)

	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	status_label.set_anchors_preset(
		Control.PRESET_TOP_WIDE
	)

	status_label.offset_top = 114
	status_label.offset_bottom = 138

	status_label.visible = false

	status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

	screen.add_child(status_label)


	# ========================================================
	# LADOS — indicadores de ação (esquerda = luva vermelha,
	# direita = luva azul). Em cada lado: SOCO em cima, DEFESA
	# (esquiva) embaixo — como no desenho.
	# ========================================================

	var left_col := _make_indicator_column(
		Control.PRESET_CENTER_LEFT,
		18.0
	)

	left_col.add_child(
		_make_indicator("punch_left", "SOCO ESQ.", HAND_LEFT_COLOR)
	)

	left_col.add_child(
		_make_indicator("dodge_left", "DEFESA ESQ.", HAND_LEFT_COLOR)
	)

	screen.add_child(left_col)


	var right_col := _make_indicator_column(
		Control.PRESET_CENTER_RIGHT,
		18.0
	)

	right_col.add_child(
		_make_indicator("punch_right", "SOCO DIR.", HAND_RIGHT_COLOR)
	)

	right_col.add_child(
		_make_indicator("dodge_right", "DEFESA DIR.", HAND_RIGHT_COLOR)
	)

	screen.add_child(right_col)


	# ========================================================
	# CENTRO-BAIXO — boneco do jogador (espelha os movimentos) e o
	# indicador de AGACHAR ao lado dele. O treinador continua no
	# centro do ringue, atrás.
	# ========================================================

	# Retrato do jogador no canto SUPERIOR ESQUERDO (moldura + "VOCÊ")
	var portrait := PanelContainer.new()

	portrait.set_anchors_preset(Control.PRESET_TOP_LEFT)
	portrait.offset_left = 14
	portrait.offset_top = 10
	portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var portrait_style := StyleBoxFlat.new()
	portrait_style.bg_color = Color(0.03, 0.03, 0.06, 0.55)
	portrait_style.border_color = COLOR_GOLD
	portrait_style.set_border_width_all(2)
	portrait_style.set_corner_radius_all(10)
	portrait_style.content_margin_left = 6
	portrait_style.content_margin_right = 6
	portrait_style.content_margin_top = 6
	portrait_style.content_margin_bottom = 4
	portrait.add_theme_stylebox_override("panel", portrait_style)

	screen.add_child(portrait)

	var portrait_box := VBoxContainer.new()
	portrait_box.add_theme_constant_override("separation", 0)
	portrait_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	portrait.add_child(portrait_box)

	avatar = PlayerAvatar.new()
	avatar.custom_minimum_size = Vector2(120, 122)
	portrait_box.add_child(avatar)

	portrait_who = _make_title("VOCÊ", 12, COLOR_GOLD)
	portrait_box.add_child(portrait_who)

	# A WEBCAM AO VIVO ocupa o lugar do bonequinho (canto superior esquerdo) quando o
	# modo Câmera (Python) está ativo e o vídeo está chegando: dá pra jogar em tela cheia
	# e se ver sem a janela separada. Sem vídeo, volta o bonequinho.
	camera_view = TextureRect.new()
	camera_view.custom_minimum_size = Vector2(256, 144) if camera_view_size == 1 else Vector2(208, 117)
	camera_view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	camera_view.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	camera_view.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	camera_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	camera_view.visible = false
	portrait_box.add_child(camera_view)

	camera_view_live = _make_title("●  AO VIVO", 11, Color(1.0, 0.35, 0.35))
	camera_view_live.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	camera_view_live.offset_left = 6
	camera_view_live.offset_top = -20
	camera_view_live.offset_bottom = -2
	camera_view.add_child(camera_view_live)


	# DEFESA ALTA (as duas mãos no rosto). Fica no TOPO, ao lado do
	# cronômetro: embaixo ele ficava escondido atrás da luva azul
	# gigante da primeira pessoa. Agachar também vale como esta defesa.
	var guard_ind := _make_indicator(
		"duck",
		"DEFESA ALTA",
		COLOR_CYAN
	)

	guard_ind.set_anchors_preset(Control.PRESET_CENTER_TOP)

	guard_ind.offset_left = 135
	guard_ind.offset_right = 135 + 190
	guard_ind.offset_top = 6
	guard_ind.offset_bottom = 6 + 188

	screen.add_child(guard_ind)


	# ========================================================
	# EMBAIXO — informações da partida numa faixa fina
	# ========================================================

	var bottom := PanelContainer.new()

	bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)

	bottom.offset_top = -62
	bottom.offset_bottom = 0

	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var bottom_style := StyleBoxFlat.new()

	bottom_style.bg_color = Color(0.03, 0.03, 0.05, 0.55)

	bottom_style.content_margin_top = 4
	bottom_style.content_margin_bottom = 4

	bottom.add_theme_stylebox_override(
		"panel",
		bottom_style
	)

	screen.add_child(bottom)


	var bar := HBoxContainer.new()

	bar.alignment = BoxContainer.ALIGNMENT_CENTER

	bar.add_theme_constant_override(
		"separation",
		24
	)

	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE

	bottom.add_child(bar)


	var score_block := _hud_stat_block(
		"PONTOS",
		"0000"
	)

	hud_score = score_block["value"]

	bar.add_child(score_block["box"])


	var combo_block := _hud_stat_block(
		"COMBO",
		"x0"
	)

	hud_combo = combo_block["value"]

	bar.add_child(combo_block["box"])


	var precision_block := _hud_stat_block(
		"PRECISÃO",
		"100%"
	)

	hud_precision = precision_block["value"]

	bar.add_child(precision_block["box"])


	# ========================================================
	# PRÉVIA DA CÂMERA (modo câmera nativa) — pequena, translúcida e
	# no canto, pra não atrapalhar (nada de janela gigante).
	# ========================================================

	camera_preview_rect = TextureRect.new()

	camera_preview_rect.set_anchors_preset(
		Control.PRESET_BOTTOM_RIGHT
	)

	camera_preview_rect.position = Vector2(-176, -196)

	camera_preview_rect.custom_minimum_size = Vector2(
		160,
		120
	)
	camera_preview_rect.size = Vector2(160, 120)

	# STRETCH_SCALE: a imagem ocupa o quadro inteiro, então as guias
	# (desenhadas em frações do tamanho) batem com as zonas da detecção.
	camera_preview_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	camera_preview_rect.stretch_mode = TextureRect.STRETCH_SCALE
	camera_preview_rect.flip_h = CameraInput.mirror
	camera_preview_rect.modulate.a = 0.7
	camera_preview_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	camera_preview_rect.visible = false

	screen.add_child(camera_preview_rect)

	camera_guide = CameraGuide.new()
	camera_guide.set_anchors_preset(Control.PRESET_FULL_RECT)
	camera_guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
	camera_preview_rect.add_child(camera_guide)

	CameraInput.gesture_seen.connect(_on_camera_gesture_seen)

	# teclado: mesmo aviso visual (boneco + indicador) na hora do toque
	InputHandler.response_pressed.connect(_on_input_recognized)


# ============================================================
# PAUSA
# ============================================================

func _build_pause_screen() -> void:

	var screen := _make_screen("pause")

	var vbox := _center_box(screen)

	vbox.add_child(
		_make_title(
			"Pausado",
			22,
			COLOR_GOLD
		)
	)


	var resume_btn := _make_button(
		"Continuar"
	)

	resume_btn.pressed.connect(
		resume_game
	)

	vbox.add_child(resume_btn)


	var quit_btn := _make_button(
		"Sair para o Menu"
	)

	quit_btn.pressed.connect(
		quit_to_menu
	)

	vbox.add_child(quit_btn)


# ============================================================
# RESULTADOS
# ============================================================

func _result_card(caption: String, key: String) -> PanelContainer:

	var card := PanelContainer.new()

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.08, 0.13, 0.95)
	sb.border_color = COLOR_GOLD
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	card.add_theme_stylebox_override("panel", sb)
	card.custom_minimum_size = Vector2(214, 0)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	card.add_child(v)

	v.add_child(_make_title(caption, 12, Color(0.75, 0.75, 0.82)))

	var val := _make_title("--", 30, COLOR_GOLD)
	v.add_child(val)
	results_labels[key] = val

	var sub := _make_title("", 12, Color(0.85, 0.85, 0.9))
	v.add_child(sub)
	results_labels[key + "_sub"] = sub

	return card


func _chart_panel(title: String, chart_mode: String, min_h: float) -> ReportCharts:

	var panel := PanelContainer.new()

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.08, 0.13, 0.95)
	sb.border_color = Color(0.96, 0.75, 0.26, 0.55)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", sb)
	panel.custom_minimum_size = Vector2(384, 0)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	panel.add_child(v)

	v.add_child(_make_title(title, 13, COLOR_GOLD))

	var chart := ReportCharts.new()
	chart.mode = chart_mode
	chart.custom_minimum_size = Vector2(360, min_h)
	v.add_child(chart)

	results_charts_flow.add_child(panel)

	return chart


func _build_results_screen() -> void:

	var screen := _make_screen("results")

	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.02, 0.05, 0.95)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	screen.add_child(bg)

	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	screen.add_child(scroll)

	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 14)
	margin.add_theme_constant_override("margin_bottom", 14)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 10)
	margin.add_child(root)


	# ---------- cabeçalho: logo, resultado, nota ----------
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 16)
	root.add_child(head)

	var logo_tex := _load_logo()

	if logo_tex:
		var logo := TextureRect.new()
		logo.texture = logo_tex
		logo.custom_minimum_size = Vector2(96, 98)
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		head.add_child(logo)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.alignment = BoxContainer.ALIGNMENT_CENTER
	title_box.add_theme_constant_override("separation", 2)
	head.add_child(title_box)

	title_box.add_child(_make_title("RELATÓRIO FINAL", 13, Color(0.75, 0.75, 0.82)))

	results_title_label = _make_title("TREINO FINALIZADO", 36, COLOR_GOLD)
	results_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_box.add_child(results_title_label)

	results_sub_label = _make_title("", 13, Color(0.85, 0.85, 0.9))
	results_sub_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_box.add_child(results_sub_label)

	chart_grade = ReportCharts.new()
	chart_grade.mode = "grade"
	chart_grade.custom_minimum_size = Vector2(130, 136)
	head.add_child(chart_grade)


	# ---------- cartões de números ----------
	var cards := HFlowContainer.new()
	cards.add_theme_constant_override("h_separation", 10)
	cards.add_theme_constant_override("v_separation", 10)
	root.add_child(cards)

	cards.add_child(_result_card("PONTUAÇÃO", "score"))
	cards.add_child(_result_card("PRECISÃO", "precision"))
	cards.add_child(_result_card("REAÇÃO MÉDIA", "reaction"))
	cards.add_child(_result_card("MELHOR COMBO", "combo"))
	cards.add_child(_result_card("FASE MÁXIMA", "phase"))


	# ---------- gráficos ----------
	results_charts_flow = HFlowContainer.new()
	results_charts_flow.add_theme_constant_override("h_separation", 10)
	results_charts_flow.add_theme_constant_override("v_separation", 10)
	root.add_child(results_charts_flow)

	chart_moves = _chart_panel("DESEMPENHO POR MOVIMENTO", "moves", 172.0)
	chart_timeline = _chart_panel("PRECISÃO AO LONGO DO TREINO", "timeline", 172.0)
	chart_balance = _chart_panel("EQUILÍBRIO ESQUERDA × DIREITA", "balance", 172.0)


	# ---------- recomendações ----------
	var rec_panel := PanelContainer.new()

	var rsb := StyleBoxFlat.new()
	rsb.bg_color = Color(0.08, 0.08, 0.13, 0.95)
	rsb.border_color = Color(0.35, 0.92, 0.5, 0.6)
	rsb.set_border_width_all(2)
	rsb.set_corner_radius_all(8)
	rsb.content_margin_left = 16
	rsb.content_margin_right = 16
	rsb.content_margin_top = 10
	rsb.content_margin_bottom = 10
	rec_panel.add_theme_stylebox_override("panel", rsb)
	root.add_child(rec_panel)

	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 6)
	rec_panel.add_child(rv)

	rv.add_child(_make_title("RECOMENDAÇÕES E ORIENTAÇÕES", 14, Color(0.35, 0.92, 0.5)))

	results_recs_label = RichTextLabel.new()
	results_recs_label.bbcode_enabled = true
	results_recs_label.fit_content = true
	results_recs_label.scroll_active = false
	results_recs_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	results_recs_label.add_theme_font_size_override("normal_font_size", 14)
	results_recs_label.add_theme_font_size_override("bold_font_size", 14)
	results_recs_label.add_theme_font_size_override("italics_font_size", 12)
	rv.add_child(results_recs_label)


	# ---------- botões ----------
	var buttons := HFlowContainer.new()
	buttons.alignment = FlowContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("h_separation", 10)
	buttons.add_theme_constant_override("v_separation", 8)
	root.add_child(buttons)

	var restart_btn := _make_button("Tentar Novamente")
	restart_btn.pressed.connect(start_game)
	buttons.add_child(restart_btn)

	var report_btn := _make_button("Relatório Detalhado")
	report_btn.pressed.connect(
		func():
			show_screen("report")
	)
	buttons.add_child(report_btn)

	var folder_btn := _make_button("Abrir Pasta dos Relatórios")
	folder_btn.pressed.connect(
		func():
			DirAccess.make_dir_recursive_absolute(REPORT_DIR)
			OS.shell_open(ProjectSettings.globalize_path(REPORT_DIR))
	)
	buttons.add_child(folder_btn)

	var menu_btn := _make_button("Menu Principal")
	menu_btn.pressed.connect(quit_to_menu)
	buttons.add_child(menu_btn)


	# confete na vitória
	results_confetti = CPUParticles2D.new()
	results_confetti.emitting = false
	results_confetti.one_shot = true
	results_confetti.amount = 90
	results_confetti.lifetime = 4.5
	results_confetti.explosiveness = 0.0
	results_confetti.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	results_confetti.emission_rect_extents = Vector2(640, 4)
	results_confetti.direction = Vector2(0, 1)
	results_confetti.spread = 12.0
	results_confetti.gravity = Vector2(0, 140)
	results_confetti.initial_velocity_min = 70.0
	results_confetti.initial_velocity_max = 170.0
	results_confetti.angular_velocity_min = -240.0
	results_confetti.angular_velocity_max = 240.0
	results_confetti.scale_amount_min = 5.0
	results_confetti.scale_amount_max = 10.0
	results_confetti.color = Color(1.0, 0.8, 0.25)
	results_confetti.hue_variation_min = -1.0
	results_confetti.hue_variation_max = 1.0
	screen.add_child(results_confetti)


func _count_up(label: Label, target: int, suffix: String) -> void:

	label.text = "0" + suffix

	var tw := create_tween()

	var setter := func(v: float): label.text = "%d%s" % [int(v), suffix]

	tw.tween_method(setter, 0.0, float(target), 1.1).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


# Preenche a tela final com os dados do relatório (chamada no fim do treino).
func _fill_final_screen() -> void:

	if last_report_data.is_empty() or results_sub_label == null:
		return

	var d: Dictionary = last_report_data
	var s: Dictionary = d["summary"]

	results_sub_label.text = "%s   •   %s   •   %s   •   Dificuldade %s" % [
		d["date_text"], d["arena"], d["mode"], d["difficulty"]
	]

	_count_up(results_labels["score"], int(s["score"]), "")
	results_labels["score_sub"].text = "%d acertos  •  %d erros" % [int(s["hits"]), int(s["misses"])]

	_count_up(results_labels["precision"], int(round(float(s["precision"]))), "%")
	results_labels["precision_sub"].text = "meta de vitória: %d%%" % int(WIN_PRECISION)

	var avg: float = float(s["avg_reaction_ms"])

	results_labels["reaction"].text = "--" if avg <= 0.0 else "%d ms" % int(round(avg))
	results_labels["reaction_sub"].text = "melhor: %d ms" % int(round(float(s["best_reaction_ms"])))

	results_labels["combo"].text = "x%d" % int(s["best_combo"])
	results_labels["combo_sub"].text = "combos perfeitos: %d/%d" % [int(d["combos"]["perfect"]), int(d["combos"]["total"])]

	results_labels["phase"].text = str(d["phase_name"])
	results_labels["phase_sub"].text = "nível %d de %d" % [int(s["max_phase"]), Trainer.PHASES.size()]

	chart_grade.set_data(d["grade"])

	chart_moves.set_data({"rows": d["rows"]})
	chart_timeline.set_data({"blocks6": d["blocks6"]})
	chart_balance.set_data(d["balance"])

	# recomendações: as baseadas nos números (até 4) + aviso de segurança
	var recs: Array = last_report_recs
	var data_count: int = maxi(0, recs.size() - 4)
	var shown: Array = []

	for i in range(mini(data_count, 4)):
		shown.append(recs[i])

	if recs.size() >= 2:
		shown.append(recs[recs.size() - 2])

	var lines: PackedStringArray = PackedStringArray()

	var evo: String = _report_evolution_line(d)

	if evo != "":
		lines.append("[color=#f5b842]•[/color] [b]Evolução:[/b] " + evo)

	for r in shown:
		lines.append("[color=#f5b842]•[/color] " + str(r))

	lines.append("[i][color=#b8b8c4]Registro de desempenho no jogo — não é diagnóstico. Decisões de saúde devem ser tomadas com médico ou fisioterapeuta. O relatório completo está em \"Relatório Detalhado\".[/color][/i]")

	results_recs_label.text = "\n".join(lines)

	# confete quando vence
	if results_confetti:

		if bool(d["won"]):
			results_confetti.position = Vector2(get_viewport().get_visible_rect().size.x / 2.0, -12.0)
			results_confetti.emission_rect_extents = Vector2(get_viewport().get_visible_rect().size.x / 2.0, 4.0)
			results_confetti.restart()
			results_confetti.emitting = true
		else:
			results_confetti.emitting = false


# ============================================================
# RELATÓRIO DO TREINO (V-FBF)
# ============================================================
# No fim de cada treino: junta os números da sessão, mostra um mini
# relatório na tela (botão na tela de resultados), salva um .txt em
# user://reports/ e guarda um histórico simples (user://fbf_history.json)
# pra comparar com o treino anterior.
#
# As recomendações são REGRAS SIMPLES sobre os números do jogo — são
# orientações gerais de segurança/treino e NÃO um diagnóstico. O texto
# do relatório deixa isso explícito.

# "2:00" (ou "02:00" com padded=true), a partir da duração da sessão.
func _duration_text(padded: bool = false) -> String:

	var total: int = int(GameManager.SESSION_DURATION_SEC)

	if padded:
		return "%02d:%02d" % [total / 60, total % 60]

	return "%d:%02d" % [total / 60, total % 60]


# Rótulos dos 3 "terços" da sessão (ex.: 0-40 s, 40-80 s, 80-120 s).
func _third_labels() -> Array:

	var d: int = int(GameManager.SESSION_DURATION_SEC / 3.0)

	return ["0-%d s" % d, "%d-%d s" % [d, d * 2], "%d-%d s" % [d * 2, d * 3]]


func _report_reset() -> void:

	var blocks: Array = []

	for i in range(int(ceil(GameManager.SESSION_DURATION_SEC / 15.0))):
		blocks.append({"ok": 0, "miss": 0})

	_rep = {
		"moves": {},
		"blocks": blocks,
		"combos": {"total": 0, "perfect": 0},
	}

	for key in MOVE_ORDER:
		_rep["moves"][key] = {"ok": 0, "miss": 0, "react": 0.0}


# Chamado a cada desafio resolvido (acerto, erro ou tempo esgotado).
func _report_record(response: String, success: bool, reaction_ms: float) -> void:

	if _rep.is_empty():
		_report_reset()

	if not _rep["moves"].has(response):
		_rep["moves"][response] = {"ok": 0, "miss": 0, "react": 0.0}

	var m: Dictionary = _rep["moves"][response]

	if success:
		m["ok"] = int(m["ok"]) + 1
		m["react"] = float(m["react"]) + reaction_ms
	else:
		m["miss"] = int(m["miss"]) + 1

	var bi: int = int(clampf(floorf(session_elapsed / 15.0), 0.0, float(_rep["blocks"].size() - 1)))

	var b: Dictionary = _rep["blocks"][bi]

	if success:
		b["ok"] = int(b["ok"]) + 1
	else:
		b["miss"] = int(b["miss"]) + 1


func _pct(ok: int, miss: int) -> float:

	var total: int = ok + miss

	if total <= 0:
		return -1.0

	return float(ok) / float(total) * 100.0


func _pct_text(p: float) -> String:

	if p < 0.0:
		return "--"

	return "%.0f%%" % p


func _bar_text(p: float) -> String:

	if p < 0.0:
		return "sem dados"

	var n: int = int(round(p / 10.0))

	return "#".repeat(n) + "-".repeat(10 - n)


func _report_row(data: Dictionary, key: String) -> Dictionary:

	for r in data["rows"]:
		if r["key"] == key:
			return r

	return {"key": key, "name": key, "ok": 0, "miss": 0, "total": 0, "prec": -1.0, "react": 0.0}


# Nota final (S/A/B/C/D): precisão pesa mais, depois reação e combo.
func _grade_for(summary: Dictionary) -> Dictionary:

	var p: float = float(summary["precision"])
	var avg: float = float(summary["avg_reaction_ms"])
	var attempts: int = int(summary["hits"]) + int(summary["misses"])

	var react_score: float = 0.0

	if avg > 0.0:
		react_score = clampf(1.0 - (avg - 350.0) / 900.0, 0.0, 1.0) * 100.0

	var combo_score: float = clampf(float(summary["best_combo"]) / 20.0, 0.0, 1.0) * 100.0

	var total: float = p * 0.6 + react_score * 0.25 + combo_score * 0.15

	if attempts < 5:
		total = minf(total, 45.0)

	var grade: String = "D"
	var stars: int = 1
	var col: Color = Color(0.95, 0.30, 0.30)

	if total >= 90.0:
		grade = "S"
		stars = 5
		col = Color(1.0, 0.82, 0.25)
	elif total >= 78.0:
		grade = "A"
		stars = 4
		col = Color(0.35, 0.92, 0.5)
	elif total >= 62.0:
		grade = "B"
		stars = 3
		col = Color(0.4, 0.85, 1.0)
	elif total >= 48.0:
		grade = "C"
		stars = 2
		col = Color(1.0, 0.6, 0.25)

	return {"grade": grade, "stars": stars, "color": col, "score": total}


func _report_compute(summary: Dictionary, won: bool) -> Dictionary:

	var rows: Array = []

	for key in MOVE_ORDER:

		var m: Dictionary = _rep["moves"].get(key, {"ok": 0, "miss": 0, "react": 0.0})
		var ok: int = int(m["ok"])
		var miss: int = int(m["miss"])
		var avg_react: float = 0.0

		if ok > 0:
			avg_react = float(m["react"]) / float(ok)

		rows.append({
			"key": key,
			"name": MOVE_NAMES[key],
			"ok": ok,
			"miss": miss,
			"total": ok + miss,
			"prec": _pct(ok, miss),
			"react": avg_react,
		})

	# 6 blocos de 15 s (gráfico) e 3 blocos de 30 s (texto / fadiga)
	var blocks6: Array = []

	for b in _rep["blocks"]:
		blocks6.append({
			"ok": int(b["ok"]),
			"miss": int(b["miss"]),
			"prec": _pct(int(b["ok"]), int(b["miss"])),
		})

	var blocks: Array = []

	var g_ok: Array = [0, 0, 0]
	var g_miss: Array = [0, 0, 0]

	for i in range(blocks6.size()):
		var g: int = mini(2, int(float(i) * 3.0 / float(blocks6.size())))
		g_ok[g] = int(g_ok[g]) + int(blocks6[i]["ok"])
		g_miss[g] = int(g_miss[g]) + int(blocks6[i]["miss"])

	for k in range(3):
		blocks.append({"ok": int(g_ok[k]), "miss": int(g_miss[k]), "prec": _pct(int(g_ok[k]), int(g_miss[k]))})

	# equilíbrio esquerda x direita (socos + defesas laterais)
	var l_ok: int = 0
	var l_total: int = 0
	var r_ok: int = 0
	var r_total: int = 0

	for r in rows:
		var rk: String = str(r["key"])
		if rk.ends_with("_left"):
			l_ok += int(r["ok"])
			l_total += int(r["total"])
		elif rk.ends_with("_right"):
			r_ok += int(r["ok"])
			r_total += int(r["total"])

	var balance: Dictionary = {
		"left_ok": l_ok,
		"left_total": l_total,
		"left_prec": _pct(l_ok, l_total - l_ok),
		"right_ok": r_ok,
		"right_total": r_total,
		"right_prec": _pct(r_ok, r_total - r_ok),
	}

	var dt: Dictionary = Time.get_datetime_dict_from_system()

	var date_text: String = "%02d/%02d/%04d  %02d:%02d" % [
		int(dt["day"]), int(dt["month"]), int(dt["year"]),
		int(dt["hour"]), int(dt["minute"])
	]

	var phase_idx: int = clampi(int(summary["max_phase"]), 1, Trainer.PHASES.size())

	return {
		"won": won,
		"summary": summary,
		"rows": rows,
		"blocks": blocks,
		"dt": dt,
		"date_text": date_text,
		"mode": MODE_NAMES.get(control_mode, control_mode),
		"difficulty": DIFFICULTY_NAMES.get(menu_difficulty, menu_difficulty),
		"difficulty_key": menu_difficulty,
		"phase_name": str(Trainer.PHASES[phase_idx - 1]["name"]),
		"prev": {},
		"blocks6": blocks6,
		"combos": _rep.get("combos", {"total": 0, "perfect": 0}),
		"balance": balance,
		"grade": _grade_for(summary),
		"arena": str(SCENARIOS[scenario_key]["name"]),
	}


# Diferença grande entre o lado esquerdo e o direito (mín. 3 tentativas
# em cada lado). Devolve "" se não houver diferença relevante.
func _side_gap_text(data: Dictionary, left_key: String, right_key: String, what: String) -> String:

	var l: Dictionary = _report_row(data, left_key)
	var r: Dictionary = _report_row(data, right_key)

	if int(l["total"]) < 3 or int(r["total"]) < 3:
		return ""

	var diff: float = float(l["prec"]) - float(r["prec"])

	if abs(diff) < 20.0:
		return ""

	var weaker: String = "esquerdo" if diff < 0.0 else "direito"
	var lp: float = float(l["prec"])
	var rp: float = float(r["prec"])

	return "%s: o lado %s teve precisão menor (esquerdo %s x direito %s). Diferenças entre os lados podem ter relação com mobilidade, força ou coordenação daquele lado — vale mostrar este relatório ao seu fisioterapeuta." % [
		what, weaker, _pct_text(lp), _pct_text(rp)
	]


func _report_recommendations(data: Dictionary) -> Array:

	var recs: Array = []
	var summary: Dictionary = data["summary"]

	var precision: float = float(summary["precision"])
	var avg_react: float = float(summary["avg_reaction_ms"])
	var attempts: int = int(summary["hits"]) + int(summary["misses"])

	# ---- qualidade dos dados ----
	if attempts < 8:
		recs.append("Poucas tentativas registradas neste treino (%d) — os números abaixo são pouco confiáveis. Faça o treino completo de %s para uma leitura melhor." % [attempts, _duration_text()])

	# ---- desempenho geral ----
	if precision >= 85.0:
		recs.append("Excelente precisão (%.0f%%). Para continuar evoluindo, aumente a dificuldade nas Configurações aos poucos." % precision)
	elif precision >= 60.0:
		recs.append("Bom desempenho (%.0f%%). Como sugestão geral, repita o treino algumas vezes por semana e acompanhe a precisão subir." % precision)
	else:
		recs.append("Precisão abaixo do esperado (%.0f%%). Tente a dificuldade FÁCIL, faça pausas entre os treinos e, se as dificuldades persistirem, converse com seu fisioterapeuta." % precision)

	# ---- reação ----
	if avg_react > 0.0:
		if avg_react <= 600.0:
			recs.append("Tempo de reação rápido (%.0f ms em média)." % avg_react)
		elif avg_react <= 1000.0:
			recs.append("Tempo de reação dentro do esperado (%.0f ms em média)." % avg_react)
		else:
			recs.append("Tempo de reação alto (%.0f ms em média). Isso pode refletir atenção, cansaço ou atraso do sistema de câmera; se você sentiu lentidão constante ao se mover, comente com um profissional." % avg_react)

	# ---- simetria (esquerda x direita) ----
	var punch_gap: String = _side_gap_text(data, "punch_left", "punch_right", "Socos")

	if punch_gap != "":
		recs.append(punch_gap)

	var dodge_gap: String = _side_gap_text(data, "dodge_left", "dodge_right", "Defesas laterais")

	if dodge_gap != "":
		recs.append(dodge_gap)

	# ---- defesa alta / agachar ----
	var duck_row: Dictionary = _report_row(data, "duck")

	if int(duck_row["total"]) >= 3 and float(duck_row["prec"]) < 50.0:
		recs.append("Muitos erros em defesa alta / agachar. Agache só até onde estiver confortável, com os pés firmes e o tronco estável. Se sentir dor no joelho, quadril ou lombar, interrompa. Exercícios de mobilidade orientados por um profissional podem ajudar.")

	# ---- fadiga ----
	var b_first: Dictionary = data["blocks"][0]
	var b_last: Dictionary = data["blocks"][2]

	if int(b_first["ok"]) + int(b_first["miss"]) >= 3 and int(b_last["ok"]) + int(b_last["miss"]) >= 3:

		var drop: float = float(b_first["prec"]) - float(b_last["prec"])

		if drop >= 20.0:
			recs.append("Queda de desempenho no final do treino (de %s para %s), o que pode indicar cansaço. Considere aquecimento antes, hidratação e intervalos maiores entre os treinos." % [
				_pct_text(float(b_first["prec"])), _pct_text(float(b_last["prec"]))
			])

	# ---- evolução ----
	var prev: Dictionary = data["prev"]

	if not prev.is_empty():

		var dp: float = precision - float(prev.get("precision", 0.0))

		if dp >= 5.0:
			recs.append("Evolução: a precisão subiu %.0f pontos em relação ao treino anterior. Continue assim!" % dp)
		elif dp <= -5.0:
			recs.append("A precisão caiu %.0f pontos em relação ao treino anterior. Isso é normal em alguns dias — descanso, sono e hidratação ajudam." % abs(dp))

	# ---- segurança (sempre) ----
	recs.append("Antes de treinar: 2 a 3 minutos de mobilidade de ombros, tronco e pernas; ao final, alongue com suavidade.")
	recs.append("Deixe espaço livre ao redor, use piso antiderrapante e, se houver risco de queda, treine com apoio ou supervisão.")
	recs.append("Pare imediatamente e procure atendimento se sentir dor, tontura, falta de ar, dor no peito ou mal-estar.")
	recs.append("Guarde os relatórios e leve ao seu fisioterapeuta: comparar treinos ao longo do tempo é o mais útil.")

	return recs


func _report_evolution_line(data: Dictionary) -> String:

	var prev: Dictionary = data["prev"]

	if prev.is_empty():
		return ""

	var summary: Dictionary = data["summary"]

	var dp: float = float(summary["precision"]) - float(prev.get("precision", 0.0))
	var pr_now: float = float(summary["avg_reaction_ms"])
	var pr_prev: float = float(prev.get("avg_reaction_ms", 0.0))

	var line: String = "Precisão: %.0f%% (antes %.0f%%, %+.0f pontos)" % [
		float(summary["precision"]), float(prev.get("precision", 0.0)), dp
	]

	if pr_now > 0.0 and pr_prev > 0.0:
		line += "  |  Reação média: %.0f ms (antes %.0f ms)" % [pr_now, pr_prev]

	if str(prev.get("difficulty", "")) != str(data["difficulty_key"]):
		line += "  |  (dificuldade diferente da anterior)"

	return line


func _report_plain_text(data: Dictionary, recs: Array) -> String:

	var s: Dictionary = data["summary"]
	var out: PackedStringArray = PackedStringArray()

	out.append("FBF - FisioBoxFight  |  RELATORIO DO TREINO")
	out.append("%s  /  %s" % [CREDIT_LINE_1, CREDIT_LINE_2])
	out.append("Data: %s   Modo: %s   Dificuldade: %s" % [data["date_text"], data["mode"], data["difficulty"]])
	out.append("Resultado: %s" % ("VITORIA POR NOCAUTE" if data["won"] else "DERROTA (nocauteado)"))
	out.append("")
	out.append("== RESUMO ==")
	out.append("Duracao: %d s   Pontuacao: %d   Melhor combo: %d   Fase maxima: %s" % [
		int(s["duration_sec"]), int(s["score"]), int(s["best_combo"]), data["phase_name"]
	])
	out.append("Precisao: %.0f%%   Acertos: %d   Erros: %d" % [float(s["precision"]), int(s["hits"]), int(s["misses"])])
	out.append("Combos de ataques: %d (perfeitos: %d)" % [int(data["combos"]["total"]), int(data["combos"]["perfect"])])
	out.append("Reacao media: %.0f ms   Melhor reacao: %.0f ms (inclui o atraso da camera)" % [
		float(s["avg_reaction_ms"]), float(s["best_reaction_ms"])
	])
	out.append("")
	out.append("== DESEMPENHO POR MOVIMENTO ==")
	out.append("%-24s %7s %6s %9s %10s" % ["Movimento", "Acertos", "Erros", "Precisao", "Reacao"])

	for r in data["rows"]:
		var react_txt: String = "--" if float(r["react"]) <= 0.0 else "%.0f ms" % float(r["react"])
		out.append("%-24s %7d %6d %9s %10s" % [
			r["name"], int(r["ok"]), int(r["miss"]), _pct_text(float(r["prec"])), react_txt
		])

	out.append("")
	out.append("== PRECISAO AO LONGO DO TREINO ==")

	var labels: Array = _third_labels()

	for i in range(3):
		var b: Dictionary = data["blocks"][i]
		out.append("%-9s %s  %s" % [labels[i], _bar_text(float(b["prec"])), _pct_text(float(b["prec"]))])

	var evo: String = _report_evolution_line(data)

	if evo != "":
		out.append("")
		out.append("== EVOLUCAO EM RELACAO AO TREINO ANTERIOR ==")
		out.append(evo)

	out.append("")
	out.append("== RECOMENDACOES ==")

	for rec in recs:
		out.append("- " + str(rec))

	out.append("")
	out.append("AVISO: este relatorio registra o desempenho no jogo e NAO e um diagnostico. Decisoes de saude e tratamento devem ser tomadas com medico ou fisioterapeuta.")

	return "\n".join(out)


func _report_bbcode(data: Dictionary, recs: Array) -> String:

	var s: Dictionary = data["summary"]
	var gold: String = "#f5b842"
	var out: PackedStringArray = PackedStringArray()

	out.append("[b]%s[/b]   |   Modo: %s   |   Dificuldade: %s" % [data["date_text"], data["mode"], data["difficulty"]])

	if data["won"]:
		out.append("[color=#59eb80][b]VITÓRIA POR NOCAUTE[/b][/color]")
	else:
		out.append("[color=#f24d4d][b]VOCÊ FOI NOCAUTEADO[/b][/color]")

	out.append("")
	out.append("[color=%s][b]RESUMO[/b][/color]" % gold)
	out.append("Pontuação: [b]%d[/b]   Melhor combo: [b]%d[/b]   Fase máxima: [b]%s[/b]" % [
		int(s["score"]), int(s["best_combo"]), data["phase_name"]
	])
	out.append("Precisão: [b]%.0f%%[/b]   Acertos: [b]%d[/b]   Erros: [b]%d[/b]" % [
		float(s["precision"]), int(s["hits"]), int(s["misses"])
	])
	out.append("Combos de ataques: [b]%d[/b]   Perfeitos: [b]%d[/b]" % [int(data["combos"]["total"]), int(data["combos"]["perfect"])])
	out.append("Reação média: [b]%.0f ms[/b]   Melhor reação: [b]%.0f ms[/b]  (inclui o atraso da câmera)" % [
		float(s["avg_reaction_ms"]), float(s["best_reaction_ms"])
	])

	out.append("")
	out.append("[color=%s][b]DESEMPENHO POR MOVIMENTO[/b][/color]" % gold)

	var table: String = "[table=5]"
	for h in ["Movimento   ", "Acertos   ", "Erros   ", "Precisão   ", "Reação"]:
		table += "[cell][b]%s[/b][/cell]" % h

	for r in data["rows"]:
		var react_txt: String = "--" if float(r["react"]) <= 0.0 else "%.0f ms" % float(r["react"])
		table += "[cell]%s   [/cell][cell]%d[/cell][cell]%d[/cell][cell]%s[/cell][cell]%s[/cell]" % [
			r["name"], int(r["ok"]), int(r["miss"]), _pct_text(float(r["prec"])), react_txt
		]

	table += "[/table]"
	out.append(table)

	out.append("")
	out.append("[color=%s][b]PRECISÃO AO LONGO DO TREINO[/b][/color]" % gold)

	var labels: Array = _third_labels()

	for i in range(3):
		var b: Dictionary = data["blocks"][i]
		out.append("%s   [color=#8ecbff]%s[/color]   %s" % [labels[i], _bar_text(float(b["prec"])), _pct_text(float(b["prec"]))])

	var evo: String = _report_evolution_line(data)

	if evo != "":
		out.append("")
		out.append("[color=%s][b]EVOLUÇÃO EM RELAÇÃO AO TREINO ANTERIOR[/b][/color]" % gold)
		out.append(evo)

	out.append("")
	out.append("[color=%s][b]RECOMENDAÇÕES[/b][/color]" % gold)

	for rec in recs:
		out.append("• " + str(rec))

	out.append("")
	out.append("[i][color=#c8c8c8]Este relatório registra o desempenho no jogo e NÃO é um diagnóstico. Decisões de saúde e tratamento devem ser tomadas com médico ou fisioterapeuta.[/color][/i]")

	return "\n".join(out)


# ------------------------------------------------------------
# Histórico simples entre treinos (user://fbf_history.json)
# ------------------------------------------------------------

func _history_load() -> Array:

	if not FileAccess.file_exists(HISTORY_PATH):
		return []

	var f := FileAccess.open(HISTORY_PATH, FileAccess.READ)

	if f == null:
		return []

	var parsed: Variant = JSON.parse_string(f.get_as_text())

	if parsed is Array:
		return parsed

	return []


func _history_append(entry: Dictionary) -> void:

	var arr: Array = _history_load()

	arr.append(entry)

	while arr.size() > 60:
		arr.remove_at(0)

	var f := FileAccess.open(HISTORY_PATH, FileAccess.WRITE)

	if f == null:
		return

	f.store_string(JSON.stringify(arr))
	f.close()


func _report_save_file(data: Dictionary) -> String:

	DirAccess.make_dir_recursive_absolute(REPORT_DIR)

	var dt: Dictionary = data["dt"]

	var file_name: String = "relatorio_%04d%02d%02d_%02d%02d%02d.txt" % [
		int(dt["year"]), int(dt["month"]), int(dt["day"]),
		int(dt["hour"]), int(dt["minute"]), int(dt["second"])
	]

	var path: String = REPORT_DIR.path_join(file_name)

	var f := FileAccess.open(path, FileAccess.WRITE)

	if f == null:
		return ""

	f.store_string(report_plain)
	f.close()

	return path


# Gera tudo no fim do treino (chamado por _end_session).
func _generate_report(summary: Dictionary, won: bool) -> void:

	var data: Dictionary = _report_compute(summary, won)

	var history: Array = _history_load()

	if not history.is_empty() and history.back() is Dictionary:
		data["prev"] = history.back()

	var recs: Array = _report_recommendations(data)

	report_plain = _report_plain_text(data, recs)

	last_report_data = data
	last_report_recs = recs

	_fill_final_screen()

	if report_text_label:
		report_text_label.text = _report_bbcode(data, recs)
		report_text_label.scroll_to_line(0)

	var saved_path: String = _report_save_file(data)

	if report_path_label:
		if saved_path != "":
			report_path_label.text = "Relatório salvo em: " + ProjectSettings.globalize_path(saved_path)
		else:
			report_path_label.text = "Não foi possível salvar o arquivo do relatório."

	_history_append({
		"t": Time.get_unix_time_from_system(),
		"precision": float(summary["precision"]),
		"avg_reaction_ms": float(summary["avg_reaction_ms"]),
		"score": int(summary["score"]),
		"hits": int(summary["hits"]),
		"misses": int(summary["misses"]),
		"difficulty": menu_difficulty,
		"mode": control_mode,
	})


func _build_report_screen() -> void:

	var screen := _make_screen("report")

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	screen.add_child(center)

	var panel := PanelContainer.new()

	var sb := _panel_style()
	sb.content_margin_left = 28
	sb.content_margin_right = 28
	sb.content_margin_top = 16
	sb.content_margin_bottom = 16
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.custom_minimum_size = Vector2(900, 0)
	panel.add_child(vbox)

	# cabeçalho: logo pequena + título
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 14)
	head.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_child(head)

	var logo_tex := _load_logo()

	if logo_tex:
		var logo := TextureRect.new()
		logo.texture = logo_tex
		logo.custom_minimum_size = Vector2(56, 57)
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		head.add_child(logo)

	var title_box := VBoxContainer.new()
	head.add_child(title_box)

	title_box.add_child(_make_title("RELATÓRIO DO TREINO", 24, COLOR_GOLD))
	title_box.add_child(_make_title("%s  •  %s" % [CREDIT_LINE_1, CREDIT_LINE_2], 12))

	report_text_label = RichTextLabel.new()
	report_text_label.bbcode_enabled = true
	report_text_label.scroll_active = true
	report_text_label.fit_content = false
	report_text_label.custom_minimum_size = Vector2(900, 440)
	report_text_label.add_theme_font_size_override("normal_font_size", 14)
	report_text_label.add_theme_font_size_override("bold_font_size", 14)
	report_text_label.add_theme_font_size_override("italics_font_size", 13)
	report_text_label.text = "Termine um treino para ver o relatório."
	vbox.add_child(report_text_label)

	report_path_label = _make_title("", 10)
	report_path_label.modulate = Color(0.75, 0.75, 0.8)
	vbox.add_child(report_path_label)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_child(row)

	var back_btn := _make_button("◀ Voltar")
	back_btn.pressed.connect(
		func():
			_go_back()
	)
	row.add_child(back_btn)

	var folder_btn := _make_button("Abrir pasta dos relatórios")
	folder_btn.pressed.connect(
		func():
			DirAccess.make_dir_recursive_absolute(REPORT_DIR)
			OS.shell_open(ProjectSettings.globalize_path(REPORT_DIR))
	)
	row.add_child(folder_btn)

	var again_btn := _make_button("Tentar Novamente")
	again_btn.pressed.connect(start_game)
	row.add_child(again_btn)

	var menu_btn := _make_button("Menu Principal")
	menu_btn.pressed.connect(quit_to_menu)
	row.add_child(menu_btn)


# ============================================================
# TELAS
# ============================================================

func show_screen(name: String, record: bool = true) -> void:

	# histórico: guarda a tela de onde você veio (só telas "de navegação")
	if record and current_screen != "" and current_screen != name and current_screen in NAV_SCREENS:
		_screen_history.append(current_screen)

	if name == "menu":
		_screen_history.clear()

	current_screen = name

	for key in screens.keys():

		screens[key].visible = false


	if screens.has(name):

		screens[name].visible = true


	# O menu agora MOSTRA o mundo 3D (o treinador aponta pro jogador);
	# só o tutorial continua com o mundo escondido.
	if world_root:

		world_root.visible = (
			name != "howto"
			and name != "minigame67"
		)

	if name == "menu" or name == "scenarios":
		_enter_menu_scene()
	else:
		_exit_menu_scene()

	# minijogo 67: liga a escuta da câmera Python (gesto da balança) enquanto aberto
	if name == "minigame67":
		_minigame_camera_on()
	else:
		_minigame_camera_off()

	_update_global_back()


# Volta pra tela anterior (a de onde você veio). Sem histórico, vai pro menu.
func _go_back() -> void:

	while not _screen_history.is_empty():

		var prev: String = _screen_history.pop_back()

		if prev != current_screen and screens.has(prev):
			show_screen(prev, false)
			return

	if current_screen != "menu":
		show_screen("menu", false)


func _build_global_back() -> void:

	global_back_btn = _menu_button("◀  VOLTAR", 20)
	global_back_btn.set_anchors_preset(Control.PRESET_TOP_LEFT)
	global_back_btn.custom_minimum_size = Vector2(170, 46)
	global_back_btn.offset_left = 16
	global_back_btn.offset_top = 14
	global_back_btn.offset_right = 186
	global_back_btn.offset_bottom = 60
	global_back_btn.alignment = HORIZONTAL_ALIGNMENT_CENTER
	global_back_btn.visible = false
	global_back_btn.pressed.connect(_go_back)
	ui_layer.add_child(global_back_btn)


# O botão "voltar" fixo aparece nas páginas que não têm o seu próprio no canto.
func _update_global_back() -> void:

	if global_back_btn:
		global_back_btn.visible = current_screen in ["howto", "scenarios", "report"]


# ============================================================
# COMEÇAR JOGO
# ============================================================

# ============================================================
# AUTO-LANCAMENTO DA CAMERA (so Windows) — SEM JANELA DE TERMINAL
# ============================================================
# Nao usa cmd.exe nem os .bat (esses continuam existindo pra quem
# quiser rodar na mao/depurar, mas abrem uma janela preta de proposito
# pra mostrar erro). Aqui a ideia e abrir tudo escondido:
#   - se existir movimentos.exe / ponte_jogo.exe (compilados com
#     PyInstaller usando --noconsole, ver COMO_GERAR_O_EXE.txt), usa
#     eles direto - sem console nenhum.
#   - senao, cai pro "pythonw" (o Python "sem janela" que ja vem
#     junto com qualquer instalacao normal de Python no Windows, do
#     lado do "python.exe") rodando os .py direto.
# Em qualquer um dos dois casos, a UNICA janela que aparece e a da
# propria webcam (isso e proposital, pra voce se ver treinando).
func _parent_dir(path: String) -> String:

	return path.trim_suffix("/").trim_suffix("\\").get_base_dir()


# Acha a pasta CameraSensores: dentro do projeto (res://CameraSensores), uma pasta acima
# (CameraSensores ao lado de TreinoDeReflexo3D) ou perto do .exe exportado. Antes só
# procurava perto do .exe, então rodando pelo editor (F5) nunca achava.
func _find_camera_dir() -> String:

	var res_dir: String = ProjectSettings.globalize_path("res://")
	var exe_dir: String = OS.get_executable_path().get_base_dir()

	var candidatos: Array[String] = [
		res_dir.path_join("CameraSensores"),
		_parent_dir(res_dir).path_join("CameraSensores"),
		exe_dir.path_join("CameraSensores"),
		_parent_dir(exe_dir).path_join("CameraSensores"),
	]

	for c in candidatos:
		if FileAccess.file_exists(c.path_join("movimentos.py")) or FileAccess.file_exists(c.path_join("movimentos.exe")):
			return c

	return ""


# Tenta abrir um script Python escondido (sem janela de terminal). Devolve o PID ou -1.
func _spawn_python(camera_dir: String, script_args: Array) -> int:

	var venv_scripts: String = camera_dir.path_join(".venv").path_join("Scripts")
	var launchers: Array[String] = [
		venv_scripts.path_join("pythonw.exe"),
		"pythonw",
		"pyw",
		venv_scripts.path_join("python.exe"),
		"python",
	]

	for exe in launchers:

		# caminhos absolutos que não existem são pulados; nomes soltos ("pythonw") vêm do PATH
		if exe.is_absolute_path() and not FileAccess.file_exists(exe):
			continue

		var pid: int = OS.create_process(exe, script_args, false)

		if pid != -1:
			return pid

	return -1


func _garantir_camera_python() -> void:

	if _pid_detector != -1 and _pid_ponte != -1:
		return  # ja lancados nesta sessao do jogo

	var camera_dir: String = _find_camera_dir()

	if camera_dir == "":
		_camera_error = "Não achei a pasta CameraSensores (dentro do projeto, ao lado dele ou do .exe)."
		push_warning(
			"FBF: nao encontrei a pasta CameraSensores (procurei dentro do projeto, " +
			"uma pasta acima e perto do .exe). Abra iniciar_detector.bat e " +
			"iniciar_ponte.bat manualmente."
		)
		return

	# arquivo combinado entre os dois processos pra saber o movimento
	# mais recente - um caminho absoluto, entao nao importa de onde
	# cada processo foi realmente iniciado.
	var log_path: String = camera_dir.path_join("movimento_ao_vivo.log")

	var exe_detector: String = camera_dir.path_join("movimentos.exe")
	var exe_ponte: String = camera_dir.path_join("tools").path_join("ponte_jogo.exe")

	# Qual CameraSensores está sendo usado? (pode haver mais de uma cópia no PC) e ele é
	# NOVO o bastante pra mandar o vídeo pro jogo? O movimentos.py novo tem "--video-porta".
	_camera_dir_used = camera_dir

	var py_detector_path: String = camera_dir.path_join("movimentos.py")
	var py_exists: bool = FileAccess.file_exists(py_detector_path)

	_camera_script_old = false

	if camera_in_game and py_exists:
		_camera_script_old = not FileAccess.get_file_as_string(py_detector_path).contains("--video-porta")

	# um movimentos.exe antigo (compilado) não manda vídeo: se o .py novo existe, usa ele
	var use_exe_detector: bool = FileAccess.file_exists(exe_detector) and not (camera_in_game and py_exists and not _camera_script_old)

	# câmera dentro do jogo: o detector manda os quadros por UDP (e, por padrão, esconde a
	# janela separada do OpenCV — a imagem aparece no canto superior esquerdo do jogo)
	var det_args: Array = [log_path]

	if camera_in_game:
		det_args.append_array(["--video-porta", str(CameraInputUDP.VIDEO_PORTA)])

		if not camera_window_visible:
			det_args.append("--sem-janela")

	if use_exe_detector:
		_pid_detector = OS.create_process(exe_detector, det_args, false)
	else:
		var py_args: Array = [camera_dir.path_join("tools").path_join("lancador.py"), py_detector_path]
		py_args.append_array(det_args)
		_pid_detector = _spawn_python(camera_dir, py_args)

		# Python não achado: tenta o .exe compilado, se existir
		if _pid_detector == -1 and FileAccess.file_exists(exe_detector):
			_pid_detector = OS.create_process(exe_detector, det_args, false)

	if FileAccess.file_exists(exe_ponte):
		_pid_ponte = OS.create_process(exe_ponte, ["--log", log_path], false)
	else:
		_pid_ponte = _spawn_python(camera_dir, [camera_dir.path_join("tools").path_join("lancador.py"), camera_dir.path_join("tools").path_join("ponte_jogo.py"), "--log", log_path])

	if _pid_detector == -1 or _pid_ponte == -1:
		_camera_error = "Não achei o Python. Instale o Python 3.11 (marque 'Add to PATH') ou use o JOGAR.bat."
		push_warning(
			"FBF: nao consegui abrir a camera sozinho (Python nao encontrado?). " +
			"Instale o Python 3.11 (com 'Add to PATH') ou abra iniciar_detector.bat e " +
			"iniciar_ponte.bat manualmente."
		)


# Fecha o detector e a ponte que ESTE jogo abriu.
func _parar_camera_python() -> void:

	if _pid_detector != -1:
		OS.kill(_pid_detector)

	if _pid_ponte != -1:
		OS.kill(_pid_ponte)

	_pid_detector = -1
	_pid_ponte = -1


# ------------------------------------------------------------
# Botão "ABRIR CÂMERA" + status
# ------------------------------------------------------------

func _start_camera() -> void:

	# a ponte manda os movimentos por UDP: o jogo precisa estar escutando a porta
	CameraInputUDP.iniciar()

	_camera_error = ""
	_camera_launch_msec = Time.get_ticks_msec()
	_garantir_camera_python()
	_camera_state_shown = ""


func _stop_camera() -> void:

	_parar_camera_python()
	_camera_state_shown = ""


func _on_camera_open_pressed() -> void:

	if _pid_detector != -1:
		_stop_camera()
	else:
		_select_mode("camera_mediapipe")
		_start_camera()

	_refresh_camera_buttons()


func _camera_autostart_check() -> void:

	_camera_autostart_ready = true

	if control_mode == "camera_mediapipe" and camera_autostart:
		_start_camera()


# Mudou "câmera no jogo"/"janela separada": salva e, se o detector já está aberto,
# reabre ele com a nova configuração.
func _on_camera_view_settings_changed() -> void:

	_save_settings()

	if _pid_detector != -1:
		_stop_camera()
		_start_camera()

	_refresh_camera_buttons()


func _apply_camera_view_size() -> void:

	if camera_view:
		camera_view.custom_minimum_size = Vector2(256, 144) if camera_view_size == 1 else Vector2(208, 117)


func _refresh_camera_buttons() -> void:

	if btn_camera_size:
		btn_camera_size.text = "TAMANHO DA CÂMERA NO JOGO: %s" % ("MÉDIO" if camera_view_size == 1 else "PEQUENO")

	if btn_camera_ingame:
		btn_camera_ingame.text = "CÂMERA NO CANTO DO JOGO: %s" % ("SIM" if camera_in_game else "NÃO")

	if btn_camera_window:
		btn_camera_window.text = "JANELA SEPARADA DA CÂMERA: %s" % ("SIM" if camera_window_visible else "NÃO")

	if btn_camera_open:
		btn_camera_open.text = "📷  FECHAR A CÂMERA" if _pid_detector != -1 else "📷  ABRIR CÂMERA AGORA"

	if btn_camera_auto:
		btn_camera_auto.text = "ABRIR SOZINHA AO INICIAR: %s" % ("SIM" if camera_autostart else "NÃO")


# "ok" = chegando dados | "starting" = abrindo/calibrando | "nosignal" = aberta mas sem dados | "off"
func _camera_state() -> String:

	var now: int = Time.get_ticks_msec()
	var last: int = maxi(CameraInputUDP.last_packet_msec, CameraInputUDP.last_balanca_msec)

	if last > 0 and now - last < 3500:
		return "ok"

	if _pid_detector == -1:
		return "error" if _camera_error != "" else "off"

	if now - _camera_launch_msec < 12000:
		return "starting"

	return "nosignal"


func _update_camera_ui() -> void:

	var st: String = _camera_state()
	var now: int = Time.get_ticks_msec()
	var blink: bool = int(now / 400) % 2 == 0

	var live: bool = (
		camera_in_game
		and control_mode == "camera_mediapipe"
		and CameraInputUDP.video_texture != null
		and CameraInputUDP.last_video_msec > 0
		and now - CameraInputUDP.last_video_msec < 1500
	)

	# há quanto tempo a câmera está "ok" (movimentos chegando) sem vídeo?
	if st == "ok":
		if _camera_ok_since_msec == 0:
			_camera_ok_since_msec = now
	else:
		_camera_ok_since_msec = 0

	var no_video: bool = (
		camera_in_game
		and st == "ok"
		and not live
		and _camera_ok_since_msec > 0
		and now - _camera_ok_since_msec > 6000
	)

	# webcam no canto superior esquerdo (no lugar do bonequinho)
	if camera_view:

		if camera_view.visible != live:
			camera_view.visible = live

			if avatar:
				avatar.visible = not live

			if portrait_who:
				portrait_who.visible = not live

		if live:
			camera_view.texture = CameraInputUDP.video_texture
			camera_view_live.modulate.a = 1.0 if blink else 0.45

	# chip do HUD (só aparece no modo Câmera Python durante a partida)
	if hud_camera_chip:
		hud_camera_chip.visible = control_mode == "camera_mediapipe" and state == State.PLAYING

		if hud_camera_chip.visible:
			if no_video:
				hud_camera_chip.text = "!  SEM VÍDEO NO JOGO" if not _camera_script_old else "!  ATUALIZE O CameraSensores"
			else:
				match st:
					"ok":
						hud_camera_chip.text = ("●  CÂMERA ATIVA" if blink else "○  CÂMERA ATIVA")
					"starting":
						hud_camera_chip.text = "…  ABRINDO A CÂMERA"
					"nosignal":
						hud_camera_chip.text = "!  SEM SINAL (clique)"
					_:
						hud_camera_chip.text = "×  CÂMERA DESLIGADA (clique)"

	if camera_status_label == null:
		return

	var key: String = "%s|%s|%s|%s" % [st, str(_camera_script_old), str(live), str(no_video)]

	if key == _camera_state_shown:
		return

	_camera_state_shown = key

	var extra: String = ""

	if _camera_dir_used != "":
		extra = "\nPasta usada: %s" % _camera_dir_used

	if _camera_script_old and camera_in_game:
		extra += "\n⚠ Esse CameraSensores é ANTIGO (o movimentos.py não manda vídeo pro jogo). Troque a pasta CameraSensores pela do zip novo e clique em FECHAR / ABRIR a câmera."

	match st:
		"ok":
			if live:
				camera_status_label.text = "Câmera ATIVA — a imagem aparece no canto superior esquerdo do jogo." + extra
				camera_status_label.add_theme_color_override("font_color", Color(0.4, 0.95, 0.5))
			elif no_video:
				camera_status_label.text = "Câmera ativa, mas o VÍDEO não está chegando ao jogo (porta %d bloqueada/ocupada, ou CameraSensores antigo)." % CameraInputUDP.VIDEO_PORTA + extra
				camera_status_label.add_theme_color_override("font_color", Color(1.0, 0.6, 0.4))
			else:
				camera_status_label.text = "Câmera ATIVA — recebendo seus movimentos." + extra
				camera_status_label.add_theme_color_override("font_color", Color(0.4, 0.95, 0.5))
		"error":
			camera_status_label.text = _camera_error
			camera_status_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.45))
		"starting":
			camera_status_label.text = ("Abrindo a câmera... a imagem aparece no CANTO SUPERIOR ESQUERDO do jogo. Fique parado em posição de luta ~5 s (calibração)." if camera_in_game else "Abrindo a câmera... a janela da webcam abre no CANTO INFERIOR DIREITO da tela (sempre na frente). Fique parado em posição de luta ~5 s (calibração).") + extra
			camera_status_label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.5))
		"nosignal":
			camera_status_label.text = "A câmera abriu mas não manda dados. Se apareceu um aviso de erro, ele diz o motivo (detalhes em CameraSensores/camera_erro.log)." + extra
			camera_status_label.add_theme_color_override("font_color", Color(1.0, 0.6, 0.4))
		_:
			camera_status_label.text = "Câmera desligada."
			camera_status_label.add_theme_color_override("font_color", Color(0.85, 0.85, 0.9))

	_refresh_camera_buttons()


# Fecha a camera e a ponte junto quando o jogo e fechado (agora mata
# o processo de verdade, ja que nao passa mais por um cmd.exe no meio).
func _notification(what: int) -> void:

	if what == NOTIFICATION_WM_CLOSE_REQUEST:

		_parar_camera_python()

		get_tree().quit()


func start_game() -> void:

	get_tree().paused = false

	GameManager.reset_scoring()

	_report_reset()

	session_elapsed = 0.0

	_last_phase_shown = 1

	GameManager.register_phase(1)

	current_sequence = []
	_seq_index = 0
	current_challenge = {}

	Trainer._last_type = ""
	Trainer._last_combo_at = -999.0
	_combo_clean = true

	if combo_label:
		combo_label.modulate.a = 0.0

	state = State.PLAYING

	# modo ALEATÓRIO: nova arena a cada partida
	if menu_scenario == "random":
		_apply_scenario("random")

	_ko_id += 1
	_reset_after_knockout()

	show_screen("hud")

	hud_time.text = _duration_text(true)

	feedback_label.modulate.a = 0.0
	flash_rect.modulate.a = 0.0
	prompt_panel_ref.modulate.a = 0.0


	# ========================================================
	# TREINADOR COMEÇA EM GUARDA
	# ========================================================

	trainer_actor.set_guard()


	_patient_reset()

	_player_arms_raise_guard_intro()

	_indicators_reset()

	_show_round_banner()


	_camera_watchdog_done = false
	camera_preview_rect.visible = false


	# ========================================================
	# CÂMERA
	# ========================================================

	if control_mode == "camera":

		var result: Dictionary = CameraInput.try_start()

		_show_status(
			result["message"],
			not result["ok"]
		)

		if result["ok"]:

			_camera_started_at = Time.get_ticks_msec()

			camera_preview_rect.texture = (
				CameraInput.get_preview_texture()
			)

			camera_preview_rect.flip_h = CameraInput.mirror

			camera_preview_rect.visible = true

		else:

			control_mode = "keyboard"


	elif control_mode == "camera_mediapipe":

		var result_udp: Dictionary = CameraInputUDP.iniciar()

		_show_status(
			result_udp["message"],
			not result_udp["ok"]
		)

		if result_udp["ok"]:

			_camera_started_at = Time.get_ticks_msec()

			# Marca a fonte externa como ativa imediatamente — o
			# processo Python leva uns segundos calibrando antes de
			# mandar o primeiro gesto, e não queremos que o watchdog
			# da câmera confunda isso com "câmera não respondeu".
			CameraInput.activate_external_source()

		else:

			control_mode = "keyboard"


	if control_mode == "keyboard":

		InputHandler.enable()


	_schedule_next_spawn()


# ============================================================
# INPUT
# ============================================================

func _sample_input() -> String:

	if control_mode == "camera" or control_mode == "camera_mediapipe":

		return CameraInput.sample()

	return InputHandler.sample()


const GESTURE_NAMES := {
	"dodge_left": "vi: ESQUIVA ESQUERDA",
	"dodge_right": "vi: ESQUIVA DIREITA",
	"duck": "vi: DEFESA ALTA / AGACHAR",
	"punch_left": "vi: SOCO ESQUERDA",
	"punch_right": "vi: SOCO DIREITA",
}


# Mostra na prévia da câmera o gesto que foi detectado — ajuda o
# jogador a entender o que a câmera está vendo.
func _on_camera_gesture_seen(gesture: String) -> void:

	if camera_guide and camera_preview_rect.visible:
		camera_guide.show_gesture(GESTURE_NAMES.get(gesture, gesture))

	_on_input_recognized(gesture)


# Um movimento foi reconhecido (câmera ou teclado): o boneco do jogador
# faz o mesmo movimento e o indicador daquele movimento dá um brilho —
# assim o jogador vê na hora que a ação foi entendida, mesmo que não
# fosse a que o jogo pediu. (Acertar/errar é resolvido em
# _resolve_challenge, que não mudou.)
func _on_input_recognized(response: String) -> void:

	if state != State.PLAYING:
		return

	if avatar:

		# na câmera Python, "AGACHAR" e "DEFESA ALTA" viram a mesma resposta
		# ("duck"); o boneco separa: agachar = corpo desce, defesa alta = luvas no rosto
		if response == "duck" and control_mode == "camera_mediapipe" and CameraInputUDP.last_label == "AGACHAR":
			avatar.play("crouch")
		else:
			avatar.play(response)

	var ind := _indicator_for(response)

	if ind:
		ind.flash(Color(1.0, 0.92, 0.45))


func _indicator_for(response: String) -> ActionIndicator:

	if indicators.has(response):
		return indicators[response]

	return null


func _indicators_reset() -> void:

	for key in indicators.keys():

		var ind: ActionIndicator = indicators[key]

		ind.set_state("idle")


# Treinador começou a se preparar: acende (pulsando) o indicador da
# ação que vai ser pedida.
func _indicators_prepare(response: String) -> void:

	_indicators_reset()

	var ind := _indicator_for(response)

	if ind:
		ind.set_state("prep")


# Janela de reação aberta: FAÇA AGORA.
func _indicators_now(response: String) -> void:

	var ind := _indicator_for(response)

	if ind:
		ind.set_state("now")


# Resultado do desafio: ✓ verde se acertou, vermelho se errou/tempo.
func _indicator_result(response: String, success: bool) -> void:

	var ind := _indicator_for(response)

	if ind == null:
		return

	if success:
		ind.set_state("ok", 0.7)
	else:
		ind.set_state("miss", 0.7)


func _show_status(
	message: String,
	is_error: bool
) -> void:

	status_label.text = message

	status_label.modulate = (
		Color(0.95, 0.4, 0.4)
		if is_error
		else Color(0.6, 0.95, 0.6)
	)

	status_label.visible = true

	status_timer.start()


# ============================================================
# DESAFIOS
# ============================================================

func _schedule_next_spawn() -> void:

	spawn_timer.start(
		Trainer.spawn_interval_for(
			session_elapsed
		)
	)


func _on_spawn_timeout() -> void:

	if state != State.PLAYING:
		return


	current_sequence = Trainer.generate_sequence(
		session_elapsed
	)

	_seq_index = 0


	_start_challenge(
		current_sequence[0]
	)


func _on_gap_timeout() -> void:

	if state != State.PLAYING:
		return


	if _seq_index < current_sequence.size():

		_start_challenge(
			current_sequence[_seq_index]
		)

	else:

		current_sequence = []

		trainer_actor.set_guard()

		_schedule_next_spawn()


# ============================================================
# COMEÇA DESAFIO
# ============================================================

func _start_challenge(
	challenge: Dictionary
) -> void:

	current_challenge = challenge

	_combo_on_start(challenge)

	challenge_started_at = session_elapsed

	_challenge_subphase = "telegraph"


	var ctype: String = challenge["type"]

	var telegraph_dur: float = (
		challenge["telegraph_ms"] / 1000.0
	)


	# ========================================================
	# TREINADOR PREPARA O GOLPE
	# ========================================================

	var wind_pose: String = (
		ctype
		if Trainer.OPEN_TYPES.has(ctype)
		else ctype + "_wind"
	)


	trainer_actor.go_to_pose(
		wind_pose,
		telegraph_dur
	)


	_patient_reset()


	# ========================================================
	# SINAL
	# ========================================================

	prompt_icon.sign_type = challenge["response"]

	prompt_icon.modulate = Color(
		1,
		0.82,
		0.45
	)

	prompt_icon.scale = Vector2(
		1.0,
		1.0
	)

	prompt_panel_ref.modulate.a = 1.0

	_indicators_prepare(challenge["response"])


# ============================================================
# LOOP
# ============================================================

func _process(delta: float) -> void:

	_update_camera_ui()

	if fps_label and fps_label.visible:
		fps_label.text = "%d FPS\n%s  •  %s" % [
			int(Engine.get_frames_per_second()),
			RenderingServer.get_video_adapter_name(),
			RenderingServer.get_current_rendering_method()
		]

	if state != State.PLAYING:
		return


	# ========================================================
	# WATCHDOG DA CÂMERA
	# ========================================================

	if (control_mode == "camera" or control_mode == "camera_mediapipe") and not _camera_watchdog_done:

		if Time.get_ticks_msec() - _camera_started_at > 2500:

			_camera_watchdog_done = true

			if not CameraInput.has_valid_frame():

				CameraInput.stop()

				camera_preview_rect.visible = false

				control_mode = "keyboard"

				InputHandler.enable()

				_show_status(
					"Não foi possível ler imagens da câmera. Usando teclado.",
					true
				)


	# ========================================================
	# TEMPO
	# ========================================================

	session_elapsed += delta


	if session_elapsed >= GameManager.SESSION_DURATION_SEC:

		session_elapsed = GameManager.SESSION_DURATION_SEC

		_update_time_label()

		_end_session()

		return


	# ========================================================
	# FASE
	# ========================================================

	var phase_now := Trainer.get_phase_index(
		session_elapsed
	)


	if phase_now != _last_phase_shown:

		_last_phase_shown = phase_now

		GameManager.register_phase(
			phase_now
		)

		_show_phase_toast(
			Trainer.get_phase(
				session_elapsed
			)["name"]
		)

		if phase_now > 1:

			AudioManager.play(
				"phase_up"
			)


	_update_time_label()


	# ========================================================
	# DESAFIO
	# ========================================================

	if not current_challenge.is_empty():

		_process_challenge()


# ============================================================
# TEMPO
# ============================================================

func _update_time_label() -> void:

	var remaining: float = max(
		0.0,
		GameManager.SESSION_DURATION_SEC - session_elapsed
	)

	var m: int = int(remaining) / 60
	var s: int = int(remaining) % 60

	hud_time.text = "%02d:%02d" % [m, s]

	# telão da arena mostra o placar ao vivo (outros cenários ignoram)
	if scenario_node:
		scenario_node.set_scoreboard(hud_time.text, GameManager.score, GameManager.get_precision())


# ============================================================
# PROCESSA DESAFIO
# ============================================================

func _process_challenge() -> void:

	var ctype: String = current_challenge["type"]

	var telegraph_dur: float = (
		current_challenge["telegraph_ms"] / 1000.0
	)

	var window_dur: float = (
		current_challenge["window_ms"] / 1000.0
	)

	var t: float = (
		session_elapsed - challenge_started_at
	)


	# ========================================================
	# PREPARAÇÃO
	# ========================================================

	if t < telegraph_dur:

		_challenge_subphase = "telegraph"


	# ========================================================
	# MOMENTO DO GOLPE
	# ========================================================

	elif t < telegraph_dur + window_dur:

		if _challenge_subphase != "window":

			_challenge_subphase = "window"

			_drive_trainer_window_start(
				ctype
			)


	# ========================================================
	# TEMPO ESGOTADO
	# ========================================================

	else:

		_resolve_challenge(
			false,
			""
		)

		return


	var resp: String = _sample_input()


	if resp != "":

		# No modo câmera, um gesto diferente do pedido é ignorado (a
		# detecção por movimento não é 100% — o jogador não deve perder
		# ponto por erro do sensor). Só o tempo esgotado conta como erro.
		# No teclado continua valendo: tecla errada = erro.
		if (control_mode == "camera" or control_mode == "camera_mediapipe") and resp != current_challenge["response"]:
			return

		_resolve_challenge(
			resp == current_challenge["response"],
			resp
		)


# ============================================================
# TREINADOR ATACA
# ============================================================

func _drive_trainer_window_start(
	ctype: String
) -> void:

	if not Trainer.OPEN_TYPES.has(ctype):

		trainer_actor.go_to_pose(
			ctype + "_strike",
			0.08
		)


	if not current_challenge.is_empty():

		_indicators_now(current_challenge["response"])

		prompt_icon.modulate = Color(
			1,
			1,
			1
		)

		var tw := create_tween()

		tw.tween_property(
			prompt_icon,
			"scale",
			Vector2(1.18, 1.18),
			0.08
		)

		tw.tween_property(
			prompt_icon,
			"scale",
			Vector2(1.0, 1.0),
			0.08
		)


# ============================================================
# TREINADOR VOLTA
# ============================================================

func _drive_trainer_resolved() -> void:

	get_tree().create_timer(
		0.35
	).timeout.connect(
		func():

			if is_instance_valid(trainer_actor):

				if current_challenge.is_empty():

					trainer_actor.set_guard()
	)


# ============================================================
# TWEEN
# ============================================================

func _kill_tween(t: Tween) -> void:

	if t and t.is_valid():

		t.kill()


# ============================================================
# RESET DO PACIENTE
# ============================================================

func _patient_reset() -> void:

	_kill_tween(_camera_pose_tween)


	var tw := create_tween()

	tw.set_parallel(true)


	tw.tween_property(
		camera,
		"position",
		base_camera_pos,
		0.15
	)

	tw.tween_property(
		camera,
		"rotation_degrees",
		base_camera_rot,
		0.15
	)


	_camera_pose_tween = tw

	_player_arms_play_guard()


func _player_arms_raise_guard_intro() -> void:

	if player_arms:
		player_arms.raise_guard_intro()


# Tranco nos braços quando o treinador acerta o paciente (junto com o
# tremor de câmera).
func _player_arms_flinch() -> void:

	if player_arms:
		player_arms.flinch()


func _player_arms_play_guard() -> void:

	if player_arms:
		player_arms.play_guard()


# ============================================================

func _camera_kick(
	pos_offset: Vector3,
	rot_offset: Vector3,
	out_dur: float,
	hold_dur: float,
	back_dur: float,
	on_finished: Callable = Callable()
) -> void:

	_kill_tween(_camera_pose_tween)


	var tw := create_tween()

	tw.set_parallel(true)


	tw.tween_property(
		camera,
		"position",
		base_camera_pos + pos_offset,
		out_dur
	)

	tw.tween_property(
		camera,
		"rotation_degrees",
		base_camera_rot + rot_offset,
		out_dur
	)


	tw.set_parallel(false)

	tw.tween_interval(
		hold_dur
	)


	tw.set_parallel(true)


	tw.tween_property(
		camera,
		"position",
		base_camera_pos,
		back_dur
	)

	tw.tween_property(
		camera,
		"rotation_degrees",
		base_camera_rot,
		back_dur
	)


	if on_finished.is_valid():

		tw.set_parallel(false)

		tw.tween_callback(
			on_finished
		)


	_camera_pose_tween = tw


func _patient_dodge_left(
	on_finished: Callable = Callable()
) -> void:

	if player_arms:
		player_arms.dodge(-1)

	_camera_kick(
		Vector3(-0.42, 0, 0),
		Vector3(0, 0, 14),
		0.11,
		0.05,
		0.16,
		on_finished
	)


func _patient_dodge_right(
	on_finished: Callable = Callable()
) -> void:

	if player_arms:
		player_arms.dodge(1)

	_camera_kick(
		Vector3(0.42, 0, 0),
		Vector3(0, 0, -14),
		0.11,
		0.05,
		0.16,
		on_finished
	)


func _patient_duck(
	on_finished: Callable = Callable()
) -> void:

	# DEFESA ALTA: guarda sobe na frente do rosto, a cabeça afunda um
	# pouco atrás das luvas e toma o tranco do golpe bloqueado.
	if player_arms:
		player_arms.high_block()

	_camera_kick(
		Vector3(0, -0.12, 0.04),
		Vector3(5, 0, 0),
		0.09,
		0.22,
		0.2,
		on_finished
	)


# ============================================================
# SOCO DO PACIENTE
# ============================================================

func _patient_punch(
	side: int,
	on_finished: Callable = Callable()
) -> void:

	if not player_arms:

		if on_finished.is_valid():
			on_finished.call()

		return

	player_arms.punch(side, on_finished)

	# a "cabeça" acompanha o soco: vai um pouquinho pra frente e pro
	# lado do braço que bateu
	_camera_kick(
		Vector3(0.02 * side, -0.01, -0.05),
		Vector3(0, -2.0 * side, -1.0 * side),
		0.09,
		0.04,
		0.18
	)


# ============================================================
# COMEMORAÇÃO DO PACIENTE
# ============================================================

func _patient_celebrate(
	on_finished: Callable = Callable()
) -> void:

	# Soquinho no ar com o braço + um aceno de câmera.
	if player_arms:
		player_arms.celebrate()

	_kill_tween(_camera_pose_tween)

	var tw := create_tween()

	tw.tween_property(
		camera,
		"position",
		base_camera_pos + Vector3(0, 0.06, 0),
		0.1
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

	tw.tween_property(
		camera,
		"position",
		base_camera_pos,
		0.14
	)

	if on_finished.is_valid():

		tw.tween_callback(
			on_finished
		)

	_camera_pose_tween = tw


# ============================================================
# RESPOSTA DO PACIENTE
# ============================================================

func _play_patient_response(
	response: String,
	celebrate: bool = false
) -> void:

	var after_response := func():

		if not current_challenge.is_empty():
			return

		if celebrate:

			_patient_celebrate()


	match response:

		"dodge_left":

			_patient_dodge_left(
				after_response
			)


		"dodge_right":

			_patient_dodge_right(
				after_response
			)


		"duck":

			_patient_duck(
				after_response
			)


		"punch_left":

			_patient_punch(
				-1,
				after_response
			)


		"punch_right":

			_patient_punch(
				1,
				after_response
			)


# ============================================================
# RESOLVE DESAFIO
# ============================================================

func _resolve_challenge(
	success: bool,
	given_response: String
) -> void:

	var challenge := current_challenge

	current_challenge = {}

	prompt_panel_ref.modulate.a = 0.0


	var response: String = challenge["response"]

	_indicator_result(response, success)


	var category: String = (
		"dodge"
		if (
			response.begins_with("dodge")
			or response == "duck"
		)
		else "punch"
	)


	var telegraph_dur_ms: float = (
		challenge["telegraph_ms"]
	)

	var window_ms: float = (
		challenge["window_ms"]
	)


	var reaction_ms: float


	if given_response == "":

		reaction_ms = window_ms

	else:

		reaction_ms = max(
			0.0,
			(
				session_elapsed
				- challenge_started_at
			) * 1000.0
			- telegraph_dur_ms
		)


	# relatório do treino: guarda o resultado deste desafio
	_report_record(response, success, reaction_ms)


	# ========================================================
	# SUCESSO
	# ========================================================

	if success:

		GameManager.add_hit(
			category,
			reaction_ms,
			window_ms
		)


		var milestone: bool = (
			(
				GameManager.combo % 5 == 0
				and GameManager.combo > 0
			)
			or reaction_ms < 220.0
		)


		_play_patient_response(
			response,
			milestone
		)

		# pulso de luz discreto no cenário (vermelho = esquerda, azul = direita)
		if scenario_node:

			var fx_col := Color(0.4, 0.9, 1.0)

			if response.ends_with("_left"):
				fx_col = Color(1.0, 0.3, 0.3)
			elif response.ends_with("_right"):
				fx_col = Color(0.3, 0.5, 1.0)

			scenario_node.flash(fx_col)


		# ====================================================
		# REAÇÃO DO TREINADOR
		# ====================================================

		if category == "punch":

			# O PACIENTE ACERTOU O TREINADOR

			if response == "punch_left":

				trainer_actor.take_hit_left()

			elif response == "punch_right":

				trainer_actor.take_hit_right()

			else:

				trainer_actor.take_hit_center()


		else:

			# O PACIENTE ESQUIVOU (ou bloqueou com a defesa alta)

			if response == "duck":
				trainer_actor.attack_blocked()
			else:
				trainer_actor.attack_missed()


		# ====================================================
		# FEEDBACK
		# ====================================================

		if milestone:

			_show_feedback(
				"MUITO BOM!",
				COLOR_GOLD
			)

			AudioManager.play(
				"combo_bonus"
			)


		elif category == "dodge":

			_show_feedback(
				"DEFESA!" if response == "duck" else "ESQUIVA!",
				COLOR_CYAN
			)

			AudioManager.play(
				"dodge_success"
			)


		else:

			_show_feedback(
				"ACERTO!",
				COLOR_GREEN
			)

			AudioManager.play(
				"punch_hit"
			)


		# ====================================================
		# PARTICULAS
		# ====================================================

		if category == "punch":

			_burst_particles(
				trainer_actor.chest_position(),
				COLOR_GREEN
			)

			_shake(
				0.03,
				0.12
			)

		else:

			_burst_particles(
				camera.global_position,
				COLOR_CYAN
			)


	# ========================================================
	# ERRO
	# ========================================================

	else:

		GameManager.add_miss(
			category
		)


		# ====================================================
		# TREINADOR ACERTOU O PACIENTE
		# ====================================================

		trainer_actor.get_angry()

		_player_arms_flinch()

		if avatar:
			avatar.flinch()


		get_tree().create_timer(
			0.3
		).timeout.connect(
			_patient_reset
		)


		_show_feedback(
			"ERRO!",
			COLOR_RED
		)


		_burst_particles(
			camera.global_position,
			COLOR_RED
		)


		_shake(
			0.07,
			0.18
		)


		_flash(
			Color(0.9, 0.15, 0.15),
			0.25
		)


		AudioManager.play(
			"miss"
		)


	# combo de ataques: acompanha o progresso e dá o bônus no fim
	_combo_track(challenge, success)


	# ========================================================
	# PRÓXIMO DESAFIO
	# ========================================================

	_seq_index += 1

	gap_timer.start(
		challenge["gap_ms"] / 1000.0
	)


# ============================================================
# COMBOS DE ATAQUES (V-FBF)
# ============================================================
# De vez em quando o treinador solta 2 a 4 golpes seguidos. O jogo anuncia
# "COMBO ...!" com o progresso (1/3, 2/3...). Terminar TODOS os golpes acertando
# dá um bônus de pontos; errar algum "quebra" o combo (os acertos seguem
# valendo normalmente, só o bônus se perde). Não muda a detecção nem a regra
# de acerto/erro de cada golpe.

func _combo_kind_text(kind: int) -> String:

	if kind == 0:
		return "COMBO DE ATAQUES!"

	if kind == 1:
		return "CONTRA-ATAQUE!"

	return "COMBO MISTO!"


func _combo_on_start(challenge: Dictionary) -> void:

	if combo_label == null:
		return

	if not bool(challenge.get("combo", false)):
		combo_label.modulate.a = 0.0
		return

	var i: int = int(challenge["combo_i"])
	var n: int = int(challenge["combo_n"])

	if i == 0:
		_combo_clean = true

	combo_label.text = "%s  %d/%d" % [_combo_kind_text(int(challenge["combo_kind"])), i + 1, n]
	combo_label.modulate = Color(1.0, 0.75, 0.25, 1.0) if _combo_clean else Color(0.75, 0.75, 0.8, 1.0)

	_kill_tween(_combo_tween)

	combo_label.pivot_offset = Vector2(300, 25)
	combo_label.scale = Vector2(0.7, 0.7)

	_combo_tween = create_tween()
	_combo_tween.tween_property(combo_label, "scale", Vector2(1.0, 1.0), 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _combo_track(challenge: Dictionary, success: bool) -> void:

	if not bool(challenge.get("combo", false)):
		return

	if not success:
		_combo_clean = false

	var i: int = int(challenge["combo_i"])
	var n: int = int(challenge["combo_n"])

	if i < n - 1:
		return

	# último golpe do combo
	if not _rep.is_empty():
		_rep["combos"]["total"] = int(_rep["combos"]["total"]) + 1

	if _combo_clean:

		if not _rep.is_empty():
			_rep["combos"]["perfect"] = int(_rep["combos"]["perfect"]) + 1

		var bonus: int = n * 25 * Trainer.get_phase_index(session_elapsed)

		GameManager.add_bonus(bonus)

		_show_feedback("COMBO PERFEITO! +%d" % bonus, COLOR_GOLD)
		_flash(Color(1.0, 0.85, 0.3), 0.25)

		if scenario_node:
			scenario_node.flash(Color(1.0, 0.85, 0.3))

	else:

		_show_feedback("COMBO QUEBRADO", Color(0.8, 0.8, 0.85))

	if combo_label:
		combo_label.modulate.a = 0.0


# ============================================================
# EFEITOS
# ============================================================

func _show_feedback(
	text: String,
	color: Color
) -> void:

	feedback_label.text = text

	feedback_label.modulate = Color(
		color.r,
		color.g,
		color.b,
		1.0
	)

	feedback_label.scale = Vector2(
		0.6,
		0.6
	)


	var tw := create_tween()


	tw.tween_property(
		feedback_label,
		"scale",
		Vector2(1.15, 1.15),
		0.12
	).set_trans(
		Tween.TRANS_BACK
	).set_ease(
		Tween.EASE_OUT
	)


	tw.tween_property(
		feedback_label,
		"scale",
		Vector2(1.0, 1.0),
		0.1
	)


	tw.tween_interval(
		0.35
	)


	tw.tween_property(
		feedback_label,
		"modulate:a",
		0.0,
		0.25
	)


func _burst_particles(
	pos: Vector3,
	color: Color
) -> void:

	hit_particles.global_position = pos

	hit_particles_mat.color = color

	hit_particles.restart()

	hit_particles.emitting = true


func _shake(
	strength: float,
	duration: float
) -> void:

	_kill_tween(
		_camera_pose_tween
	)


	var tw := create_tween()

	var steps := 6


	for i in range(steps):

		var off := (
			base_camera_pos
			+ Vector3(
				randf_range(-strength, strength),
				randf_range(-strength, strength),
				0
			)
		)


		tw.tween_property(
			camera,
			"position",
			off,
			duration / steps
		)

		tw.tween_property(
			camera,
			"position",
			base_camera_pos,
			duration / steps
		)


	_camera_pose_tween = tw


func _flash(
	color: Color,
	duration: float
) -> void:

	flash_rect.color = color

	flash_rect.modulate.a = 0.0


	var tw := create_tween()


	tw.tween_property(
		flash_rect,
		"modulate:a",
		0.5,
		duration * 0.25
	)


	tw.tween_property(
		flash_rect,
		"modulate:a",
		0.0,
		duration * 0.75
	)


func _show_phase_toast(
	phase_name: String
) -> void:

	phase_toast_label.text = (
		"FASE: %s"
		% phase_name.to_upper()
	)

	phase_toast_label.modulate.a = 1.0


	var tw := create_tween()

	tw.tween_interval(1.2)

	tw.tween_property(
		phase_toast_label,
		"modulate:a",
		0.0,
		0.4
	)


# ============================================================
# PAUSA
# ============================================================

func _input(event: InputEvent) -> void:

	# abertura (logo + créditos): qualquer tecla/clique pula
	if _splash_active:

		if (
			(event is InputEventKey and event.pressed and not event.echo)
			or (event is InputEventMouseButton and event.pressed)
		):
			_finish_splash()

		return

	# F3 = mostra/esconde o contador de FPS
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F3:
		if fps_label:
			fps_label.visible = not fps_label.visible
		return

	# M = inverter os lados da câmera (se esquerda/direita saírem trocadas)
	if (
		event is InputEventKey
		and event.pressed
		and not event.echo
		and event.physical_keycode == KEY_M
		and control_mode == "camera"
	):
		CameraInput.toggle_mirror()
		camera_preview_rect.flip_h = CameraInput.mirror
		_show_status(
			"Lados da câmera invertidos (espelho: %s)." % ("SIM" if CameraInput.mirror else "NÃO"),
			false
		)

	if (
		event is InputEventKey
		and event.pressed
		and not event.echo
		and event.physical_keycode == KEY_ESCAPE
	):

		if state == State.PLAYING:

			pause_game()

		elif state == State.PAUSED:

			resume_game()

		elif not _secret_busy:

			if current_screen == "menu":
				if _menu_current_page != "main":
					_menu_back()
			elif current_screen == "results":
				quit_to_menu()
			else:
				_go_back()


func pause_game() -> void:

	if state != State.PLAYING:
		return

	state = State.PAUSED

	get_tree().paused = true

	show_screen("pause")


func resume_game() -> void:

	if state != State.PAUSED:
		return

	state = State.PLAYING

	get_tree().paused = false

	show_screen("hud")


# ============================================================
# FIM DA SESSÃO
# ============================================================

func _end_session() -> void:

	state = State.GAMEOVER

	get_tree().paused = false

	spawn_timer.stop()
	gap_timer.stop()

	_cleanup_inputs()

	current_challenge = {}
	current_sequence = []

	prompt_panel_ref.modulate.a = 0.0


	var summary := (
		GameManager.build_session_summary()
	)

	last_session = SessionData.from_summary(
		summary
	)


	# ========================================================
	# NOCAUTE — quem ganhou a luta?
	# ========================================================

	var won: bool = float(summary["precision"]) >= WIN_PRECISION

	_generate_report(summary, won)

	_indicators_reset()

	if avatar:
		if won:
			avatar.celebrate()
		else:
			avatar.flinch()

	_ko_id += 1
	var id := _ko_id

	if won:
		await _knockout_trainer_sequence(id)
	else:
		await _knockout_player_sequence(id)

	# se o jogador saiu/recomeçou no meio da cena, não mostra nada
	if id != _ko_id or state != State.GAMEOVER:
		return


	AudioManager.play(
		"session_end"
	)

	_populate_results(
		summary
	)

	if results_title_label:
		if won:
			results_title_label.text = "VITÓRIA POR NOCAUTE!"
			results_title_label.add_theme_color_override("font_color", COLOR_GOLD)
		else:
			results_title_label.text = "VOCÊ FOI NOCAUTEADO"
			results_title_label.add_theme_color_override("font_color", COLOR_RED)

	show_screen("results")


# Espera um tempo e diz se a cena ainda deve continuar.
func _ko_wait(seconds: float, id: int) -> bool:

	await get_tree().create_timer(seconds).timeout
	return id == _ko_id and state == State.GAMEOVER


# Contagem do juiz no feedback central.
func _ko_count(id: int, color: Color) -> bool:

	for n in ["1", "2", "3"]:
		_show_feedback(n, color)
		AudioManager.play("count")
		if not await _ko_wait(0.5, id):
			return false
	return true


# VOCÊ VENCEU: o treinador abre a guarda tonto, você solta um gancho
# de baixo pra cima, ele cai de costas, o juiz conta e você comemora.
func _knockout_trainer_sequence(id: int) -> void:

	_patient_reset()

	_show_feedback("GOLPE FINAL!", COLOR_GOLD)

	trainer_actor.go_to_pose("dizzy", 0.35)

	if not await _ko_wait(0.7, id):
		return

	player_arms.uppercut()

	if not await _ko_wait(PlayerArms3D.UPPERCUT_IMPACT_TIME, id):
		return

	# impacto
	trainer_actor.knockout()
	AudioManager.play("punch_hit")
	_burst_particles(trainer_actor.head_position(), COLOR_GOLD)
	_flash(Color(1, 1, 1), 0.45)
	_camera_kick(
		Vector3(0, 0.02, -0.08),
		Vector3(4, 3, -2),
		0.08,
		0.12,
		0.3
	)
	_show_feedback("NOCAUTE!", COLOR_GOLD)

	# espera ele terminar de cair
	if not await _ko_wait(1.3, id):
		return

	# poeira quando bate no chão
	_burst_particles(trainer_actor.global_position + Vector3(0, 0.1, -0.9), Color(0.8, 0.75, 0.65))

	if not await _ko_count(id, Color(1, 1, 1)):
		return

	_show_feedback("VOCÊ VENCEU!", COLOR_GOLD)
	player_arms.victory()
	AudioManager.play("combo_bonus")

	await _ko_wait(1.8, id)


# VOCÊ PERDEU: o treinador carrega um direto, acerta em cheio, seus
# braços voam, a câmera cai no chão do ringue, a tela escurece, o juiz
# conta e o treinador comemora em cima de você.
func _knockout_player_sequence(id: int) -> void:

	_patient_reset()

	_show_feedback("CUIDADO!", COLOR_RED)

	trainer_actor.go_to_pose("attack_right_wind", 0.45)

	if not await _ko_wait(0.55, id):
		return

	trainer_actor.go_to_pose("attack_right_strike", 0.09)

	if not await _ko_wait(0.09, id):
		return

	# impacto
	AudioManager.play("miss")
	_burst_particles(camera.global_position + Vector3(0, 0, -0.3), COLOR_RED)
	_flash(Color(0.9, 0.1, 0.1), 0.5)
	player_arms.knocked_out()
	_show_feedback("NOCAUTE!", COLOR_RED)
	_camera_knockdown()

	if not await _ko_wait(1.1, id):
		return

	# tela escurece (visão "apagando")
	flash_rect.color = Color(0, 0, 0)
	var dark := create_tween()
	dark.tween_property(flash_rect, "modulate:a", 0.55, 0.6)

	trainer_actor.celebrate_hit()

	if not await _ko_count(id, Color(1, 0.6, 0.6)):
		return

	_show_feedback("VOCÊ FOI NOCAUTEADO", COLOR_RED)

	await _ko_wait(1.8, id)


# Câmera = sua cabeça: estala pra trás com o soco, depois despenca até
# o chão do ringue, caída de lado, olhando o treinador de baixo.
func _camera_knockdown() -> void:

	_kill_tween(_camera_pose_tween)

	var tw := create_tween()

	tw.set_parallel(true)
	tw.tween_property(camera, "position", base_camera_pos + Vector3(0.0, 0.05, 0.18), 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(camera, "rotation_degrees", base_camera_rot + Vector3(22, 6, -8), 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)

	# cambaleia
	tw.chain().tween_property(camera, "position", base_camera_pos + Vector3(0.12, -0.25, 0.3), 0.35).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(camera, "rotation_degrees", base_camera_rot + Vector3(10, -8, 18), 0.35).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	# desaba no chão (com quique)
	tw.chain().tween_property(camera, "position", base_camera_pos + Vector3(0.3, -1.38, 0.45), 0.7).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tw.tween_property(camera, "rotation_degrees", base_camera_rot + Vector3(20, 0, 78), 0.7).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)

	_camera_pose_tween = tw


# Desfaz o nocaute (treinador em pé, câmera e braços no lugar, tela limpa).
func _reset_after_knockout() -> void:

	if trainer_actor:
		trainer_actor.revive()

	if player_arms:
		player_arms.reset_pose()

	if avatar:
		avatar.reset()

	_indicators_reset()

	_kill_tween(_camera_pose_tween)

	if camera:
		camera.position = base_camera_pos
		camera.rotation_degrees = base_camera_rot

	if flash_rect:
		flash_rect.modulate.a = 0.0


# ============================================================
# RESULTADOS
# ============================================================

func _populate_results(_summary: Dictionary) -> void:

	# a tela final é preenchida por _fill_final_screen() a partir do relatório
	_fill_final_screen()


# ============================================================
# VOLTAR MENU
# ============================================================

func quit_to_menu() -> void:

	state = State.MENU

	get_tree().paused = false

	spawn_timer.stop()
	gap_timer.stop()

	_cleanup_inputs()

	current_challenge = {}
	current_sequence = []

	_ko_id += 1
	_reset_after_knockout()

	trainer_actor.set_guard()

	show_screen("menu")


# ============================================================
# LIMPA CONTROLES
# ============================================================

func _cleanup_inputs() -> void:

	InputHandler.disable()

	CameraInput.stop()

	CameraInputUDP.parar()

	camera_preview_rect.visible = false


# ============================================================
# HUD
# ============================================================

func _on_hud_changed(
	s: Dictionary
) -> void:

	hud_score.text = "%04d" % int(
		s["score"]
	)

	hud_combo.text = "x%d" % int(
		s["combo"]
	)

	hud_precision.text = "%.0f%%" % (
		s["precision"]
	)
