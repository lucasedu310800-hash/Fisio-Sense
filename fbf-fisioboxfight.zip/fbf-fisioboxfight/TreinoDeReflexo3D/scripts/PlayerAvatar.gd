# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends SubViewportContainer
class_name PlayerAvatar
# Boneco do JOGADOR no centro-baixo da tela (V-FBF). Ele "espelha" os
# movimentos reconhecidos pela câmera (ou teclado): soco esquerdo/
# direito estica o braço, defesa esquerda/direita fecha a guarda e
# balança o corpo pro lado, agachar abaixa o corpo inteiro.
#
# Reaproveita o BoxerRig3D (o mesmo corpo do treinador, em azul) dentro
# de um SubViewport com mundo 3D PRÓPRIO e fundo transparente — então
# não mexe em nada do cenário principal, e o treinador continua sendo
# o adversário no centro do ringue.
#
# ESPELHO: o boneco fica de FRENTE pra tela, como um espelho. O que
# está no lado ESQUERDO da tela é o lado esquerdo do jogador (igual à
# prévia da câmera). Como o boneco olha pra tela, o braço "Right" do
# BoxerRig3D é o que aparece à esquerda — por isso "punch_left" usa a
# pose attack_right_* (ver _side_pose_name).
#
# API: play(response) | flinch() | celebrate() | reset()
# response = "punch_left" | "punch_right" | "dodge_left" | "dodge_right"
#          | "duck" (DEFESA ALTA: luvas no rosto) | "crouch" (AGACHAR: corpo desce)

const LEFT_GLOVE_COLOR := Color(0.85, 0.12, 0.12)    # luva esquerda = vermelha
const RIGHT_GLOVE_COLOR := Color(0.12, 0.35, 0.95)   # luva direita = azul

var rig: BoxerRig3D

var _viewport: SubViewport
var _pivot: Node3D
var _seq_tween: Tween
var _pivot_tween: Tween


func _ready() -> void:

	stretch = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	_viewport = SubViewport.new()
	_viewport.own_world_3d = true
	_viewport.transparent_bg = true
	add_child(_viewport)

	# luz própria (o mundo do SubViewport é separado do principal)
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.72, 0.80)
	env.ambient_light_energy = 0.9

	var world_env := WorldEnvironment.new()
	world_env.environment = env
	_viewport.add_child(world_env)

	var key_light := DirectionalLight3D.new()
	key_light.rotation_degrees = Vector3(-30, -20, 0)
	key_light.light_energy = 1.1
	_viewport.add_child(key_light)

	var cam := Camera3D.new()
	cam.fov = 38.0
	cam.position = Vector3(0.0, 1.1, 3.6)
	_viewport.add_child(cam)
	cam.look_at(Vector3(0.0, 0.98, 0.0), Vector3.UP)
	cam.current = true

	# pivô nos pés: balançar o pivô inclina o corpo todo pro lado
	_pivot = Node3D.new()
	_viewport.add_child(_pivot)

	rig = BoxerRig3D.new()
	rig.body_color = Color(0.15, 0.32, 0.80)
	rig.headgear = true   # protetor de cabeça de treino (diferencia do treinador)
	_pivot.add_child(rig)

	# de frente pra tela (mesma ideia do treinador, que é girado 180°)
	rig.set_base_transform(Vector3.ZERO, Vector3(0, 180, 0))
	rig.set_guard()

	# luvas: esquerda do jogador (lado esquerdo da tela = "Right" do rig)
	# vermelha, direita azul
	_recolor_glove(rig.right_glove, "RightThumb", LEFT_GLOVE_COLOR)
	_recolor_glove(rig.left_glove, "LeftThumb", RIGHT_GLOVE_COLOR)


func _recolor_glove(glove: MeshInstance3D, thumb_name: String, col: Color) -> void:

	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.45

	if glove != null:
		glove.material_override = m

	var thumb: Node = rig.find_child(thumb_name, true, false)

	if thumb is MeshInstance3D:
		(thumb as MeshInstance3D).material_override = m


func _kill(t: Tween) -> void:

	if t != null and t.is_valid():
		t.kill()


# ------------------------------------------------------------
# Entrada principal
# ------------------------------------------------------------

func play(response: String) -> void:

	if rig == null:
		return

	match response:
		"punch_left":
			_punch("attack_right")
		"punch_right":
			_punch("attack_left")
		"dodge_left":
			_defend(-1)
		"dodge_right":
			_defend(1)
		"duck":
			_guard_up()
		"crouch":
			_duck()


# SOCO: prepara (braço recua), estica o braço pra frente com o corpo
# avançando (pose *_strike do rig) e volta pra guarda.
func _punch(rig_side_pose: String) -> void:

	_kill(_seq_tween)
	_lean(0.0, 0.0, 0.12)

	_seq_tween = create_tween()
	_seq_tween.tween_callback(rig.go_to_pose.bind(rig_side_pose + "_wind", 0.07))
	_seq_tween.tween_interval(0.07)
	_seq_tween.tween_callback(rig.go_to_pose.bind(rig_side_pose + "_strike", 0.08))
	_seq_tween.tween_interval(0.26)
	_seq_tween.tween_callback(rig.go_to_pose.bind("guard", 0.25))


# DEFESA LATERAL (esquiva): guarda fecha e sobe no rosto + o corpo
# inteiro inclina e desliza pro lado (dir: -1 = esquerda da tela =
# esquerda do jogador, 1 = direita).
func _defend(dir: int) -> void:

	_kill(_seq_tween)

	rig.go_to_pose("avatar_block", 0.10)
	_lean(-dir * 9.0, dir * 0.16, 0.13)

	_seq_tween = create_tween()
	_seq_tween.tween_interval(0.50)
	_seq_tween.tween_callback(_lean.bind(0.0, 0.0, 0.25))
	_seq_tween.tween_callback(rig.go_to_pose.bind("guard", 0.25))


# DEFESA ALTA: as duas luvas sobem coladas no rosto e o queixo abaixa, com
# um leve recuo do tronco — SEM abaixar o corpo (isso é o agachar).
func _guard_up() -> void:

	_kill(_seq_tween)

	_lean(0.0, 0.0, 0.10, -6.0)
	rig.go_to_pose("avatar_block", 0.10)

	_seq_tween = create_tween()
	_seq_tween.tween_interval(0.85)
	_seq_tween.tween_callback(_lean.bind(0.0, 0.0, 0.25, 0.0))
	_seq_tween.tween_callback(rig.go_to_pose.bind("guard", 0.25))


# AGACHAR: o corpo desce (joelhos dobram sozinhos) e volta a subir.
func _duck() -> void:

	_kill(_seq_tween)
	_lean(0.0, 0.0, 0.10)

	rig.go_to_pose("avatar_duck", 0.14)

	_seq_tween = create_tween()
	_seq_tween.tween_interval(0.70)
	_seq_tween.tween_callback(rig.go_to_pose.bind("guard", 0.30))


func _lean(z_deg: float, x_off: float, dur: float, x_deg: float = 0.0) -> void:

	_kill(_pivot_tween)

	_pivot_tween = create_tween()
	_pivot_tween.set_parallel(true)
	_pivot_tween.tween_property(
		_pivot, "rotation_degrees:z", z_deg, dur
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_pivot_tween.tween_property(
		_pivot, "position:x", x_off, dur
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	_pivot_tween.tween_property(
		_pivot, "rotation_degrees:x", x_deg, dur
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


# ------------------------------------------------------------
# Reações extras
# ------------------------------------------------------------

# Levou o golpe (erro): o corpo joga pra trás e volta.
func flinch() -> void:

	if rig == null:
		return

	_kill(_pivot_tween)

	_pivot_tween = create_tween()
	_pivot_tween.tween_property(_pivot, "rotation_degrees:x", -12.0, 0.07)
	_pivot_tween.tween_property(
		_pivot, "rotation_degrees:x", 0.0, 0.28
	).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


# Pulinho de comemoração.
func celebrate() -> void:

	if rig == null:
		return

	_kill(_pivot_tween)

	_pivot_tween = create_tween()
	_pivot_tween.tween_property(_pivot, "position:y", 0.14, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_pivot_tween.tween_property(_pivot, "position:y", 0.0, 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_pivot_tween.tween_property(_pivot, "position:y", 0.10, 0.10).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	_pivot_tween.tween_property(_pivot, "position:y", 0.0, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


# Volta tudo pra guarda parada no meio.
func reset() -> void:

	if rig == null:
		return

	_kill(_seq_tween)
	_kill(_pivot_tween)

	_pivot.position = Vector3.ZERO
	_pivot.rotation_degrees = Vector3.ZERO

	rig.set_guard()
