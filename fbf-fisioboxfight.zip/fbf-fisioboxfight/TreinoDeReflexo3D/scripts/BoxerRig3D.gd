# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node3D
class_name BoxerRig3D

@export var body_color: Color = Color(0.82, 0.08, 0.08)
@export var skin_color: Color = Color(0.86, 0.66, 0.48)
@export var glove_color: Color = Color(0.08, 0.08, 0.10)
@export var shorts_color: Color = Color(0.04, 0.04, 0.05)
# Protetor de cabeça de treino (usado no boneco do jogador, na cor do corpo)
@export var headgear: bool = false

var head_pivot: Node3D
var left_shoulder: Node3D
var right_shoulder: Node3D
var left_elbow: Node3D
var right_elbow: Node3D

var left_glove: MeshInstance3D
var right_glove: MeshInstance3D

var base_position := Vector3.ZERO
var base_rotation_degrees := Vector3.ZERO

var current_pose := "guard"
var animation_id := 0

# O treinador é 100% feito por código (primitivas) — sem arquivo
# 3D externo. Mantido só pra compatibilidade com o resto do script.
const IMPORTED_MODEL_MOTION_BOOST := 1.0
var using_imported_model := false

# Balanço de respiração — só ativo enquanto o treinador está parado
# na guarda entre os desafios, pra ele não parecer uma estátua.
# Qualquer chamada a go_to_pose() cancela isso automaticamente antes
# de fazer qualquer outra coisa.
var _idle_tween: Tween = null


# CONVENÇÃO DOS ÂNGULOS (Godot, rotation_degrees do nó):
#  ombro  = (X: levanta o braço pra frente | Y: fecha(-)/abre(+) pro lado esq. | Z: leve inclinação)
#  cotovelo = (X: dobra o antebraço pra CIMA/frente, 0 = braço esticado, ~120 = luva no queixo, 0, 0)
#  O braço direito é o espelho do esquerdo (Y e Z com sinal trocado).
#  Dobrar o cotovelo em Z (como era antes) abre o antebraço pro lado => pose de "T".
const POSES := {

	# =========================
	# GUARDA DE BOXE
	# =========================
	"guard": {
		"left_shoulder": Vector3(56, -29, 0),
		"right_shoulder": Vector3(56, 29, 0),

		"left_elbow": Vector3(118, 0, 0),
		"right_elbow": Vector3(118, 0, 0),

		"root_pos": Vector3.ZERO,
		"root_rot": Vector3(0, 7, 0),
		"head_rot": Vector3(0, -7, 0),

		# assentar na guarda é um movimento tranquilo, sem pressa
		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN_OUT,
	},


	# =========================
	# SOCO ESQUERDO - PREPARAÇÃO
	# =========================
	"attack_left_wind": {
		"left_shoulder": Vector3(14, -24, 0),
		"left_elbow": Vector3(150, 0, 0),

		"right_shoulder": Vector3(56, 29, 0),
		"right_elbow": Vector3(118, 0, 0),

		"root_pos": Vector3.ZERO,
		"root_rot": Vector3(0, 12, 0),
		"head_rot": Vector3(0, -10, 0),

		# preparação: começa devagar e vai ganhando impulso —
		# antecipação clássica, dá tempo do jogador perceber o golpe
		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN,
	},


	# =========================
	# SOCO ESQUERDO
	# =========================
	"attack_left_strike": {
		"left_shoulder": Vector3(94, -14, 0),
		"left_elbow": Vector3(0, 0, 0),

		"right_shoulder": Vector3(56, 29, 0),
		"right_elbow": Vector3(118, 0, 0),

		"root_pos": Vector3(0, 0, -0.28),
		"root_rot": Vector3(0, -8, 0),
		"head_rot": Vector3(0, -5, 0),

		# golpe: seco e rápido, com um pouquinho de "estouro" no final
		# (passa um pouco do alvo e assenta) — dá peso ao impacto
		"trans": Tween.TRANS_BACK, "ease": Tween.EASE_OUT,
	},


	# =========================
	# SOCO DIREITO - PREPARAÇÃO
	# =========================
	"attack_right_wind": {
		"right_shoulder": Vector3(14, 24, 0),
		"right_elbow": Vector3(150, 0, 0),

		"left_shoulder": Vector3(56, -29, 0),
		"left_elbow": Vector3(118, 0, 0),

		"root_pos": Vector3.ZERO,
		"root_rot": Vector3(0, -12, 0),
		"head_rot": Vector3(0, 10, 0),

		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN,
	},


	# =========================
	# SOCO DIREITO
	# =========================
	"attack_right_strike": {
		"right_shoulder": Vector3(94, 14, 0),
		"right_elbow": Vector3(0, 0, 0),

		"left_shoulder": Vector3(56, -29, 0),
		"left_elbow": Vector3(118, 0, 0),

		"root_pos": Vector3(0, 0, -0.28),
		"root_rot": Vector3(0, 8, 0),
		"head_rot": Vector3(0, 5, 0),

		"trans": Tween.TRANS_BACK, "ease": Tween.EASE_OUT,
	},


	# =========================
	# ATAQUE BAIXO
	# =========================
	"attack_low_wind": {
		"left_shoulder": Vector3(123, -9, 6),
		"right_shoulder": Vector3(123, 9, -6),

		"left_elbow": Vector3(92, 0, 0),
		"right_elbow": Vector3(92, 0, 0),

		"root_pos": Vector3(0, -0.12, 0),
		"root_rot": Vector3(-5, 0, 0),
		"head_rot": Vector3(8, 0, 0),

		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN,
	},


	"attack_low_strike": {
		"left_shoulder": Vector3(111, -10, 3),
		"right_shoulder": Vector3(111, 10, -3),

		"left_elbow": Vector3(0, 0, 0),
		"right_elbow": Vector3(0, 0, 0),

		"root_pos": Vector3(0, -0.20, -0.22),
		"root_rot": Vector3(-8, 0, 0),
		"head_rot": Vector3(12, 0, 0),

		"trans": Tween.TRANS_BACK, "ease": Tween.EASE_OUT,
	},


	# =========================
	# RECEBE GOLPE ESQUERDA
	# =========================
	"hit_left": {
		"left_shoulder": Vector3(24, 22, -7),
		"right_shoulder": Vector3(45, 29, 0),

		"left_elbow": Vector3(150, 0, 0),
		"right_elbow": Vector3(130, 0, 0),

		"root_pos": Vector3(-0.10, 0.03, 0),
		"root_rot": Vector3(0, -18, -10),
		"head_rot": Vector3(0, -22, -12),

		# apanhar tem que parecer súbito — sem antecipação nenhuma,
		# só o repuxo abrupto do impacto
		"trans": Tween.TRANS_EXPO, "ease": Tween.EASE_OUT,
	},


	# =========================
	# RECEBE GOLPE DIREITA
	# =========================
	"hit_right": {
		"left_shoulder": Vector3(45, -29, 0),
		"right_shoulder": Vector3(24, -22, 7),

		"left_elbow": Vector3(130, 0, 0),
		"right_elbow": Vector3(150, 0, 0),

		"root_pos": Vector3(0.10, 0.03, 0),
		"root_rot": Vector3(0, 18, 10),
		"head_rot": Vector3(0, 22, 12),

		"trans": Tween.TRANS_EXPO, "ease": Tween.EASE_OUT,
	},


	# =========================
	# RECEBE GOLPE CENTRO
	# =========================
	"hit_center": {
		"left_shoulder": Vector3(34, -28, 0),
		"right_shoulder": Vector3(34, 28, 0),

		"left_elbow": Vector3(141, 0, 0),
		"right_elbow": Vector3(141, 0, 0),

		"root_pos": Vector3(0, 0.03, -0.05),
		"root_rot": Vector3(-5, 0, 0),
		"head_rot": Vector3(15, 0, 0),

		"trans": Tween.TRANS_EXPO, "ease": Tween.EASE_OUT,
	},


	# =========================
	# TONTO
	# =========================
	"dizzy": {
		"left_shoulder": Vector3(6, -17, 0),
		"right_shoulder": Vector3(6, 17, 0),

		"left_elbow": Vector3(150, 0, 0),
		"right_elbow": Vector3(150, 0, 0),

		"root_pos": Vector3(0, 0.04, 0),
		"root_rot": Vector3(0, 20, 0),
		"head_rot": Vector3(0, -25, 15),

		# tonto balança devagar e solto, sem pressa nenhuma
		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN_OUT,
	},


	# =========================
	# BRAVO
	# =========================
	"angry": {
		"left_shoulder": Vector3(63, -27, 0),
		"right_shoulder": Vector3(63, 27, 0),

		"left_elbow": Vector3(107, 0, 0),
		"right_elbow": Vector3(107, 0, 0),

		"root_pos": Vector3(0, 0, -0.05),
		"root_rot": Vector3(0, 5, 0),
		"head_rot": Vector3(-8, 0, 0),

		# bravo cresce devagar e ganha força — ameaça em câmera lenta
		"trans": Tween.TRANS_QUAD, "ease": Tween.EASE_IN,
	},


	# =========================
	# COMEMORAÇÃO
	# =========================
	"celebrate": {
		"left_shoulder": Vector3(150, 0, -12),
		"right_shoulder": Vector3(150, 0, 12),

		"left_elbow": Vector3(25, 0, 0),
		"right_elbow": Vector3(25, 0, 0),

		"root_pos": Vector3(0, 0.10, 0),
		"root_rot": Vector3(0, 0, 0),
		"head_rot": Vector3(-5, 0, 0),

		# comemoração quicando — energia, empolgação
		"trans": Tween.TRANS_BACK, "ease": Tween.EASE_OUT,
	},


	# =========================
	# POSES DO BONECO DO JOGADOR (PlayerAvatar.gd) — NOVAS, só usadas
	# pelo boneco central; o treinador não usa nenhuma destas.
	# =========================

	# DEFESA: antebraços sobem colados no rosto, cabeça encolhida
	# (diferente de qualquer soco: aqui os braços FECHAM e SOBEM, não
	# esticam pra frente). O balanço do corpo pro lado é feito pelo
	# PlayerAvatar.
	"avatar_block": {
		"left_shoulder": Vector3(76, -10, 0),
		"right_shoulder": Vector3(76, 10, 0),

		"left_elbow": Vector3(132, 0, 0),
		"right_elbow": Vector3(132, 0, 0),

		"root_pos": Vector3.ZERO,
		"root_rot": Vector3(0, 0, 0),
		"head_rot": Vector3(10, 0, 0),

		"trans": Tween.TRANS_QUAD, "ease": Tween.EASE_OUT,
	},

	# AGACHAMENTO: o corpo inteiro desce (as pernas dobram sozinhas em
	# _update_legs) com a guarda fechada e a cabeça baixa.
	# MENU: o treinador olha pro jogador e APONTA a luva pra frente
	# (braço esquerdo dele = lado direito da tela). Só usada no menu.
	"menu_point": {
		"left_shoulder": Vector3(90, -8, 0),
		"left_elbow": Vector3(6, 0, 0),

		"right_shoulder": Vector3(52, 30, 0),
		"right_elbow": Vector3(112, 0, 0),

		"root_pos": Vector3.ZERO,
		"root_rot": Vector3(0, -6, 0),
		"head_rot": Vector3(-3, 6, 0),

		"trans": Tween.TRANS_SINE, "ease": Tween.EASE_IN_OUT,
	},

	"avatar_duck": {
		"left_shoulder": Vector3(64, -22, 0),
		"right_shoulder": Vector3(64, 22, 0),

		"left_elbow": Vector3(124, 0, 0),
		"right_elbow": Vector3(124, 0, 0),

		"root_pos": Vector3(0, -0.42, 0),
		"root_rot": Vector3(0, 0, 0),
		"head_rot": Vector3(14, 0, 0),

		"trans": Tween.TRANS_QUAD, "ease": Tween.EASE_OUT,
	}
}


# ============================================================
# INICIALIZAÇÃO
# ============================================================

func _ready() -> void:

	_build_boxer()

	base_position = position
	base_rotation_degrees = rotation_degrees

	go_to_pose("guard", 0.01)


# ============================================================
# CONSTRÓI O TREINADOR — FISICULTURISTA (tudo por código)
# ============================================================
# Silhueta em "V": ombros largos, peitoral e dorsais grandes,
# cintura fina, abdômen definido, trapézio alto, pescoço grosso,
# braços com bíceps/tríceps e antebraços grossos, coxas e
# panturrilhas fortes. Os PIVÔS de animação (head_pivot, ombros,
# cotovelos, luvas) continuam nos mesmos lugares de antes, então
# todas as poses (guarda, socos, reações...) seguem funcionando.
# As pernas agora têm quadril, joelho e tornozelo de verdade: quando
# o corpo desce (gingado, ataque baixo), os joelhos dobram sozinhos
# e os pés continuam no chão (ver _update_legs).

const THIGH_LEN := 0.40
const SHIN_LEN := 0.40
const ANKLE_HEIGHT := 0.075
const STANCE_KNEE_DEG := 10.0   # joelhos levemente flexionados (base de boxeador)

var _skin_mat: StandardMaterial3D
var _chest_group: Node3D
var _legs: Array = []           # [{hip, knee, ankle}]
var _eyes: Array = []
var _brows: Array = []
var _blink_timer := 2.5
var _life_time := 0.0
var _ko := false           # nocauteado: olhos fechados, sem piscar


func _make_mat(color: Color, roughness: float, extra_spec: bool = false) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	if extra_spec:
		# pele "oleada" de fisiculturista — brilho que marca os músculos
		m.metallic_specular = 0.7
		# luz de contorno suave: separa o corpo do fundo e dá volume
		m.rim_enabled = true
		m.rim = 0.28
		m.rim_tint = 0.55
	return m


func _build_boxer() -> void:

	_skin_mat = _make_mat(skin_color, 0.42, true)

	var skin_shadow_mat := _make_mat(skin_color.darkened(0.18), 0.5, true)
	var trunks_mat := _make_mat(body_color, 0.55)
	var band_mat := _make_mat(Color(0.95, 0.95, 0.95), 0.6)
	var glove_mat := _make_mat(glove_color, 0.28)
	glove_mat.clearcoat_enabled = true
	glove_mat.clearcoat = 0.6
	var cuff_mat := _make_mat(Color(0.92, 0.92, 0.92), 0.5)
	var hair_mat := _make_mat(Color(0.06, 0.05, 0.05), 0.9)
	var stubble_mat := _make_mat(skin_color.darkened(0.45), 0.95)
	var shoe_mat := _make_mat(Color(0.08, 0.08, 0.09), 0.5)
	var sock_mat := _make_mat(Color(0.93, 0.93, 0.93), 0.9)

	# ---------------- PERNAS ----------------
	_build_leg("LeftLeg", -0.17, -0.07, _skin_mat, trunks_mat, shoe_mat, sock_mat)
	_build_leg("RightLeg", 0.17, 0.07, _skin_mat, trunks_mat, shoe_mat, sock_mat)

	var hip_y := ANKLE_HEIGHT + (THIGH_LEN + SHIN_LEN) * cos(deg_to_rad(STANCE_KNEE_DEG))

	# ---------------- CALÇÃO ----------------
	var trunks := CylinderMesh.new()
	trunks.top_radius = 0.285
	trunks.bottom_radius = 0.30
	trunks.height = 0.30
	var trunks_inst := _mesh("Trunks", trunks, trunks_mat, self, Vector3(0, hip_y - 0.04, 0))
	trunks_inst.scale = Vector3(1.0, 1.0, 0.72)

	var band := CylinderMesh.new()
	band.top_radius = 0.275
	band.bottom_radius = 0.285
	band.height = 0.07
	var band_inst := _mesh("Waistband", band, band_mat, self, Vector3(0, hip_y + 0.13, 0))
	band_inst.scale = Vector3(1.0, 1.0, 0.72)

	# ---------------- CINTURA / ABDÔMEN ----------------
	var waist := CylinderMesh.new()
	waist.top_radius = 0.27
	waist.bottom_radius = 0.24
	waist.height = 0.34
	var waist_inst := _mesh("Waist", waist, _skin_mat, self, Vector3(0, hip_y + 0.32, 0))
	waist_inst.scale = Vector3(1.0, 1.0, 0.70)

	# gomos do abdômen (3 fileiras x 2)
	var ab := SphereMesh.new()
	ab.radius = 0.048
	ab.height = 0.075
	for row in range(3):
		for side in [-1, 1]:
			var a := _mesh(
				"Ab", ab, _skin_mat, self,
				Vector3(0.052 * side, hip_y + 0.22 + row * 0.085, -0.158)
			)
			a.scale = Vector3(1.0, 1.0, 0.55)

	# oblíquos
	var obl := SphereMesh.new()
	obl.radius = 0.10
	obl.height = 0.26
	for side in [-1, 1]:
		var o := _mesh("Oblique", obl, _skin_mat, self, Vector3(0.20 * side, hip_y + 0.26, -0.02))
		o.scale = Vector3(0.6, 1.0, 0.9)

	# ---------------- TÓRAX (grupo que "respira") ----------------
	_chest_group = Node3D.new()
	_chest_group.name = "ChestGroup"
	_chest_group.position = Vector3(0, 1.32, 0)
	add_child(_chest_group)

	var rib := SphereMesh.new()
	rib.radius = 0.30
	rib.height = 0.60
	var rib_inst := _mesh("Ribcage", rib, _skin_mat, _chest_group, Vector3.ZERO)
	rib_inst.scale = Vector3(1.32, 1.0, 0.76)

	# peitorais
	var pec := SphereMesh.new()
	pec.radius = 0.14
	pec.height = 0.24
	for side in [-1, 1]:
		var p := _mesh("Pec", pec, _skin_mat, _chest_group, Vector3(0.12 * side, 0.03, -0.17))
		p.scale = Vector3(1.15, 0.85, 0.62)
		p.rotation_degrees = Vector3(0, 0, -8 * side)

	# linha entre os peitorais (sombra)
	var sternum := BoxMesh.new()
	sternum.size = Vector3(0.012, 0.16, 0.02)
	_mesh("Sternum", sternum, skin_shadow_mat, _chest_group, Vector3(0, 0.02, -0.245))

	# dorsais (asas do "V")
	var lat := SphereMesh.new()
	lat.radius = 0.17
	lat.height = 0.40
	for side in [-1, 1]:
		var l := _mesh("Lat", lat, _skin_mat, _chest_group, Vector3(0.27 * side, -0.12, 0.03))
		l.scale = Vector3(0.62, 1.1, 0.85)
		l.rotation_degrees = Vector3(0, 0, 14 * side)

	# trapézio
	var trap := SphereMesh.new()
	trap.radius = 0.12
	trap.height = 0.18
	for side in [-1, 1]:
		var t := _mesh("Trap", trap, _skin_mat, _chest_group, Vector3(0.14 * side, 0.24, 0.04))
		t.scale = Vector3(1.3, 0.8, 0.9)
		t.rotation_degrees = Vector3(0, 0, -22 * side)

	# ---------------- PESCOÇO ----------------
	var neck := CylinderMesh.new()
	neck.top_radius = 0.085
	neck.bottom_radius = 0.11
	neck.height = 0.20
	_mesh("Neck", neck, _skin_mat, self, Vector3(0, 1.66, 0.01))

	# ---------------- CABEÇA ----------------
	head_pivot = Node3D.new()
	head_pivot.name = "HeadPivot"
	head_pivot.position = Vector3(0, 1.84, 0)
	add_child(head_pivot)

	var skull := SphereMesh.new()
	skull.radius = 0.19
	skull.height = 0.40
	var skull_inst := _mesh("Head", skull, _skin_mat, head_pivot, Vector3(0, 0.02, 0))
	skull_inst.scale = Vector3(0.95, 1.0, 1.0)

	# mandíbula quadrada com barba por fazer
	var jaw := SphereMesh.new()
	jaw.radius = 0.14
	jaw.height = 0.22
	var jaw_inst := _mesh("Jaw", jaw, stubble_mat, head_pivot, Vector3(0, -0.09, -0.05))
	jaw_inst.scale = Vector3(1.05, 0.75, 1.0)

	var chin := SphereMesh.new()
	chin.radius = 0.06
	chin.height = 0.10
	_mesh("Chin", chin, stubble_mat, head_pivot, Vector3(0, -0.15, -0.14))

	# cabelo raspado (topo achatado)
	var hair := SphereMesh.new()
	hair.radius = 0.195
	hair.height = 0.26
	var hair_inst := _mesh("Hair", hair, hair_mat, head_pivot, Vector3(0, 0.09, 0.015))
	hair_inst.scale = Vector3(0.98, 0.75, 1.0)

	# orelhas
	var ear := SphereMesh.new()
	ear.radius = 0.045
	ear.height = 0.10
	for side in [-1, 1]:
		var e := _mesh("Ear", ear, _skin_mat, head_pivot, Vector3(0.18 * side, 0.0, 0.01))
		e.scale = Vector3(0.5, 1.0, 0.8)

	# nariz
	var nose := SphereMesh.new()
	nose.radius = 0.035
	nose.height = 0.08
	var nose_inst := _mesh("Nose", nose, _skin_mat, head_pivot, Vector3(0, -0.02, -0.19))
	nose_inst.scale = Vector3(0.9, 1.0, 1.1)

	# olhos (branco + pupila) — piscam sozinhos (ver _process)
	var eye_white_mat := _make_mat(Color(0.95, 0.95, 0.92), 0.3)
	var pupil_mat := _make_mat(Color(0.02, 0.02, 0.02), 0.2)
	var eye_mesh := SphereMesh.new()
	eye_mesh.radius = 0.03
	eye_mesh.height = 0.06
	var pupil_mesh := SphereMesh.new()
	pupil_mesh.radius = 0.016
	pupil_mesh.height = 0.032

	for side in [-1, 1]:
		var eye_root := Node3D.new()
		eye_root.name = "EyeRoot"
		eye_root.position = Vector3(0.068 * side, 0.035, -0.165)
		head_pivot.add_child(eye_root)
		_mesh("EyeWhite", eye_mesh, eye_white_mat, eye_root, Vector3.ZERO)
		_mesh("Pupil", pupil_mesh, pupil_mat, eye_root, Vector3(0, 0, -0.022))
		_eyes.append(eye_root)

		# sobrancelha grossa, franzida (cara de treinador bravo)
		var brow := BoxMesh.new()
		brow.size = Vector3(0.075, 0.018, 0.025)
		var b := _mesh("Brow", brow, hair_mat, head_pivot, Vector3(0.07 * side, 0.078, -0.172))
		b.rotation_degrees = Vector3(0, 0, 14 * side)
		_brows.append(b)

	# boca
	var mouth := BoxMesh.new()
	mouth.size = Vector3(0.07, 0.012, 0.02)
	_mesh("Mouth", mouth, _make_mat(Color(0.35, 0.12, 0.10), 0.8), head_pivot, Vector3(0, -0.085, -0.178))

	# ---------------- BRAÇOS ----------------
	left_shoulder = _build_arm("Left", -0.40, _skin_mat, glove_mat, cuff_mat)
	right_shoulder = _build_arm("Right", 0.40, _skin_mat, glove_mat, cuff_mat)

	_build_pro_details()


# ============================================================
# DETALHES DE LUTADOR PROFISSIONAL (só acrescenta peças; nenhum
# pivô de animação foi mexido): faixa dourada e listras no calção,
# emblema FBF, solas brancas e cadarços nas botas, braçadeiras e,
# se `headgear` estiver ligado, o protetor de cabeça.
# ============================================================
func _build_pro_details() -> void:

	var white := _make_mat(Color(0.96, 0.96, 0.96), 0.45)
	var black := _make_mat(Color(0.05, 0.05, 0.06), 0.5)
	var gold := _make_mat(Color(0.95, 0.75, 0.25), 0.3)
	gold.metallic = 0.6

	var hip_y := ANKLE_HEIGHT + (THIGH_LEN + SHIN_LEN) * cos(deg_to_rad(STANCE_KNEE_DEG))

	# faixa dourada na base da cintura do calção
	var gold_ring := CylinderMesh.new()
	gold_ring.top_radius = 0.292
	gold_ring.bottom_radius = 0.292
	gold_ring.height = 0.018
	var gr := _mesh("GoldBand", gold_ring, gold, self, Vector3(0, hip_y + 0.098, 0))
	gr.scale = Vector3(1.0, 1.0, 0.72)

	# emblema FBF na frente do calção (a frente do corpo é -Z)
	var emblem := Label3D.new()
	emblem.text = "FBF"
	emblem.font_size = 64
	emblem.pixel_size = 0.0013
	emblem.modulate = Color(1, 1, 1)
	emblem.outline_size = 8
	emblem.outline_modulate = Color(0, 0, 0, 0.6)
	emblem.shaded = false
	emblem.position = Vector3(0, hip_y - 0.03, -0.226)
	emblem.rotation_degrees = Vector3(0, 180, 0)
	add_child(emblem)

	# pernas: listra lateral e barra na boca do calção, sola e cadarço
	for leg in _legs:

		var hip: Node3D = leg["hip"]
		var ankle: Node3D = leg["ankle"]
		var sgn: float = 1.0 if hip.position.x > 0.0 else -1.0

		_mesh_box("Stripe", Vector3(0.018, 0.19, 0.10), white, hip, Vector3(sgn * 0.164, -0.08, 0.0))

		var hem := CylinderMesh.new()
		hem.top_radius = 0.163
		hem.bottom_radius = 0.163
		hem.height = 0.02
		_mesh("Hem", hem, white, hip, Vector3(0, -0.172, 0))

		_mesh_box("Sole", Vector3(0.14, 0.03, 0.285), white, ankle, Vector3(0, -0.06, -0.05))

		for i in range(3):
			_mesh_box("Lace", Vector3(0.08, 0.008, 0.012), white, ankle, Vector3(0, 0.017, -0.15 + float(i) * 0.04))

	# braçadeiras escuras nos braços
	for sh in [left_shoulder, right_shoulder]:
		var band := TorusMesh.new()
		band.inner_radius = 0.10
		band.outer_radius = 0.128
		_mesh("Armband", band, black, sh, Vector3(0, -0.30, 0))

	# protetor de cabeça (topo/fundo/laterais — a testa e o rosto ficam livres)
	if headgear:

		var gear_mat := _make_mat(body_color, 0.38)
		gear_mat.clearcoat_enabled = true
		gear_mat.clearcoat = 0.5

		var cap := SphereMesh.new()
		cap.radius = 0.205
		cap.height = 0.41
		var cap_inst := _mesh("Headgear", cap, gear_mat, head_pivot, Vector3(0, 0.10, 0.05))
		cap_inst.scale = Vector3(1.0, 0.70, 1.0)

		var pad := SphereMesh.new()
		pad.radius = 0.07
		pad.height = 0.15
		for side in [-1, 1]:
			var pd := _mesh("CheekPad", pad, gear_mat, head_pivot, Vector3(0.165 * side, -0.03, -0.04))
			pd.scale = Vector3(0.55, 1.0, 1.0)


# ============================================================
# FANTASIAS (V-FBF): o Main.gd chama set_costume("brasil") quando a arena
# São Paulo está ativa e set_costume("") nas outras. Só acrescenta peças
# e troca materiais — nenhum pivô de animação é tocado — e tudo é
# desfeito no _clear_costume().
# ============================================================
var _costume_nodes: Array = []
var _costume_saved: Array = []


func set_costume(costume: String) -> void:

	_clear_costume()

	if costume == "brasil":
		_apply_costume_brasil()


func _clear_costume() -> void:

	for n in _costume_nodes:
		if is_instance_valid(n):
			n.queue_free()

	_costume_nodes.clear()

	for e in _costume_saved:
		var mi: MeshInstance3D = e["node"]
		if is_instance_valid(mi):
			mi.material_override = e["mat"]

	_costume_saved.clear()


func _swap_material(mi: MeshInstance3D, mat: Material) -> void:

	if mi == null:
		return

	_costume_saved.append({"node": mi, "mat": mi.material_override})
	mi.material_override = mat


func _costume_mesh(node_name: String, mesh: Mesh, material: Material, parent: Node3D, pos: Vector3) -> MeshInstance3D:

	var mi := _mesh(node_name, mesh, material, parent, pos)
	_costume_nodes.append(mi)

	return mi


func _apply_costume_brasil() -> void:

	var yellow := _make_mat(Color(0.99, 0.86, 0.05), 0.55)
	var green := _make_mat(Color(0.0, 0.58, 0.24), 0.5)
	var blue := _make_mat(Color(0.05, 0.22, 0.72), 0.55)
	var lens := _make_mat(Color(0.35, 0.20, 0.04), 0.1)
	lens.metallic = 0.9
	lens.emission_enabled = true
	lens.emission = Color(0.65, 0.35, 0.05)
	lens.emission_energy_multiplier = 0.3
	var frame := _make_mat(Color(0.92, 0.72, 0.22), 0.25)
	frame.metallic = 0.8

	var hip_y := ANKLE_HEIGHT + (THIGH_LEN + SHIN_LEN) * cos(deg_to_rad(STANCE_KNEE_DEG))

	# ---------- camisa amarela (acompanha a respiração do tórax) ----------
	var shirt := SphereMesh.new()
	shirt.radius = 0.315
	shirt.height = 0.63
	var shirt_inst := _costume_mesh("JerseyChest", shirt, yellow, _chest_group, Vector3.ZERO)
	shirt_inst.scale = Vector3(1.36, 1.05, 0.86)

	var waist := CylinderMesh.new()
	waist.top_radius = 0.29
	waist.bottom_radius = 0.265
	waist.height = 0.38
	var waist_inst := _costume_mesh("JerseyWaist", waist, yellow, self, Vector3(0, hip_y + 0.31, 0))
	waist_inst.scale = Vector3(1.0, 1.0, 0.74)

	var hem := CylinderMesh.new()
	hem.top_radius = 0.268
	hem.bottom_radius = 0.268
	hem.height = 0.025
	var hem_inst := _costume_mesh("JerseyHem", hem, green, self, Vector3(0, hip_y + 0.13, 0))
	hem_inst.scale = Vector3(1.0, 1.0, 0.74)

	# gola verde
	var collar := TorusMesh.new()
	collar.inner_radius = 0.09
	collar.outer_radius = 0.13
	_costume_mesh("JerseyCollar", collar, green, self, Vector3(0, 1.625, 0.01))

	# mangas curtas com barra verde
	for sh in [left_shoulder, right_shoulder]:

		var sleeve := CylinderMesh.new()
		sleeve.top_radius = 0.15
		sleeve.bottom_radius = 0.135
		sleeve.height = 0.22
		_costume_mesh("Sleeve", sleeve, yellow, sh, Vector3(0, -0.10, 0))

		var sleeve_hem := CylinderMesh.new()
		sleeve_hem.top_radius = 0.137
		sleeve_hem.bottom_radius = 0.137
		sleeve_hem.height = 0.025
		_costume_mesh("SleeveHem", sleeve_hem, green, sh, Vector3(0, -0.205, 0))

	# número no peito (meme: 67)
	var number := Label3D.new()
	number.text = "67"
	number.font_size = 72
	number.pixel_size = 0.0034
	number.modulate = Color(0.0, 0.5, 0.2)
	number.outline_size = 0
	number.shaded = false
	number.position = Vector3(0, -0.02, -0.28)
	number.rotation_degrees = Vector3(0, 180, 0)
	_chest_group.add_child(number)
	_costume_nodes.append(number)

	# ---------- calção azul, luvas verdes ----------
	var trunks_node: Node = find_child("Trunks", true, false)

	if trunks_node is MeshInstance3D:
		_swap_material(trunks_node as MeshInstance3D, blue)

	for tl in find_children("*TrunkLeg", "MeshInstance3D", true, false):
		_swap_material(tl as MeshInstance3D, blue)

	var glove_green := _make_mat(Color(0.05, 0.62, 0.26), 0.28)
	glove_green.clearcoat_enabled = true
	glove_green.clearcoat = 0.6

	_swap_material(left_glove, glove_green)
	_swap_material(right_glove, glove_green)

	for tn in ["LeftThumb", "RightThumb"]:
		var th: Node = find_child(tn, true, false)
		if th is MeshInstance3D:
			_swap_material(th as MeshInstance3D, glove_green)

	# ---------- boné amarelo com aba verde ----------
	var cap := SphereMesh.new()
	cap.radius = 0.215
	cap.height = 0.43
	var cap_inst := _costume_mesh("Cap", cap, yellow, head_pivot, Vector3(0, 0.13, 0.05))
	cap_inst.scale = Vector3(1.0, 0.72, 1.0)

	var brim := BoxMesh.new()
	brim.size = Vector3(0.27, 0.02, 0.18)
	var brim_inst := _costume_mesh("CapBrim", brim, green, head_pivot, Vector3(0, 0.105, -0.215))
	brim_inst.rotation_degrees = Vector3(-9, 0, 0)

	# ---------- óculos Juliet (lentes douradas + armação) ----------
	for side in [-1, 1]:

		var lens_mesh := BoxMesh.new()
		lens_mesh.size = Vector3(0.10, 0.058, 0.014)
		var lens_inst := _costume_mesh("JulietLens", lens_mesh, lens, head_pivot, Vector3(0.07 * side, 0.035, -0.216))
		lens_inst.rotation_degrees = Vector3(0, 0, 9 * side)

		var rim_mesh := BoxMesh.new()
		rim_mesh.size = Vector3(0.108, 0.066, 0.008)
		var rim_inst := _costume_mesh("JulietRim", rim_mesh, frame, head_pivot, Vector3(0.07 * side, 0.035, -0.211))
		rim_inst.rotation_degrees = Vector3(0, 0, 9 * side)

		var temple := BoxMesh.new()
		temple.size = Vector3(0.01, 0.012, 0.19)
		var temple_inst := _costume_mesh("JulietTemple", temple, frame, head_pivot, Vector3(0.15 * side, 0.04, -0.12))
		temple_inst.rotation_degrees = Vector3(0, 19 * side, 0)

	var bridge := BoxMesh.new()
	bridge.size = Vector3(0.05, 0.012, 0.012)
	_costume_mesh("JulietBridge", bridge, frame, head_pivot, Vector3(0, 0.045, -0.218))

	# ---------- munhequeiras verde e amarela ----------
	var elbows: Array = [find_child("LeftElbow", true, false), find_child("RightElbow", true, false)]

	for eb in elbows:

		if eb is Node3D:
			var wrist := TorusMesh.new()
			wrist.inner_radius = 0.075
			wrist.outer_radius = 0.105
			_costume_mesh("Wristband", wrist, green, eb as Node3D, Vector3(0, -0.26, 0))


# Caixa simples (usada pelos detalhes acima)
func _mesh_box(node_name: String, size: Vector3, material: Material, parent: Node3D, mesh_position: Vector3) -> MeshInstance3D:

	var box := BoxMesh.new()
	box.size = size

	return _mesh(node_name, box, material, parent, mesh_position)


# ============================================================
# BRAÇO ARTICULADO (musculoso)
# ============================================================

func _build_arm(
	side_name: String,
	x_offset: float,
	skin_mat: StandardMaterial3D,
	glove_mat: StandardMaterial3D,
	cuff_mat: StandardMaterial3D
) -> Node3D:

	var s := -1.0 if side_name == "Left" else 1.0

	var shoulder := Node3D.new()
	shoulder.name = side_name + "Shoulder"
	shoulder.position = Vector3(x_offset, 1.44, -0.10)
	add_child(shoulder)

	# deltoide (redondão, acompanha o braço)
	var delt := SphereMesh.new()
	delt.radius = 0.13
	delt.height = 0.24
	var d := _mesh(side_name + "Delt", delt, skin_mat, shoulder, Vector3(0.015 * s, -0.04, 0))
	d.scale = Vector3(1.0, 1.05, 1.05)

	# braço
	var upper := CapsuleMesh.new()
	upper.radius = 0.095
	upper.height = 0.46
	_mesh(side_name + "UpperArm", upper, skin_mat, shoulder, Vector3(0, -0.23, 0))

	# bíceps (frente) e tríceps (trás)
	var bicep := SphereMesh.new()
	bicep.radius = 0.09
	bicep.height = 0.26
	_mesh(side_name + "Bicep", bicep, skin_mat, shoulder, Vector3(0, -0.24, -0.045))

	var tricep := SphereMesh.new()
	tricep.radius = 0.085
	tricep.height = 0.24
	_mesh(side_name + "Tricep", tricep, skin_mat, shoulder, Vector3(0.01 * s, -0.20, 0.045))

	# cotovelo
	var elbow := Node3D.new()
	elbow.name = side_name + "Elbow"
	elbow.position = Vector3(0, -0.46, 0)
	shoulder.add_child(elbow)

	# antebraço grosso, afinando até o punho
	var forearm := CylinderMesh.new()
	forearm.top_radius = 0.088
	forearm.bottom_radius = 0.062
	forearm.height = 0.34
	_mesh(side_name + "Forearm", forearm, skin_mat, elbow, Vector3(0, -0.17, 0))

	var fore_bulge := SphereMesh.new()
	fore_bulge.radius = 0.085
	fore_bulge.height = 0.22
	_mesh(side_name + "ForearmBulge", fore_bulge, skin_mat, elbow, Vector3(0, -0.10, -0.01))

	# punho da luva (branco)
	var cuff := CylinderMesh.new()
	cuff.top_radius = 0.085
	cuff.bottom_radius = 0.095
	cuff.height = 0.10
	_mesh(side_name + "Cuff", cuff, cuff_mat, elbow, Vector3(0, -0.32, 0))

	# luva grande
	var glove_mesh := SphereMesh.new()
	glove_mesh.radius = 0.135
	glove_mesh.height = 0.29
	var glove := _mesh(side_name + "Glove", glove_mesh, glove_mat, elbow, Vector3(0, -0.45, -0.01))
	glove.scale = Vector3(1.0, 1.0, 1.08)

	# polegar colado na luva
	var thumb := CapsuleMesh.new()
	thumb.radius = 0.04
	thumb.height = 0.15
	var th := _mesh(side_name + "Thumb", thumb, glove_mat, elbow, Vector3(-0.09 * s, -0.42, -0.07))
	th.rotation_degrees = Vector3(-20, 0, 25 * s)

	if side_name == "Left":
		left_elbow = elbow
		left_glove = glove
	else:
		right_elbow = elbow
		right_glove = glove

	return shoulder


# ============================================================
# PERNAS (quadril -> joelho -> tornozelo)
# ============================================================

func _build_leg(
	side_name: String,
	x_offset: float,
	z_offset: float,
	skin_mat: StandardMaterial3D,
	trunks_mat: StandardMaterial3D,
	shoe_mat: StandardMaterial3D,
	sock_mat: StandardMaterial3D
) -> void:

	var hip_y := ANKLE_HEIGHT + (THIGH_LEN + SHIN_LEN) * cos(deg_to_rad(STANCE_KNEE_DEG))

	var hip := Node3D.new()
	hip.name = side_name + "Hip"
	hip.position = Vector3(x_offset, hip_y, z_offset)
	add_child(hip)

	# coxa (quadríceps grosso)
	var thigh := CapsuleMesh.new()
	thigh.radius = 0.135
	thigh.height = 0.50
	_mesh(side_name + "Thigh", thigh, skin_mat, hip, Vector3(0, -THIGH_LEN * 0.5, 0))

	var quad := SphereMesh.new()
	quad.radius = 0.11
	quad.height = 0.30
	_mesh(side_name + "Quad", quad, skin_mat, hip, Vector3(0, -0.22, -0.05))

	# perna do calção
	var leg_trunk := CylinderMesh.new()
	leg_trunk.top_radius = 0.165
	leg_trunk.bottom_radius = 0.16
	leg_trunk.height = 0.20
	_mesh(side_name + "TrunkLeg", leg_trunk, trunks_mat, hip, Vector3(0, -0.08, 0))

	var knee := Node3D.new()
	knee.name = side_name + "Knee"
	knee.position = Vector3(0, -THIGH_LEN, 0)
	hip.add_child(knee)

	var shin := CapsuleMesh.new()
	shin.radius = 0.085
	shin.height = 0.44
	_mesh(side_name + "Shin", shin, skin_mat, knee, Vector3(0, -SHIN_LEN * 0.5, 0))

	# panturrilha
	var calf := SphereMesh.new()
	calf.radius = 0.09
	calf.height = 0.24
	_mesh(side_name + "Calf", calf, skin_mat, knee, Vector3(0, -0.13, 0.04))

	var ankle := Node3D.new()
	ankle.name = side_name + "Ankle"
	ankle.position = Vector3(0, -SHIN_LEN, 0)
	knee.add_child(ankle)

	var sock := CylinderMesh.new()
	sock.top_radius = 0.07
	sock.bottom_radius = 0.07
	sock.height = 0.10
	_mesh(side_name + "Sock", sock, sock_mat, ankle, Vector3(0, 0.02, 0))

	# bota de boxe (cano alto)
	var shoe := BoxMesh.new()
	shoe.size = Vector3(0.13, 0.09, 0.27)
	_mesh(side_name + "Shoe", shoe, shoe_mat, ankle, Vector3(0, -ANKLE_HEIGHT + 0.045, -0.05))

	_legs.append({"hip": hip, "knee": knee, "ankle": ankle})


# ============================================================
# CRIA MESH
# ============================================================

func _mesh(
	node_name: String,
	mesh: Mesh,
	material: Material,
	parent: Node3D,
	mesh_position: Vector3
) -> MeshInstance3D:

	var instance := MeshInstance3D.new()

	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = mesh_position

	parent.add_child(instance)

	return instance


# ============================================================
# VIDA PROCEDURAL — respiração, pernas, piscada, sobrancelha
# ============================================================
# Roda todo frame, POR CIMA das poses: mexe só em nós que as poses
# não tocam (grupo do tórax, quadril/joelho/tornozelo, olhos,
# sobrancelhas), então nunca briga com go_to_pose().

func _process(delta: float) -> void:

	_life_time += delta

	# respiração — o peito enche e esvazia (mais rápido quando bravo)
	var breath_speed := 3.2 if current_pose == "angry" else 1.9
	var b := sin(_life_time * breath_speed)
	if _chest_group:
		_chest_group.scale = Vector3(1.0 + 0.012 * b, 1.0 + 0.018 * b, 1.0 + 0.03 * b)

	_update_legs()

	# piscada
	_blink_timer -= delta
	var eye_y := 1.0
	if _blink_timer < 0.0:
		eye_y = 0.12
		if _blink_timer < -0.09:
			_blink_timer = randf_range(2.0, 4.5)
	if _ko:
		eye_y = 0.1
	for e in _eyes:
		e.scale.y = eye_y

	# sobrancelha: franze mais quando bravo, sobe quando apanha
	var brow_target := 14.0
	var brow_lift := 0.0
	if current_pose == "angry" or current_pose.ends_with("_wind"):
		brow_target = 26.0
		brow_lift = -0.008
	elif current_pose.begins_with("hit_") or current_pose == "dizzy" or current_pose == "ko":
		brow_target = -8.0
		brow_lift = 0.014
	for i in range(_brows.size()):
		var br: MeshInstance3D = _brows[i]
		var side := -1.0 if i == 0 else 1.0
		br.rotation_degrees.z = lerp(br.rotation_degrees.z, brow_target * side, min(1.0, delta * 12.0))
		br.position.y = lerp(br.position.y, 0.078 + brow_lift, min(1.0, delta * 12.0))


# Mantém os pés no chão: quanto mais o corpo desce em relação à
# posição base, mais os joelhos dobram (conta de dois segmentos
# iguais: altura = 2 * L * cos(ângulo)). Se o corpo sobe (pulinho),
# as pernas esticam e o pé sai do chão naturalmente.
func _update_legs() -> void:

	if _legs.is_empty():
		return

	var drop := base_position.y - position.y
	var base_cos := cos(deg_to_rad(STANCE_KNEE_DEG))
	var c: float = clamp(base_cos - drop / (THIGH_LEN + SHIN_LEN) * 1.0, cos(deg_to_rad(65.0)), 1.0)
	var a := rad_to_deg(acos(c))

	for leg in _legs:
		var hip: Node3D = leg["hip"]
		var knee: Node3D = leg["knee"]
		var ankle: Node3D = leg["ankle"]
		hip.rotation_degrees.x = a
		knee.rotation_degrees.x = -2.0 * a
		ankle.rotation_degrees.x = a


# ============================================================
# ANIMAÇÃO DE POSE
# ============================================================

func go_to_pose(
	pose_name: String,
	duration: float = 0.2
) -> void:

	if not POSES.has(pose_name):
		return

	# nocauteado não levanta sozinho (só com revive())
	if _ko:
		return

	_kill_idle_tween()

	current_pose = pose_name

	var pose: Dictionary = POSES[pose_name]

	# Sem braço articulado pra vender o golpe, o modelo importado
	# precisa de um deslocamento/rotação de corpo inteiro bem mais
	# forte pra a mesma pose ainda ser legível (ver
	# IMPORTED_MODEL_MOTION_BOOST no topo do arquivo).
	var motion_scale: float = IMPORTED_MODEL_MOTION_BOOST if using_imported_model else 1.0

	# Curva de movimento — cada pose escolhe a sua (preparação
	# acelera aos poucos, golpe é seco e "estoura" no final, apanhar é
	# abrupto...). Se uma pose não especificar, cai num padrão neutro.
	var trans: int = pose.get("trans", Tween.TRANS_QUAD)
	var ease: int = pose.get("ease", Tween.EASE_OUT)

	var tween := create_tween()
	tween.set_parallel(true)


	# CORPO
	if pose.has("root_pos"):

		tween.tween_property(
			self,
			"position",
			base_position + _local_offset(pose["root_pos"]) * motion_scale,
			duration
		).set_trans(trans).set_ease(ease)


	if pose.has("root_rot"):

		tween.tween_property(
			self,
			"rotation_degrees",
			base_rotation_degrees + pose["root_rot"] * motion_scale,
			duration
		).set_trans(trans).set_ease(ease)


	# CABEÇA
	if pose.has("head_rot"):

		tween.tween_property(
			head_pivot,
			"rotation_degrees",
			pose["head_rot"],
			duration
		).set_trans(trans).set_ease(ease)


	# OMBRO ESQUERDO
	if pose.has("left_shoulder"):

		tween.tween_property(
			left_shoulder,
			"rotation_degrees",
			pose["left_shoulder"],
			duration
		).set_trans(trans).set_ease(ease)


	# OMBRO DIREITO
	if pose.has("right_shoulder"):

		tween.tween_property(
			right_shoulder,
			"rotation_degrees",
			pose["right_shoulder"],
			duration
		).set_trans(trans).set_ease(ease)


	# COTOVELO ESQUERDO
	if pose.has("left_elbow"):

		tween.tween_property(
			left_elbow,
			"rotation_degrees",
			pose["left_elbow"],
			duration
		).set_trans(trans).set_ease(ease)


	# COTOVELO DIREITO
	if pose.has("right_elbow"):

		tween.tween_property(
			right_elbow,
			"rotation_degrees",
			pose["right_elbow"],
			duration
		).set_trans(trans).set_ease(ease)


	# Parado na guarda? Assim que a pose terminar de assentar, começa
	# a respirar sozinho (só some quando outra pose for pedida).
	if pose_name == "guard":

		tween.chain().tween_callback(
			_start_idle_breathing
		)


# Os deslocamentos de pose usam Z = "pra frente do treinador" (negativo
# = avança). Como ele está girado 180° pra olhar pro jogador, o Z
# precisa ser convertido pra direção real que ele encara — antes o
# bote do soco ia pra TRÁS (se afastando). X/Y ficam como já estavam
# (as reações de apanhar já estavam calibradas no espaço do mundo).
func _local_offset(offset: Vector3) -> Vector3:

	var forward := Basis.from_euler(base_rotation_degrees * (PI / 180.0)) * Vector3(0, 0, -1)
	forward.y = 0.0
	if forward.length() > 0.001:
		forward = forward.normalized()
	return Vector3(offset.x, offset.y, 0.0) + forward * (-offset.z)


func _kill_idle_tween() -> void:

	if _idle_tween and _idle_tween.is_valid():
		_idle_tween.kill()


# Balanço de respiração sutil (sobe/desce bem de leve) enquanto o
# treinador espera parado na guarda entre os desafios — só um detalhe
# de vida, não interfere em nada do jogo.
func _start_idle_breathing() -> void:

	if current_pose != "guard":
		return

	_kill_idle_tween()

	var guard: Dictionary = POSES["guard"]
	var ls: Vector3 = guard["left_shoulder"]
	var rs: Vector3 = guard["right_shoulder"]
	var hr: Vector3 = guard["head_rot"]
	var rr: Vector3 = guard["root_rot"]

	# Gingado de boxeador: quica nos joelhos (as pernas dobram sozinhas
	# em _update_legs), balança o tronco de um lado pro outro e as
	# luvas "pulsam" alternadas, como quem está estudando o adversário.
	var tw := create_tween()
	tw.set_loops()

	# desce + pende pra um lado
	tw.set_parallel(true)
	tw.tween_property(self, "position:y", base_position.y - 0.03, 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(self, "rotation_degrees", base_rotation_degrees + rr + Vector3(0, 3, 2), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(left_shoulder, "rotation_degrees", ls + Vector3(6, 0, 0), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(right_shoulder, "rotation_degrees", rs + Vector3(-3, 0, 0), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(head_pivot, "rotation_degrees", hr + Vector3(3, 2, -2), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	# sobe
	tw.chain().tween_property(self, "position:y", base_position.y, 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	# desce + pende pro outro lado
	tw.chain().tween_property(self, "position:y", base_position.y - 0.03, 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(self, "rotation_degrees", base_rotation_degrees + rr + Vector3(0, -3, -2), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(left_shoulder, "rotation_degrees", ls + Vector3(-3, 0, 0), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(right_shoulder, "rotation_degrees", rs + Vector3(6, 0, 0), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(head_pivot, "rotation_degrees", hr + Vector3(3, -2, 2), 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	# sobe
	tw.chain().tween_property(self, "position:y", base_position.y, 0.30).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	_idle_tween = tw


# ============================================================
# SOCO ESQUERDO
# ============================================================

func attack_left() -> void:

	animation_id += 1

	var id := animation_id

	go_to_pose("attack_left_wind", 0.18)

	await get_tree().create_timer(0.18).timeout

	if id != animation_id:
		return

	go_to_pose("attack_left_strike", 0.08)

	await get_tree().create_timer(0.10).timeout

	if id != animation_id:
		return

	go_to_pose("guard", 0.25)


# ============================================================
# SOCO DIREITO
# ============================================================

func attack_right() -> void:

	animation_id += 1

	var id := animation_id

	go_to_pose("attack_right_wind", 0.18)

	await get_tree().create_timer(0.18).timeout

	if id != animation_id:
		return

	go_to_pose("attack_right_strike", 0.08)

	await get_tree().create_timer(0.10).timeout

	if id != animation_id:
		return

	go_to_pose("guard", 0.25)


# ============================================================
# ATAQUE BAIXO
# ============================================================

func attack_low() -> void:

	animation_id += 1

	var id := animation_id

	go_to_pose("attack_low_wind", 0.18)

	await get_tree().create_timer(0.18).timeout

	if id != animation_id:
		return

	go_to_pose("attack_low_strike", 0.08)

	await get_tree().create_timer(0.10).timeout

	if id != animation_id:
		return

	go_to_pose("guard", 0.25)


# ============================================================
# TOMOU GOLPE
# ============================================================

func take_hit_left() -> void:

	animation_id += 1
	var id := animation_id

	go_to_pose("hit_left", 0.08)

	await get_tree().create_timer(0.10).timeout

	if id != animation_id:
		return

	_dizzy(id)


func take_hit_right() -> void:

	animation_id += 1
	var id := animation_id

	go_to_pose("hit_right", 0.08)

	await get_tree().create_timer(0.10).timeout

	if id != animation_id:
		return

	_dizzy(id)


func take_hit_center() -> void:

	animation_id += 1
	var id := animation_id

	go_to_pose("hit_center", 0.08)

	await get_tree().create_timer(0.12).timeout

	if id != animation_id:
		return

	_dizzy(id)


# ============================================================
# TONTEIRA
# ============================================================

func _dizzy(id: int) -> void:

	go_to_pose("dizzy", 0.16)

	await get_tree().create_timer(0.16).timeout

	if id != animation_id:
		return

	var motion_scale: float = IMPORTED_MODEL_MOTION_BOOST if using_imported_model else 1.0

	# BALANÇA PARA UM LADO
	var tween1 := create_tween()

	tween1.set_parallel(true)

	tween1.tween_property(
		self,
		"rotation_degrees",
		base_rotation_degrees + Vector3(0, -18, -9) * motion_scale,
		0.16
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	tween1.tween_property(
		head_pivot,
		"rotation_degrees",
		Vector3(0, 25, -15),
		0.16
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	await tween1.finished

	if id != animation_id:
		return


	# BALANÇA PARA O OUTRO
	var tween2 := create_tween()

	tween2.set_parallel(true)

	tween2.tween_property(
		self,
		"rotation_degrees",
		base_rotation_degrees + Vector3(0, 18, 9) * motion_scale,
		0.16
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	tween2.tween_property(
		head_pivot,
		"rotation_degrees",
		Vector3(0, -25, 15),
		0.16
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	await tween2.finished

	if id != animation_id:
		return


	go_to_pose("guard", 0.30)


# ============================================================
# FICA BRAVO
# ============================================================

func get_angry() -> void:

	animation_id += 1

	var id := animation_id

	go_to_pose("angry", 0.15)

	await get_tree().create_timer(0.18).timeout

	if id != animation_id:
		return

	# Pequena aproximação
	var motion_scale: float = IMPORTED_MODEL_MOTION_BOOST if using_imported_model else 1.0
	var tween := create_tween()

	tween.tween_property(
		self,
		"position",
		base_position + _local_offset(Vector3(0, 0, -0.10)) * motion_scale,
		0.12
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

	await tween.finished

	if id != animation_id:
		return

	await get_tree().create_timer(0.20).timeout

	go_to_pose("guard", 0.25)


# ============================================================
# COMEMORA
# ============================================================

func celebrate_hit() -> void:

	animation_id += 1

	var id := animation_id

	go_to_pose("celebrate", 0.18)

	await get_tree().create_timer(0.18).timeout

	if id != animation_id:
		return


	# BRAÇOS PARA CIMA
	var tween := create_tween()

	tween.set_parallel(true)

	tween.tween_property(
		left_shoulder,
		"rotation_degrees",
		Vector3(160, 0, -12),
		0.15
	).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	tween.tween_property(
		right_shoulder,
		"rotation_degrees",
		Vector3(160, 0, 12),
		0.15
	).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	await tween.finished

	if id != animation_id:
		return


	# PEQUENO PULO
	var jump_scale: float = IMPORTED_MODEL_MOTION_BOOST if using_imported_model else 1.0
	var jump := create_tween()

	jump.tween_property(
		self,
		"position",
		base_position + Vector3(0, 0.10, 0) * jump_scale,
		0.10
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

	jump.tween_property(
		self,
		"position",
		base_position,
		0.16
	).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)

	await jump.finished

	if id != animation_id:
		return

	await get_tree().create_timer(0.25).timeout

	go_to_pose("guard", 0.25)


# ============================================================
# ERROU O SOCO
# ============================================================

func attack_missed() -> void:

	animation_id += 1

	var id := animation_id

	var motion_scale: float = IMPORTED_MODEL_MOTION_BOOST if using_imported_model else 1.0
	var tween := create_tween()

	tween.set_parallel(true)

	tween.tween_property(
		self,
		"rotation_degrees",
		base_rotation_degrees + Vector3(0, 0, 12) * motion_scale,
		0.15
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	tween.tween_property(
		head_pivot,
		"rotation_degrees",
		Vector3(0, 0, 10),
		0.15
	).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

	await tween.finished

	if id != animation_id:
		return

	go_to_pose("guard", 0.25)


# ============================================================
# SOCO BLOQUEADO (jogador fez a DEFESA ALTA)
# ============================================================
# O golpe bate nas luvas do jogador e "quica": o braço volta, o corpo
# recua um pouco e ele balança a cabeça, meio contrariado.

func attack_blocked() -> void:

	animation_id += 1
	var id := animation_id
	_kill_idle_tween()
	current_pose = "blocked"

	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(self, "position", base_position + _local_offset(Vector3(0, 0.02, 0.10)), 0.10).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(6, -4, 0), 0.10).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(left_shoulder, "rotation_degrees", Vector3(30, -31, 0), 0.10).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(right_shoulder, "rotation_degrees", Vector3(30, 31, 0), 0.10).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(left_elbow, "rotation_degrees", Vector3(140, 0, 0), 0.10)
	tw.tween_property(right_elbow, "rotation_degrees", Vector3(140, 0, 0), 0.10)
	tw.tween_property(head_pivot, "rotation_degrees", Vector3(10, 0, 0), 0.10)

	# balança a cabeça ("tsc...")
	tw.chain().tween_property(head_pivot, "rotation_degrees", Vector3(5, 14, 0), 0.12)
	tw.chain().tween_property(head_pivot, "rotation_degrees", Vector3(5, -14, 0), 0.14)
	tw.chain().tween_property(head_pivot, "rotation_degrees", Vector3(0, 0, 0), 0.10)

	await tw.finished
	if id != animation_id:
		return
	go_to_pose("guard", 0.25)


# ============================================================
# NOCAUTE (o jogador venceu)
# ============================================================
# 1) a cabeça estala pra trás com o gancho, 2) os joelhos cedem e ele
# cambaleia, 3) cai de costas no ringue e 4) quica no chão, com os
# braços abertos, olhos fechados. Fica deitado até revive().

func knockout() -> void:

	animation_id += 1
	var id := animation_id
	_kill_idle_tween()
	current_pose = "ko"
	_ko = true

	# 1) impacto
	var t1 := create_tween()
	t1.set_parallel(true)
	t1.tween_property(head_pivot, "rotation_degrees", Vector3(42, 15, 10), 0.10).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	t1.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(14, 0, 4), 0.14).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	t1.tween_property(self, "position", base_position + _local_offset(Vector3(0, 0.04, 0.18)), 0.14).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	t1.tween_property(left_shoulder, "rotation_degrees", Vector3(40, 55, -45), 0.14)
	t1.tween_property(right_shoulder, "rotation_degrees", Vector3(40, -55, 45), 0.14)
	t1.tween_property(left_elbow, "rotation_degrees", Vector3(0, 0, -20), 0.14)
	t1.tween_property(right_elbow, "rotation_degrees", Vector3(0, 0, 20), 0.14)
	await t1.finished
	if id != animation_id:
		return

	# 2) joelhos cedem, cambaleia
	var t2 := create_tween()
	t2.set_parallel(true)
	t2.tween_property(self, "position", base_position + _local_offset(Vector3(0, -0.24, 0.26)), 0.40).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t2.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(8, 6, -8), 0.40).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t2.tween_property(head_pivot, "rotation_degrees", Vector3(25, -12, -22), 0.40).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t2.tween_property(left_shoulder, "rotation_degrees", Vector3(10, 20, -20), 0.40)
	t2.tween_property(right_shoulder, "rotation_degrees", Vector3(10, -20, 20), 0.40)
	await t2.finished
	if id != animation_id:
		return

	# 3) cai de costas (gira em volta dos pés; sobe um pouco o corpo pra
	#    as costas encostarem no chão em vez de atravessar)
	var t3 := create_tween()
	t3.set_parallel(true)
	t3.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(88, 0, 0), 0.50).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t3.tween_property(self, "position", base_position + _local_offset(Vector3(0, 0.22, 0.30)), 0.50).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t3.tween_property(left_shoulder, "rotation_degrees", Vector3(160, 0, -45), 0.50)
	t3.tween_property(right_shoulder, "rotation_degrees", Vector3(160, 0, 45), 0.50)
	t3.tween_property(left_elbow, "rotation_degrees", Vector3(0, 0, -25), 0.50)
	t3.tween_property(right_elbow, "rotation_degrees", Vector3(0, 0, 25), 0.50)
	t3.tween_property(head_pivot, "rotation_degrees", Vector3(-10, 35, 0), 0.50)
	await t3.finished
	if id != animation_id:
		return

	# 4) quica no chão
	var t4 := create_tween()
	t4.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(80, 0, 0), 0.10).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t4.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(88, 0, 0), 0.14).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	t4.tween_property(self, "rotation_degrees", base_rotation_degrees + Vector3(86, 0, 0), 0.06)


# Levanta na hora (nova partida / voltar ao menu).
func revive() -> void:

	animation_id += 1
	_kill_idle_tween()
	_ko = false
	position = base_position
	rotation_degrees = base_rotation_degrees
	if head_pivot:
		head_pivot.rotation_degrees = Vector3.ZERO
	current_pose = "guard"
	go_to_pose("guard", 0.01)


# ============================================================
# GUARDA
# ============================================================

func set_guard() -> void:

	animation_id += 1

	go_to_pose("guard", 0.25)


# Pose do menu: aponta pro jogador e "cutuca" o ar de leve, sem parar.
# (qualquer go_to_pose() depois disso cancela o cutucar sozinho)
func menu_point() -> void:

	animation_id += 1
	var id := animation_id

	go_to_pose("menu_point", 0.5)

	await get_tree().create_timer(0.55).timeout

	if id != animation_id or current_pose != "menu_point":
		return

	_kill_idle_tween()

	var ls: Vector3 = POSES["menu_point"]["left_shoulder"]

	var tw := create_tween()
	tw.set_loops()
	tw.tween_property(left_shoulder, "rotation_degrees", ls + Vector3(8, -3, 0), 0.34).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(left_shoulder, "rotation_degrees", ls, 0.34).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	_idle_tween = tw


func recover() -> void:

	animation_id += 1

	go_to_pose("guard", 0.25)


# ============================================================
# BASE
# ============================================================

func set_base_transform(
	new_position: Vector3,
	new_rotation_degrees: Vector3
) -> void:

	base_position = new_position
	base_rotation_degrees = new_rotation_degrees

	position = new_position
	rotation_degrees = new_rotation_degrees


# ============================================================
# POSIÇÕES
# ============================================================

func chest_position() -> Vector3:

	return global_position + Vector3(0, 1.35, 0)


func head_position() -> Vector3:

	return head_pivot.global_position


func left_glove_position() -> Vector3:

	return left_glove.global_position


func right_glove_position() -> Vector3:

	return right_glove.global_position
