# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node3D
class_name PlayerArms3D

# ============================================================
# BRAÇOS DO JOGADOR (primeira pessoa) — 100% feitos por código
# ============================================================
# Vai preso na câmera. Cada braço tem ombro -> cotovelo -> punho de
# verdade, então dá pra dobrar/esticar, girar o punho no soco etc.
#
# Camadas (cada uma mexida por uma coisa diferente, pra nunca brigar):
#   PlayerArms3D  (posição/escala fixas, colocado pelo Main)
#     └ React     (tweens de reação: tranco, esquiva, giro do tronco)
#         └ Sway  (respiração/balanço contínuo, em _process)
#             └ IdleL / IdleR   (micro-movimento de cada luva)
#                 └ Shoulder -> Elbow -> Wrist -> luva
#
# Os segmentos apontam pra -Z (pra frente da câmera). Ângulos das
# poses foram calculados por cinemática (as luvas caem dentro do campo
# de visão da câmera, FOV 75°).

@export var skin_color: Color = Color(0.80, 0.58, 0.42)
@export var glove_color: Color = Color(0.10, 0.32, 0.88)   # (antigo, não usado mais)
# Luva ESQUERDA vermelha, DIREITA azul (igual ao boneco, aos indicadores
# e à câmera).
@export var left_glove_color: Color = Color(0.85, 0.12, 0.12)
@export var right_glove_color: Color = Color(0.12, 0.35, 0.95)
@export var cuff_color: Color = Color(0.95, 0.95, 0.95)
@export var wrap_color: Color = Color(0.93, 0.93, 0.90)

const SHOULDER_POS := Vector3(0.24, -0.30, 0.12)   # braço direito (esquerdo é espelhado)
const UPPER_LEN := 0.30
const FOREARM_LEN := 0.27

# Poses do braço DIREITO (o esquerdo usa _mirror). x = ergue/abaixa,
# y = fecha pra dentro, z = torce. Cotovelo: x = dobra. Punho: z = gira
# (na guarda a palma fica virada pra dentro; no soco o punho gira até
# a palma ficar pra baixo — o "saca-rolha" do soco de verdade).
const POSES := {
	"lowered": {"sh": Vector3(-62, 6, 0),  "el": Vector3(25, 0, 0),  "wr": Vector3(0, 0, -80)},
	"guard":   {"sh": Vector3(-23, 12, 0), "el": Vector3(85, 0, 0),  "wr": Vector3(0, 0, -70)},
	"tuck":    {"sh": Vector3(-17, 17, 0), "el": Vector3(96, 0, 0),  "wr": Vector3(0, 0, -75)},
	"wind":    {"sh": Vector3(-33, 6, 0),  "el": Vector3(102, 0, 0), "wr": Vector3(0, 0, -60)},
	"jab":     {"sh": Vector3(16, 15, 0),  "el": Vector3(2, 0, 0),   "wr": Vector3(0, 0, 0)},
	"cross":   {"sh": Vector3(14, 22, 0),  "el": Vector3(0, 0, 0),   "wr": Vector3(0, 0, 8)},
	"cover":   {"sh": Vector3(-6, 22, 0),  "el": Vector3(110, 0, 0), "wr": Vector3(0, 0, -60)},
	"cheer":   {"sh": Vector3(34, -6, 0),  "el": Vector3(34, 0, 0),  "wr": Vector3(0, 0, -40)},
	# defesa alta: antebraços em pé na frente do rosto, luvas na testa
	"high_block": {"sh": Vector3(2, 20, 6),  "el": Vector3(72, 0, 0),  "wr": Vector3(0, 0, -85)},
	# gancho de baixo pra cima (golpe final do nocaute)
	"upper_wind": {"sh": Vector3(-47, 8, 8), "el": Vector3(104, 0, 0), "wr": Vector3(0, 0, -40)},
	"uppercut":   {"sh": Vector3(14, 19, 4), "el": Vector3(29, 0, 0),  "wr": Vector3(0, 0, -90)},
	# os dois braços pro alto (vitória)
	"victory":    {"sh": Vector3(37, -1, 20), "el": Vector3(23, 0, 0), "wr": Vector3(0, 0, -40)},
}

# Tempo (s) entre chamar uppercut() e a luva chegar no queixo do
# treinador — o Main.gd espera isso pra disparar o nocaute no momento
# exato do impacto.
const UPPERCUT_IMPACT_TIME := 0.23
var _react: Node3D
var _sway: Node3D
var _idle := {}            # side (-1/1) -> Node3D
var _shoulder := {}
var _elbow := {}
var _wrist := {}

var _pose_tween: Tween
var _react_tween: Tween
var _anim_id := 0

var _time := 0.0
var _idle_weight := 1.0
var _idle_target := 1.0


# ============================================================
# CONSTRUÇÃO
# ============================================================

func _ready() -> void:

	_react = Node3D.new()
	_react.name = "React"
	add_child(_react)

	_sway = Node3D.new()
	_sway.name = "Sway"
	_react.add_child(_sway)

	var skin := _mat(skin_color, 0.5)
	skin.metallic_specular = 0.6
	var skin_dark := _mat(skin_color.darkened(0.15), 0.55)
	var cuff := _mat(cuff_color, 0.55)
	var wrap_m := _mat(wrap_color, 0.95)

	for side in [-1, 1]:
		var gc: Color = left_glove_color if side < 0 else right_glove_color
		var glove := _mat(gc, 0.25)
		glove.clearcoat_enabled = true
		glove.clearcoat = 0.7
		var glove_dark := _mat(gc.darkened(0.35), 0.35)
		_build_arm(side, skin, skin_dark, glove, glove_dark, cuff, wrap_m)

	_apply_pose_instant("lowered")


func _mat(c: Color, rough: float) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m


func _part(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot
	mi.scale = scl
	# braço de primeira pessoa não projeta sombra (evita sombra
	# estranha "flutuando" na frente da câmera)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


# Cápsula/cilindro nascem em pé (eixo Y); girando 90° em X eles
# deitam ao longo do eixo Z (o "comprimento" do braço).
const ALONG_Z := Vector3(90, 0, 0)


func _build_arm(side: int, skin, skin_dark, glove, glove_dark, cuff, wrap_m) -> void:

	var s := float(side)

	var idle := Node3D.new()
	idle.name = "Idle" + ("R" if side > 0 else "L")
	idle.position = Vector3(SHOULDER_POS.x * s, SHOULDER_POS.y, SHOULDER_POS.z)
	_sway.add_child(idle)

	var shoulder := Node3D.new()
	shoulder.name = "Shoulder"
	idle.add_child(shoulder)

	# --- braço (bíceps grande) ---
	var upper := CapsuleMesh.new()
	upper.radius = 0.062
	upper.height = UPPER_LEN + 0.06
	_part(shoulder, upper, skin, Vector3(0, 0, -UPPER_LEN * 0.5), ALONG_Z)

	var bicep := SphereMesh.new()
	bicep.radius = 0.058
	bicep.height = 0.15
	_part(shoulder, bicep, skin, Vector3(0, 0.03, -UPPER_LEN * 0.55), ALONG_Z)

	# --- cotovelo ---
	var elbow := Node3D.new()
	elbow.name = "Elbow"
	elbow.position = Vector3(0, 0, -UPPER_LEN)
	shoulder.add_child(elbow)

	var elbow_ball := SphereMesh.new()
	elbow_ball.radius = 0.055
	elbow_ball.height = 0.11
	_part(elbow, elbow_ball, skin_dark, Vector3(0, -0.005, 0.005))

	# --- antebraço (grosso perto do cotovelo, afina no punho) ---
	var fore := CylinderMesh.new()
	fore.top_radius = 0.054       # lado do cotovelo (topo vira +Z)
	fore.bottom_radius = 0.041    # lado do punho
	fore.height = FOREARM_LEN
	_part(elbow, fore, skin, Vector3(0, 0, -FOREARM_LEN * 0.5), ALONG_Z)

	var flexor := SphereMesh.new()
	flexor.radius = 0.052
	flexor.height = 0.16
	_part(elbow, flexor, skin, Vector3(-0.006 * s, 0.006, -0.08), ALONG_Z)

	# veia saltada no antebraço
	var vein := CapsuleMesh.new()
	vein.radius = 0.006
	vein.height = 0.16
	_part(elbow, vein, skin_dark, Vector3(0.02 * s, 0.046, -0.13), Vector3(88, 0, -8 * s))

	# atadura aparecendo antes da luva
	var wrap_mesh := CylinderMesh.new()
	wrap_mesh.top_radius = 0.045
	wrap_mesh.bottom_radius = 0.043
	wrap_mesh.height = 0.05
	_part(elbow, wrap_mesh, wrap_m, Vector3(0, 0, -FOREARM_LEN + 0.03), ALONG_Z)

	# --- punho (gira no soco) ---
	var wrist := Node3D.new()
	wrist.name = "Wrist"
	wrist.position = Vector3(0, 0, -FOREARM_LEN)
	elbow.add_child(wrist)

	# punho da luva (branco) + faixa escura
	var cuff_mesh := CylinderMesh.new()
	cuff_mesh.top_radius = 0.052
	cuff_mesh.bottom_radius = 0.058
	cuff_mesh.height = 0.065
	_part(wrist, cuff_mesh, cuff, Vector3(0, 0, 0.005), ALONG_Z)

	var stripe := CylinderMesh.new()
	stripe.top_radius = 0.0595
	stripe.bottom_radius = 0.0595
	stripe.height = 0.012
	_part(wrist, stripe, glove_dark, Vector3(0, 0, -0.012), ALONG_Z)

	# corpo da luva
	var fist := SphereMesh.new()
	fist.radius = 0.072
	fist.height = 0.144
	_part(wrist, fist, glove, Vector3(0, 0.004, -0.075), Vector3.ZERO, Vector3(1.0, 0.92, 1.22))

	# almofada dos dedos (parte da frente, um pouco mais alta)
	var knuckle := SphereMesh.new()
	knuckle.radius = 0.06
	knuckle.height = 0.10
	_part(wrist, knuckle, glove, Vector3(0, 0.018, -0.115), Vector3.ZERO, Vector3(1.05, 0.9, 0.8))

	# polegar colado do lado de dentro
	var thumb := CapsuleMesh.new()
	thumb.radius = 0.022
	thumb.height = 0.095
	_part(wrist, thumb, glove, Vector3(-0.058 * s, -0.012, -0.07), Vector3(78, 0, 18 * s))

	# costura/cadarço em cima
	var lace := BoxMesh.new()
	lace.size = Vector3(0.012, 0.006, 0.06)
	_part(wrist, lace, glove_dark, Vector3(0, 0.068, -0.045))

	_idle[side] = idle
	_shoulder[side] = shoulder
	_elbow[side] = elbow
	_wrist[side] = wrist


# ============================================================
# POSES
# ============================================================

func _mirror(v: Vector3, side: int) -> Vector3:
	# espelha o braço direito pro esquerdo (inverte giro em Y e Z)
	return v if side > 0 else Vector3(v.x, -v.y, -v.z)


func _apply_pose_instant(pose_name: String) -> void:

	var p: Dictionary = POSES[pose_name]
	for side in [-1, 1]:
		_shoulder[side].rotation_degrees = _mirror(p["sh"], side)
		_elbow[side].rotation_degrees = _mirror(p["el"], side)
		_wrist[side].rotation_degrees = _mirror(p["wr"], side)


func _tween_arm(tw: Tween, side: int, pose_name: String, dur: float, trans: Tween.TransitionType = Tween.TRANS_SINE, ease_type: Tween.EaseType = Tween.EASE_OUT) -> void:

	var p: Dictionary = POSES[pose_name]
	tw.tween_property(_shoulder[side], "rotation_degrees", _mirror(p["sh"], side), dur).set_trans(trans).set_ease(ease_type)
	tw.tween_property(_elbow[side], "rotation_degrees", _mirror(p["el"], side), dur).set_trans(trans).set_ease(ease_type)
	tw.tween_property(_wrist[side], "rotation_degrees", _mirror(p["wr"], side), dur).set_trans(trans).set_ease(ease_type)


func _new_pose_tween() -> Tween:

	if _pose_tween and _pose_tween.is_valid():
		_pose_tween.kill()
	_pose_tween = create_tween()
	_pose_tween.set_parallel(true)
	return _pose_tween


func _new_react_tween() -> Tween:

	if _react_tween and _react_tween.is_valid():
		_react_tween.kill()
	_react_tween = create_tween()
	_react_tween.set_parallel(true)
	return _react_tween


func _react_to(pos: Vector3, rot: Vector3, out_dur: float, back_dur: float, hold := 0.0) -> void:

	var tw := _new_react_tween()
	tw.tween_property(_react, "position", pos, out_dur).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_react, "rotation_degrees", rot, out_dur).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	if hold > 0.0:
		tw.chain().tween_interval(hold)
	tw.chain().tween_property(_react, "position", Vector3.ZERO, back_dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(_react, "rotation_degrees", Vector3.ZERO, back_dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


# ============================================================
# API USADA PELO Main.gd
# ============================================================

# Entrada: os braços sobem de baixo da tela até a guarda.
func raise_guard_intro() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	if _react_tween and _react_tween.is_valid():
		_react_tween.kill()
	_react.position = Vector3.ZERO
	_react.rotation_degrees = Vector3.ZERO
	_apply_pose_instant("lowered")
	var tw := _new_pose_tween()
	for side in [-1, 1]:
		_tween_arm(tw, side, "guard", 0.45 + (0.06 if side > 0 else 0.0), Tween.TRANS_BACK, Tween.EASE_OUT)
	# batidinha de luvas no final (tipo "bora!")
	tw.chain().tween_property(_shoulder[-1], "rotation_degrees:y", -POSES["guard"]["sh"].y - 8.0, 0.08)
	tw.tween_property(_shoulder[1], "rotation_degrees:y", POSES["guard"]["sh"].y + 8.0, 0.08)
	tw.chain().tween_property(_shoulder[-1], "rotation_degrees:y", -POSES["guard"]["sh"].y, 0.12)
	tw.tween_property(_shoulder[1], "rotation_degrees:y", POSES["guard"]["sh"].y, 0.12)
	_idle_target = 1.0


func play_guard(dur := 0.18) -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	var tw := _new_pose_tween()
	for side in [-1, 1]:
		_tween_arm(tw, side, "guard", dur)
	_idle_target = 1.0


# Soco: antecipação curtinha -> estica rápido girando o punho ->
# segura um instante no impacto -> recolhe pra guarda. Esquerda =
# jab (rápido, pouco giro de tronco); direita = direto/cruzado (mais
# giro de tronco e mais alcance). A outra mão recolhe pra proteger o
# queixo. Cada soco sai com velocidade um pouquinho diferente.
func punch(side: int, on_finished: Callable = Callable()) -> void:

	if _shoulder.is_empty():
		if on_finished.is_valid():
			on_finished.call()
		return

	_anim_id += 1
	var id := _anim_id
	var other := -side
	var is_cross := side > 0
	var spd := randf_range(0.9, 1.1)
	_idle_target = 0.15

	var tw := _new_pose_tween()

	# 1) antecipação
	_tween_arm(tw, side, "wind", 0.05 * spd, Tween.TRANS_SINE, Tween.EASE_IN)
	_tween_arm(tw, other, "tuck", 0.08 * spd)

	# 2) golpe (estica + corkscrew no punho)
	tw.chain()
	_tween_arm(tw, side, "cross" if is_cross else "jab", (0.085 if is_cross else 0.07) * spd, Tween.TRANS_EXPO, Tween.EASE_OUT)

	# 3) segura no impacto
	tw.chain().tween_interval(0.05)

	# 4) recolhe
	tw.chain()
	_tween_arm(tw, side, "guard", 0.16 * spd, Tween.TRANS_SINE, Tween.EASE_OUT)
	_tween_arm(tw, other, "guard", 0.18 * spd)

	tw.chain().tween_callback(func():
		if id == _anim_id:
			_idle_target = 1.0
		if on_finished.is_valid():
			on_finished.call()
	)

	# tronco gira pro lado do soco e o ombro vai pra frente
	var twist := (8.0 if is_cross else 4.0) * float(side)
	var push := Vector3(-0.015 * float(side), 0.0, -0.05 if is_cross else -0.035)
	var rtw := _new_react_tween()
	rtw.tween_interval(0.05 * spd)
	rtw.chain().tween_property(_react, "position", push, 0.08 * spd).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3(0, twist, -1.5 * float(side)), 0.08 * spd).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.chain().tween_interval(0.05)
	rtw.chain().tween_property(_react, "position", Vector3.ZERO, 0.18 * spd).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3.ZERO, 0.18 * spd).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)


# Esquiva pro lado: a câmera já anda; os braços "atrasam" um pouco
# (inércia) e fecham a guarda pra se proteger.
func dodge(dir: int) -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	var id := _anim_id
	var tw := _new_pose_tween()
	for side in [-1, 1]:
		_tween_arm(tw, side, "cover", 0.09)
	tw.chain().tween_interval(0.08)
	tw.chain().tween_callback(func():
		if id == _anim_id:
			play_guard(0.2)
	)
	_react_to(Vector3(0.05 * float(-dir), 0.0, 0.0), Vector3(0, 0, 6.0 * float(dir)), 0.1, 0.22, 0.04)


# DEFESA ALTA: sobe os dois antebraços na frente do rosto, a câmera
# afunda um pouco (Main.gd) e, quando o soco do treinador bate nas
# luvas, os braços tomam o tranco do impacto e voltam pra guarda.
func high_block() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	var id := _anim_id
	_idle_target = 0.2

	var tw := _new_pose_tween()
	for side in [-1, 1]:
		_tween_arm(tw, side, "high_block", 0.08, Tween.TRANS_BACK, Tween.EASE_OUT)
	tw.chain().tween_interval(0.28)
	tw.chain().tween_callback(func():
		if id == _anim_id:
			play_guard(0.22)
	)

	# impacto do golpe nas luvas (um instante depois de fechar)
	var rtw := _new_react_tween()
	rtw.tween_property(_react, "position", Vector3(0.0, 0.02, 0.0), 0.08)
	rtw.chain().tween_property(_react, "position", Vector3(0.0, -0.02, 0.06), 0.05).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3(7, 0, 2), 0.05).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.chain().tween_property(_react, "position", Vector3(0.0, 0.01, 0.0), 0.12).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3(-1, 0, 0), 0.12).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	rtw.chain().tween_property(_react, "position", Vector3.ZERO, 0.2)
	rtw.tween_property(_react, "rotation_degrees", Vector3.ZERO, 0.2)


# Mantido por compatibilidade: "duck" agora é a defesa alta.
func duck() -> void:

	high_block()


# Levou o golpe: tranco pra baixo/trás, e as luvas se desalinham.
func flinch() -> void:

	if _shoulder.is_empty():
		return

	var dir := -1.0 if randf() < 0.5 else 1.0
	_react_to(Vector3(0.02 * dir, -0.06, 0.05), Vector3(8, 3.0 * dir, 5.0 * dir), 0.06, 0.28)

	_anim_id += 1
	var id := _anim_id
	var tw := _new_pose_tween()
	tw.tween_property(_shoulder[-1], "rotation_degrees", _mirror(POSES["guard"]["sh"], -1) + Vector3(-14, -6, 0), 0.06)
	tw.tween_property(_shoulder[1], "rotation_degrees", POSES["guard"]["sh"] + Vector3(-10, -9, 0), 0.06)
	tw.tween_property(_elbow[-1], "rotation_degrees", _mirror(POSES["guard"]["el"], -1) + Vector3(-15, 0, 0), 0.06)
	tw.chain().tween_callback(func():
		if id == _anim_id:
			play_guard(0.3)
	)


# Comemoração: soquinho no ar com a direita, a esquerda fica na guarda.
func celebrate() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	var id := _anim_id
	var tw := _new_pose_tween()
	_tween_arm(tw, 1, "cheer", 0.12, Tween.TRANS_BACK, Tween.EASE_OUT)
	_tween_arm(tw, -1, "tuck", 0.12)
	# chacoalha o punho duas vezes
	var cheer_sh: Vector3 = POSES["cheer"]["sh"]
	tw.chain().tween_property(_shoulder[1], "rotation_degrees", cheer_sh + Vector3(-10, 0, 0), 0.07)
	tw.chain().tween_property(_shoulder[1], "rotation_degrees", cheer_sh, 0.07)
	tw.chain().tween_property(_shoulder[1], "rotation_degrees", cheer_sh + Vector3(-10, 0, 0), 0.07)
	tw.chain().tween_property(_shoulder[1], "rotation_degrees", cheer_sh, 0.07)
	tw.chain().tween_callback(func():
		if id == _anim_id:
			play_guard(0.22)
	)


# ============================================================
# NOCAUTE / FIM DE LUTA
# ============================================================

# Golpe final: gancho de baixo pra cima com a direita. A luva chega no
# queixo do treinador depois de UPPERCUT_IMPACT_TIME segundos.
func uppercut() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	_idle_target = 0.0

	var tw := _new_pose_tween()
	_tween_arm(tw, 1, "upper_wind", 0.14, Tween.TRANS_SINE, Tween.EASE_IN)
	_tween_arm(tw, -1, "tuck", 0.12)
	tw.chain()
	_tween_arm(tw, 1, "uppercut", 0.09, Tween.TRANS_EXPO, Tween.EASE_OUT)
	tw.chain().tween_interval(0.25)
	tw.chain()
	_tween_arm(tw, 1, "guard", 0.3)
	_tween_arm(tw, -1, "guard", 0.3)

	var rtw := _new_react_tween()
	# abaixa o corpo pra carregar o golpe...
	rtw.tween_property(_react, "position", Vector3(0.02, -0.06, 0.02), 0.14).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	rtw.tween_property(_react, "rotation_degrees", Vector3(-4, -6, 0), 0.14)
	# ...e explode pra cima/frente girando o tronco
	rtw.chain().tween_property(_react, "position", Vector3(-0.02, 0.03, -0.07), 0.09).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3(6, 10, -3), 0.09).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.chain().tween_interval(0.25)
	rtw.chain().tween_property(_react, "position", Vector3.ZERO, 0.3)
	rtw.tween_property(_react, "rotation_degrees", Vector3.ZERO, 0.3)


# Vitória: os dois braços pro alto, sacudindo os punhos.
func victory() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	_idle_target = 0.5

	var tw := _new_pose_tween()
	for side in [-1, 1]:
		_tween_arm(tw, side, "victory", 0.18, Tween.TRANS_BACK, Tween.EASE_OUT)
	var v_sh: Vector3 = POSES["victory"]["sh"]
	for i in range(4):
		tw.chain().tween_property(_shoulder[1], "rotation_degrees", v_sh + Vector3(-9, 0, 0), 0.09)
		tw.tween_property(_shoulder[-1], "rotation_degrees", _mirror(v_sh, -1), 0.09)
		tw.chain().tween_property(_shoulder[1], "rotation_degrees", v_sh, 0.09)
		tw.tween_property(_shoulder[-1], "rotation_degrees", _mirror(v_sh + Vector3(-9, 0, 0), -1), 0.09)


# Nocauteado: os braços são arremessados pra longe e caem pra fora da
# tela (a câmera cai junto no Main.gd).
func knocked_out() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	_idle_target = 0.0

	var tw := _new_pose_tween()
	# abrem com o impacto
	tw.tween_property(_shoulder[1], "rotation_degrees", Vector3(-10, -25, -30), 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(_shoulder[-1], "rotation_degrees", Vector3(-15, 25, 30), 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(_elbow[1], "rotation_degrees", Vector3(40, 0, 0), 0.1)
	tw.tween_property(_elbow[-1], "rotation_degrees", Vector3(55, 0, 0), 0.1)
	# e desabam, moles
	tw.chain()
	for side in [-1, 1]:
		_tween_arm(tw, side, "lowered", 0.55, Tween.TRANS_BOUNCE, Tween.EASE_OUT)

	var rtw := _new_react_tween()
	rtw.tween_property(_react, "position", Vector3(0, 0.05, 0.08), 0.1).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	rtw.tween_property(_react, "rotation_degrees", Vector3(-15, 0, 8), 0.1)
	rtw.chain().tween_property(_react, "position", Vector3(0, -0.25, 0.1), 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	rtw.tween_property(_react, "rotation_degrees", Vector3(30, 0, 20), 0.6)


# Volta tudo pro lugar na hora (nova partida / volta ao menu).
func reset_pose() -> void:

	if _shoulder.is_empty():
		return

	_anim_id += 1
	if _pose_tween and _pose_tween.is_valid():
		_pose_tween.kill()
	if _react_tween and _react_tween.is_valid():
		_react_tween.kill()
	_react.position = Vector3.ZERO
	_react.rotation_degrees = Vector3.ZERO
	_apply_pose_instant("guard")
	_idle_target = 1.0


# ============================================================
# VIDA CONTÍNUA (respiração + luvas "vivas")
# ============================================================

func _process(delta: float) -> void:

	_time += delta
	_idle_weight = move_toward(_idle_weight, _idle_target, delta * 5.0)
	var w := _idle_weight

	# respiração: sobe/desce o conjunto todo, bem de leve
	_sway.position = Vector3(
		sin(_time * 0.9) * 0.004,
		sin(_time * 1.8) * 0.006,
		0.0
	) * w
	_sway.rotation_degrees = Vector3(sin(_time * 1.8 + 0.6) * 0.6, 0.0, sin(_time * 0.9) * 0.5) * w

	# cada luva com um ritmo próprio (fora de fase), como quem está
	# "mexendo" as mãos na guarda
	if _idle.has(-1):
		_idle[-1].position = Vector3(-SHOULDER_POS.x, SHOULDER_POS.y, SHOULDER_POS.z) + Vector3(
			sin(_time * 2.3) * 0.004,
			sin(_time * 3.1 + 1.0) * 0.006,
			sin(_time * 1.7) * 0.008
		) * w
		_idle[1].position = SHOULDER_POS + Vector3(
			sin(_time * 2.0 + 2.0) * 0.004,
			sin(_time * 2.7 + 0.3) * 0.006,
			sin(_time * 1.5 + 1.2) * 0.008
		) * w
