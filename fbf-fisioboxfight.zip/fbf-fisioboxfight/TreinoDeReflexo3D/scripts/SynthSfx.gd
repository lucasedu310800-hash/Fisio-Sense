# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
class_name SynthSfx
# Efeitos sonoros SINTETIZADOS por código (ondas quadradas, seno, ruído...),
# pra o minigame secreto 67 e a animação de desbloqueio terem som mesmo
# sem nenhum arquivo de áudio na pasta assets/sounds. Cada efeito é gerado
# uma vez (AudioStreamWAV em memória) e reaproveitado. Toca no barramento
# "Master", então o controle de volume do menu vale pra eles também.
#
# Uso: sfx.play("blip", pitch, volume_db)
# Nomes: blip, coin, boom, rumble, whoosh, glitch, win, error, tick

const RATE := 22050

var _pool: Array = []
var _idx: int = 0
var _cache: Dictionary = {}


func _ready() -> void:

	for i in range(10):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)


func play(sound_name: String, pitch: float = 1.0, volume_db: float = 0.0) -> void:

	var stream: AudioStream = _stream_for(sound_name)

	if stream == null or _pool.is_empty():
		return

	var p: AudioStreamPlayer = _pool[_idx]
	_idx = (_idx + 1) % _pool.size()

	p.stream = stream
	p.pitch_scale = clampf(pitch, 0.25, 4.0)
	p.volume_db = volume_db
	p.play()


func _stream_for(sound_name: String) -> AudioStream:

	if _cache.has(sound_name):
		return _cache[sound_name]

	var s: AudioStream = null

	match sound_name:
		"blip":
			s = _tone(660.0, 0.07, "square", 0.30, -60.0, 3.5)
		"tick":
			s = _tone(1200.0, 0.03, "square", 0.20, 0.0, 6.0)
		"coin":
			s = _seq([988.0, 1319.0], 0.09, "square", 0.30)
		"boom":
			s = _mix(_tone(55.0, 0.9, "sine", 0.95, -30.0, 3.0), _tone(1.0, 0.9, "noise", 0.55, 0.0, 5.0))
		"rumble":
			s = _mix(_tone(42.0, 2.4, "sine", 0.7, 6.0, 0.4), _tone(58.0, 2.4, "saw", 0.22, -6.0, 0.6))
		"whoosh":
			s = _tone(1100.0, 0.55, "saw", 0.22, -950.0, 2.2)
		"glitch":
			s = _mix(_tone(300.0, 0.25, "square", 0.25, 500.0, 1.5), _tone(1.0, 0.25, "noise", 0.3, 0.0, 3.0))
		"error":
			s = _seq([220.0, 165.0], 0.14, "saw", 0.28)
		"win":
			s = _seq([523.0, 659.0, 784.0, 1047.0, 784.0, 1047.0, 1319.0], 0.12, "square", 0.32)

	if s != null:
		_cache[sound_name] = s

	return s


func _wave(kind: String, ph: float, rng: RandomNumberGenerator) -> float:

	match kind:
		"sine":
			return sin(TAU * ph)
		"square":
			return 1.0 if ph < 0.5 else -1.0
		"saw":
			return 2.0 * ph - 1.0
		"tri":
			return 4.0 * absf(ph - 0.5) - 1.0
		"noise":
			return rng.randf_range(-1.0, 1.0)

	return 0.0


func _tone(freq: float, dur: float, kind: String, vol: float, slide: float, decay: float) -> AudioStreamWAV:

	var n: int = int(dur * float(RATE))
	var data := PackedByteArray()
	data.resize(n * 2)

	var rng := RandomNumberGenerator.new()
	rng.seed = 4242

	var phase: float = 0.0

	for i in range(n):

		var t: float = float(i) / float(RATE)
		var k: float = t / dur

		phase += (freq + slide * k) / float(RATE)

		var ph: float = phase - floorf(phase)
		var env: float = exp(-decay * k) * minf(1.0, t * 300.0)
		var v: float = _wave(kind, ph, rng) * env * vol

		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))

	return _wav(data)


# Notas em sequência (arpejo curto).
func _seq(freqs: Array, note_dur: float, kind: String, vol: float) -> AudioStreamWAV:

	var per: int = int(note_dur * float(RATE))
	var n: int = per * freqs.size()
	var data := PackedByteArray()
	data.resize(n * 2)

	var rng := RandomNumberGenerator.new()
	rng.seed = 99

	for j in range(freqs.size()):

		var f: float = freqs[j]
		var phase: float = 0.0

		for i in range(per):

			var t: float = float(i) / float(RATE)
			var k: float = float(i) / float(per)

			phase += f / float(RATE)

			var ph: float = phase - floorf(phase)
			var env: float = exp(-2.2 * k) * minf(1.0, t * 300.0)
			var v: float = _wave(kind, ph, rng) * env * vol

			data.encode_s16((j * per + i) * 2, int(clampf(v, -1.0, 1.0) * 30000.0))

	return _wav(data)


# Soma dois sons (mesmo tamanho ou não) num só.
func _mix(a: AudioStreamWAV, b: AudioStreamWAV) -> AudioStreamWAV:

	var da: PackedByteArray = a.data
	var db: PackedByteArray = b.data
	var n: int = maxi(da.size(), db.size()) / 2
	var data := PackedByteArray()
	data.resize(n * 2)

	for i in range(n):

		var va: int = da.decode_s16(i * 2) if i * 2 + 1 < da.size() else 0
		var vb: int = db.decode_s16(i * 2) if i * 2 + 1 < db.size() else 0

		data.encode_s16(i * 2, clampi(va + vb, -32000, 32000))

	return _wav(data)


func _wav(data: PackedByteArray) -> AudioStreamWAV:

	var w := AudioStreamWAV.new()

	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data

	return w
