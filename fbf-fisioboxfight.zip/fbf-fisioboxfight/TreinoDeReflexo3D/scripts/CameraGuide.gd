# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name CameraGuide
# Desenha guias por cima da prévia da câmera, nas MESMAS zonas que o
# CameraInput.gd usa pra detectar — assim dá pra se posicionar certo:
#   - linha do topo: o topo da cabeça deve ficar perto/acima dela;
#   - retângulo do rosto: nariz dentro, é onde as mãos sobem na defesa;
#   - faixa do meio (tracejada): os socos são lidos FORA dela.
# Também pisca o nome do gesto detectado.

var flash_text := ""
var _flash_alpha := 0.0


func show_gesture(text: String) -> void:
	flash_text = text
	_flash_alpha = 1.0
	queue_redraw()


func _process(delta: float) -> void:
	if _flash_alpha > 0.0:
		_flash_alpha = max(0.0, _flash_alpha - delta * 1.4)
		queue_redraw()


func _draw() -> void:
	var s := size
	var col := Color(0.55, 0.88, 0.98, 0.55)

	# topo da cabeça
	draw_line(Vector2(0, s.y * CameraInput.TOP_Y), Vector2(s.x, s.y * CameraInput.TOP_Y), col, 1.0)

	# zona do rosto
	var r := Rect2(
		Vector2(s.x * CameraInput.FACE_X0, s.y * CameraInput.FACE_Y0),
		Vector2(s.x * (CameraInput.FACE_X1 - CameraInput.FACE_X0), s.y * (CameraInput.FACE_Y1 - CameraInput.FACE_Y0))
	)
	draw_rect(r, col, false, 1.5)

	# faixa do meio (socos são lidos fora dela)
	for fx in [CameraInput.SIDE_L, CameraInput.SIDE_R]:
		var x: float = s.x * fx
		var y := s.y * CameraInput.BAND_Y
		while y < s.y:
			draw_line(Vector2(x, y), Vector2(x, min(y + 4.0, s.y)), col, 1.0)
			y += 8.0

	# rótulos E / D (lado do jogador)
	var font := ThemeDB.fallback_font
	# esquerda = vermelho, direita = azul (mesma cor das luvas)
	var col_l := Color(0.95, 0.28, 0.28, 0.95)
	var col_r := Color(0.30, 0.55, 1.0, 0.95)
	draw_rect(Rect2(Vector2(0, 0), Vector2(5, s.y)), Color(col_l.r, col_l.g, col_l.b, 0.55))
	draw_rect(Rect2(Vector2(s.x - 5, 0), Vector2(5, s.y)), Color(col_r.r, col_r.g, col_r.b, 0.55))
	draw_string(font, Vector2(8, s.y - 4), "E", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, col_l)
	draw_string(font, Vector2(s.x - 20, s.y - 4), "D", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, col_r)

	# gesto detectado
	if _flash_alpha > 0.0 and flash_text != "":
		var fc := Color(1.0, 0.85, 0.3, _flash_alpha)
		draw_rect(Rect2(Vector2(0, 0), Vector2(s.x, 18)), Color(0, 0, 0, 0.55 * _flash_alpha))
		draw_string(font, Vector2(4, 14), flash_text, HORIZONTAL_ALIGNMENT_LEFT, s.x - 8, 12, fc)
