# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Faz o papel do treinador "cérebro do jogo": decide o que
# acontece a cada desafio (ataque de um lado, ataque baixo, ou abertura
# de guarda pedindo um golpe) e cuida da dificuldade progressiva ao
# longo da sessão (2:00).
#
# A dificuldade é 100% baseada no TEMPO DECORRIDO da sessão (não em
# quantos acertos o paciente fez) — exatamente como pedido: fácil no
# primeiros 30 s, médio até 1:15, difícil no resto. Os números
# de cada fase estão todos aqui, juntos, para serem fáceis de ajustar.
#
# Tipos de desafio e a resposta correta esperada:
#   attack_left   -> o treinador golpeia pela esquerda  -> dodge_right
#   attack_right  -> o treinador golpeia pela direita    -> dodge_left
#   attack_low    -> golpe alto, na guarda              -> duck (esquiva alta)
#   open_left     -> treinador abre a guarda do lado esq. -> punch_left
#   open_right    -> treinador abre a guarda do lado dir. -> punch_right

# ------------------------------------------------------------
# FASES DE DIFICULDADE (ajuste aqui para tunar o jogo)
# ------------------------------------------------------------
const PHASES := [
	{
		"name": "Fácil",
		"until_sec": 30.0,
		"spawn_interval": 2.2,
		"telegraph_ms": 780.0,
		"window_ms": 1500.0,
		"combo_chance": 0.10,
		"combo_len": [2, 2],
		"gap_ms": 300.0,
	},
	{
		"name": "Médio",
		"until_sec": 75.0,
		"spawn_interval": 1.6,
		"telegraph_ms": 560.0,
		"window_ms": 1120.0,
		"combo_chance": 0.22,
		"combo_len": [2, 3],
		"gap_ms": 240.0,
	},
	{
		"name": "Difícil",
		"until_sec": 999999.0,
		"spawn_interval": 1.15,
		"telegraph_ms": 400.0,
		"window_ms": 860.0,
		"combo_chance": 0.30,
		"combo_len": [3, 4],
		"gap_ms": 170.0,
	},
]
# V-FBF: jogo um pouco MAIS DIFÍCIL (aviso e janela ~15% menores, golpes mais
# seguidos) e sessão mais LONGA (2:00): fácil até 30 s, médio até 1:15 e
# difícil no resto. Os COMBOS de ataques (2 a 4 golpes seguidos, anunciados na
# tela) aparecem "de vez em quando": no máximo um a cada COMBO_COOLDOWN_SEC e
# nunca antes de COMBO_FIRST_AT.
const COMBO_COOLDOWN_SEC := 12.0
const COMBO_FIRST_AT := 10.0
var _last_combo_at: float = -999.0

# ------------------------------------------------------------
# DIFICULDADE ESCOLHIDA NO MENU (Configurações)
# ------------------------------------------------------------
# Multiplica os tempos das PHASES acima (a progressão por tempo da
# sessão continua igual). "normal" = exatamente os números originais.
# facil   -> mais tempo pra perceber e reagir, golpes mais espaçados
# dificil -> aviso curto, janela curta, golpes mais seguidos
var difficulty: String = "normal"

const DIFFICULTY_SCALE := {
	"facil":   {"telegraph": 1.30, "window": 1.50, "gap": 1.25, "spawn": 1.25},
	"normal":  {"telegraph": 1.00, "window": 1.00, "gap": 1.00, "spawn": 1.00},
	"dificil": {"telegraph": 0.80, "window": 0.75, "gap": 0.80, "spawn": 0.80},
}

func _scale(key: String) -> float:
	var table: Dictionary = DIFFICULTY_SCALE.get(difficulty, DIFFICULTY_SCALE["normal"])
	return float(table[key])

const CHALLENGE_RESPONSE := {
	"attack_left": "dodge_right",
	"attack_right": "dodge_left",
	"attack_low": "duck",
	"open_left": "punch_left",
	"open_right": "punch_right",
}

const ATTACK_TYPES := ["attack_left", "attack_right", "attack_low"]
const OPEN_TYPES := ["open_left", "open_right"]
const ALL_TYPES := ["attack_left", "attack_right", "attack_low", "open_left", "open_right"]

var _last_type: String = ""

func get_phase_index(elapsed_sec: float) -> int:
	for i in range(PHASES.size()):
		if elapsed_sec < PHASES[i]["until_sec"]:
			return i + 1
	return PHASES.size()

func get_phase(elapsed_sec: float) -> Dictionary:
	return PHASES[get_phase_index(elapsed_sec) - 1]

# Retorna uma lista de 1 a 4 desafios (Array[Dictionary]) já na ordem em
# que devem ser apresentados. Cada item:
# { type, response, telegraph_ms, window_ms, gap_ms }
# Nos COMBOS (2+ golpes) cada item também traz:
# { combo: true, combo_i, combo_n, combo_kind }  kind: 0 = só ataques do
# treinador (defesas), 1 = só aberturas (socos), 2 = misto.
func generate_sequence(elapsed_sec: float) -> Array:
	var phase: Dictionary = get_phase(elapsed_sec)
	var seq: Array = []

	var length := 1
	var can_combo: bool = (
		elapsed_sec >= COMBO_FIRST_AT
		and (elapsed_sec - _last_combo_at) >= COMBO_COOLDOWN_SEC
	)

	if can_combo and randf() < phase["combo_chance"]:
		var lo: int = phase["combo_len"][0]
		var hi: int = phase["combo_len"][1]
		length = lo if lo == hi else (lo + randi() % (hi - lo + 1))
		_last_combo_at = elapsed_sec

	var kind: int = -1

	if length > 1:
		kind = randi() % 3

	for i in range(length):
		var ctype := _pick_type_for(kind)
		var item := {
			"type": ctype,
			"response": CHALLENGE_RESPONSE[ctype],
			"telegraph_ms": float(phase["telegraph_ms"]) * _scale("telegraph"),
			"window_ms": float(phase["window_ms"]) * _scale("window"),
			"gap_ms": float(phase["gap_ms"]) * _scale("gap"),
		}

		if length > 1:
			item["combo"] = true
			item["combo_i"] = i
			item["combo_n"] = length
			item["combo_kind"] = kind
			# dentro do combo os golpes vêm mais colados
			item["gap_ms"] = float(item["gap_ms"]) * 0.8

		seq.append(item)

	return seq

func spawn_interval_for(elapsed_sec: float) -> float:
	return float(get_phase(elapsed_sec)["spawn_interval"]) * _scale("spawn")

func _pick_type_for(kind: int) -> String:
	var base: Array = ALL_TYPES

	if kind == 0:
		base = ATTACK_TYPES
	elif kind == 1:
		base = OPEN_TYPES

	var pool := base.duplicate()
	if _last_type != "" and pool.size() > 1:
		pool.erase(_last_type)
	var choice: String = pool[randi() % pool.size()]
	_last_type = choice
	return choice

func _pick_type() -> String:
	var pool := ALL_TYPES.duplicate()
	if _last_type != "" and pool.size() > 1:
		pool.erase(_last_type)
	var choice: String = pool[randi() % pool.size()]
	_last_type = choice
	return choice
