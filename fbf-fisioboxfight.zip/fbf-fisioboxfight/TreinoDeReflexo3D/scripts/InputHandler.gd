# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Entrada por teclado — usada como alternativa sempre
# disponível ao controle por câmera. Mesmo contrato de CameraInput.sample():
# devolve uma String com a resposta detectada, ou "" quando nada foi
# detectado, para Main.gd tratar as duas fontes de forma intercambiável.
#
# Respostas possíveis: "dodge_left", "dodge_right", "duck" (agachar),
# "punch_left", "punch_right".

# Emitido no instante em que uma tecla de movimento é apertada (só
# aviso visual: o boneco e os indicadores reagem na hora). Não muda em
# nada o funcionamento do sample().
signal response_pressed(response: String)

const WINDOW_MS := 150

const KEY_RESPONSE_MAP := {
	KEY_LEFT: "dodge_left", KEY_A: "dodge_left",
	KEY_RIGHT: "dodge_right", KEY_D: "dodge_right",
	KEY_DOWN: "duck", KEY_S: "duck",
	KEY_Z: "punch_left",
	KEY_X: "punch_right",
}

var active: bool = false
var _last_response: String = ""
var _last_response_time: int = 0

func enable() -> void:
	active = true

func disable() -> void:
	active = false
	_last_response = ""

func _input(event: InputEvent) -> void:
	if not active:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		var code: int = event.physical_keycode
		if KEY_RESPONSE_MAP.has(code):
			_last_response = KEY_RESPONSE_MAP[code]
			_last_response_time = Time.get_ticks_msec()
			response_pressed.emit(_last_response)

func sample() -> String:
	if _last_response == "":
		return ""
	if Time.get_ticks_msec() - _last_response_time > WINDOW_MS:
		return ""
	var response: String = _last_response
	_last_response = ""
	return response
