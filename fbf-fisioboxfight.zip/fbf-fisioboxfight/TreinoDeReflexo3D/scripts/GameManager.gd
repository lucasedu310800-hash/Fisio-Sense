# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node
# Autoload. Controla pontuação, combo, precisão e todas as estatísticas
# da sessão de 2:00 (V2 — treino de boxe em pixel art).
#
# Não existe mais sistema de "vidas": a sessão sempre dura o tempo
# completos (ver GameManager.SESSION_DURATION_SEC). Erros reduzem a
# precisão e zeram o combo, mas não terminam o treino antes da hora —
# isso é o que torna os dados comparáveis entre sessões (mesma duração
# sempre) para uso futuro em fisioterapia.

signal hud_changed(state: Dictionary)
signal feedback(kind: String, is_hit: bool)  # kind: "dodge" | "punch" | "timeout"

const SESSION_DURATION_SEC := 120.0  # 2 minutos (antes 1:30)

# Pontuação base por tipo de resposta correta.
const BASE_POINTS := { "dodge": 10, "punch": 12 }

var score: int = 0
var combo: int = 0
var best_combo: int = 0
var multiplier: float = 1.0

var hits: int = 0          # total de respostas corretas (esquivas + golpes)
var misses: int = 0        # total de respostas erradas ou tempo esgotado

var dodges_correct: int = 0
var dodges_wrong: int = 0
var punches_correct: int = 0
var punches_wrong: int = 0

var reaction_times_ms: Array = []
var best_reaction_ms: float = -1.0

var max_phase_reached: int = 1

func reset_scoring() -> void:
	score = 0
	combo = 0
	best_combo = 0
	multiplier = 1.0
	hits = 0
	misses = 0
	dodges_correct = 0
	dodges_wrong = 0
	punches_correct = 0
	punches_wrong = 0
	reaction_times_ms.clear()
	best_reaction_ms = -1.0
	max_phase_reached = 1
	_emit_hud()

func register_phase(phase_index: int) -> void:
	if phase_index > max_phase_reached:
		max_phase_reached = phase_index

# response_type: "dodge" ou "punch". reaction_ms: tempo de reação em ms.
# window_ms: janela de reação que estava disponível (usado para bônus).
func add_hit(response_type: String, reaction_ms: float, window_ms: float) -> void:
	combo += 1
	best_combo = max(best_combo, combo)
	multiplier = 1.0 + floor(combo / 5.0) * 0.5

	# Bônus de velocidade: quanto mais rápido, mais o golpe/esquiva vale
	# (até 50% extra quando a reação é quase instantânea).
	var speed_ratio: float = clamp(1.0 - (reaction_ms / max(window_ms, 1.0)), 0.0, 1.0)
	var speed_bonus: float = 1.0 + speed_ratio * 0.5

	var base: int = BASE_POINTS.get(response_type, 10)
	score += int(round(base * multiplier * speed_bonus))

	hits += 1
	if response_type == "dodge":
		dodges_correct += 1
	else:
		punches_correct += 1

	reaction_times_ms.append(reaction_ms)
	if best_reaction_ms < 0.0 or reaction_ms < best_reaction_ms:
		best_reaction_ms = reaction_ms

	_emit_hud()
	feedback.emit(response_type, true)

func add_miss(response_type: String) -> void:
	combo = 0
	multiplier = 1.0
	misses += 1
	if response_type == "dodge":
		dodges_wrong += 1
	else:
		punches_wrong += 1
	_emit_hud()
	feedback.emit(response_type, false)

# Bônus por combo de ataques completo (não mexe em acertos/erros/precisão).
func add_bonus(points: int) -> void:
	score += points
	_emit_hud()

func get_precision() -> float:
	var total: int = hits + misses
	if total <= 0:
		return 100.0
	return (float(hits) / float(total)) * 100.0

func get_avg_reaction_ms() -> float:
	if reaction_times_ms.is_empty():
		return 0.0
	var sum: float = 0.0
	for t in reaction_times_ms:
		sum += t
	return sum / reaction_times_ms.size()

func get_state() -> Dictionary:
	return {
		"score": score,
		"combo": combo,
		"multiplier": multiplier,
		"precision": get_precision(),
	}

# Estrutura final, pronta para ser guardada por SessionData.gd e
# futuramente comparada entre sessões / usada em relatórios.
func build_session_summary() -> Dictionary:
	return {
		"duration_sec": SESSION_DURATION_SEC,
		"score": score,
		"hits": hits,
		"misses": misses,
		"precision": get_precision(),
		"avg_reaction_ms": get_avg_reaction_ms(),
		"best_reaction_ms": (best_reaction_ms if best_reaction_ms >= 0.0 else 0.0),
		"dodges_correct": dodges_correct,
		"dodges_wrong": dodges_wrong,
		"punches_correct": punches_correct,
		"punches_wrong": punches_wrong,
		"best_combo": best_combo,
		"max_phase": max_phase_reached,
	}

func _emit_hud() -> void:
	hud_changed.emit(get_state())
