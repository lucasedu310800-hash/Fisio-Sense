# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name ReportCharts
# Gráficos do relatório final (V-FBF), desenhados por código:
#   mode "grade"    -> nota (S/A/B/C/D) num selo com estrelas
#   mode "moves"    -> barras de precisão por movimento
#   mode "timeline" -> precisão ao longo do treino (blocos de 15 s)
#   mode "balance"  -> equilíbrio esquerda x direita (vermelho x azul)
# Os dados chegam por set_data(); tudo se ajusta ao tamanho do controle.

const RED := Color(0.95, 0.28, 0.28)
const BLUE := Color(0.30, 0.55, 1.0)
const CYAN := Color(0.4, 0.9, 1.0)
const GOLD := Color(0.96, 0.75, 0.26)
const GREEN := Color(0.35, 0.92, 0.5)
const PANEL := Color(0.02, 0.02, 0.05, 0.55)
const GRID := Color(1, 1, 1, 0.12)
const TEXT := Color(0.92, 0.92, 0.96)
const DIM := Color(0.62, 0.62, 0.70)

var mode: String = "moves"
var data: Dictionary = {}


func set_data(d: Dictionary) -> void:

	data = d
	queue_redraw()


func _font() -> Font:

	return ThemeDB.fallback_font


func _text(pos: Vector2, text: String, size_px: int, color: Color, align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:

	draw_string(_font(), pos, text, align, width, size_px, color)


func _prec_color(p: float) -> Color:

	if p >= 80.0:
		return GREEN

	if p >= 60.0:
		return GOLD

	return RED


func _draw() -> void:

	if data.is_empty():
		return

	match mode:
		"grade":
			_draw_grade()
		"moves":
			_draw_moves()
		"timeline":
			_draw_timeline()
		"balance":
			_draw_balance()


# ------------------------------------------------------------
# Nota
# ------------------------------------------------------------

func _star(center: Vector2, r: float, color: Color) -> void:

	var pts := PackedVector2Array()

	for i in range(10):
		var a: float = -PI / 2.0 + float(i) * PI / 5.0
		var rr: float = r if i % 2 == 0 else r * 0.45
		pts.append(center + Vector2(cos(a), sin(a)) * rr)

	draw_colored_polygon(pts, color)


func _draw_grade() -> void:

	var col: Color = data.get("color", GOLD)
	var grade: String = str(data.get("grade", "-"))
	var stars: int = int(data.get("stars", 0))

	_text(Vector2(0, 14), "NOTA", 13, DIM, HORIZONTAL_ALIGNMENT_CENTER, size.x)

	var c := Vector2(size.x / 2.0, 70.0)
	var r: float = 44.0

	draw_circle(c, r + 6.0, Color(col.r, col.g, col.b, 0.18))
	draw_circle(c, r, Color(0.03, 0.03, 0.07, 0.95))
	draw_arc(c, r - 2.0, 0.0, TAU, 48, col, 5.0, true)

	_text(Vector2(0, c.y + 24.0), grade, 68, col, HORIZONTAL_ALIGNMENT_CENTER, size.x)

	for i in range(5):
		var sc: Color = col if i < stars else Color(1, 1, 1, 0.15)
		_star(Vector2(size.x / 2.0 + (float(i) - 2.0) * 20.0, 126.0), 8.0, sc)


# ------------------------------------------------------------
# Desempenho por movimento
# ------------------------------------------------------------

func _draw_moves() -> void:

	var rows: Array = data.get("rows", [])

	if rows.is_empty():
		return

	var row_h: float = size.y / float(rows.size())
	var label_w: float = minf(size.x * 0.38, 150.0)
	var bar_x: float = label_w + 6.0
	var bar_w: float = size.x - bar_x - 74.0

	for i in range(rows.size()):

		var r: Dictionary = rows[i]
		var y: float = float(i) * row_h
		var cy: float = y + row_h / 2.0

		var key: String = str(r["key"])
		var base: Color = CYAN

		if key.ends_with("_left"):
			base = RED
		elif key.ends_with("_right"):
			base = BLUE

		_text(Vector2(0, cy + 5.0), str(r["name"]), 13, TEXT, HORIZONTAL_ALIGNMENT_LEFT, label_w)

		# trilho + preenchimento
		draw_rect(Rect2(Vector2(bar_x, cy - 8.0), Vector2(bar_w, 16.0)), PANEL)

		var p: float = float(r["prec"])

		if p >= 0.0:
			var fw: float = bar_w * clampf(p / 100.0, 0.0, 1.0)
			draw_rect(Rect2(Vector2(bar_x, cy - 8.0), Vector2(fw, 16.0)), base)
			draw_rect(Rect2(Vector2(bar_x, cy - 8.0), Vector2(fw, 5.0)), Color(1, 1, 1, 0.22))
			_text(Vector2(bar_x + bar_w + 8.0, cy + 5.0), "%.0f%%" % p, 13, TEXT)
		else:
			_text(Vector2(bar_x + 8.0, cy + 5.0), "sem tentativas", 11, DIM)

		_text(Vector2(bar_x + bar_w + 8.0, cy + 19.0), "%d/%d" % [int(r["ok"]), int(r["total"])], 10, DIM)


# ------------------------------------------------------------
# Linha do tempo (precisão a cada 15 s)
# ------------------------------------------------------------

func _draw_timeline() -> void:

	var blocks: Array = data.get("blocks6", [])

	if blocks.is_empty():
		return

	var left: float = 34.0
	var right: float = 8.0
	var top: float = 10.0
	var bottom: float = 24.0

	var pw: float = size.x - left - right
	var ph: float = size.y - top - bottom

	# grade horizontal (0 / 50 / 100 %)
	for g in [0, 50, 100]:
		var gy: float = top + ph * (1.0 - float(g) / 100.0)
		draw_line(Vector2(left, gy), Vector2(left + pw, gy), GRID, 1.0)
		_text(Vector2(0, gy + 4.0), "%d%%" % g, 10, DIM)

	var n: int = blocks.size()
	var slot: float = pw / float(n)
	var pts := PackedVector2Array()

	for i in range(n):

		var b: Dictionary = blocks[i]
		var p: float = float(b["prec"])
		var x: float = left + slot * (float(i) + 0.5)

		_text(Vector2(left + slot * float(i), size.y - 6.0), "%d s" % ((i + 1) * 15), 9, DIM, HORIZONTAL_ALIGNMENT_CENTER, slot)

		if p < 0.0:
			_text(Vector2(left + slot * float(i), top + ph * 0.5), "--", 12, DIM, HORIZONTAL_ALIGNMENT_CENTER, slot)
			continue

		var col: Color = _prec_color(p)
		var by: float = top + ph * (1.0 - p / 100.0)

		draw_rect(Rect2(Vector2(x - slot * 0.28, by), Vector2(slot * 0.56, top + ph - by)), Color(col.r, col.g, col.b, 0.30))

		pts.append(Vector2(x, by))

		_text(Vector2(left + slot * float(i), maxf(by - 6.0, top + 8.0)), "%.0f" % p, 11, col, HORIZONTAL_ALIGNMENT_CENTER, slot)

	if pts.size() >= 2:
		draw_polyline(pts, GOLD, 2.5, true)

	for pt in pts:
		draw_circle(pt, 4.0, Color(1, 1, 1))
		draw_circle(pt, 2.5, GOLD)


# ------------------------------------------------------------
# Equilíbrio esquerda x direita
# ------------------------------------------------------------

func _draw_balance() -> void:

	var lp: float = float(data.get("left_prec", -1.0))
	var rp: float = float(data.get("right_prec", -1.0))

	var label_w: float = 78.0
	var bar_x: float = label_w
	var bar_w: float = size.x - bar_x - 52.0

	var entries := [
		["ESQUERDA", lp, RED, 22.0, data.get("left_ok", 0), data.get("left_total", 0)],
		["DIREITA", rp, BLUE, 62.0, data.get("right_ok", 0), data.get("right_total", 0)],
	]

	for e in entries:

		var y: float = e[3]
		var p: float = e[1]
		var col: Color = e[2]

		_text(Vector2(0, y + 5.0), str(e[0]), 13, TEXT)

		draw_rect(Rect2(Vector2(bar_x, y - 9.0), Vector2(bar_w, 18.0)), PANEL)

		if p >= 0.0:
			var fw: float = bar_w * clampf(p / 100.0, 0.0, 1.0)
			draw_rect(Rect2(Vector2(bar_x, y - 9.0), Vector2(fw, 18.0)), col)
			draw_rect(Rect2(Vector2(bar_x, y - 9.0), Vector2(fw, 5.0)), Color(1, 1, 1, 0.22))
			_text(Vector2(bar_x + bar_w + 8.0, y + 5.0), "%.0f%%" % p, 13, TEXT)
		else:
			_text(Vector2(bar_x + 8.0, y + 5.0), "sem dados", 11, DIM)

	# medidor de equilíbrio
	var my: float = 112.0
	var mx: float = 10.0
	var mw: float = size.x - 20.0

	draw_rect(Rect2(Vector2(mx, my), Vector2(mw / 2.0, 12.0)), Color(RED.r, RED.g, RED.b, 0.55))
	draw_rect(Rect2(Vector2(mx + mw / 2.0, my), Vector2(mw / 2.0, 12.0)), Color(BLUE.r, BLUE.g, BLUE.b, 0.55))
	draw_line(Vector2(mx + mw / 2.0, my - 4.0), Vector2(mx + mw / 2.0, my + 16.0), Color(1, 1, 1, 0.8), 2.0)

	var status: String = "sem dados suficientes"
	var status_col: Color = DIM

	if lp >= 0.0 and rp >= 0.0:

		var diff: float = lp - rp
		var marker: float = clampf(0.5 + (rp - lp) / 200.0 * 1.0, 0.05, 0.95)
		# marcador se afasta do lado mais forte
		var mkx: float = mx + mw * (0.5 - diff / 200.0)

		mkx = clampf(mkx, mx + 6.0, mx + mw - 6.0)

		var tri := PackedVector2Array([
			Vector2(mkx, my - 2.0), Vector2(mkx - 7.0, my - 12.0), Vector2(mkx + 7.0, my - 12.0)
		])

		draw_colored_polygon(tri, GOLD)

		if absf(diff) < 10.0:
			status = "EQUILIBRADO"
			status_col = GREEN
		elif diff > 0.0:
			status = "lado DIREITO mais fraco (%.0f pts)" % absf(diff)
			status_col = GOLD
		else:
			status = "lado ESQUERDO mais fraco (%.0f pts)" % absf(diff)
			status_col = GOLD

		if marker < 0.0:
			status = ""

	_text(Vector2(0, my + 36.0), status, 13, status_col, HORIZONTAL_ALIGNMENT_CENTER, size.x)
