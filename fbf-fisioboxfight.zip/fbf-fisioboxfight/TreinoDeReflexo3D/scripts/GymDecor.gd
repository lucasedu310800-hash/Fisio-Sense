# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Node3D
class_name GymDecor
# Decoração EXTRA da academia (V-FBF) — só acrescenta coisas ao cenário
# que o Main.gd já monta (paredes, ringue, sacos, bancos...). Nada aqui
# mexe em jogabilidade. Tudo é feito por código (primitivas + materiais),
# sem arquivos externos.
#
# Sala: X de -5.2 a 5.2, Z de -6.2 (parede do fundo) a 3.0, altura 4.2.
# Ringue em (2.6, 0, -3.4). Câmera do jogo em (0, 1.64, 0.9) olhando -Z;
# treinador em (0, 0, -2.2). Por isso o centro da parede do fundo (atrás
# do treinador) fica só com o letreiro no alto — o resto é decoração nas
# laterais e mais baixa, pra não atrapalhar a silhueta dele.

const MIN_X := -5.2
const MAX_X := 5.2
const MIN_Z := -6.2
const MAX_Z := 3.0
const HEIGHT := 4.2
const LOGO_PATH := "res://assets/textures/logo_fbf.png"

var _iron: StandardMaterial3D
var _iron_dark: StandardMaterial3D
var _chrome: StandardMaterial3D
var _rubber: StandardMaterial3D
var _wood: StandardMaterial3D
var _red_paint: StandardMaterial3D
var _padding: StandardMaterial3D


func _ready() -> void:

	_iron = _mat(Color(0.16, 0.16, 0.18), 0.45, 0.6)
	_iron_dark = _mat(Color(0.08, 0.08, 0.09), 0.55, 0.5)
	_chrome = _mat(Color(0.78, 0.80, 0.83), 0.22, 0.95)
	_rubber = _mat(Color(0.04, 0.04, 0.05), 0.85, 0.0)
	_wood = _mat(Color(0.60, 0.43, 0.26), 0.7, 0.0)
	_red_paint = _mat(Color(0.72, 0.08, 0.08), 0.4, 0.3)
	_padding = _mat(Color(0.07, 0.07, 0.09), 0.6, 0.0)

	_build_wall_padding()
	_build_led_strips()
	_build_banner()
	_build_wall_clock()
	_build_hanging_gloves()
	_build_mirror()
	_build_floor_mat()

	_build_dumbbell_rack(Vector3(-2.5, 0.0, -5.75))
	_build_weight_plates(Vector3(-4.35, 0.0, -5.5))
	_build_kettlebells(Vector3(-3.55, 0.0, -5.55))
	_build_plyo_boxes(Vector3(-1.3, 0.0, -5.6))
	_build_power_rack(Vector3(4.15, 0.0, -5.6))

	_build_spotlights()


# ------------------------------------------------------------
# Ferramentas
# ------------------------------------------------------------

func _mat(color: Color, rough: float, metal: float = 0.0) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()

	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal

	return m


func _emit_mat(color: Color, energy: float) -> StandardMaterial3D:

	var m := StandardMaterial3D.new()

	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy

	return m


func _add(parent: Node3D, mi: MeshInstance3D, pos: Vector3, rot: Vector3, mat: Material) -> MeshInstance3D:

	mi.position = pos
	mi.rotation_degrees = rot
	mi.material_override = mat
	parent.add_child(mi)

	return mi


func _box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := BoxMesh.new()
	mesh.size = size

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _add(parent, mi, pos, rot, mat)


func _cyl(parent: Node3D, pos: Vector3, radius: float, height: float, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 24

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _add(parent, mi, pos, rot, mat)


func _sphere(parent: Node3D, pos: Vector3, radius: float, mat: Material, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:

	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.scale = scl

	return _add(parent, mi, pos, Vector3.ZERO, mat)


func _torus(parent: Node3D, pos: Vector3, inner: float, outer: float, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:

	var mesh := TorusMesh.new()
	mesh.inner_radius = inner
	mesh.outer_radius = outer

	var mi := MeshInstance3D.new()
	mi.mesh = mesh

	return _add(parent, mi, pos, rot, mat)


func _no_shadow(mi: MeshInstance3D) -> void:

	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _label(text: String, pos: Vector3, font_size: int, pixel_size: float, color: Color) -> Label3D:

	var l := Label3D.new()

	l.text = text
	l.font_size = font_size
	l.pixel_size = pixel_size
	l.modulate = color
	l.outline_size = 14
	l.outline_modulate = Color(0.03, 0.02, 0.02, 1.0)
	l.shaded = false
	l.position = pos

	add_child(l)

	return l


# ------------------------------------------------------------
# Paredes: estofado escuro embaixo com friso vermelho e LEDs
# ------------------------------------------------------------

func _build_wall_padding() -> void:

	var stripe := _emit_mat(Color(0.95, 0.10, 0.10), 1.6)
	var len_x: float = MAX_X - MIN_X
	var len_z: float = MAX_Z - MIN_Z
	var mid_z: float = (MIN_Z + MAX_Z) / 2.0

	# fundo
	_box(self, Vector3(0, 0.55, MIN_Z + 0.04), Vector3(len_x, 1.10, 0.08), _padding)
	_no_shadow(_box(self, Vector3(0, 1.13, MIN_Z + 0.05), Vector3(len_x, 0.05, 0.09), stripe))

	# esquerda
	_box(self, Vector3(MIN_X + 0.04, 0.55, mid_z), Vector3(0.08, 1.10, len_z), _padding)
	_no_shadow(_box(self, Vector3(MIN_X + 0.05, 1.13, mid_z), Vector3(0.09, 0.05, len_z), stripe))

	# direita
	_box(self, Vector3(MAX_X - 0.04, 0.55, mid_z), Vector3(0.08, 1.10, len_z), _padding)
	_no_shadow(_box(self, Vector3(MAX_X - 0.05, 1.13, mid_z), Vector3(0.09, 0.05, len_z), stripe))


# Faixas de LED no alto das paredes: vermelha à esquerda, azul à direita
# (as cores das luvas) e branca no fundo, com luz suave em cada lado.
func _build_led_strips() -> void:

	var red := _emit_mat(Color(1.0, 0.12, 0.12), 2.2)
	var blue := _emit_mat(Color(0.15, 0.4, 1.0), 2.2)
	var white := _emit_mat(Color(1.0, 0.95, 0.85), 1.8)
	var mid_z: float = (MIN_Z + MAX_Z) / 2.0

	_no_shadow(_box(self, Vector3(MIN_X + 0.06, 3.75, mid_z), Vector3(0.05, 0.06, MAX_Z - MIN_Z), red))
	_no_shadow(_box(self, Vector3(MAX_X - 0.06, 3.75, mid_z), Vector3(0.05, 0.06, MAX_Z - MIN_Z), blue))
	_no_shadow(_box(self, Vector3(0, 3.75, MIN_Z + 0.06), Vector3(MAX_X - MIN_X, 0.06, 0.05), white))

	var red_light := OmniLight3D.new()
	red_light.position = Vector3(MIN_X + 0.9, 3.0, -2.0)
	red_light.light_color = Color(1.0, 0.25, 0.2)
	red_light.light_energy = 1.4
	red_light.omni_range = 5.5
	add_child(red_light)

	var blue_light := OmniLight3D.new()
	blue_light.position = Vector3(MAX_X - 0.9, 3.0, -2.0)
	blue_light.light_color = Color(0.25, 0.45, 1.0)
	blue_light.light_energy = 1.4
	blue_light.omni_range = 5.5
	add_child(blue_light)


# ------------------------------------------------------------
# Letreiro FBF no alto da parede do fundo (centro)
# ------------------------------------------------------------

func _build_banner() -> void:

	var gold := _mat(Color(0.95, 0.74, 0.25), 0.3, 0.7)
	var z: float = MIN_Z + 0.09

	_box(self, Vector3(0, 3.05, z), Vector3(3.7, 1.05, 0.06), _mat(Color(0.05, 0.05, 0.07), 0.5, 0.0))

	# moldura dourada
	_box(self, Vector3(0, 3.05 + 0.53, z + 0.02), Vector3(3.8, 0.05, 0.05), gold)
	_box(self, Vector3(0, 3.05 - 0.53, z + 0.02), Vector3(3.8, 0.05, 0.05), gold)
	_box(self, Vector3(-1.875, 3.05, z + 0.02), Vector3(0.05, 1.11, 0.05), gold)
	_box(self, Vector3(1.875, 3.05, z + 0.02), Vector3(0.05, 1.11, 0.05), gold)

	if ResourceLoader.exists(LOGO_PATH):

		# logo do jogo à esquerda + nome e créditos à direita
		var tex: Texture2D = load(LOGO_PATH) as Texture2D

		var logo := Sprite3D.new()
		logo.texture = tex
		logo.pixel_size = 0.96 / float(tex.get_height())
		logo.shaded = false
		logo.position = Vector3(-1.2, 3.05, z + 0.05)
		add_child(logo)

		_label("FisioBoxFight", Vector3(0.55, 3.20, z + 0.05), 70, 0.0035, Color(0.98, 0.78, 0.28))
		_label("by FisioSense", Vector3(0.55, 2.90, z + 0.05), 46, 0.0035, Color(1, 1, 1))
		_label("From Next-FIAP", Vector3(0.55, 2.68, z + 0.05), 34, 0.0035, Color(0.85, 0.85, 0.9))

	else:

		_label("FBF", Vector3(0, 3.25, z + 0.05), 120, 0.0042, Color(0.98, 0.78, 0.28))
		_label("FisioBoxFight", Vector3(0, 2.77, z + 0.05), 64, 0.0040, Color(1, 1, 1))


func _build_wall_clock() -> void:

	var root := Node3D.new()
	root.position = Vector3(3.05, 3.15, MIN_Z + 0.09)
	add_child(root)

	_cyl(root, Vector3.ZERO, 0.32, 0.05, _iron_dark, Vector3(90, 0, 0))
	_cyl(root, Vector3(0, 0, 0.02), 0.28, 0.05, _mat(Color(0.95, 0.95, 0.93), 0.4, 0.0), Vector3(90, 0, 0))

	# marcações das horas
	for i in range(12):
		var a: float = float(i) * TAU / 12.0
		var tick := _box(root, Vector3(sin(a) * 0.23, cos(a) * 0.23, 0.05), Vector3(0.02, 0.05, 0.01), _iron_dark)
		tick.rotation = Vector3(0, 0, -a)

	# ponteiros (10:10 — o clássico bonito de relógio)
	var hour := _box(root, Vector3(-0.045, 0.045, 0.06), Vector3(0.025, 0.15, 0.012), _iron_dark)
	hour.rotation_degrees = Vector3(0, 0, 45)
	var minute := _box(root, Vector3(0.07, 0.085, 0.065), Vector3(0.018, 0.22, 0.012), _red_paint)
	minute.rotation_degrees = Vector3(0, 0, -30)


# Par de luvas penduradas na parede: ESQUERDA vermelha, DIREITA azul.
func _build_hanging_gloves() -> void:

	var colors := [Color(0.85, 0.10, 0.10), Color(0.13, 0.35, 0.95)]
	var xs := [1.85, 2.30]

	for i in range(2):

		var g_mat := _mat(colors[i], 0.3, 0.1)
		g_mat.clearcoat_enabled = true
		g_mat.clearcoat = 0.6

		var root := Node3D.new()
		root.position = Vector3(xs[i], 2.05, MIN_Z + 0.14)
		add_child(root)

		# cordinha
		_cyl(root, Vector3(0, 0.27, 0), 0.008, 0.20, _iron_dark)
		_cyl(root, Vector3(0, 0.36, -0.02), 0.02, 0.03, _iron, Vector3(90, 0, 0))

		_cyl(root, Vector3(0, 0.05, 0), 0.055, 0.10, _mat(Color(0.93, 0.93, 0.93), 0.5, 0.0))
		_sphere(root, Vector3(0, -0.06, 0), 0.10, g_mat, Vector3(1.0, 1.15, 0.9))
		_sphere(root, Vector3(-0.07 if i == 0 else 0.07, -0.05, 0.03), 0.04, g_mat)


# Espelho grande na parede direita (perto da câmera): dá profundidade.
func _build_mirror() -> void:

	var glass := _mat(Color(0.10, 0.14, 0.19), 0.06, 0.9)
	glass.emission_enabled = true
	glass.emission = Color(0.05, 0.09, 0.14)
	glass.emission_energy_multiplier = 0.6

	var frame := _mat(Color(0.05, 0.05, 0.06), 0.4, 0.5)

	var x: float = MAX_X - 0.06
	var z: float = 1.5

	_box(self, Vector3(x, 1.95, z), Vector3(0.03, 1.7, 2.6), glass)
	_box(self, Vector3(x - 0.01, 1.95 + 0.87, z), Vector3(0.05, 0.05, 2.7), frame)
	_box(self, Vector3(x - 0.01, 1.95 - 0.87, z), Vector3(0.05, 0.05, 2.7), frame)
	_box(self, Vector3(x - 0.01, 1.95, z - 1.32), Vector3(0.05, 1.79, 0.05), frame)
	_box(self, Vector3(x - 0.01, 1.95, z + 1.32), Vector3(0.05, 1.79, 0.05), frame)


# Tapete de treino no centro (onde o treinador e o jogador ficam), com
# borda branca — deixa a "zona de luta" bem definida.
func _build_floor_mat() -> void:

	var mat_body := _mat(Color(0.09, 0.10, 0.16), 0.9, 0.0)
	var line := _mat(Color(0.92, 0.92, 0.92), 0.8, 0.0)

	var cx: float = 0.0
	var cz: float = -1.55
	var w: float = 5.0
	var d: float = 4.4

	_box(self, Vector3(cx, 0.008, cz), Vector3(w, 0.016, d), mat_body)

	_box(self, Vector3(cx, 0.017, cz - d / 2.0 + 0.05), Vector3(w, 0.004, 0.07), line)
	_box(self, Vector3(cx, 0.017, cz + d / 2.0 - 0.05), Vector3(w, 0.004, 0.07), line)
	_box(self, Vector3(cx - w / 2.0 + 0.05, 0.017, cz), Vector3(0.07, 0.004, d), line)
	_box(self, Vector3(cx + w / 2.0 - 0.05, 0.017, cz), Vector3(0.07, 0.004, d), line)

	# faixa vermelha e azul no meio (esquerda / direita)
	_box(self, Vector3(-w / 4.0, 0.0175, cz), Vector3(w / 2.0 - 0.3, 0.003, 0.05), _emit_mat(Color(0.9, 0.12, 0.12), 0.4))
	_box(self, Vector3(w / 4.0, 0.0175, cz), Vector3(w / 2.0 - 0.3, 0.003, 0.05), _emit_mat(Color(0.15, 0.4, 0.95), 0.4))


# ------------------------------------------------------------
# Equipamentos
# ------------------------------------------------------------

func _dumbbell(parent: Node3D, pos: Vector3, head_r: float) -> void:

	var root := Node3D.new()
	root.position = pos
	parent.add_child(root)

	# eixo apontando pra frente/trás (a gente vê as "carinhas" redondas)
	_cyl(root, Vector3.ZERO, 0.017, 0.22, _chrome, Vector3(90, 0, 0))

	for sz in [-1.0, 1.0]:
		_cyl(root, Vector3(0, 0, sz * 0.09), head_r, 0.06, _iron_dark, Vector3(90, 0, 0))
		_cyl(root, Vector3(0, 0, sz * 0.126), head_r * 0.55, 0.012, _chrome, Vector3(90, 0, 0))


func _build_dumbbell_rack(pos: Vector3) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	# estrutura
	for sx in [-0.66, 0.66]:
		_box(root, Vector3(sx, 0.45, 0), Vector3(0.05, 0.9, 0.42), _iron)

	for y in [0.42, 0.82]:
		_box(root, Vector3(0, y, 0), Vector3(1.34, 0.04, 0.44), _iron_dark)

	# halteres (do mais leve ao mais pesado)
	var radii := [0.048, 0.056, 0.064, 0.072, 0.080]

	for row in range(2):
		for i in range(5):
			var r: float = radii[i]
			_dumbbell(root, Vector3(-0.52 + float(i) * 0.26, 0.44 + float(row) * 0.40 + r, 0.0), r)


func _build_weight_plates(pos: Vector3) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	var plate_mats := [
		_mat(Color(0.05, 0.05, 0.06), 0.6, 0.3),
		_mat(Color(0.70, 0.08, 0.08), 0.5, 0.3),
		_mat(Color(0.08, 0.20, 0.65), 0.5, 0.3),
	]

	# duas pilhas de anilhas + um "pino" no meio
	for s in range(2):

		var stack := Node3D.new()
		stack.position = Vector3(float(s) * 0.62, 0.0, float(s) * 0.12)
		root.add_child(stack)

		_cyl(stack, Vector3(0, 0.30, 0), 0.02, 0.60, _chrome)

		for i in range(6):
			var r: float = 0.24 - float(i % 2) * 0.03
			_cyl(stack, Vector3(0, 0.02 + float(i) * 0.04, 0), r, 0.035, plate_mats[(i + s) % 3])


func _kettlebell(parent: Node3D, pos: Vector3, r: float, mat: Material) -> void:

	var root := Node3D.new()
	root.position = pos
	parent.add_child(root)

	_sphere(root, Vector3(0, r, 0), r, mat)
	_torus(root, Vector3(0, r * 1.85, 0), r * 0.36, r * 0.55, mat, Vector3(90, 0, 0))


func _build_kettlebells(pos: Vector3) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	var k_black := _mat(Color(0.06, 0.06, 0.07), 0.45, 0.4)
	var k_red := _mat(Color(0.75, 0.08, 0.08), 0.4, 0.3)

	_kettlebell(root, Vector3(0.00, 0, 0.00), 0.11, k_black)
	_kettlebell(root, Vector3(0.30, 0, 0.05), 0.13, k_red)
	_kettlebell(root, Vector3(0.62, 0, -0.02), 0.15, k_black)


func _build_plyo_boxes(pos: Vector3) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	_box(root, Vector3(0, 0.25, 0), Vector3(0.72, 0.50, 0.62), _wood)
	_box(root, Vector3(0.62, 0.20, 0.03), Vector3(0.58, 0.40, 0.50), _wood)

	# bolas medicinais
	_sphere(root, Vector3(0.0, 0.50 + 0.15, 0.0), 0.15, _mat(Color(0.72, 0.10, 0.10), 0.5, 0.0))
	_sphere(root, Vector3(0.62, 0.40 + 0.14, 0.03), 0.14, _mat(Color(0.10, 0.22, 0.65), 0.5, 0.0))


func _build_power_rack(pos: Vector3) -> void:

	var root := Node3D.new()
	root.position = pos
	add_child(root)

	# 4 postes + travessas de cima
	for sx in [-0.55, 0.55]:
		for sz in [-0.42, 0.42]:
			_box(root, Vector3(sx, 1.15, sz), Vector3(0.07, 2.3, 0.07), _red_paint)

	for sz in [-0.42, 0.42]:
		_box(root, Vector3(0, 2.28, sz), Vector3(1.17, 0.07, 0.07), _red_paint)

	for sx in [-0.55, 0.55]:
		_box(root, Vector3(sx, 2.28, 0), Vector3(0.07, 0.07, 0.91), _red_paint)

	# barra com anilhas (apoiada nos ganchos)
	_cyl(root, Vector3(0, 1.35, 0.42), 0.014, 1.55, _chrome, Vector3(0, 0, 90))

	for sx in [-1.0, 1.0]:
		for k in range(2):
			_cyl(root, Vector3(sx * (0.62 + float(k) * 0.045), 1.35, 0.42), 0.22 - float(k) * 0.04, 0.04, _iron_dark, Vector3(0, 0, 90))

	# ganchos
	for sx in [-0.55, 0.55]:
		_box(root, Vector3(sx, 1.30, 0.42), Vector3(0.08, 0.05, 0.10), _iron)


# ------------------------------------------------------------
# Iluminação de destaque
# ------------------------------------------------------------

func _spot_fixture(pos: Vector3) -> void:

	_no_shadow(_cyl(self, pos + Vector3(0, 0.12, 0), 0.10, 0.22, _iron_dark))
	_no_shadow(_cyl(self, pos + Vector3(0, 0.005, 0), 0.07, 0.02, _emit_mat(Color(1.0, 0.95, 0.85), 3.0)))


func _build_spotlights() -> void:

	# em cima do ringue
	var ring_pos := Vector3(2.6, HEIGHT - 0.32, -3.4)
	_spot_fixture(ring_pos)

	var ring_spot := SpotLight3D.new()
	ring_spot.position = ring_pos
	ring_spot.rotation_degrees = Vector3(-90, 0, 0)
	ring_spot.light_color = Color(1.0, 0.93, 0.80)
	ring_spot.light_energy = 3.5
	ring_spot.spot_range = 5.5
	ring_spot.spot_angle = 42.0
	add_child(ring_spot)

	# em cima do treinador (luz de destaque, sem sombra pra não pesar)
	var trainer_pos := Vector3(0.0, HEIGHT - 0.32, -1.0)
	_spot_fixture(trainer_pos)

	var trainer_spot := SpotLight3D.new()
	trainer_spot.position = trainer_pos
	add_child(trainer_spot)
	trainer_spot.look_at(Vector3(0.0, 1.2, -2.2), Vector3.UP)
	trainer_spot.light_color = Color(1.0, 0.95, 0.88)
	trainer_spot.light_energy = 2.6
	trainer_spot.spot_range = 7.0
	trainer_spot.spot_angle = 30.0
