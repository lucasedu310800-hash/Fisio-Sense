# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
extends Control
class_name SignIcon
# Ícone desenhado por código (sem nenhuma imagem externa) representando
# cada resposta como um SINAL gráfico, não uma palavra — pra dar pra
# reconhecer no susto, sem precisar ler nada.
#
# V-FBF: desenhos refeitos pra serem mais intuitivos:
#   - SOCO: luva grande com os "raios" de impacto em cima e o rastro de
#     velocidade embaixo (a luva sobe/avança como num soco de verdade).
#   - DEFESA lateral (dodge_*): bonequinho INCLINADO pro lado + seta
#     grande apontando pro mesmo lado.
#   - AGACHAR (crouch): bonequinho agachado (joelhos dobrados) + seta
#     grande pra baixo.
#   - DEFESA ALTA (duck): rosto coberto pelas duas luvas (vermelha e azul).
#
# Cor: se `tint` tiver alfa > 0, TUDO usa essa cor (o HUD usa vermelho
# pra esquerda e azul pra direita). Sem tint, mantém o padrão antigo
# (defesa = ciano, ataque = laranja) — usado na legenda do tutorial.
#
# sign_type aceita: "dodge_left", "dodge_right", "duck", "crouch",
# "punch_left", "punch_right".
# ("crouch" = agachar. "duck" = guarda alta.)

@export var sign_type: String = "dodge_left":
	set(v):
		sign_type = v
		queue_redraw()

@export var tint: Color = Color(0, 0, 0, 0):
	set(v):
		tint = v
		queue_redraw()

const DEFENSE_COLOR := Color(0.4, 0.85, 1.0)
const ATTACK_COLOR := Color(1.0, 0.55, 0.2)
const OUTLINE := Color(0.02, 0.02, 0.05, 0.85)
const WHITE := Color(0.97, 0.97, 0.97)
const HAND_LEFT := Color(0.90, 0.16, 0.16)    # luva esquerda = vermelha
const HAND_RIGHT := Color(0.16, 0.42, 0.98)   # luva direita = azul


func _draw() -> void:
	var s: Vector2 = size
	var c: Vector2 = s / 2.0

	var col: Color = ATTACK_COLOR if sign_type.begins_with("punch") else DEFENSE_COLOR

	if tint.a > 0.0:
		col = Color(tint.r, tint.g, tint.b, 1.0)

	match sign_type:
		"dodge_left":
			_draw_dodge(c, s, -1, col)
		"dodge_right":
			_draw_dodge(c, s, 1, col)
		"duck":
			_draw_high_guard(c, s, col)
		"crouch":
			_draw_crouch(c, s, col)
		"punch_left":
			_draw_punch(c, s, -1, col)
		"punch_right":
			_draw_punch(c, s, 1, col)


# ------------------------------------------------------------
# Ferramentas de desenho (sempre com contorno escuro, pra o sinal
# aparecer bem em cima de qualquer cenário)
# ------------------------------------------------------------

func _lines(segs: Array, w: float, col: Color) -> void:
	for sg in segs:
		draw_line(sg[0], sg[1], OUTLINE, w + 5.0, true)
	for sg in segs:
		draw_line(sg[0], sg[1], col, w, true)


func _disc(p: Vector2, r: float, col: Color) -> void:
	draw_circle(p, r + 2.5, OUTLINE)
	draw_circle(p, r, col)


# Seta grossa de `a` até `b` (ponta triangular em `b`).
func _arrow(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	var d: Vector2 = (b - a).normalized()
	var n := Vector2(-d.y, d.x)
	var head_len: float = w * 2.6
	var head_w: float = w * 1.9
	var base: Vector2 = b - d * head_len

	draw_line(a, base + d * 2.0, OUTLINE, w + 5.0, true)

	var tri := PackedVector2Array([b, base + n * head_w, base - n * head_w])
	var tri_out := PackedVector2Array([b, base + n * head_w, base - n * head_w, b])
	draw_polyline(tri_out, OUTLINE, 5.0, true)

	draw_line(a, base + d * 2.0, col, w, true)
	draw_colored_polygon(tri, col)


# Bonequinho de frente. `lean` (-1..1) inclina o corpo todo pro lado;
# `crouch` dobra os joelhos e abaixa tudo.
func _draw_figure(c: Vector2, u: float, col: Color, lean: float, crouch: bool) -> void:

	var w: float = u * 0.075
	var hip: Vector2
	var sh: Vector2
	var head: Vector2
	var knee_l: Vector2
	var knee_r: Vector2
	var foot_l: Vector2
	var foot_r: Vector2

	if crouch:
		hip = c + Vector2(0, u * 0.22)
		sh = c + Vector2(0, u * 0.00)
		head = c + Vector2(0, -u * 0.15)
		knee_l = c + Vector2(-u * 0.21, u * 0.32)
		knee_r = c + Vector2(u * 0.21, u * 0.32)
		foot_l = c + Vector2(-u * 0.13, u * 0.45)
		foot_r = c + Vector2(u * 0.13, u * 0.45)
	else:
		hip = c + Vector2(lean * u * 0.03, u * 0.14)
		sh = c + Vector2(lean * u * 0.12, -u * 0.10)
		head = c + Vector2(lean * u * 0.20, -u * 0.25)
		knee_l = c + Vector2(-u * 0.09 + lean * u * 0.01, u * 0.29)
		knee_r = c + Vector2(u * 0.09 + lean * u * 0.01, u * 0.29)
		foot_l = c + Vector2(-u * 0.13 - lean * u * 0.02, u * 0.45)
		foot_r = c + Vector2(u * 0.13 - lean * u * 0.02, u * 0.45)

	var elbow_l: Vector2 = sh + Vector2(-u * 0.17, u * 0.09)
	var elbow_r: Vector2 = sh + Vector2(u * 0.17, u * 0.09)
	var fist_l: Vector2 = sh + Vector2(-u * 0.10, -u * 0.06)
	var fist_r: Vector2 = sh + Vector2(u * 0.10, -u * 0.06)

	_lines([
		[sh, hip],
		[hip, knee_l], [knee_l, foot_l],
		[hip, knee_r], [knee_r, foot_r],
		[sh, elbow_l], [elbow_l, fist_l],
		[sh, elbow_r], [elbow_r, fist_r],
	], w, col)

	_disc(fist_l, u * 0.055, col)
	_disc(fist_r, u * 0.055, col)
	_disc(head, u * 0.10, col)


# ------------------------------------------------------------
# DEFESA lateral: bonequinho inclinado + seta grande pro mesmo lado
# ------------------------------------------------------------
func _draw_dodge(c: Vector2, s: Vector2, dir: int, col: Color) -> void:
	var u: float = min(s.x, s.y)

	_draw_figure(c + Vector2(-dir * u * 0.08, -u * 0.06), u, col, float(dir), false)

	# seta grande apontando pro lado da defesa
	var y: float = c.y + u * 0.40
	_arrow(
		Vector2(c.x - dir * u * 0.05, y),
		Vector2(c.x + dir * u * 0.46, y),
		u * 0.07,
		WHITE
	)


# ------------------------------------------------------------
# AGACHAR: bonequinho agachado + seta grande pra baixo
# ------------------------------------------------------------
func _draw_crouch(c: Vector2, s: Vector2, col: Color) -> void:
	var u: float = min(s.x, s.y)

	_draw_figure(c + Vector2(0, -u * 0.02), u * 0.9, col, 0.0, true)

	_arrow(
		Vector2(c.x - u * 0.34, c.y - u * 0.40),
		Vector2(c.x - u * 0.34, c.y + u * 0.08),
		u * 0.07,
		WHITE
	)
	_arrow(
		Vector2(c.x + u * 0.34, c.y - u * 0.40),
		Vector2(c.x + u * 0.34, c.y + u * 0.08),
		u * 0.07,
		WHITE
	)


# ------------------------------------------------------------
# DEFESA ALTA: rosto protegido pelas DUAS luvas (esquerda vermelha,
# direita azul), com os antebraços subindo
# ------------------------------------------------------------
func _draw_high_guard(c: Vector2, s: Vector2, _col: Color) -> void:
	var u: float = min(s.x, s.y)
	var r: float = u * 0.19

	# cabeça atrás das luvas
	var head: Vector2 = c + Vector2(0, -u * 0.06)
	_disc(head, u * 0.22, Color(0.90, 0.70, 0.52))

	# ombros/tronco embaixo
	_lines([[c + Vector2(-u * 0.30, u * 0.44), c + Vector2(-u * 0.10, u * 0.28)],
		[c + Vector2(u * 0.30, u * 0.44), c + Vector2(u * 0.10, u * 0.28)]], u * 0.10, Color(0.90, 0.70, 0.52))

	var cols := [HAND_LEFT, HAND_RIGHT]
	var idx := 0

	for dir in [-1, 1]:
		var gx: float = c.x + dir * u * 0.15
		var glove := Vector2(gx, c.y - u * 0.04)
		var gc: Color = cols[idx]
		idx += 1
		# antebraço subindo até a luva
		_lines([[Vector2(gx + dir * u * 0.14, c.y + u * 0.44), glove + Vector2(0, r * 0.5)]], u * 0.10, gc.darkened(0.25))
		_disc(glove, r, gc)
		draw_arc(glove, r * 0.6, deg_to_rad(200.0), deg_to_rad(275.0), 12, Color(1, 1, 1, 0.55), u * 0.03, true)

	# escudo pequeno: "protege"
	_arrow(
		Vector2(c.x, c.y - u * 0.30),
		Vector2(c.x, c.y - u * 0.47),
		u * 0.05,
		WHITE
	)


# ------------------------------------------------------------
# SOCO: luva grande + raios de impacto em cima + rastro embaixo
# ------------------------------------------------------------
func _draw_punch(c: Vector2, s: Vector2, dir: int, col: Color) -> void:
	var u: float = min(s.x, s.y)
	var g: Vector2 = c + Vector2(0, -u * 0.02)
	var r: float = u * 0.24

	# raios de impacto (em cima da luva)
	var rays: Array = []
	for ang in [-150.0, -120.0, -90.0, -60.0, -30.0]:
		var a: float = deg_to_rad(ang)
		var d := Vector2(cos(a), sin(a))
		var origin: Vector2 = g + Vector2(0, -r * 0.2)
		rays.append([origin + d * (r * 1.28), origin + d * (r * 1.62)])
	_lines(rays, u * 0.05, Color(1.0, 0.92, 0.45))

	# rastro de velocidade (embaixo)
	var trail: Array = []
	for i in range(3):
		var x: float = g.x + (i - 1) * u * 0.15
		var y0: float = g.y + r * 1.25 + (0.0 if i == 1 else u * 0.05)
		trail.append([Vector2(x, y0), Vector2(x, y0 + u * 0.12)])
	_lines(trail, u * 0.045, col.lightened(0.15))

	# punho branco da luva
	var cuff := Rect2(
		Vector2(g.x - r * 0.62, g.y + r * 0.62),
		Vector2(r * 1.24, r * 0.62)
	)
	draw_rect(cuff.grow(2.5), OUTLINE)
	draw_rect(cuff, WHITE)

	# polegar (do lado de dentro do corpo) e corpo da luva
	_disc(g + Vector2(-dir * r * 0.86, r * 0.18), r * 0.36, col)
	_disc(g, r, col)

	# brilho e linha dos dedos
	draw_arc(g, r * 0.62, deg_to_rad(200.0), deg_to_rad(270.0), 12, Color(1, 1, 1, 0.55), u * 0.035, true)
	draw_line(
		g + Vector2(-r * 0.55, -r * 0.05),
		g + Vector2(r * 0.55, -r * 0.05),
		Color(0, 0, 0, 0.30),
		u * 0.02,
		true
	)
