#!/usr/bin/env python3
# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
"""
Gera as texturas do cenário do ginásio (parede de tijolo, piso de
borracha, lona do ringue, pôsteres originais de decoração, vista de
rua pela janela). Tudo desenhado com formas simples via PIL — nenhuma
imagem/foto real usada, nenhuma marca ou personagem protegido por
direitos autorais (os pôsteres são design gráfico genérico, criado do
zero).
"""

import os
import math
import random
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "textures")
os.makedirs(OUT, exist_ok=True)

random.seed(7)

FONT_CANDIDATES = [
    "/mnt/skills/examples/canvas-design/canvas-fonts/BigShoulders-Bold.ttf",
    "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]


def font(size):
    for path in FONT_CANDIDATES:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def save(img, name):
    path = os.path.join(OUT, f"{name}.png")
    img.save(path)
    print(f"  {name}.png -> {img.size}")


# ----------------------------------------------------------------------
# PAREDE DE TIJOLO (tileable)
# ----------------------------------------------------------------------
def gen_brick_wall():
    W, H = 512, 512
    img = Image.new("RGB", (W, H), (58, 30, 26))
    d = ImageDraw.Draw(img)

    brick_w, brick_h = 64, 28
    mortar = 4
    row = 0
    y = -brick_h
    while y < H + brick_h:
        offset = (brick_w // 2) if (row % 2 == 1) else 0
        x = -brick_w + offset
        while x < W + brick_w:
            base = random.randint(-14, 10)
            r = max(0, min(255, 120 + base))
            g = max(0, min(255, 52 + int(base * 0.6)))
            b = max(0, min(255, 42 + int(base * 0.5)))
            d.rectangle(
                [x + mortar // 2, y + mortar // 2, x + brick_w - mortar // 2, y + brick_h - mortar // 2],
                fill=(r, g, b),
            )
            # leve sombra na base de cada tijolo, dá volume sem precisar de normal map
            d.rectangle(
                [x + mortar // 2, y + brick_h - mortar // 2 - 4, x + brick_w - mortar // 2, y + brick_h - mortar // 2],
                fill=(max(0, r - 22), max(0, g - 14), max(0, b - 12)),
            )
            x += brick_w
        y += brick_h
        row += 1

    img = img.filter(ImageFilter.GaussianBlur(0.4))
    # ruído leve pra quebrar a repetição
    px = img.load()
    for _ in range(9000):
        xx = random.randint(0, W - 1)
        yy = random.randint(0, H - 1)
        c = px[xx, yy]
        n = random.randint(-8, 8)
        px[xx, yy] = (max(0, min(255, c[0] + n)), max(0, min(255, c[1] + n)), max(0, min(255, c[2] + n)))

    save(img, "brick_wall")


# ----------------------------------------------------------------------
# PISO DE BORRACHA (tileable)
# ----------------------------------------------------------------------
def gen_rubber_floor():
    W, H = 512, 512
    base = (24, 24, 27)
    img = Image.new("RGB", (W, H), base)
    d = ImageDraw.Draw(img)

    # padrão de losangos bem sutil (piso emborrachado de academia)
    step = 32
    for y in range(-step, H + step, step):
        for x in range(-step, W + step, step):
            cx, cy = x + (step // 2 if (y // step) % 2 else 0), y
            pts = [(cx, cy - 6), (cx + 10, cy), (cx, cy + 6), (cx - 10, cy)]
            shade = random.randint(-4, 6)
            c = tuple(max(0, min(255, v + shade)) for v in (34, 34, 38))
            d.polygon(pts, fill=c)

    img = img.filter(ImageFilter.GaussianBlur(0.6))
    px = img.load()
    for _ in range(14000):
        xx = random.randint(0, W - 1)
        yy = random.randint(0, H - 1)
        c = px[xx, yy]
        n = random.randint(-6, 6)
        px[xx, yy] = (max(0, min(255, c[0] + n)), max(0, min(255, c[1] + n)), max(0, min(255, c[2] + n)))

    save(img, "rubber_floor")


# ----------------------------------------------------------------------
# LONA DO RINGUE
# ----------------------------------------------------------------------
def gen_ring_canvas():
    W, H = 768, 768
    img = Image.new("RGB", (W, H), (58, 74, 112))
    d = ImageDraw.Draw(img)

    cx, cy = W / 2, H / 2
    d.ellipse([cx - 240, cy - 240, cx + 240, cy + 240], outline=(220, 224, 232), width=6)
    d.ellipse([cx - 170, cy - 170, cx + 170, cy + 170], outline=(220, 224, 232), width=3)

    # leve textura de lona (linhas horizontais bem sutis)
    for y in range(0, H, 3):
        shade = 4 if (y // 3) % 2 == 0 else -4
        d.line([(0, y), (W, y)], fill=tuple(max(0, min(255, v + shade)) for v in (58, 74, 112)))

    # cantos levemente mais escuros (vinheta simples)
    vign = Image.new("L", (W, H), 0)
    vd = ImageDraw.Draw(vign)
    vd.ellipse([-W * 0.3, -H * 0.3, W * 1.3, H * 1.3], fill=60)
    img = Image.composite(img, Image.new("RGB", (W, H), (30, 38, 58)), vign.point(lambda p: 255 - p // 3))

    save(img, "ring_canvas")


# ----------------------------------------------------------------------
# PÔSTERES ORIGINAIS (design gráfico simples, sem fotos/marcas reais)
# ----------------------------------------------------------------------
def _poster_base(w, h, bg):
    img = Image.new("RGB", (w, h), bg)
    d = ImageDraw.Draw(img)
    d.rectangle([8, 8, w - 9, h - 9], outline=(230, 230, 230), width=3)
    return img, d


def gen_poster_glove():
    w, h = 384, 512
    img, d = _poster_base(w, h, (26, 20, 22))

    # luva estilizada (formas simples)
    gx, gy = w / 2, h * 0.40
    d.ellipse([gx - 95, gy - 90, gx + 95, gy + 90], fill=(196, 30, 30))
    d.rectangle([gx - 60, gy + 40, gx + 60, gy + 150], fill=(196, 30, 30))
    d.ellipse([gx - 60, gy + 120, gx + 60, gy + 180], fill=(196, 30, 30))
    for i in range(4):
        fx = gx - 70 + i * 46
        d.ellipse([fx - 20, gy - 70, fx + 20, gy + 10], fill=(168, 20, 20))
    d.ellipse([gx - 95, gy - 90, gx + 95, gy + 90], outline=(90, 8, 8), width=4)

    d.text((w / 2, h * 0.82), "BOXE", font=font(64), fill=(230, 230, 230), anchor="mm")
    d.rectangle([w * 0.28, h * 0.88, w * 0.72, h * 0.885], fill=(196, 30, 30))
    save(img, "poster_glove")


def gen_poster_motivational():
    w, h = 384, 512
    img, d = _poster_base(w, h, (14, 14, 16))

    lines = ["FOCO", "FORÇA", "GARRA"]
    y = h * 0.16
    for line in lines:
        d.rectangle([w * 0.12, y, w * 0.88, y + 74], outline=(196, 30, 30), width=2)
        d.text((w / 2, y + 37), line, font=font(46), fill=(230, 230, 230), anchor="mm")
        y += 104

    # silhueta simples de lutador em guarda (formas geométricas)
    sx, sy = w / 2, h * 0.83
    d.ellipse([sx - 22, sy - 90, sx + 22, sy - 46], fill=(70, 70, 74))
    d.polygon([(sx - 30, sy - 46), (sx + 30, sy - 46), (sx + 22, sy + 10), (sx - 22, sy + 10)], fill=(70, 70, 74))
    d.ellipse([sx - 55, sy - 40, sx - 15, sy], fill=(70, 70, 74))
    d.ellipse([sx + 15, sy - 40, sx + 55, sy], fill=(70, 70, 74))

    save(img, "poster_motivational")


def gen_poster_badge():
    w, h = 384, 512
    img, d = _poster_base(w, h, (20, 22, 28))

    cx, cy, r = w / 2, h * 0.38, 130
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(196, 30, 30), width=6)
    d.ellipse([cx - r + 16, cy - r + 16, cx + r - 16, cy + r - 16], outline=(230, 230, 230), width=2)

    # duas luvas cruzadas simplificadas
    for side in (-1, 1):
        gx = cx + side * 38
        d.ellipse([gx - 40, cy - 30, gx + 40, cy + 50], fill=(196, 30, 30))
    d.ellipse([cx - 46, cy - 20, cx + 46, cy + 30], fill=(160, 22, 22))

    d.text((w / 2, h * 0.65), "ACADEMIA", font=font(38), fill=(230, 230, 230), anchor="mm")
    d.text((w / 2, h * 0.71), "DE BOXE", font=font(38), fill=(230, 230, 230), anchor="mm")

    save(img, "poster_badge")


# ----------------------------------------------------------------------
# VISTA DE RUA (pela janela) — cena estilizada simples, sem fotos reais
# ----------------------------------------------------------------------
def gen_street_view():
    W, H = 896, 512
    img = Image.new("RGB", (W, H), (146, 172, 196))
    d = ImageDraw.Draw(img)

    # céu em degradê
    top = (120, 150, 182)
    bottom = (190, 205, 210)
    horizon = int(H * 0.58)
    for y in range(0, horizon):
        t = y / horizon
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        d.line([(0, y), (W, y)], fill=c)

    # prédios em silhueta, alturas variadas
    x = 0
    random.seed(3)
    while x < W:
        bw = random.randint(60, 130)
        bh = random.randint(int(H * 0.12), int(H * 0.34))
        shade = random.randint(-14, 10)
        c = tuple(max(30, min(140, 92 + shade + i * 4)) for i in range(3))
        d.rectangle([x, horizon - bh, x + bw, horizon + 2], fill=c)
        # janelinhas
        for wy in range(horizon - bh + 10, horizon - 8, 16):
            for wx in range(x + 8, x + bw - 8, 14):
                if random.random() < 0.6:
                    d.rectangle([wx, wy, wx + 6, wy + 8], fill=(210, 200, 150))
        x += bw + random.randint(4, 14)

    # rua + calçada
    d.rectangle([0, horizon, W, H], fill=(70, 70, 74))
    d.rectangle([0, horizon, W, horizon + 14], fill=(150, 150, 152))
    for lx in range(0, W, 60):
        d.rectangle([lx, horizon + H * 0.18, lx + 30, horizon + H * 0.18 + 4], fill=(220, 200, 90))

    # um carro estacionado, bem simples
    cx = W * 0.62
    cy = horizon + H * 0.22
    d.rounded_rectangle([cx, cy, cx + 130, cy + 40], radius=10, fill=(200, 40, 40))
    d.rounded_rectangle([cx + 20, cy - 22, cx + 100, cy + 4], radius=8, fill=(200, 40, 40))
    d.ellipse([cx + 12, cy + 30, cx + 40, cy + 58], fill=(20, 20, 20))
    d.ellipse([cx + 92, cy + 30, cx + 120, cy + 58], fill=(20, 20, 20))

    save(img, "street_view")


if __name__ == "__main__":
    print("Texturas do cenário:")
    gen_brick_wall()
    gen_rubber_floor()
    gen_ring_canvas()
    gen_poster_glove()
    gen_poster_motivational()
    gen_poster_badge()
    gen_street_view()
    print("\nTodas geradas em:", OUT)
