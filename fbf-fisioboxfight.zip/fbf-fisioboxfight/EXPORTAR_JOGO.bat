﻿@echo off
chcp 65001 >nul
REM ============================================================
REM EXPORTAR_JOGO.bat - gera o FBF.exe SEM abrir a tela do Godot.
REM Clique duas vezes UMA VEZ so. Depois disso, use o JOGAR.bat
REM normalmente (ele ja vai achar o FBF.exe pronto).
REM
REM Funciona tanto se o projeto Godot estiver na pasta
REM "TreinoDeReflexo3D" do lado deste .bat, quanto se este .bat
REM estiver DENTRO da propria pasta do projeto (ao lado do
REM project.godot direto) - detecta sozinho qual dos dois casos e.
REM
REM Precisa: Godot 4 instalado no seu PC e os "Export Templates" ja
REM baixados (ver aviso no final deste arquivo se der erro nisso).
REM ============================================================

setlocal
cd /d "%~dp0"

REM -------------------------------------------------------------
REM Se o seu "godot" nao estiver no PATH do Windows, escreva aqui
REM embaixo o caminho completo do Godot_v4...exe entre aspas, por
REM exemplo:
REM     set GODOT_EXE="C:\Godot\Godot_v4.3-stable_win64.exe"
REM Deixe como esta (comentado) se "godot" ja funciona no PATH.
REM -------------------------------------------------------------
set GODOT_EXE="C:\Users\lucas\OneDrive\Área de Trabalho\Godot_v4.7.2-stable_win64.exe"

if not defined GODOT_EXE (
    where godot >nul 2>nul && set GODOT_EXE=godot
)

if not defined GODOT_EXE (
    where godot4 >nul 2>nul && set GODOT_EXE=godot4
)

if not defined GODOT_EXE (
    echo.
    echo Nao encontrei o Godot no PATH do Windows.
    echo Abra este arquivo ^(EXPORTAR_JOGO.bat^) com o Bloco de Notas e
    echo escreva o caminho completo do seu Godot_v4...exe na linha
    echo     set GODOT_EXE=
    echo entre aspas, salve, e rode este .bat de novo.
    pause
    exit /b 1
)

REM -------------------------------------------------------------
REM Acha o projeto: tanto faz se esta em "TreinoDeReflexo3D\" do
REM lado deste .bat, ou se o project.godot esta bem aqui do lado.
REM -------------------------------------------------------------
set PROJECT_DIR=
if exist "TreinoDeReflexo3D\project.godot" set PROJECT_DIR=TreinoDeReflexo3D
if "%PROJECT_DIR%"=="" if exist "project.godot" set PROJECT_DIR=.

if "%PROJECT_DIR%"=="" (
    echo Nao encontrei um project.godot nem em "TreinoDeReflexo3D\"
    echo nem nesta propria pasta. Deixe o EXPORTAR_JOGO.bat do lado
    echo da pasta do projeto Godot ^(ou dentro dela^) e tente de novo.
    pause
    exit /b 1
)

echo Projeto encontrado em: %PROJECT_DIR%
echo Gerando o FBF.exe (sem abrir a tela do Godot, so aguarde)...
echo.

%GODOT_EXE% --headless --path "%PROJECT_DIR%" --export-release "Windows Desktop" "%~dp0%PROJECT_DIR%\FBF.exe"

echo.
if exist "%PROJECT_DIR%\FBF.exe" (
    echo ======================================================
    echo PRONTO! Criado %PROJECT_DIR%\FBF.exe
    echo Agora e so usar o JOGAR.bat normalmente pra jogar.
    echo ======================================================
) else (
    echo ======================================================
    echo Nao consegui criar o FBF.exe. Erros mais comuns:
    echo  - "Export Templates" nao instalados: abra o Godot uma vez,
    echo    va em Editor ^> Manage Export Templates ^> Download and
    echo    Install.
    echo  - O preset "Windows Desktop" nao existe no projeto: abra o
    echo    Godot, Project ^> Export..., e adicione "Windows Desktop"
    echo    uma vez ^(so precisa fazer isso uma vez, nunca mais^).
    echo ======================================================
)

pause
endlocal
