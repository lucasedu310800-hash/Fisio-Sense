@echo off
setlocal EnableDelayedExpansion
title Limpar cache do Godot (FBF)

REM ============================================================
REM LIMPAR_CACHE_GODOT.bat
REM 1) cache so deste projeto   2) + cache global (shaders)
REM 3) RESET TOTAL: Godot "novinho", como recem-instalado
REM Coloque este arquivo na mesma pasta do JOGAR.bat.
REM ============================================================

set "PROJ=%~dp0TreinoDeReflexo3D"
set "SAVES=%APPDATA%\Godot\app_userdata"

echo.
echo ==============================================
echo    LIMPAR CACHE DO GODOT  (FBF)
echo ==============================================
echo.
echo  FECHE O GODOT (e o jogo) ANTES DE CONTINUAR!
echo.
echo   1 - Limpar so o cache DESTE projeto
echo       (pasta .godot e arquivos .import - o Godot refaz sozinho)
echo   2 - Opcao 1 + cache global do Godot (shaders, etc.)
echo   3 - RESET TOTAL (apaga TUDO do Godot: configuracoes, projetos
echo       recentes, export templates e os SAVES do jogo)
echo   0 - Sair
echo.
set /p OP=Escolha (0-3): 

if "%OP%"=="1" goto OPCAO1
if "%OP%"=="2" goto OPCAO2
if "%OP%"=="3" goto OPCAO3
goto FIM

:OPCAO1
call :LIMPA_PROJETO
goto PRONTO

:OPCAO2
call :LIMPA_PROJETO
call :LIMPA_GLOBAL
goto PRONTO

:OPCAO3
echo.
echo ATENCAO: isso deixa o Godot como se nunca tivesse sido aberto:
echo  - apaga configuracoes do editor, projetos recentes e export templates
echo  - apaga os SAVES do FBF (desbloqueios, recordes, conquistas, relatorios)
echo  - Uma COPIA dos saves sera feita na sua Area de Trabalho antes.
echo.
set /p OK=Digite SIM para continuar: 
if /i not "%OK%"=="SIM" goto FIM

if exist "%SAVES%" (
    echo Salvando copia dos saves em "%USERPROFILE%\Desktop\Backup_saves_Godot" ...
    xcopy "%SAVES%" "%USERPROFILE%\Desktop\Backup_saves_Godot" /e /i /y >nul
)

call :LIMPA_PROJETO

if exist "%APPDATA%\Godot" rd /s /q "%APPDATA%\Godot"
if exist "%LOCALAPPDATA%\Godot" rd /s /q "%LOCALAPPDATA%\Godot"
goto PRONTO

:LIMPA_PROJETO
echo Limpando o cache do projeto...
if exist "%PROJ%\.godot" rd /s /q "%PROJ%\.godot"
for /r "%PROJ%" %%F in (*.import) do del /q "%%F" >nul 2>&1
goto :eof

:LIMPA_GLOBAL
echo Limpando o cache global do Godot...
if exist "%LOCALAPPDATA%\Godot" rd /s /q "%LOCALAPPDATA%\Godot"
if exist "%APPDATA%\Godot\shader_cache" rd /s /q "%APPDATA%\Godot\shader_cache"
if exist "%SAVES%" (
    for /d %%D in ("%SAVES%\*") do (
        if exist "%%D\shader_cache" rd /s /q "%%D\shader_cache"
    )
)
goto :eof

:PRONTO
echo.
echo Pronto! Abra o Godot de novo: na primeira vez ele vai reimportar
echo os arquivos do projeto (pode demorar um pouquinho).
echo.

:FIM
pause
