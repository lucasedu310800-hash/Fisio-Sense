﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
set TREINO_LOG_PATH=movimento_ao_vivo.log
python movimentos.py
echo.
echo (janela do Detector fechada - pressione uma tecla pra fechar)
pause >nul
