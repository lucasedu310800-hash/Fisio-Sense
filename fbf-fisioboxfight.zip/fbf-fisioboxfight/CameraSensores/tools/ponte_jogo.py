#!/usr/bin/env python3
# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
"""
ponte_jogo.py
=============

Ponte entre a webcam (movimentos.py) e QUALQUER jogo/engine, em tempo
real, via UDP. Foi feita pra nao depender de saber de antemao qual
motor o jogo novo vai usar (Godot, Unity, Unreal, um HTML...) — ela so
manda o nome do movimento detectado como texto simples por UDP; o lado
do jogo decide como interpretar isso quando estiver pronto.

Movimentos encaminhados (os 5 que o projeto novo vai usar, mais NEUTRO
pra sinalizar "sem movimento"/postura de descanso):

    SOCO ESQUERDO
    SOCO DIREITO
    DEFESA ALTA
    ESQUIVA ESQUERDA
    ESQUIVA DIREITA
    AGACHAR
    NEUTRO

(SOCO DUPLO e ignorado de proposito. AGACHAR passou a ser encaminhado
na versao FBF - FisioBoxFight, que usa o agachamento como defesa.)

------------------------------------------------------------------------
COMO FUNCIONA
------------------------------------------------------------------------
O movimentos.py ja tem um "observador" aditivo (_log_tester_frame),
originalmente feito pra Maquina de Testes, que escreve
"frame_id,MOVIMENTO" a cada frame num arquivo — SO quando a variavel de
ambiente TREINO_LOG_PATH esta definida. Fora isso ele nao faz nada
diferente do normal.

Esse script aqui reaproveita exatamente esse mesmo mecanismo, so que ao
vivo: ele fica "seguindo" esse arquivo de log (como um `tail -f`) e, toda
vez que o movimento MUDA, manda um pacote UDP com o novo movimento pro
host/porta configurados. Nao precisa gravar video nem esperar nada
terminar — funciona junto com o movimentos.py rodando ao vivo pela
webcam.

------------------------------------------------------------------------
COMO USAR (duas janelas de terminal)
------------------------------------------------------------------------
Janela 1 — roda o detector normalmente, so que com o log ligado:

    set TREINO_LOG_PATH=movimento_ao_vivo.log
    python movimentos.py

Janela 2 — roda a ponte, apontando pro mesmo arquivo:

    python tools\\ponte_jogo.py

Por padrao ela manda pra 127.0.0.1:5555 (o jogo rodando no mesmo PC).
Pra mandar pra outro host/porta:

    python tools\\ponte_jogo.py --host 127.0.0.1 --port 6000

------------------------------------------------------------------------
DO LADO DO JOGO
------------------------------------------------------------------------
Cada pacote UDP e so o texto do movimento, em maiusculas, exatamente
como o detector usa internamente, por exemplo:

    SOCO ESQUERDO
    DEFESA ALTA
    NEUTRO

Qualquer engine com suporte a socket UDP consegue ler isso (em Godot,
por exemplo, e o mesmo padrao do PacketPeerUDP que ja usamos no outro
projeto). Assim que o projeto novo chegar, eu adapto o lado de recepcao
pro motor/engine que ele estiver usando — esse script aqui nao muda.
"""

import argparse
import socket
import sys
import time
from pathlib import Path

MOVIMENTOS_RELEVANTES = {
    "SOCO ESQUERDO",
    "SOCO DIREITO",
    "DEFESA ALTA",
    "ESQUIVA ESQUERDA",
    "ESQUIVA DIREITA",
    "AGACHAR",
    "NEUTRO",
}


def seguir_e_enviar(log_path: str, host: str, port: int) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    caminho = Path(log_path)
    print(f"Aguardando {caminho} ser criado (rode movimentos.py com TREINO_LOG_PATH definido)...")
    while not caminho.exists():
        time.sleep(0.2)

    print(f"Encontrado. Enviando movimentos para {host}:{port} — Ctrl+C para parar.")

    ultimo_enviado = None
    ultimo_bal = None
    ultimo_bal_t = 0.0
    with open(caminho, "r", encoding="utf-8") as f:
        f.seek(0, 2)  # vai para o fim: so processa o que acontecer da agora em diante
        while True:
            linha = f.readline()
            if not linha:
                time.sleep(0.01)
                continue

            linha = linha.strip()
            if not linha or "," not in linha:
                continue

            _, rotulo = linha.split(",", 1)

            # BALANCA 67 (minigame secreto): "BALANCA:ESQ|DIR|NEUTRO". Manda
            # "BALANCA ESQ" etc. quando muda e a cada ~0.8 s (batida de vida).
            if rotulo.startswith("BALANCA:"):
                estado = rotulo.split(":", 1)[1]
                if estado in ("ESQ", "DIR", "NEUTRO"):
                    agora = time.time()
                    if estado != ultimo_bal or agora - ultimo_bal_t > 0.8:
                        sock.sendto(f"BALANCA {estado}".encode("utf-8"), (host, port))
                        if estado != ultimo_bal:
                            print(f"-> BALANCA {estado}")
                        ultimo_bal = estado
                        ultimo_bal_t = agora
                continue

            if rotulo not in MOVIMENTOS_RELEVANTES:
                continue

            if rotulo != ultimo_enviado:
                sock.sendto(rotulo.encode("utf-8"), (host, port))
                print(f"-> {rotulo}")
                ultimo_enviado = rotulo


def main() -> None:
    parser = argparse.ArgumentParser(description="Ponte webcam -> jogo (UDP), ao vivo.")
    parser.add_argument("--log", default="movimento_ao_vivo.log", help="Mesmo caminho usado em TREINO_LOG_PATH.")
    parser.add_argument("--host", default="127.0.0.1", help="Host do jogo (127.0.0.1 = mesmo PC).")
    parser.add_argument("--port", type=int, default=5555, help="Porta UDP do jogo.")
    args = parser.parse_args()

    try:
        seguir_e_enviar(args.log, args.host, args.port)
    except KeyboardInterrupt:
        print("\nEncerrado.")
        sys.exit(0)


if __name__ == "__main__":
    main()
