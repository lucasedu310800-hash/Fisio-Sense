#!/usr/bin/env python3
# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
"""
lancador.py
===========

Usado pelo JOGO (Godot) para abrir o detector (movimentos.py) e a ponte
(tools/ponte_jogo.py) sem janela de terminal (pythonw). Como o pythonw nao tem
console, qualquer erro sumia em silencio e a camera "nao abria". Este lancador:

  - grava tudo (saida e erros) em  CameraSensores/camera_erro.log ;
  - se o script falhar (modulo faltando, camera ocupada...), mostra uma JANELA de
    aviso com o erro, em vez de morrer calado;
  - define FBF_JANELA_NA_FRENTE=1, para a janela da webcam abrir no canto inferior
    direito e SEMPRE NA FRENTE (antes ela costumava abrir escondida atras do jogo).

Uso:  pythonw tools/lancador.py <script.py> [argumentos do script...]
"""

import datetime
import os
import runpy
import sys
import traceback


def _aviso(texto):
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(0, texto, "FBF - Camera", 0x10)
    except Exception:
        pass


def main():
    if len(sys.argv) < 2:
        return 2

    alvo = os.path.abspath(sys.argv[1])
    resto = sys.argv[2:]
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # pasta CameraSensores
    os.chdir(base)

    log_path = os.path.join(base, "camera_erro.log")

    try:
        log = open(log_path, "a", encoding="utf-8", buffering=1)
        sys.stdout = log
        sys.stderr = log
    except Exception:
        log = None

    print("\n=== %s  %s %s" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), os.path.basename(alvo), resto))

    os.environ["FBF_JANELA_NA_FRENTE"] = "1"
    sys.path.insert(0, os.path.dirname(alvo))
    sys.argv = [alvo] + resto

    try:
        runpy.run_path(alvo, run_name="__main__")
    except SystemExit as e:
        if e.code not in (None, 0):
            print("saiu com codigo", e.code)
            _aviso("A camera fechou com o codigo %s.\n\nDetalhes em:\n%s" % (e.code, log_path))
    except BaseException:
        erro = traceback.format_exc()
        print(erro)
        ultimas = "\n".join(erro.strip().splitlines()[-4:])
        _aviso(
            "A camera nao abriu.\n\n%s\n\n"
            "Dicas: instale opencv-python e mediapipe (pip install opencv-python mediapipe) "
            "e feche outros programas que usam a webcam.\n\nDetalhes em:\n%s" % (ultimas, log_path)
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
