﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
python tools\ponte_jogo.py
echo.
echo (janela da Ponte fechada - pressione uma tecla pra fechar)
pause >nul
