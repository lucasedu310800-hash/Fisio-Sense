# © 2026 Lucas Eduardo De Gois — FisioSense (Next-FIAP). Todos os direitos reservados.
# Autoria: Lucas Eduardo De Gois. Assinatura SHA-256: c0ddd2be9d9847f9ba5bbf9fb9beac0a…
# Uso, cópia ou redistribuição sem autorização do autor são proibidos.
import cv2
import math
import mediapipe as mp
import os
import sys
import time
from collections import deque


# ============================================================
# CONFIGURAÇÃO GERAL
# ============================================================

def _pasta_do_programa():
    """Pasta onde o proprio script (ou o .exe, se compilado com
    PyInstaller) esta - NAO a pasta de onde ele foi chamado. Sem isso,
    rodar o programa a partir de outro lugar (por exemplo, o jogo
    Godot abrindo ele sozinho) faz o arquivo do modelo nao ser
    encontrado."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


MODEL_PATH = os.path.join(_pasta_do_programa(), "pose_landmarker.task")

# ------------------------------------------------------------------
# MUDANCA ADITIVA (Maquina de Testes) - NAO altera nenhuma regra de
# deteccao. Por padrao (sem a variavel de ambiente) o comportamento
# e IDENTICO ao original: abre a webcam 0. So quando o Tester define
# TREINO_FONTE_VIDEO (apontando para um arquivo .mp4 gravado) e que a
# fonte muda, para permitir reexecutar o detector sobre gravacoes ja
# feitas sem precisar repetir o movimento na frente da camera.
# Ver tester/README ou README.md, secao "Mudancas no movimentos.py".
# ------------------------------------------------------------------
import os as _os_tester

_FONTE_VIDEO_ENV = _os_tester.environ.get("TREINO_FONTE_VIDEO")
FONTE_VIDEO = int(_FONTE_VIDEO_ENV) if (_FONTE_VIDEO_ENV is not None and _FONTE_VIDEO_ENV.isdigit()) else (_FONTE_VIDEO_ENV if _FONTE_VIDEO_ENV else 0)

# Caminho opcional de log por frame, usado somente pela Maquina de
# Testes (tester/executor.py). Quando None (uso normal, ao vivo), o
# log fica desligado e nada e escrito em disco.
_LOG_TESTER_PATH = _os_tester.environ.get("TREINO_LOG_PATH")

# Tambem aceita o caminho do log como primeiro argumento de linha de
# comando (alem da variavel de ambiente) - assim o jogo Godot consegue
# abrir esse script/exe diretamente, com um caminho absoluto, sem
# precisar passar por um .bat so pra configurar a variavel de
# ambiente antes.
if len(sys.argv) > 1 and sys.argv[1].strip():
    _LOG_TESTER_PATH = sys.argv[1].strip()

# CAMERA DENTRO DO JOGO (FBF): quando o jogo abre este detector, ele manda cada quadro
# (JPEG pequeno, ~15 por segundo) por UDP pra porta --video-porta, e o jogo mostra a
# webcam no canto superior esquerdo da tela. --sem-janela esconde a janela separada do
# OpenCV (a imagem so aparece dentro do jogo). Nada disso muda a deteccao.
_FBF_VIDEO_PORTA = int(os.environ.get("FBF_VIDEO_PORTA") or 0)
_FBF_SEM_JANELA = os.environ.get("FBF_SEM_JANELA") == "1"

for _i_arg, _arg in enumerate(sys.argv[2:], start=2):
    if _arg == "--sem-janela":
        _FBF_SEM_JANELA = True
    elif _arg == "--video-porta" and _i_arg + 1 < len(sys.argv):
        try:
            _FBF_VIDEO_PORTA = int(sys.argv[_i_arg + 1])
        except ValueError:
            pass


# ============================================================
# BALANCA 67 (minigame secreto do FBF) — ADITIVO
# ============================================================
# Detecta o gesto da "balanca" do meme: uma mao ACIMA da outra (como os
# dois pratos de uma balanca). Escreve no mesmo log do observador, em
# linhas separadas "frame,BALANCA:ESQ|DIR|NEUTRO" (ESQ = mao esquerda
# mais alta, DIR = mao direita mais alta), so quando muda e tambem a cada
# BALANCA_HEARTBEAT_FRAMES frames (pra o jogo saber que a camera esta viva).
# NAO interfere na deteccao dos movimentos normais: so le os pontos.
BALANCA_LIMIAR = 0.15          # diferenca de altura dos pulsos / largura dos ombros (histerese)
BALANCA_HEARTBEAT_FRAMES = 20
_balanca_estado = "NEUTRO"
_balanca_cand = "NEUTRO"
_balanca_cont = 0
_balanca_hb = 0


def _atualizar_balanca(frame_id_log, pulso_e, pulso_d, ombro_e, ombro_d):
    global _balanca_estado, _balanca_cand, _balanca_cont, _balanca_hb

    # HISTERESE: o lado so troca quando a outra mao passa do outro lado por
    # mais que BALANCA_LIMIAR. Dentro dessa faixa o estado anterior e
    # mantido (nao existe "neutro" no meio), e a troca vale NA HORA (sem
    # esperar confirmacao de varios frames) — assim da pra fazer a balanca
    # bem rapido sem o contador perder movimentos.
    bruto = _balanca_estado

    try:
        largura = abs(ombro_e.x - ombro_d.x)
        vis_e = getattr(pulso_e, "visibility", 1.0)
        vis_d = getattr(pulso_d, "visibility", 1.0)

        if largura < 0.01 or vis_e < 0.3 or vis_d < 0.3:
            bruto = "NEUTRO"
        else:
            dif = (pulso_d.y - pulso_e.y) / largura   # > 0: pulso esquerdo mais alto

            if dif > BALANCA_LIMIAR:
                bruto = "ESQ"
            elif dif < -BALANCA_LIMIAR:
                bruto = "DIR"
    except Exception:
        bruto = "NEUTRO"

    mudou = bruto != _balanca_estado

    if mudou:
        _balanca_estado = bruto

    _balanca_hb += 1

    if mudou or _balanca_hb >= BALANCA_HEARTBEAT_FRAMES:
        _balanca_hb = 0
        _log_tester_frame(frame_id_log, "BALANCA:" + _balanca_estado)


def _balanca_sem_corpo(frame_id_log):
    global _balanca_estado, _balanca_cand, _balanca_cont, _balanca_hb

    _balanca_cand = "NEUTRO"
    _balanca_cont = 0
    _balanca_hb += 1

    if _balanca_estado != "NEUTRO" or _balanca_hb >= BALANCA_HEARTBEAT_FRAMES:
        _balanca_estado = "NEUTRO"
        _balanca_hb = 0
        _log_tester_frame(frame_id_log, "BALANCA:NEUTRO")


def _log_tester_frame(frame_id_log, movimento_log):
    """Observador aditivo: so escreve algo se TREINO_LOG_PATH estiver
    definido (uso pela Maquina de Testes). Nao le nem altera nenhuma
    variavel de decisao do detector - so registra o resultado ja
    calculado por ele."""
    if not _LOG_TESTER_PATH:
        return
    with open(_LOG_TESTER_PATH, "a", encoding="utf-8") as _log_f:
        _log_f.write(f"{frame_id_log},{movimento_log}\n")


CALIBRATION_TIME = 5.0

FRAME_WIDTH = 640
FRAME_HEIGHT = 480


# ============================================================
# SOCO
# MANTIDO DA VERSÃO FUNCIONAL
# ============================================================

# ------------------------------------------------------------
# SOCO v4 - ZONAS DE TOQUE (alvo fixo, sem medir movimento)
# ------------------------------------------------------------
# Em vez de tentar reconhecer o GESTO do soco (braco esticando rapido),
# desenha dois alvos na tela, um do lado esquerdo e um do lado direito.
# O soco conta quando qualquer uma das maos entra no alvo e FICA la
# por HAND_ZONE_HOLD_TIME segundos. Isso e bem mais confiavel do que
# medir velocidade/angulo do braco, que dependia demais da distancia
# e do angulo da camera.
#
# Tudo e medido em "larguras de ombro" (1.0 = distancia entre os dois
# ombros na imagem, em pixels) pra o tamanho e a posicao dos alvos
# acompanharem a distancia da pessoa ate a camera.

HAND_ZONE_OFFSET = 1.40       # o quao longe do centro do corpo fica cada alvo
HAND_ZONE_Y_OFFSET = -0.05    # ajuste fino de altura (negativo = mais pra cima)
HAND_ZONE_RADIUS_ENTER = 0.55 # raio do alvo (a mao precisa entrar ate aqui)
HAND_ZONE_RADIUS_EXIT = 0.75  # a mao precisa SAIR ate aqui pra rearmar o alvo
HAND_ZONE_HOLD_TIME = 0.10    # segundos parado dentro do alvo pra confirmar o soco (mais rapido)
HAND_ZONE_MAX_HOLD = 1.2      # segundos: solta sozinho se a mao ficar esquecida no alvo

# Cores das luvas/alvos (BGR do OpenCV): ESQUERDA = vermelha, DIREITA = azul
# (igual ao jogo). "_FRACA" e a versao apagada usada na previa da calibracao.
COR_LUVA_ESQ = (40, 40, 225)
COR_LUVA_DIR = (225, 110, 30)
COR_LUVA_ESQ_FRACA = (90, 90, 170)
COR_LUVA_DIR_FRACA = (170, 120, 80)


# ============================================================
# DEFESA ALTA
# MANTIDO DA VERSÃO FUNCIONAL
# ============================================================

DEFENSE_FACE_HEIGHT = 0.10
DEFENSE_FACE_DISTANCE = 0.32


# ============================================================
# ESQUIVAS
# AJUSTADO PELA CALIBRAÇÃO
# ============================================================

DODGE_ANGLE_ENTER = 9.0       # graus de inclinacao do tronco pra contar esquiva
DODGE_ANGLE_RETURN = 5.0      # graus pra contar que voltou pro centro
DODGE_MAX_HOLD = 1.2         # segundos: solta sozinho se ficar preso por tempo demais

DODGE_CONFIRM_FRAMES = 2
DODGE_RETURN_FRAMES = 3


# ============================================================
# AGACHAMENTO
# SISTEMA AJUSTADO PELA CALIBRAÇÃO
# ============================================================

# Quanto os joelhos precisam flexionar
DUCK_KNEE_ENTER = 18.0
DUCK_KNEE_EXIT = 10.0

# Escala relativa do corpo
#
# A escala compara a distância atual entre nariz e
# quadril com a distância registrada na calibração.
#
# Nos testes:
#
# NEUTRO  -> aproximadamente 0.55 ~ 0.63
# ESQUIVA -> aproximadamente 0.44 ~ 0.51
# AGACHAR -> aproximadamente 0.21 ~ 0.32

DUCK_SCALE_ENTER = 0.68
DUCK_SCALE_STRONG = 0.55
DUCK_SCALE_EXIT = 0.74

# Confirmação
DUCK_CONFIRM_FRAMES = 3
DUCK_RETURN_FRAMES = 3

# Suavização
DUCK_SMOOTHING_FRAMES = 5


# ============================================================
# DISTÂNCIA DA CÂMERA
# ============================================================

CAMERA_TOO_FAR_SCALE = 0.72
CAMERA_TOO_CLOSE_SCALE = 1.35

MIN_BODY_SCALE = 0.18


# ============================================================
# VISIBILIDADE
# ============================================================

MIN_VISIBILITY = 0.45


# ============================================================
# FUNÇÕES MATEMÁTICAS
# ============================================================

def distancia_3d(a, b):

    return math.sqrt(
        (a.x - b.x) ** 2 +
        (a.y - b.y) ** 2 +
        (a.z - b.z) ** 2
    )


def distancia_2d(a, b):

    return math.sqrt(
        (a.x - b.x) ** 2 +
        (a.y - b.y) ** 2
    )


def angulo_3d(a, b, c):

    v1 = (
        a.x - b.x,
        a.y - b.y,
        a.z - b.z
    )

    v2 = (
        c.x - b.x,
        c.y - b.y,
        c.z - b.z
    )

    produto = (
        v1[0] * v2[0] +
        v1[1] * v2[1] +
        v1[2] * v2[2]
    )

    tamanho1 = math.sqrt(
        v1[0] ** 2 +
        v1[1] ** 2 +
        v1[2] ** 2
    )

    tamanho2 = math.sqrt(
        v2[0] ** 2 +
        v2[1] ** 2 +
        v2[2] ** 2
    )

    if tamanho1 == 0 or tamanho2 == 0:

        return 180

    valor = produto / (
        tamanho1 * tamanho2
    )

    valor = max(
        -1,
        min(1, valor)
    )

    return math.degrees(
        math.acos(valor)
    )


def media(lista):

    if not lista:

        return 0

    return sum(lista) / len(lista)


def _iso(p, w, h):
    return (p.x * w, p.y * h, p.z * w)


def _dist_iso(a, b):
    return math.sqrt(
        (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2
    )


def _ang_iso(a, b, c):
    v1 = (a[0] - b[0], a[1] - b[1], a[2] - b[2])
    v2 = (c[0] - b[0], c[1] - b[1], c[2] - b[2])
    n1 = math.sqrt(sum(t * t for t in v1))
    n2 = math.sqrt(sum(t * t for t in v2))
    if n1 < 1e-6 or n2 < 1e-6:
        return 180.0
    cos = sum(p * q for p, q in zip(v1, v2)) / (n1 * n2)
    return math.degrees(math.acos(max(-1.0, min(1.0, cos))))


def novo_estado_zona():
    return {
        "ativo": False,
        "armado": True,
        "tempo_dentro": 0.0,
        "inicio_ativo": 0.0,
    }


def medir_zona(dist_min, raio_enter, raio_exit, hold_time, max_hold, dt, agora, estado):
    """Zona de toque: acumula tempo enquanto a mao mais proxima estiver
    dentro do alvo. Ao atingir hold_time, dispara UMA vez (ativo=True)
    e so dispara de novo depois que a mao sair pelo raio de saida
    (maior que o de entrada, pra dar folga na borda).

    Dois raios diferentes servem pra duas coisas diferentes:
    - raio_enter decide se uma segurada PODE COMECAR (precisa realmente
      acertar o meio do alvo).
    - raio_exit decide quando uma segurada JA EM ANDAMENTO se perde.
      Sem essa diferenca, um tremor bem pequeno de mao bem na borda do
      alvo (entrando e saindo do raio menor) zerava o progresso toda
      hora e o soco nunca completava o tempo de segurar.

    dist_min: menor distancia (em larguras de ombro) entre as duas maos
    e o centro do alvo. Ja vem "infinita" (grande) se nenhuma mao
    estiver com boa visibilidade, entao essa funcao nao precisa saber
    nada sobre visibilidade.
    """
    dentro_enter = dist_min < raio_enter
    dentro_exit = dist_min < raio_exit

    if estado["tempo_dentro"] > 0:
        # ja comecou a segurar: so perde o progresso se sair de
        # verdade (alem do raio maior), nao no primeiro tremor.
        continua_segurando = dentro_exit
    else:
        continua_segurando = dentro_enter

    if continua_segurando:
        estado["tempo_dentro"] += dt
    else:
        estado["tempo_dentro"] = 0.0

    if not estado["armado"] and not dentro_exit:
        estado["armado"] = True

    if estado["ativo"]:
        # trava de seguranca: solta sozinho se ficar "ativo" por tempo
        # demais (ex.: mao esquecida dentro do alvo).
        segurando_demais = (agora - estado["inicio_ativo"]) > max_hold
        estado["ativo"] = dentro_exit and not segurando_demais
    elif estado["armado"] and estado["tempo_dentro"] >= hold_time:
        estado["ativo"] = True
        estado["armado"] = False
        estado["inicio_ativo"] = agora

    return estado["ativo"], estado["tempo_dentro"]


# ============================================================
# DADOS DO TREINO
# ============================================================

dados_treino = {

    "NEUTRO": 0,

    "SOCO ESQUERDO": 0,

    "SOCO DIREITO": 0,

    "SOCO DUPLO": 0,

    "DEFESA ALTA": 0,

    "ESQUIVA ESQUERDA": 0,

    "ESQUIVA DIREITA": 0,

    "AGACHAR": 0
}


def registrar_movimento(movimento):

    """
    Ponto central para coleta de dados.

    Futuramente podemos colocar aqui:

    - tempo de reação
    - acertos
    - erros
    - amplitude
    - velocidade
    - quantidade
    - evolução
    - relatório do paciente
    """

    if movimento in dados_treino:

        dados_treino[movimento] += 1


# ============================================================
# MEDIAPIPE
# ============================================================

BaseOptions = mp.tasks.BaseOptions

PoseLandmarker = (
    mp.tasks.vision.PoseLandmarker
)

PoseLandmarkerOptions = (
    mp.tasks.vision.PoseLandmarkerOptions
)

VisionRunningMode = (
    mp.tasks.vision.RunningMode
)


options = PoseLandmarkerOptions(

    base_options=BaseOptions(
        model_asset_path=MODEL_PATH
    ),

    running_mode=VisionRunningMode.VIDEO,

    num_poses=1
)


landmarker = (
    PoseLandmarker.create_from_options(
        options
    )
)


# ============================================================
# CÂMERA
# ============================================================

camera = cv2.VideoCapture(FONTE_VIDEO)


if not camera.isOpened():

    print(
        "ERRO: Não foi possível abrir a câmera."
    )

    exit()


camera.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    FRAME_WIDTH
)

camera.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    FRAME_HEIGHT
)

camera.set(
    cv2.CAP_PROP_BUFFERSIZE,
    1
)


# ============================================================
# CALIBRAÇÃO
# ============================================================

frame_id = 0

calibrado = False

inicio_calibracao = time.time()

calibracao_x = []
calibracao_angulo_tronco = []

calibracao_altura = []

calibracao_escala = []

calibracao_quadril_y = []

calibracao_ombros_y = []

calibracao_joelho_esq = []

calibracao_joelho_dir = []


referencia_x = 0
referencia_angulo_tronco = 0.0

referencia_altura = 0

referencia_escala = 0

referencia_quadril_y = 0

referencia_ombros_y = 0

referencia_joelho_esq = 180

referencia_joelho_dir = 180


# ============================================================
# HISTÓRICOS
# ============================================================

historico_x = deque(
    maxlen=5
)

historico_angulo_tronco = deque(
    maxlen=5
)

historico_altura = deque(
    maxlen=DUCK_SMOOTHING_FRAMES
)

historico_escala = deque(
    maxlen=5
)

historico_quadril_agachar = deque(
    maxlen=DUCK_SMOOTHING_FRAMES
)

historico_flexao_joelho = deque(
    maxlen=DUCK_SMOOTHING_FRAMES
)


# ============================================================
# ESTADO DA ESQUIVA
# ============================================================

esquiva_ativa = None

inicio_esquiva = 0.0

contador_esquerda = 0

contador_direita = 0

contador_retorno_esquiva = 0


# ============================================================
# ESTADO DAS ZONAS DE SOCO (v4)
# ============================================================
historico_escala_ombros = deque(maxlen=30)
estado_zona_esq = novo_estado_zona()
estado_zona_dir = novo_estado_zona()
_ultimo_tempo_zona = None
_soco_esq_estava_ativo = False
_soco_dir_estava_ativo = False
_flash_ate_esq = 0.0
_flash_ate_dir = 0.0


# ============================================================
# ESTADO DO AGACHAMENTO
# ============================================================

agachamento_ativo = False

contador_agachar = 0

contador_retorno_agachar = 0


# ============================================================
# ÚLTIMO MOVIMENTO
# ============================================================

ultimo_movimento = "NEUTRO"


def _desenhar_luva(frame, cx, cy, r, cor, espelhado):
    """Desenha uma luva de boxe estilizada centrada em (cx, cy), com
    "raio" aproximado r, so com formas geometricas (sem arquivo de
    imagem). espelhado troca o lado do polegar, pra as duas luvas dos
    dois alvos ficarem de frente uma pra outra."""

    contorno = (25, 25, 25)
    sinal = 1 if espelhado else -1

    # punho (parte de baixo, mais estreita)
    cv2.ellipse(
        frame, (cx, cy + int(r * 0.80)),
        (int(r * 0.55), int(r * 0.40)), 0, 0, 360, cor, -1
    )
    cv2.ellipse(
        frame, (cx, cy + int(r * 0.80)),
        (int(r * 0.55), int(r * 0.40)), 0, 0, 360, contorno, 2
    )

    # corpo principal (mao fechada)
    cv2.ellipse(
        frame, (cx, cy), (int(r * 0.85), int(r * 0.78)), 0, 0, 360, cor, -1
    )

    # polegar
    px = cx + sinal * int(r * 0.72)
    py = cy - int(r * 0.05)
    cv2.circle(frame, (px, py), int(r * 0.32), cor, -1)
    cv2.circle(frame, (px, py), int(r * 0.32), contorno, 2)

    cv2.ellipse(
        frame, (cx, cy), (int(r * 0.85), int(r * 0.78)), 0, 0, 360, contorno, 2
    )

    # linhas dos nos dos dedos
    for _dx in (-0.32, 0.0, 0.32):
        _lx = cx + int(_dx * r)
        cv2.line(
            frame, (_lx, cy - int(r * 0.55)), (_lx, cy - int(r * 0.15)),
            contorno, 2
        )

    # brilho, pra dar volume
    hx = cx - sinal * int(r * 0.30)
    hy = cy - int(r * 0.40)
    cv2.ellipse(
        frame, (hx, hy), (int(r * 0.22), int(r * 0.13)),
        20 * sinal, 0, 360, (255, 255, 255), -1
    )


_janela_camera_pronta = False

# Quando o JOGO abre este detector sozinho (via tools/lancador.py), ele define
# FBF_JANELA_NA_FRENTE=1. Janelas criadas por um processo em segundo plano costumam
# abrir ATRAS da janela ativa (o Windows impede "roubar o foco") — por isso a webcam
# parecia nao abrir. Nesse modo a janela vai pro canto inferior DIREITO da area de
# trabalho e fica SEMPRE NA FRENTE (e e reforcada nos primeiros frames).
_FBF_NA_FRENTE = os.environ.get("FBF_JANELA_NA_FRENTE") == "1"
_JANELA_TITULO = "Treino de Reflexo - Camera"
_janela_frames = 0


def _fixar_janela_na_frente():
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        user32.FindWindowW.restype = ctypes.c_void_p
        user32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
        user32.SetWindowPos.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint,
        ]

        hwnd = user32.FindWindowW(None, _JANELA_TITULO)
        if not hwnd:
            return

        area = wintypes.RECT()
        user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(area), 0)  # area de trabalho (sem a barra de tarefas)

        largura, altura = 440, 360
        x = area.right - largura - 12
        y = area.bottom - altura - 12

        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.SetWindowPos(hwnd, ctypes.c_void_p(-1), x, y, largura, altura, 0x0040)  # HWND_TOPMOST + SWP_SHOWWINDOW
    except Exception:
        pass


_video_sock = None
_video_ultimo = 0.0


def _enviar_frame_ao_jogo(frame):
    """Manda o quadro (reduzido, JPEG) pro jogo mostrar no canto da tela."""
    global _video_sock, _video_ultimo
    if not _FBF_VIDEO_PORTA:
        return
    agora = time.time()
    if agora - _video_ultimo < 1.0 / 15.0:
        return
    _video_ultimo = agora
    try:
        if _video_sock is None:
            import socket
            _video_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        alt, larg = frame.shape[:2]
        nova_larg = 320
        nova_alt = max(1, int(alt * nova_larg / larg))
        pequeno = cv2.resize(frame, (nova_larg, nova_alt), interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode(".jpg", pequeno, [cv2.IMWRITE_JPEG_QUALITY, 62])
        if ok and len(buf) < 60000:
            _video_sock.sendto(buf.tobytes(), ("127.0.0.1", _FBF_VIDEO_PORTA))
    except Exception:
        pass


def _mostrar_frame(frame):
    """Manda o quadro pro jogo (se configurado) e mostra a janela do OpenCV
    (a nao ser que --sem-janela)."""
    _enviar_frame_ao_jogo(frame)
    if _FBF_SEM_JANELA:
        return
    _preparar_janela_camera()
    cv2.imshow(_JANELA_TITULO, frame)


def _preparar_janela_camera():
    """Deixa a janela da webcam pequena e no canto inferior esquerdo da
    tela, pra dar pra rodar junto com o jogo (o jogo abre com 1280x720,
    entao sobra espaco embaixo/do lado)."""
    global _janela_camera_pronta, _janela_frames
    _janela_frames += 1
    if _FBF_NA_FRENTE and _janela_frames in (3, 30, 90, 180):
        _fixar_janela_na_frente()
    if _janela_camera_pronta:
        return
    try:
        cv2.namedWindow("Treino de Reflexo - Camera", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Treino de Reflexo - Camera", 420, 315)
        if not _FBF_NA_FRENTE:
            cv2.moveWindow("Treino de Reflexo - Camera", 10, 700)
    except Exception:
        pass
    _janela_camera_pronta = True


# ============================================================
# LOOP
# ============================================================

while True:

    sucesso, frame = camera.read()


    if not sucesso:

        print(
            "ERRO: Não foi possível ler a câmera."
        )

        break


    # ========================================================
    # ESPELHAR CÂMERA
    # ========================================================

    frame = cv2.flip(
        frame,
        1
    )


    altura_tela, largura_tela, _ = (
        frame.shape
    )


    # ========================================================
    # MEDIAPIPE
    # ========================================================

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )


    mp_image = mp.Image(
        image_format=mp.ImageFormat.SRGB,
        data=rgb
    )


    frame_id += 1


    resultado = (
        landmarker.detect_for_video(
            mp_image,
            frame_id
        )
    )


    movimento = "NEUTRO"


    # ========================================================
    # CORPO DETECTADO
    # ========================================================

    if resultado.pose_landmarks:

        pontos = resultado.pose_landmarks[0]


        # ====================================================
        # PONTOS DO CORPO
        # ====================================================

        nariz = pontos[0]


        ombro_esq = pontos[11]
        cotovelo_esq = pontos[13]
        pulso_esq = pontos[15]


        ombro_dir = pontos[12]
        cotovelo_dir = pontos[14]
        pulso_dir = pontos[16]


        quadril_esq = pontos[23]
        quadril_dir = pontos[24]


        joelho_esq = pontos[25]
        joelho_dir = pontos[26]


        tornozelo_esq = pontos[27]
        tornozelo_dir = pontos[28]


        # ====================================================
        # QUALIDADE
        # ====================================================

        pontos_importantes = [

            nariz,

            ombro_esq,
            ombro_dir,

            pulso_esq,
            pulso_dir,

            quadril_esq,
            quadril_dir,

            joelho_esq,
            joelho_dir,

            tornozelo_esq,
            tornozelo_dir
        ]


        pontos_visiveis = 0


        for ponto in pontos_importantes:

            visibilidade = getattr(
                ponto,
                "visibility",
                1.0
            )

            if visibilidade >= MIN_VISIBILITY:

                pontos_visiveis += 1


        deteccao_boa = (
            pontos_visiveis >= 7
        )


        # ====================================================
        # CENTRO DOS OMBROS
        # ====================================================

        centro_ombros_x = (
            ombro_esq.x +
            ombro_dir.x
        ) / 2


        centro_ombros_y = (
            ombro_esq.y +
            ombro_dir.y
        ) / 2


        # ====================================================
        # CENTRO DO QUADRIL
        # ====================================================

        centro_quadril_x = (
            quadril_esq.x +
            quadril_dir.x
        ) / 2


        centro_quadril_y = (
            quadril_esq.y +
            quadril_dir.y
        ) / 2


        # ====================================================
        # CENTRO DO CORPO
        # ====================================================

        centro_corpo_x = (
            centro_ombros_x +
            centro_quadril_x
        ) / 2


        # ====================================================
        # EIXO DO CORPO (NARIZ -> QUADRIL, tipo nariz-umbigo)
        # ====================================================
        # Usado pra esquiva: em vez de medir se o corpo INTEIRO se
        # deslocou pro lado, mede se essa linha imaginaria INCLINOU
        # pra esquerda ou pra direita (o corpo pode inclinar sem
        # necessariamente se deslocar muito de lugar).

        _dx_eixo_corpo = (
            nariz.x -
            centro_quadril_x
        )

        _dy_eixo_corpo = (
            centro_quadril_y -
            nariz.y
        )

        angulo_tronco = math.degrees(
            math.atan2(_dx_eixo_corpo, max(_dy_eixo_corpo, 0.01))
        )


        # ====================================================
        # ALTURA
        # ====================================================

        altura_corpo = (
            centro_quadril_y -
            nariz.y
        )


        # ====================================================
        # ESCALA
        # ====================================================

        escala_corpo = abs(
            centro_quadril_y -
            nariz.y
        )


        historico_escala.append(
            escala_corpo
        )


        escala_suave = media(
            list(historico_escala)
        )


        # ====================================================
        # DISTÂNCIA DA CÂMERA
        # ====================================================

        if escala_suave < MIN_BODY_SCALE:

            status_camera = (
                "CORPO NAO DETECTADO"
            )

            cor_camera = (
                0,
                0,
                255
            )

        elif (
            calibrado and
            escala_suave <
            referencia_escala *
            CAMERA_TOO_FAR_SCALE
        ):

            status_camera = (
                "MUITO LONGE DA CAMERA"
            )

            cor_camera = (
                0,
                165,
                255
            )

        elif (
            calibrado and
            escala_suave >
            referencia_escala *
            CAMERA_TOO_CLOSE_SCALE
        ):

            status_camera = (
                "MUITO PERTO DA CAMERA"
            )

            cor_camera = (
                0,
                165,
                255
            )

        else:

            status_camera = (
                "DISTANCIA OK"
            )

            cor_camera = (
                0,
                255,
                0
            )


        # ====================================================
        # CALIBRAÇÃO
        # ====================================================

        if not calibrado:

            tempo_passado = (
                time.time() -
                inicio_calibracao
            )


            calibracao_x.append(
                centro_corpo_x
            )


            calibracao_angulo_tronco.append(
                angulo_tronco
            )


            calibracao_altura.append(
                altura_corpo
            )


            calibracao_escala.append(
                escala_corpo
            )


            calibracao_quadril_y.append(
                centro_quadril_y
            )


            calibracao_ombros_y.append(
                centro_ombros_y
            )


            # -----------------------------------------------
            # ÂNGULOS DOS JOELHOS
            # -----------------------------------------------

            angulo_calibracao_esq = (
                angulo_3d(
                    quadril_esq,
                    joelho_esq,
                    tornozelo_esq
                )
            )


            angulo_calibracao_dir = (
                angulo_3d(
                    quadril_dir,
                    joelho_dir,
                    tornozelo_dir
                )
            )


            calibracao_joelho_esq.append(
                angulo_calibracao_esq
            )


            calibracao_joelho_dir.append(
                angulo_calibracao_dir
            )


            tempo_restante = max(
                0,
                CALIBRATION_TIME -
                tempo_passado
            )


            # -----------------------------------------------
            # TELA DE CALIBRAÇÃO
            # -----------------------------------------------

            cv2.rectangle(
                frame,
                (10, 10),
                (630, 125),
                (20, 20, 20),
                -1
            )


            cv2.putText(
                frame,
                "CALIBRANDO...",
                (25, 45),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 255, 255),
                3,
                cv2.LINE_AA
            )


            cv2.putText(
                frame,
                "FIQUE NA POSICAO DE LUTA",
                (25, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.62,
                (255, 255, 255),
                2,
                cv2.LINE_AA
            )


            cv2.putText(
                frame,
                f"{tempo_restante:.1f}s",
                (540, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2,
                cv2.LINE_AA
            )


            cv2.putText(
                frame,
                "Nao se mova durante a calibracao",
                (25, 108),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                (180, 180, 180),
                1,
                cv2.LINE_AA
            )


            # -----------------------------------------------
            # FINAL DA CALIBRAÇÃO
            # -----------------------------------------------

            if (
                tempo_passado >=
                CALIBRATION_TIME
            ):

                if len(calibracao_x) > 20:

                    referencia_x = (
                        media(calibracao_x)
                    )


                    referencia_angulo_tronco = (
                        media(calibracao_angulo_tronco)
                    )


                    referencia_altura = (
                        media(calibracao_altura)
                    )


                    referencia_escala = (
                        media(calibracao_escala)
                    )


                    referencia_quadril_y = (
                        media(calibracao_quadril_y)
                    )


                    referencia_ombros_y = (
                        media(calibracao_ombros_y)
                    )


                    referencia_joelho_esq = (
                        media(calibracao_joelho_esq)
                    )


                    referencia_joelho_dir = (
                        media(calibracao_joelho_dir)
                    )


                    calibrado = True


                    historico_x.clear()
                    historico_angulo_tronco.clear()

                    historico_altura.clear()

                    historico_escala.clear()

                    historico_quadril_agachar.clear()

                    historico_flexao_joelho.clear()


                    print("")

                    print(
                        "======================================"
                    )

                    print(
                        "       CALIBRACAO CONCLUIDA"
                    )

                    print(
                        "======================================"
                    )

                    print(
                        f"Referencia X: "
                        f"{referencia_x:.3f}"
                    )

                    print(
                        f"Referencia angulo do tronco: "
                        f"{referencia_angulo_tronco:+.1f} graus"
                    )

                    print(
                        f"Referencia quadril: "
                        f"{referencia_quadril_y:.3f}"
                    )

                    print(
                        f"Referencia escala: "
                        f"{referencia_escala:.3f}"
                    )

                    print(
                        f"Joelho esquerdo: "
                        f"{referencia_joelho_esq:.1f}"
                    )

                    print(
                        f"Joelho direito: "
                        f"{referencia_joelho_dir:.1f}"
                    )

                    print(
                        "Sistema pronto."
                    )

                    print(
                        "======================================"
                    )

                    print("")


            # =================================================
            # DESENHAR CORPO DURANTE CALIBRAÇÃO
            # =================================================

            pontos_desenho = [

                (ombro_esq, (0, 0, 255)),
                (cotovelo_esq, (0, 255, 255)),
                (pulso_esq, (0, 255, 0)),

                (ombro_dir, (0, 0, 255)),
                (cotovelo_dir, (0, 255, 255)),
                (pulso_dir, (0, 255, 0)),

                (nariz, (255, 0, 255)),

                (quadril_esq, (255, 255, 0)),
                (quadril_dir, (255, 255, 0)),

                (joelho_esq, (255, 128, 0)),
                (joelho_dir, (255, 128, 0)),

                (tornozelo_esq, (0, 128, 255)),
                (tornozelo_dir, (0, 128, 255))
            ]


            for ponto, cor in pontos_desenho:

                x = int(
                    ponto.x *
                    largura_tela
                )

                y = int(
                    ponto.y *
                    altura_tela
                )

                cv2.circle(
                    frame,
                    (x, y),
                    7,
                    cor,
                    -1
                )


            # -------------------------------------------------
            # PREVIA DAS LUVAS (so estetica - mostra ja durante a
            # calibracao onde os alvos de soco vao aparecer, pra
            # a pessoa se acostumar com a posicao deles).
            # -------------------------------------------------
            _escala_preview = math.hypot(
                (ombro_esq.x - ombro_dir.x) * largura_tela,
                (ombro_esq.y - ombro_dir.y) * altura_tela
            )
            if _escala_preview >= 8:
                _cx_preview = centro_ombros_x * largura_tela
                _cy_preview = (
                    centro_ombros_y * altura_tela +
                    HAND_ZONE_Y_OFFSET * _escala_preview
                )
                _off_preview = HAND_ZONE_OFFSET * _escala_preview
                _raio_preview = int(HAND_ZONE_RADIUS_ENTER * _escala_preview * 0.80)

                for _dx_preview, _esp_preview, _cor_preview in (
                    (-_off_preview, False, COR_LUVA_ESQ_FRACA),
                    (_off_preview, True, COR_LUVA_DIR_FRACA)
                ):
                    _desenhar_luva(
                        frame,
                        int(_cx_preview + _dx_preview),
                        int(_cy_preview),
                        _raio_preview,
                        _cor_preview,
                        _esp_preview
                    )


            _mostrar_frame(frame)


            tecla = (
                cv2.waitKey(1) &
                0xFF
            )


            if tecla == ord("q"):

                break


            continue


        # ====================================================
        # SISTEMA CALIBRADO
        # ====================================================

        historico_x.append(
            centro_corpo_x
        )


        historico_altura.append(
            altura_corpo
        )


        centro_x_suave = media(
            list(historico_x)
        )


        altura_suave = media(
            list(historico_altura)
        )


        historico_angulo_tronco.append(
            angulo_tronco
        )

        angulo_tronco_suave = media(
            list(historico_angulo_tronco)
        )


        # ====================================================
        # ESQUIVA (pela INCLINACAO do tronco, nao mais por
        # deslocamento de lugar) - a linha imaginaria do nariz ate o
        # quadril (tipo nariz-umbigo): reta pra cima = neutro,
        # inclinada pra esquerda = esquiva esquerda, inclinada pra
        # direita = esquiva direita.
        # ====================================================

        desvio_angulo_tronco = (
            angulo_tronco_suave -
            referencia_angulo_tronco
        )


        esquerda_detectada = (
            desvio_angulo_tronco <
            -DODGE_ANGLE_ENTER
        )


        direita_detectada = (
            desvio_angulo_tronco >
            DODGE_ANGLE_ENTER
        )


        # ====================================================
        # CONTADORES DE ESQUIVA
        # ====================================================

        # teto no contador: nao adianta em nada deixar crescer mais
        # que isso, e evita que segurar a esquiva por muito tempo
        # atrase o retorno ao neutro depois.
        _teto_contador_esquiva = DODGE_CONFIRM_FRAMES + 2

        if esquerda_detectada:

            contador_esquerda = min(
                _teto_contador_esquiva,
                contador_esquerda + 1
            )

        else:

            contador_esquerda = max(
                0,
                contador_esquerda - 1
            )


        if direita_detectada:

            contador_direita = min(
                _teto_contador_esquiva,
                contador_direita + 1
            )

        else:

            contador_direita = max(
                0,
                contador_direita - 1
            )


        # ====================================================
        # ATIVAR ESQUIVA
        # ====================================================

        if (
            contador_esquerda >=
            DODGE_CONFIRM_FRAMES
        ):

            if esquiva_ativa != "ESQUIVA ESQUERDA":
                # so zera o contador de retorno numa troca de
                # estado de verdade, nao em toda confirmacao
                # repetida (isso e o que travava o retorno).
                inicio_esquiva = time.time()
                contador_retorno_esquiva = 0

            esquiva_ativa = (
                "ESQUIVA ESQUERDA"
            )


        elif (
            contador_direita >=
            DODGE_CONFIRM_FRAMES
        ):

            if esquiva_ativa != "ESQUIVA DIREITA":
                inicio_esquiva = time.time()
                contador_retorno_esquiva = 0

            esquiva_ativa = (
                "ESQUIVA DIREITA"
            )


        # ====================================================
        # RETORNO DA ESQUIVA
        # ====================================================

        if esquiva_ativa is not None:

            voltou_centro = (
                abs(
                    desvio_angulo_tronco
                )
                <
                DODGE_ANGLE_RETURN
            )


            if voltou_centro:

                contador_retorno_esquiva += 1

            else:

                # perde 1 em vez de zerar: um unico frame ruim (jitter
                # da camera) nao pode jogar fora o progresso todo de
                # voltar pro centro.
                contador_retorno_esquiva = max(
                    0,
                    contador_retorno_esquiva - 1
                )


            # TRAVA DE SEGURANCA: se a esquiva ficar presa por tempo
            # demais (a pessoa pode ter se deslocado de verdade, ou o
            # rastreamento pode ter ficado ruim), solta sozinha.
            tempo_preso = time.time() - inicio_esquiva
            esquiva_travada = tempo_preso > DODGE_MAX_HOLD

            if (
                contador_retorno_esquiva >=
                DODGE_RETURN_FRAMES
            ) or esquiva_travada:

                esquiva_ativa = None

                contador_retorno_esquiva = 0

                contador_esquerda = 0

                contador_direita = 0


        # ====================================================
        # AGACHAMENTO
        # SISTEMA AJUSTADO
        # ====================================================

        # -----------------------------------------------
        # DESCIDA DO QUADRIL
        # -----------------------------------------------

        queda_quadril = (
            centro_quadril_y -
            referencia_quadril_y
        )


        # -----------------------------------------------
        # MOVIMENTO DOS OMBROS
        # -----------------------------------------------

        queda_ombros = (
            centro_ombros_y -
            referencia_ombros_y
        )


        # -----------------------------------------------
        # MOVIMENTO RELATIVO
        # -----------------------------------------------

        queda_relativa = (
            queda_quadril -
            (
                queda_ombros *
                0.50
            )
        )


        # -----------------------------------------------
        # NORMALIZAÇÃO
        # -----------------------------------------------

        queda_relativa_normalizada = (
            queda_relativa /
            max(
                referencia_escala,
                0.001
            )
        )


        # =================================================
        # FLEXÃO DOS JOELHOS
        # =================================================

        angulo_joelho_esq = (
            angulo_3d(
                quadril_esq,
                joelho_esq,
                tornozelo_esq
            )
        )


        angulo_joelho_dir = (
            angulo_3d(
                quadril_dir,
                joelho_dir,
                tornozelo_dir
            )
        )


        flexao_esq = (
            referencia_joelho_esq -
            angulo_joelho_esq
        )


        flexao_dir = (
            referencia_joelho_dir -
            angulo_joelho_dir
        )


        flexao_joelho = (
            flexao_esq +
            flexao_dir
        ) / 2


        # Evita números negativos

        flexao_joelho = max(
            0,
            flexao_joelho
        )


        # =================================================
        # SUAVIZAÇÃO DO AGACHAMENTO
        # =================================================

        historico_quadril_agachar.append(
            queda_relativa_normalizada
        )


        historico_flexao_joelho.append(
            flexao_joelho
        )


        queda_agachar_suave = media(
            list(
                historico_quadril_agachar
            )
        )


        flexao_joelho_suave = media(
            list(
                historico_flexao_joelho
            )
        )


        # =================================================
        # ESCALA RELATIVA
        # =================================================

        escala_relativa = (
            escala_suave /
            max(
                referencia_escala,
                0.001
            )
        )


        # =================================================
        # INDICADORES DO AGACHAMENTO
        # =================================================

        agachar_por_escala = (
            escala_relativa < DUCK_SCALE_ENTER
        )

        agachar_por_joelho = (
            flexao_joelho_suave > DUCK_KNEE_ENTER
        )

        agachar_muito_forte = (
            escala_relativa < DUCK_SCALE_STRONG
        )

        # A escala corporal é o principal indicador.
        # Uma redução forte confirma; em reduções menores,
        # exigimos também flexão dos joelhos.
        agachar_detectado = (
            agachar_muito_forte
            or
            (agachar_por_escala and agachar_por_joelho)
        )


        # =================================================
        # SAÍDA DO AGACHAMENTO
        # =================================================

        agachar_escala_voltou = (
            escala_relativa >
            DUCK_SCALE_EXIT
        )


        agachar_joelho_voltou = (
            flexao_joelho_suave < DUCK_KNEE_EXIT
        )

        agachar_finalizado = (
            agachar_escala_voltou
            and
            agachar_joelho_voltou
        )


        # =================================================
        # ENTRANDO NO AGACHAMENTO
        # =================================================

        if not agachamento_ativo:

            if agachar_detectado:

                contador_agachar += 1

            else:

                contador_agachar = max(
                    0,
                    contador_agachar - 1
                )


            if (
                contador_agachar >=
                DUCK_CONFIRM_FRAMES
            ):

                agachamento_ativo = True

                contador_agachar = 0

                contador_retorno_agachar = 0


        # =================================================
        # SAINDO DO AGACHAMENTO
        # =================================================

        else:

            if agachar_finalizado:

                contador_retorno_agachar += 1

            else:

                contador_retorno_agachar = 0


            if (
                contador_retorno_agachar >=
                DUCK_RETURN_FRAMES
            ):

                agachamento_ativo = False

                contador_retorno_agachar = 0

                contador_agachar = 0

                historico_quadril_agachar.clear()
                historico_flexao_joelho.clear()


        # ====================================================
        # DEFESA ALTA
        # MANTIDA
        # ====================================================

        distancia_mao_esq_rosto = math.sqrt(

            (pulso_esq.x - nariz.x) ** 2 +

            (pulso_esq.y - nariz.y) ** 2
        )


        distancia_mao_dir_rosto = math.sqrt(

            (pulso_dir.x - nariz.x) ** 2 +

            (pulso_dir.y - nariz.y) ** 2
        )


        mao_esq_rosto = (
            abs(
                pulso_esq.y -
                nariz.y
            )
            <
            DEFENSE_FACE_HEIGHT
        )


        mao_dir_rosto = (
            abs(
                pulso_dir.y -
                nariz.y
            )
            <
            DEFENSE_FACE_HEIGHT
        )


        mao_esq_perto = (
            distancia_mao_esq_rosto
            <
            DEFENSE_FACE_DISTANCE
        )


        mao_dir_perto = (
            distancia_mao_dir_rosto
            <
            DEFENSE_FACE_DISTANCE
        )


        angulo_defesa_esq = (
            angulo_3d(
                ombro_esq,
                cotovelo_esq,
                pulso_esq
            )
        )


        angulo_defesa_dir = (
            angulo_3d(
                ombro_dir,
                cotovelo_dir,
                pulso_dir
            )
        )


        braco_esq_dobrado = (
            angulo_defesa_esq < 150
        )


        braco_dir_dobrado = (
            angulo_defesa_dir < 150
        )


        defesa_alta = (

            mao_esq_rosto

            and

            mao_dir_rosto

            and

            mao_esq_perto

            and

            mao_dir_perto

            and

            braco_esq_dobrado

            and

            braco_dir_dobrado
        )


        # ====================================================
        # ZONAS DE SOCO (v4) - alvos fixos na tela. A escala usa a
        # largura dos ombros, nao o quadril, porque os ombros aparecem
        # no quadro mesmo com a pessoa perto da camera.
        # ====================================================
        _escala_agora = math.hypot(
            (ombro_esq.x - ombro_dir.x) * largura_tela,
            (ombro_esq.y - ombro_dir.y) * altura_tela
        )
        historico_escala_ombros.append(_escala_agora)
        _ord = sorted(historico_escala_ombros)
        escala_ombros = _ord[int(0.75 * (len(_ord) - 1))]

        _agora_zona = time.time()
        if _ultimo_tempo_zona is None:
            _dt_zona = 1.0 / 30.0
        else:
            _dt_zona = _agora_zona - _ultimo_tempo_zona
        _dt_zona = max(0.0, min(_dt_zona, 0.1))  # protege contra travadas longas
        _ultimo_tempo_zona = _agora_zona

        _centro_corpo_x_px = centro_ombros_x * largura_tela
        _zona_y_px = (
            centro_ombros_y * altura_tela +
            HAND_ZONE_Y_OFFSET * escala_ombros
        )
        _offset_px = HAND_ZONE_OFFSET * escala_ombros
        _raio_enter_px = HAND_ZONE_RADIUS_ENTER * escala_ombros
        _raio_exit_px = HAND_ZONE_RADIUS_EXIT * escala_ombros

        zona_esq_px = (_centro_corpo_x_px - _offset_px, _zona_y_px)
        zona_dir_px = (_centro_corpo_x_px + _offset_px, _zona_y_px)

        dist_zona_esq = float("inf")
        dist_zona_dir = float("inf")
        if escala_ombros >= 8:
            # so mede se os ombros estao com um tamanho minimamente
            # confiavel na imagem; com escala_ombros minusculo (ombros
            # mal detectados) os alvos ficariam colados um no outro.
            for _p in (pulso_esq, pulso_dir):
                if getattr(_p, "visibility", 1.0) < MIN_VISIBILITY:
                    continue
                _px = (_p.x * largura_tela, _p.y * altura_tela)
                _d_esq = math.hypot(
                    _px[0] - zona_esq_px[0], _px[1] - zona_esq_px[1]
                ) / escala_ombros
                _d_dir = math.hypot(
                    _px[0] - zona_dir_px[0], _px[1] - zona_dir_px[1]
                ) / escala_ombros
                dist_zona_esq = min(dist_zona_esq, _d_esq)
                dist_zona_dir = min(dist_zona_dir, _d_dir)

        soco_esquerdo, progresso_esq = medir_zona(
            dist_zona_esq, HAND_ZONE_RADIUS_ENTER, HAND_ZONE_RADIUS_EXIT,
            HAND_ZONE_HOLD_TIME, HAND_ZONE_MAX_HOLD, _dt_zona, _agora_zona,
            estado_zona_esq
        )
        soco_direito, progresso_dir = medir_zona(
            dist_zona_dir, HAND_ZONE_RADIUS_ENTER, HAND_ZONE_RADIUS_EXIT,
            HAND_ZONE_HOLD_TIME, HAND_ZONE_MAX_HOLD, _dt_zona, _agora_zona,
            estado_zona_dir
        )

        # ----------------------------------------------------
        # FLASH DE CONFIRMACAO (texto grande por um instante quando
        # o soco e reconhecido, pra ficar bem claro pra quem esta
        # treinando na frente da tela).
        # ----------------------------------------------------
        if soco_esquerdo and not _soco_esq_estava_ativo:
            _flash_ate_esq = _agora_zona + 0.35
        if soco_direito and not _soco_dir_estava_ativo:
            _flash_ate_dir = _agora_zona + 0.35
        _soco_esq_estava_ativo = soco_esquerdo
        _soco_dir_estava_ativo = soco_direito

        if _agora_zona < _flash_ate_esq:
            cv2.putText(
                frame, "SOCO ESQUERDO!",
                (int(largura_tela * 0.5) - 260, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 255, 0), 3, cv2.LINE_AA
            )
        if _agora_zona < _flash_ate_dir:
            cv2.putText(
                frame, "SOCO DIREITO!",
                (int(largura_tela * 0.5) + 20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 255, 0), 3, cv2.LINE_AA
            )

        # ----------------------------------------------------
        # DESENHAR OS ALVOS NA TELA (so se os ombros estiverem com um
        # tamanho minimamente confiavel na imagem - do contrario os
        # alvos ficariam desenhados em cima um do outro, minusculos).
        # ----------------------------------------------------
        if escala_ombros >= 8:
            for _centro_zona, _progresso, _ativo, _rotulo, _espelhado, _cor_lado in (
                (zona_esq_px, progresso_esq, soco_esquerdo, "ESQUERDO", False, COR_LUVA_ESQ),
                (zona_dir_px, progresso_dir, soco_direito, "DIREITO", True, COR_LUVA_DIR),
            ):
                _cx, _cy = int(_centro_zona[0]), int(_centro_zona[1])
                # anel na cor do lado (vermelho/azul); fica VERDE so
                # quando o soco e reconhecido.
                _cor_anel = (0, 255, 0) if _ativo else _cor_lado
                _cor_luva = (60, 220, 60) if _ativo else _cor_lado

                # trilha (aro fino, sempre visivel) + arco de progresso
                # em volta da luva - a luva fica por cima, no meio.
                cv2.circle(
                    frame, (_cx, _cy), int(_raio_enter_px * 1.18),
                    (90, 90, 90), 2
                )

                _fracao = min(1.0, _progresso / HAND_ZONE_HOLD_TIME)
                if _fracao > 0:
                    cv2.ellipse(
                        frame, (_cx, _cy),
                        (int(_raio_enter_px * 1.18), int(_raio_enter_px * 1.18)),
                        -90, 0, 360 * _fracao,
                        _cor_anel, 4
                    )

                _desenhar_luva(
                    frame, _cx, _cy, int(_raio_enter_px * 0.80),
                    _cor_luva, _espelhado
                )

                cv2.putText(
                    frame, _rotulo,
                    (_cx - 38, _cy + int(_raio_enter_px * 1.18) + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, _cor_anel, 2, cv2.LINE_AA
                )


        # ====================================================
        # PAINEL DE DIAGNOSTICO (aditivo, so mostra numeros na
        # tela - nao muda nenhuma decisao).
        # ====================================================

        _diag = [
            f"ZONA ESQ  dist={dist_zona_esq:.2f}/{HAND_ZONE_RADIUS_ENTER:.2f}"
            f" segurando={progresso_esq:.2f}/{HAND_ZONE_HOLD_TIME:.2f}s"
            f" {'SOCO!' if soco_esquerdo else '-'}"
            + ("" if escala_ombros >= 8 else "  (ombros nao detectados)"),

            f"ZONA DIR  dist={dist_zona_dir:.2f}/{HAND_ZONE_RADIUS_ENTER:.2f}"
            f" segurando={progresso_dir:.2f}/{HAND_ZONE_HOLD_TIME:.2f}s"
            f" {'SOCO!' if soco_direito else '-'}",

            f"ESQUIVA  angulo={desvio_angulo_tronco:+.1f} graus"
            f" (entra +-{DODGE_ANGLE_ENTER:.1f} / volta +-{DODGE_ANGLE_RETURN:.1f})"
            f" ativa={esquiva_ativa or '-'}",

            f"DEFESA ALTA={'OK' if defesa_alta else 'nao'}"
            f"  AGACHAR={'OK' if agachamento_ativo else 'nao'}"
            f" (escala={escala_relativa:.2f} joelho={flexao_joelho_suave:.0f})",
        ]

        for _i_diag, _linha_diag in enumerate(_diag):
            cv2.putText(
                frame,
                _linha_diag,
                (10, FRAME_HEIGHT - 90 + _i_diag * 20),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.42,
                (0, 255, 255),
                1,
                cv2.LINE_AA,
            )


        # ====================================================
        # PRIORIDADE
        # ====================================================

        if defesa_alta:

            movimento = "DEFESA ALTA"


        # SOCO vem ANTES da esquiva e do agachamento: um soco com o
        # corpo balancando/descendo um pouco nao pode ser engolido por
        # uma esquiva "grudada" nem por um agachamento falso.
        elif soco_esquerdo or soco_direito:

            if soco_esquerdo and soco_direito:
                _usar_esq = progresso_esq >= progresso_dir
            else:
                _usar_esq = soco_esquerdo

            # Os alvos na tela ja sao ESQUERDO/DIREITO do jeito que o
            # jogador ve na propria tela - sem precisar levar em conta
            # o espelhamento da camera.
            movimento = "SOCO ESQUERDO" if _usar_esq else "SOCO DIREITO"


        elif esquiva_ativa == "ESQUIVA ESQUERDA":

            movimento = "ESQUIVA ESQUERDA"


        elif esquiva_ativa == "ESQUIVA DIREITA":

            movimento = "ESQUIVA DIREITA"


        # AGACHAR (reativado): so vale se NADA mais foi reconhecido
        # neste frame (defesa alta, soco e esquiva tem prioridade),
        # entao ele nao consegue roubar a vez de nenhum outro
        # movimento. A deteccao em si (agachamento_ativo) e a mesma
        # de antes, com confirmacao de varios frames.
        elif agachamento_ativo:

            movimento = "AGACHAR"


        else:

            movimento = "NEUTRO"


        # ====================================================
        # LOG DA MAQUINA DE TESTES (aditivo, so ativo com
        # TREINO_LOG_PATH definido - nao interfere na deteccao)
        # ====================================================

        _log_tester_frame(frame_id, movimento)

        # balanca 67 (minigame secreto): so le os pontos, nao muda nada acima
        _atualizar_balanca(frame_id, pulso_esq, pulso_dir, ombro_esq, ombro_dir)


        # ====================================================
        # REGISTRAR
        # ====================================================

        if movimento != ultimo_movimento:

            registrar_movimento(
                movimento
            )

            ultimo_movimento = movimento


        # ====================================================
        # DESENHAR MARCAÇÕES
        # ====================================================

        pontos_desenho = [

            # Braço esquerdo
            (ombro_esq, (0, 0, 255)),
            (cotovelo_esq, (0, 255, 255)),
            (pulso_esq, (0, 255, 0)),

            # Braço direito
            (ombro_dir, (0, 0, 255)),
            (cotovelo_dir, (0, 255, 255)),
            (pulso_dir, (0, 255, 0)),

            # Cabeça
            (nariz, (255, 0, 255)),

            # Quadril
            (quadril_esq, (255, 255, 0)),
            (quadril_dir, (255, 255, 0)),

            # Joelhos
            (joelho_esq, (255, 128, 0)),
            (joelho_dir, (255, 128, 0)),

            # Tornozelos
            (tornozelo_esq, (0, 128, 255)),
            (tornozelo_dir, (0, 128, 255))
        ]


        for ponto, cor in pontos_desenho:

            x = int(
                ponto.x *
                largura_tela
            )


            y = int(
                ponto.y *
                altura_tela
            )


            cv2.circle(
                frame,
                (x, y),
                7,
                cor,
                -1
            )


        # ====================================================
        # LINHAS DOS BRAÇOS
        # ====================================================

        cv2.line(

            frame,

            (
                int(
                    ombro_esq.x *
                    largura_tela
                ),

                int(
                    ombro_esq.y *
                    altura_tela
                )
            ),

            (
                int(
                    cotovelo_esq.x *
                    largura_tela
                ),

                int(
                    cotovelo_esq.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    cotovelo_esq.x *
                    largura_tela
                ),

                int(
                    cotovelo_esq.y *
                    altura_tela
                )
            ),

            (
                int(
                    pulso_esq.x *
                    largura_tela
                ),

                int(
                    pulso_esq.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    ombro_dir.x *
                    largura_tela
                ),

                int(
                    ombro_dir.y *
                    altura_tela
                )
            ),

            (
                int(
                    cotovelo_dir.x *
                    largura_tela
                ),

                int(
                    cotovelo_dir.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    cotovelo_dir.x *
                    largura_tela
                ),

                int(
                    cotovelo_dir.y *
                    altura_tela
                )
            ),

            (
                int(
                    pulso_dir.x *
                    largura_tela
                ),

                int(
                    pulso_dir.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        # ====================================================
        # LINHAS DO CORPO
        # ====================================================

        cv2.line(

            frame,

            (
                int(
                    ombro_esq.x *
                    largura_tela
                ),

                int(
                    ombro_esq.y *
                    altura_tela
                )
            ),

            (
                int(
                    quadril_esq.x *
                    largura_tela
                ),

                int(
                    quadril_esq.y *
                    altura_tela
                )
            ),

            (180, 180, 180),

            2
        )


        cv2.line(

            frame,

            (
                int(
                    ombro_dir.x *
                    largura_tela
                ),

                int(
                    ombro_dir.y *
                    altura_tela
                )
            ),

            (
                int(
                    quadril_dir.x *
                    largura_tela
                ),

                int(
                    quadril_dir.y *
                    altura_tela
                )
            ),

            (180, 180, 180),

            2
        )


        # ====================================================
        # LINHAS DAS PERNAS
        # ====================================================

        cv2.line(

            frame,

            (
                int(
                    quadril_esq.x *
                    largura_tela
                ),

                int(
                    quadril_esq.y *
                    altura_tela
                )
            ),

            (
                int(
                    joelho_esq.x *
                    largura_tela
                ),

                int(
                    joelho_esq.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    joelho_esq.x *
                    largura_tela
                ),

                int(
                    joelho_esq.y *
                    altura_tela
                )
            ),

            (
                int(
                    tornozelo_esq.x *
                    largura_tela
                ),

                int(
                    tornozelo_esq.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    quadril_dir.x *
                    largura_tela
                ),

                int(
                    quadril_dir.y *
                    altura_tela
                )
            ),

            (
                int(
                    joelho_dir.x *
                    largura_tela
                ),

                int(
                    joelho_dir.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        cv2.line(

            frame,

            (
                int(
                    joelho_dir.x *
                    largura_tela
                ),

                int(
                    joelho_dir.y *
                    altura_tela
                )
            ),

            (
                int(
                    tornozelo_dir.x *
                    largura_tela
                ),

                int(
                    tornozelo_dir.y *
                    altura_tela
                )
            ),

            (255, 255, 255),

            3
        )


        # ====================================================
        # LINHA CENTRAL
        # ====================================================

        centro_x_tela = int(
            centro_x_suave *
            largura_tela
        )


        cv2.line(

            frame,

            (
                centro_x_tela,
                0
            ),

            (
                centro_x_tela,
                altura_tela
            ),

            (100, 100, 100),

            1
        )


        # ====================================================
        # LINHA DO EIXO DO CORPO (nariz -> quadril, tipo
        # nariz-umbigo) - o que a esquiva realmente mede agora.
        # Fica branca quando reta, e na cor da esquiva quando
        # inclinada o suficiente pra contar.
        # ====================================================

        if esquiva_ativa == "ESQUIVA ESQUERDA":
            _cor_eixo = (0, 255, 0)
        elif esquiva_ativa == "ESQUIVA DIREITA":
            _cor_eixo = (0, 255, 0)
        else:
            _cor_eixo = (255, 255, 255)

        cv2.line(
            frame,
            (int(nariz.x * largura_tela), int(nariz.y * altura_tela)),
            (
                int(centro_quadril_x * largura_tela),
                int(centro_quadril_y * altura_tela)
            ),
            _cor_eixo,
            3
        )


        # ====================================================
        # DISTÂNCIA
        # ====================================================

        cv2.rectangle(

            frame,

            (10, 70),

            (310, 110),

            (20, 20, 20),

            -1
        )


        cv2.putText(

            frame,

            status_camera,

            (20, 97),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.55,

            cor_camera,

            2,

            cv2.LINE_AA
        )


        # ====================================================
        # CALIBRADO
        # ====================================================

        cv2.putText(

            frame,

            "SISTEMA CALIBRADO",

            (400, 95),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.45,

            (0, 255, 0),

            2,

            cv2.LINE_AA
        )


        # ====================================================
        # DEBUG DO AGACHAMENTO
        # ====================================================

        cv2.putText(

            frame,

            f"QUADRIL: {queda_agachar_suave:.3f}",

            (10, 420),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.40,

            (180, 180, 180),

            1,

            cv2.LINE_AA
        )


        cv2.putText(

            frame,

            f"JOELHO: {flexao_joelho_suave:.1f}",

            (10, 440),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.40,

            (180, 180, 180),

            1,

            cv2.LINE_AA
        )


        cv2.putText(

            frame,

            f"ESCALA: {escala_relativa:.2f}",

            (10, 460),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.40,

            (180, 180, 180),

            1,

            cv2.LINE_AA
        )


    else:

        # ====================================================
        # SEM CORPO
        # ====================================================

        movimento = "NEUTRO"

        _log_tester_frame(frame_id, "SEM_CORPO")
        _balanca_sem_corpo(frame_id)
        historico_escala_ombros.clear()
        estado_zona_esq = novo_estado_zona()
        estado_zona_dir = novo_estado_zona()
        _ultimo_tempo_zona = None
        _soco_esq_estava_ativo = False
        _soco_dir_estava_ativo = False


        agachamento_ativo = False

        contador_agachar = 0

        contador_retorno_agachar = 0


        esquiva_ativa = None

        inicio_esquiva = 0.0

        contador_esquerda = 0

        contador_direita = 0

        contador_retorno_esquiva = 0

        historico_x.clear()
        historico_angulo_tronco.clear()
        historico_altura.clear()
        historico_escala.clear()
        historico_quadril_agachar.clear()
        historico_flexao_joelho.clear()


        cv2.rectangle(

            frame,

            (10, 70),

            (390, 115),

            (20, 20, 20),

            -1
        )


        cv2.putText(

            frame,

            "CORPO NAO DETECTADO",

            (20, 100),

            cv2.FONT_HERSHEY_SIMPLEX,

            0.65,

            (0, 0, 255),

            2,

            cv2.LINE_AA
        )


    # ========================================================
    # INTERFACE PRINCIPAL
    # ========================================================

    cv2.rectangle(

        frame,

        (10, 10),

        (560, 65),

        (20, 20, 20),

        -1
    )


    cv2.putText(

        frame,

        movimento,

        (25, 50),

        cv2.FONT_HERSHEY_SIMPLEX,

        0.9,

        (0, 255, 0),

        3,

        cv2.LINE_AA
    )


    # ========================================================
    # CONTADOR
    # ========================================================

    total_movimentos = sum(
        dados_treino.values()
    )


    cv2.putText(

        frame,

        f"Movimentos: {total_movimentos}",

        (420, 450),

        cv2.FONT_HERSHEY_SIMPLEX,

        0.45,

        (200, 200, 200),

        1,

        cv2.LINE_AA
    )


    # ========================================================
    # CÂMERA
    # ========================================================

    _mostrar_frame(frame)


    # ========================================================
    # TECLADO
    # ========================================================

    tecla = (
        cv2.waitKey(1) &
        0xFF
    )


    if tecla == ord("q"):

        break


# ============================================================
# FINALIZAR
# ============================================================

camera.release()

cv2.destroyAllWindows()

landmarker.close()


# ============================================================
# RESUMO
# ============================================================

print("")

print(
    "======================================"
)

print(
    "          RESUMO DO TREINO"
)

print(
    "======================================"
)


for movimento, quantidade in dados_treino.items():

    print(
        f"{movimento}: {quantidade}"
    )


print(
    "======================================"
)

print("")