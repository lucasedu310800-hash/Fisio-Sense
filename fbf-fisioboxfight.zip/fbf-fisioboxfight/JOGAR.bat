﻿@echo off
chcp 65001 >nul
REM ============================================================
REM JOGAR.bat - abre a camera (detector + ponte) e o jogo juntos,
REM cada um na sua propria janela (do jeito de antes - separado).
REM ============================================================

setlocal
cd /d "%~dp0"

echo Abrindo o detector e a ponte...
start "Detector" "CameraSensores\iniciar_detector.bat"
start "Ponte" "CameraSensores\iniciar_ponte.bat"

if exist "TreinoDeReflexo3D\FBF.exe" (
    echo Abrindo o jogo...
    start "" "TreinoDeReflexo3D\FBF.exe"
) else if exist "FBF.exe" (
    echo Abrindo o jogo...
    start "" "FBF.exe"
) else if exist "TreinoDeReflexo3D\TreinoDeReflexo3D.exe" (
    echo Abrindo o jogo...
    start "" "TreinoDeReflexo3D\TreinoDeReflexo3D.exe"
) else (
    echo.
    echo Ainda nao existe um jogo exportado ^(FBF.exe^).
    echo Rode EXPORTAR_JOGO.bat, nesta mesma pasta, uma vez primeiro.
    echo As janelas do Detector e da Ponte ja estao abertas, pode
    echo deixar elas do jeito que estao.
    pause
)

endlocal
